# Fix log — "Make it trustworthy" (2026-09-30)

Base: source from branch `payment_tracker` copied into the Framework root. Focus: Mobile automation on BrowserStack.
Verified: `mvn -DskipTests test-compile` passes. No scenarios were executed (no BrowserStack run).

| # | File | What changed | Why |
|---|------|--------------|-----|
| 1 | `src/test/java/.../runners/TestRunner.java` | Removed hard-coded `tags = "@Mobile and @SC_2741358"`. Data provider is now always `parallel = true` (thread count is still decided by `ParallelExecutionListener`, 1 by default). | The annotation tag overrode the command line, so every run executed one scenario only. The old `parallel=false` made `-Dparallel=true` do nothing for this runner. |
| 2 | `pom.xml` | Added default properties `cucumber.tags` (empty), `parallel=false`, `threads=1`. | Surefire forwards these to Cucumber/TestNG. Without defaults an unset value could arrive as the literal text `${cucumber.tags}` and break the tag filter. Empty tags = run all. |
| 3 | `src/main/java/.../utils/PropertiesHelpers.java` | New `getRequiredValue(key)` that throws a clear message for a missing or empty key. `getValue(key)` now honours a `-D<KEY>` override first. | Missing keys used to return null and crash later with an opaque NullPointerException. The `-D` overrides documented in `config.properties` (e.g. `-DMOBILE_EXECUTION_MODE`) were not actually applied. |
| 4 | `src/main/java/.../constants/FrameworkConstants.java` | Mandatory settings use `getRequiredValue`. BrowserStack/BS_* settings use a null-safe `optionalValue`. New `validateBrowserStackConfig()` lists every missing BrowserStack setting in one message. | Fail fast with a readable error. BrowserStack settings are checked only when a BrowserStack session starts, so web or local runs are not blocked. |
| 5 | `src/main/java/.../driver/MobileDriverManager.java` | One line added: `FrameworkConstants.validateBrowserStackConfig();` before creating a BrowserStack driver. | Wires in the check from #4. |
| 6 | `src/main/java/.../users/UserCredentialsManager.java` | `checkoutUserPair()` now waits at most 300s (override `-DUSER_POOL_TIMEOUT_SECONDS=<n>`) and throws a clear error. `checkinUserPair()` no longer blocks and ignores duplicate returns. | A run could hang forever when no pair was free. A double check-in could over-fill the pool. |
| 7 | `src/test/java/.../hooks/ApplicationHooks.java` | `@Before` only checks out a user pair for scenarios that are not `@Mobile` or `@API`. Logging uses a null-safe pair id. | Only web steps use the pair. With one pair in the pool, every mobile scenario was queued behind it, which blocked parallel BrowserStack devices. |
| 8 | `src/main/java/.../context/ScenarioContext.java` | `page` changed from `static` to an instance field. | A static page was shared by all threads, so parallel web scenarios could drive each other's browser. `ScenarioContext` is created per scenario by PicoContainer. |
| 9 | `src/test/java/.../stepdefinitions/Web/CustomerMaintenanceSteps.java` | Import fixed to `pages.Web.CustomerMaintenancePage`. | Pre-existing compile error on this branch (class lives in the `pages.Web` package). Needed to compile and verify. |

## Follow-up changes (same day, after first BrowserStack run)

| # | File | What changed | Why |
|---|------|--------------|-----|
| 10 | `src/main/java/.../driver/MobileDriverManager.java` | `getBrowserStackProxy()` returns no proxy when `-DBS_USE_PROXY=false` (default `true`, so client-site behaviour is unchanged). | The configured corporate proxy host cannot be resolved outside the client network. With the switch off, the JDK connects directly, or via the OS proxy when `-Djava.net.useSystemProxies=true` is also passed. |
| 11 | `src/main/resources/config/config.properties` | `BROWSERSTACK_APP_URL` changed from `bs://e5aa30f…` to `bs://fd7d4745…` (newest upload, 2026-09-22). | The old app ID no longer exists in the BrowserStack account, so session creation hung until the 90s timeout. Replace it again whenever a new build is uploaded; BrowserStack deletes old uploads. |

| 12 | `pom.xml` | Default `cucumber.tags` is now `@Mobile` (was empty = everything). New property `bs.use.proxy` (default `true`) passed to the tests as `BS_USE_PROXY`. `java.net.useSystemProxies=true` is always passed. New Maven profile `offsite` sets `bs.use.proxy=false`. | This framework is mostly for mobile, so a plain `mvn test` runs only mobile scenarios instead of the broken web/API ones. Working outside the client network only needs `-Poffsite` (tick it in IntelliJ's Maven panel) instead of several `-D` flags. Override tags with `-Dcucumber.tags=""` (all) or `-Dcucumber.tags="@SC_xxx"`. |

| 13 | `flexcube-features/Mobile/01.MobileLogin.feature` | Scenario names `\|SC_2741351\|…` and `Mobile\|SC_2700567\|…` changed to module `TermDeposit\|…`. The step `the user verifies the following mobile elements should be visible under "X" screen` (2 places, no step definition) changed to the existing step `the user verifies the following elements should be "visible" under "X" screen`. | The module in the scenario name selects the locator and test-data files, and the old names matched none. The old step wording was undefined, so the scenarios stopped with UndefinedStepException. |

Result after #13 (`mvn test -Poffsite`, real BrowserStack devices): login and the Deposits page now work, so the scenarios run further, but all 3 failed on test content/stability: SC_2741351 has no `USDAccountNumber` in `testdata/02.TERMDEPOSIT` test data; SC_2700567 and SC_2741358 lost the BrowserStack session while typing the PIN (`Error communicating with the remote browser`). SC_2741358 passed in two earlier runs, so this looks intermittent.

Earlier result of `mvn test -Poffsite` (3 `@Mobile` scenarios, real BrowserStack sessions): 1 passed (`TermDeposit\|SC_2741358`), 2 failed with `OR path not found: /Loginflow/Login` and `Mobile/Loginflow/Login`. Cause: the scenario names in `01.MobileLogin.feature` have an empty or unknown module (`\|SC_2741351\|...`, `Mobile\|SC_2700567\|...`). The module in the name selects the object-repository file, and only `Term` / `TermDeposit` exist. Not changed yet; needs the right module name from the feature owner.

Earlier result: `SC_2741358` (`@Mobile`) passed on a BrowserStack Android device (1 run, 0 failures, about 320s) with the proxy off.
Known minor issue seen: the failure screenshot at session close logged "Error communicating with the remote browser" (scenario still passed).

## How to run now
```
mvn test -Dcucumber.tags="@Mobile and @SC_2741358"
mvn test -Dcucumber.tags="@Mobile" -Dparallel=true -Dthreads=3 -DMOBILE_EXECUTION_MODE=browserstack
mvn test                                   # no tags = all scenarios
```
Optional: `-DUSER_POOL_TIMEOUT_SECONDS=600`.
Outside the client network add `"-DBS_USE_PROXY=false" "-Djava.net.useSystemProxies=true"` (quote each `-D` in PowerShell).

## Behaviour changes to be aware of
- Runs with no `-Dcucumber.tags` now execute all scenarios (before: one mobile scenario).
- A missing mandatory config key stops the run at start-up with the key name.
- A web scenario waits at most 300s for a user pair, then fails with an explanation.

## Not changed (still open)
Secrets in `config.properties` and `testdata/Users/*.json`, git token in `.git/config`, `setIgnoreHTTPSErrors(true)`, `Thread.sleep` calls, swallowed exceptions, commented-out code in `MobileDriverManager`, pom duplicate dependencies, `Launcher` glue package.

## Web and mobile separated (2026-10-02)

Backup before these changes: `C:\Uday\RD\Automation\Framework-backup-before-web-mobile-split-20261002-002303.zip`.

| # | File | What changed | Why |
|---|------|--------------|-----|
| 14 | `src/main/java/.../context/Platform.java` (new) | `WEB` / `MOBILE` / `API`, decided from the scenario's tags (`@Mobile`, `@API`, otherwise web). | One clear answer to "what does this scenario automate", used everywhere instead of guessing. |
| 15 | `context/ScenarioContext.java`, `hooks/ApplicationHooks.java` | `ScenarioContext.platform`, set in `@Before` from the tags, before anything else runs. | The object repository lookup needs to know the platform. |
| 16 | `constants/FrameworkConstants.java` | `OBJECT_REPO_ROOT`, `OBJECT_REPO_WEB_PATH` (`objectrepo/Web`), `OBJECT_REPO_MOBILE_PATH` (`objectrepo/Mobile`), `objectRepoPath(platform)`. `OBJECT_REPO_PATH` stays (deprecated, = mobile) for older code. | Every lookup used to read `objectrepo/Mobile`, also for web scenarios, so web locators had to live in the mobile folder and `objectrepo/Web/OR_Common.json` was never found. |
| 17 | `utils/DataHandler.java` | A scenario reads only its own platform's folder (and `target/classes/objectrepo/<Web|Mobile>`). The locator cache is per platform. The android/ios sub-node lookup is done for mobile only. The "not found" message names the platform and the folder. Outside a scenario (tools) both folders are searched. | Web never sees mobile files and the other way round; no mix-ups when web and mobile use the same module name. |
| 18 | `pom.xml` | Profiles `-Pweb` (`@Web and not @WIP`, one browser at a time) and `-Pmobile` (`@Mobile and not @WIP`). Default tags `@Mobile and not @WIP`. | Run one platform without remembering tag filters. Unfinished scenarios are kept out of runs. |
| 19 | `flexcube-features/01.CIF/**` (3 files) | `@Web` added to the feature tags. | `-Pweb` runs them. |
| 20 | `flexcube-features/Mobile/paymentTracker.feature` | `@Mobile @WIP` added. | It had no `@Mobile` tag, so the hooks started a **web browser** for this mobile feature. It also has 5 steps with no step definition yet, hence `@WIP` until they are written. |

Verified: `mvn -o test-compile` OK. Dry run `-Pmobile`: 3 scenarios, all steps bound. Dry run `-Pweb`: 4 scenarios (3 CIF + 1 Lior RMS), all steps bound.
Real run (copy of the framework): Lior-generated `RMS|SC_001` with `-Pweb -DHEADLESS=true` passed; its locators came from `objectrepo/Web`.
Lookup check: mobile scenario -> `objectrepo/Mobile` (android node), web -> `objectrepo/Web` (incl. `OR_Common.json`), mobile asking for a web module and web asking for a mobile module -> not found.

How to run:
```
mvn test -Pweb
mvn test -Pmobile
mvn test -Pweb -Dcucumber.tags="@Web and @SC_001"
```

## Waits, errors, dead code, browser Back (2026-10-02)

Backup before these changes: `C:\Uday\RD\Automation\Framework-backup-before-cleanup-20261002-003800.zip` (src, features, pom, Script).

| # | Area | What changed | Why |
|---|------|--------------|-----|
| 21 | Fixed waits (web) | `CommonSteps`: 10 s / 5 s / 1.5 s sleeps -> `waitForPageToLoad()` + loading-indicator waits (`waitUntilScreenSettled`). `CommonPage`: OBTF login 5 s, OBTFPM logout 3 s + 2 s, logout 0.5 s -> page-load waits; `click()` already waits for the element. `CustomerMaintenancePage` LOV 5 s -> page-load wait. `WebUI`: 200 ms before drop-down click removed (Playwright waits), alert check waits until the alert appears instead of always the full time, paging waits until the table content changes instead of 2 s, upload fallback pause removed (and its broken JS fixed). `WebUI.sleep()` kept but deprecated. | A fixed pause is too long on a fast day and too short on a slow one: slow and flaky runs. |
| 22 | Fixed waits (mobile) | `MobileUI.click`: 500 ms pause -> waits until the element stops moving (`waitUntilStill`). New `MobileUI.waitUntilEnabled(locator, max)`. `CommonMobilePage` T&C: 1.5 s pause -> waits until the confirm button is enabled (re-taps when the tick was lost). | Same; taps no longer land mid-animation. |
| 23 | Fixed waits (hooks/reports) | `ApplicationHooks.afterAll`: 2 s grace pause removed (the file-polling loop that follows is the real wait). | Faster end of run. Polling loops (DriverManager, ReportUtils, hooks) stay: they wait for a condition. The explicit "wait N seconds" keyword stays. |
| 24 | Swallowed errors | `waitForPageToLoad` and the loading-indicator wait now log a WARN with the reason (was: silent / misleading ERROR). `FileHelpers` throws `UncheckedIOException` with the file path (was `printStackTrace`). `FeatureAggregator` logs report failures with `LogUtils.error` (was `printStackTrace`). `ReportUtils` / `WebUI.sleep` keep the thread's interrupt flag. 86 `System.out/err.println` calls in framework code now go through `LogUtils`, so they appear in the scenario logs and reports (generator tools and `PropertiesHelpers` unchanged). Two leftover debug prints in `uploadFile` removed. | Failures and warnings are visible where people look. Verification keywords already failed correctly and were not changed. |
| 25 | Dead code | 3,856 lines of commented-out code removed from 20 files (e.g. `MobileDriverManager` 3,168 -> 950 lines, `ApplicationHooks` 1,708 -> 980). Explanation comments were kept. The API layer was 100% commented out, so these 5 files had nothing left and were deleted: `keywords/WebAPI.java`, `keywords/WebAPIPlaywright.java`, `pages/API/BaseAPIPage.java`, `pages/API/UserAPIPage.java`, `stepdefinitions/API/UserAPISteps.java`. | Readable code. To get the old code back: `git show HEAD:<path>` or the backup zips. `flexcube-features/API/UserAPI.feature` had no working steps before and still has none. |
| 26 | Browser Back | New `WebUI.navigateBack()` and step `user goes back to the previous page` (`CommonSteps`). | Recorded Back presses now run; Lior generates this step (and only adds its own copy for frameworks that lack it). |

Verified: `mvn -o test-compile` OK. Dry run `-Pmobile` 3 scenarios and `-Pweb` 4 scenarios: all steps bound.
Real run (copy of the framework, `-Pweb -DHEADLESS=true`): Lior-generated `RMS|SC_001` passed - open app, click "Forgot password?", type e-mail, go back (log: "Went back from .../forgot-password to .../login"). Custom dashboard, feature report and Cucumber HTML report generated.
Not verified: mobile on a real device (BrowserStack still blocks the IP); Flexcube web scenarios (no Flexcube system here).

| 27 | `keywords/WebUI.java` `selectOption` (custom drop-downs) | Opens the list, reads each option's VISIBLE text (icon names such as `smart_toy` left out), picks the exact match, else the only option that contains the text; otherwise fails at once with the options that were shown. | Angular Material option texts contain icon names, so the exact XPath never matched; it then waited 60 s and threw, and the "fuzzy" fallback after it was never reached. Found by a real run of a Lior-recorded RMS test. |

Real run 2026-10-02 (copy of the framework, `-Pweb -Dcucumber.tags="@RMS" -DHEADLESS=true`): Lior-recorded "Create a project" passed end to end (login, New Project, 2 text fields, 2 Material drop-downs, date-picker calendar, typed date, Create Project, user menu, Sign out) in 50 s.
Run only one application: Lior tags each generated feature with its module, e.g. `mvn test -Pweb -Dcucumber.tags="@RMS"`. Plain `-Pweb` runs ALL web features, including the Flexcube CIF ones.

| 28 | `flexcube-features/01.CIF/**` (3 files) | `@Web` tag removed again (reverts #19). | `-Pweb` runs only web applications recorded with Lior (e.g. RMS). The CIF (Flexcube) features are unchanged and still run as web tests when asked for: `mvn test -Dcucumber.tags="@CIF"`. |
| 29 | `utils/TestDataTokens.java` (new), `utils/DataHandler.java` | Test data values may contain `${unique}` (new on every run), `${today}`, `${today:+5}`, `${today:+5:dd-MM-yyyy}`, `${random:6}`; resolved when a value is read. | Tests that CREATE something can run again: the RMS app rejects a second project with the same name ("already exists"), which made every re-run of "Create a project" fail. Example: `"ProjectName": "Test1 ${unique}"`. |

Real run 2026-10-02 02:29 (copy of the framework, Lior-recorded RMS "Create a project", `-Pweb -Dcucumber.tags="@RMS" -DHEADLESS=true`): passed; every screen change waited for (Login, Dashboard, New, project page, Login after Sign out), project name "Lior Project ${unique}".
| 30 | `utils/OneTimeCodes.java` (new), `utils/TestDataTokens.java` | One-time passwords (OTP) in the test data. A fixed test OTP is written as it is (`"123456"`). An OTP that changes on every run: `${fromScreen:Screen.Element}` = the code the application shows in that element ("Your OTP is 482913" gives 482913; `:3` = only the 3rd character, for one-digit OTP boxes); `${ask:question}` = a person types it in a small always-on-top window while the test runs (asked once per scenario, gives up after 5 minutes; fails at once with a clear message when there is no screen); `${totp:SECRETKEY}` = the 6-digit authenticator-app code (RFC 6238; `${totp:KEY:8}` for 8 digits; waits for the next code when the current one has under 3 s left). New Lior step `user remembers the text of the following elements under "X" screen` (LiorWebSteps / LiorMobileSteps) reads the code early - for a code shown on one screen and typed on the next, or in a message that disappears; `${fromScreen:...}` then uses the remembered code. An OTP that cannot be worked out raises `OneTimeCodes.CodeException`, which the "... if they are in the test data" steps never treat as "field not in the test data". | Sites that show a new OTP on every run made recorded tests fail on the second run. OTPs sent by SMS / e-mail: ask the application team for a fixed test OTP, or use `${ask:...}` for runs someone watches. |

Real run 2026-10-02 09:21 (copy of the framework, `-Pweb -Dcucumber.tags="@OtpDemo" -DHEADLESS=true`) against a local test site that shows NEW codes on every page load (6-digit OTP field, then 4 one-digit boxes; the site goes on only with the right code): Lior-recorded test passed. Same run with a wrong fixed OTP failed as expected ("The SecondCheck screen did not appear"). Checked separately: RFC 6238 test vectors, code extraction from messages, `${ask}` window, no-screen error.

| 31 | `keywords/WebUI.java` `selectOption` (standard `<select>`) | The option is picked in the page in one go: the visible text (spaces and line breaks ignored), else the option value, else the first option whose text contains the value; options that load a moment later are waited for (up to the timeout). The error now lists the options shown. Backup: `extractor-backup/20261002-112227-before-selectOption-fix/`. | Lior leaves the balance out of a recorded choice (`911000000001 — SAVINGS` for `911000000001 — SAVINGS (₹249,880)`), so it is a partial text. Playwright's select by label waited the full timeout for it, then by value again, before the partial match was tried: the Tristha Bank Fund Transfer looked stuck on "From account" (2026-10-02 11:17). |

Real run 2026-10-02 11:24 (copy of the framework, Lior test bank with Angular-style option text and options loaded late, `-Pweb -Dcucumber.tags="@BankDemo" -DHEADLESS=true`): passed in 27 s (was over 2.5 min); From account chosen about 3 s after the step before; balance 249880.00 -> 249870.00 checked.
| 32 | `driver/DriverManager.java` (`initDriver(String browser)`), `hooks/ApplicationHooks.java` (`browserTag`) | A web scenario tagged `@Chrome`, `@Edge`, `@Firefox` or `@Webkit`/`@Safari` runs in that browser; untagged scenarios use `BROWSER` from config.properties as before. `-DBROWSER=...` on the command line still wins for the whole run. Backup: `extractor-backup/20261002-112634-before-browser-tag/`. | Lior tags each recorded web test with the browser it was recorded in. The Tristha Bank test was recorded in Chrome but ran in Edge (`BROWSER=edge`). |

Real run 2026-10-02 11:29 (copy of the framework, config `BROWSER=edge`, Lior pack tagged `@Web @Chrome @SC_001`): "Web Driver started: Chrome 155.0.8059.27", scenario passed.
| 33 | `keywords/WebUI.java` `uploadFile`, new `findElementInFrame(selector, mustBeVisible)` | Uploads find the file box when it is in the page, also when it is hidden (the first match); other steps still wait for a visible element. Backup: `extractor-backup/20261002-120436-before-hidden-upload-fix/`. | File boxes are usually hidden behind a "Click to upload or drag & drop" area (RMS Create Project). The upload waited the full timeout for the box to become visible and failed. |

Real run 2026-10-02 12:05 (copy of the framework, Lior test bank with a drop zone and two hidden file boxes): "Successfully uploaded file to element: Input|//input[@type="file" and @accept='.xlsx,.xls']", scenario passed.

## Clean-up: shared state, swallowed errors, dependencies, secrets, git (2026-10-02 evening)

Backup of the old pom: `extractor-backup/20261002-cleanup/pom.xml`.

| # | Area | What changed | Why |
|---|------|--------------|-----|
| 34 | `driver/DriverManager`, `driver/MobileDriverManager` | `browserVersion` and `deviceDetails` were plain `static` fields (Lombok `@Getter`), shared by all threads. Now per thread (`ThreadLocal`); `getBrowserVersion()` falls back to the last browser started, for the end-of-run reports. | Parallel mobile runs (3 devices) could log another scenario's device; parallel web runs another browser. |
| 35 | `keywords/WebUI.verifyTableCell` | Fails the step when the Signature ID is on no page (it returned a "FAILED" text that the caller ignored, so the step always passed). Errors while reading the table are no longer swallowed; highlight / screenshot failures are logged as warnings. | A verification that cannot fail hides real defects. |
| 36 | `DashboardGenerator`, `ReportUtils`, `TestRunner`, `RerunTestRunner` | `printStackTrace()` / `System.err` -> `LogUtils.error(message, exception)`. | Report failures appear in the log files, with the stack trace. |
| 37 | 4 files | Last 7 commented-out code lines removed. | |
| 38 | `pom.xml` | Removed unused libraries: REST Assured (+ a commented-out second copy), BrowserStack Java SDK (the framework talks to the BrowserStack hub through Appium; no SDK agent is used), Owner, PDFBox. Appium client and AssertJ now use their version properties (`appium.version` 10.1.0, `assertj.version` 3.26.3 - the versions that were really used; the properties said 10.1.1 / 3.26.0). Unused properties removed. | Hard-coded versions that differed from the declared properties; unused jars on the classpath. |
| 39 | `utils/PropertiesHelpers`, `config/config.properties`, `.gitignore` | BrowserStack username / access key moved out of `config.properties` (now empty placeholders) into `src/main/resources/config/secrets.local.properties` (git-ignored, read last, never written to). A setting can also come from an environment variable of the same name; `-D<KEY>` still wins over everything. `extractor-backup/` git-ignored. | Keys must not be in git. On another PC / a build server: create the secrets file or set the environment variables `BROWSERSTACK_USERNAME`, `BROWSERSTACK_ACCESS_KEY`. |

Not changed: `Thread.sleep` that remain are polling intervals of condition waits and the explicit "wait N seconds" keyword. User passwords in `testdata/Users/*.json` and the git token in `.git/config` (rotate it) are still open.
Verified: `mvn -o test-compile` OK; Cucumber dry run `-Pmobile` and `-Pweb`: all steps bound; credentials load from the secrets file.

## Lior "Swipe and tap" up / down (2026-10-02 night, NeoCorp EULA)

| # | Area | What changed | Why |
|---|------|--------------|-----|
| 40 | `CommonStepsMobile`, `CommonMobilePage.swipeVerticallyAndClick`, `MobileUI.swipeVertically` + `flick` | New steps `user swipes up|down N time(s) and clicks the ... button under ... screen` and `user swipes up|down and clicks ...` (no count = quick long swipes, 72%->15% of the screen in 0.3 s so the content flings, until the screenshot stops changing, at most 25 - a PDF viewer scrolls without changing the page source; the first version used the slow 70%->30% scrollDown and needed 8+ round trips for the 6-page NeoCorp EULA). Scroll failures keep the original exception as cause. | "user swipes and clicks" only swipes sideways; on the EULA screen the PDF was never scrolled, so the tick box and "Agree & continue" stayed disabled (SC_002 / SC_003 failed). |
| 41 | `driver/MobileDriverManager.createBrowserStackClientConfig` | BrowserStack HTTP read timeout 90 s -> 180 s, configurable (`BS_READ_TIMEOUT_SECONDS`, -D or config.properties). | Two NeoCorp runs: the sessions that were busy exactly 90 s after they were created failed at the same second with `UnreachableBrowserException` / `connection closed locally` (the HTTP client's own response timer), on requests that had just started; the session that was idle at that moment passed. Looks like the 90 s timer of the session-creation request firing on the reused connection. Confirm with a run longer than 90 s. |
| 42 | `pom.xml` (defaults + `mobile` profile) | Mobile runs are sequential by default (`parallel=false`, `threads=1`); parallel on request with `-Dparallel=true -Dthreads=3`. | CorpLogin SC_001-003 all log in as the same user and register a device; run on three phones at once, the bank's server answered one of them with "Error! We're unable to complete your request" (SC_003, 2026-10-02 23:08). |
| 43 | `MobileUI.swipeVertically` (counted swipes) | `user swipes up N time(s) and clicks ...` now makes N quick swipes (`flick`, the same gesture as the uncounted step) instead of N slow `scrollDown` drags. | A person's swipe flings the content on; the slow 70%->30% drag does not. NeoCorp SC_001 (recorded `up:5`): 5 drags stopped on page 4 of the 6-page EULA, the app ignored the tick box taps and "Agree & continue" stayed disabled (`element was not enabled`, 2026-10-02 23:40). With flicks SC_001 passed (23:45). |
