# TCoE Automation Framework — working context

Repo: Azure DevOps `MashreqCorpTech/TCOE/_git/Native_Mobile_Apps` (local clone at this folder). Maven, Java 17, groupId `com.mashreq.automation`, artifact `TCoE`.

## Branch layout (important)
- `master` holds the framework source (merged PR 110504 "IFT-Changes to Master"); this working copy commits on `master`.
- Real framework code lives on branch `payment_tracker` (latest, local), `origin/OAT` ("Framework code" commit) and `origin/IFT` (only in the pack file).
- `git` is not on PATH on this machine. To inspect other branches without git, loose objects were extracted with Python (scratchpad `extract.py`); `IFT` is packed and not extracted.
- `.git/config` contains a plaintext Azure DevOps bearer token in `http.extraHeader`. Never print or copy it; rotate it.

## What the framework is
Keyword-driven BDD framework: Cucumber 7 + TestNG + PicoContainer, with
- Web UI via Playwright Java (Flexcube/OBDX/OBPM/OBTF/OBTFPM style banking UIs)
- Mobile via Appium (Android/iOS, local or BrowserStack App Automate)
- API via Playwright APIRequest (RestAssured version is commented out)
- Custom reporting: Cucumber JSON -> FreeMarker dashboard + per-feature HTML, plus Allure, Extent, cucumber-reporting.

## Layout (branch payment_tracker)
- `flexcube-features/` Gherkin (01.CIF, API, Mobile)
- `src/main/.../keywords` WebUI, MobileUI (action libs); `pages/` page objects; `driver/` DriverManager (ThreadLocal Playwright), MobileDriverManager
- `constants/` generated locator-key constants (CIF, COMMON, MOBILE, TERM...), `Script/LocatorConstantGenerator.java` + `utils/ORGenerator` generate them from `objectrepo/*.json`
- `utils/DataHandler` test data JSON by module/scenarioId; `testdata/` (+ `excel_files/`); `users/` maker/checker pool (BlockingQueue)
- `src/test/.../hooks/ApplicationHooks` (Before/After/AfterStep/AfterAll), `stepdefinitions/`, `runners/` (TestRunner, RerunTestRunner, MainRunner), `listeners/`, `utils/FeatureAggregator` + `FeatureStepCollector` (history/master.json for dashboard)
- Config: `src/main/resources/config/config.properties` + `urls-<ENV>.properties`; `-DENV -DREGION -Dparallel -Dthreads -Dcucumber.tags` overrides
- Run: `mvn test` (suite `src/test/resources/suites/testng.xml`, needs aspectj javaagent); failed scenarios -> `target/rerun.txt`

## Known issues (updated 2026-10-02 evening - see CHANGELOG-FIXES.md #1-39)
Fixed: hard-coded runner tag, static ScenarioContext.page and other static per-run state, commented-out code (API layer deleted),
fixed sleeps (remaining Thread.sleep are poll intervals), swallowed exceptions in framework code, duplicate / unused pom
dependencies, BrowserStack key moved to git-ignored `src/main/resources/config/secrets.local.properties`.
Still open: user passwords in testdata/Users/*.json, git token in .git/config (rotate it), setIgnoreHTTPSErrors(true).
Rule: never hand-edit Lior-recorded features / test data; fix Lior or the framework.

## Web / mobile separation (2026-10-02)
`Platform` (WEB/MOBILE/API) comes from scenario tags and is stored in `ScenarioContext`; `DataHandler` reads only
`objectrepo/Web` or `objectrepo/Mobile` for that platform. Run with `-Pweb` / `-Pmobile`. `@WIP` scenarios are excluded.
Lior (the recorder in ..\Web_Element\element-extractor) writes into the same layout and adds `stepdefinitions/Web/LiorWebSteps.java`
(+ `Mobile/LiorMobileSteps.java` when needed) and `url.<REGION>.<APP>` lines in `urls-<ENV>.properties`. Details: CHANGELOG-FIXES.md #14-20.
`git` IS on PATH now (C:\Program Files\Git). The working tree has many uncommitted changes on `master`; nothing was committed.
