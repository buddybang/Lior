# Made by Lior on 2026-10-02 09:36.
# The values typed or checked by these steps are in the test data file
# testdata/<NN>.TRISTHABANK/US_TestData_TRISTHABANK.json (look for the scenario id).
# A test recorded in several versions (other data) is one Scenario Outline: steps ending in "if ... in the test data"
# run only for the versions whose test data has that field.
# Run only this module:  mvn test -Pweb -Dcucumber.tags="@TristhaBank"
@TristhaBank
Feature: TristhaBank - recorded web flow

  @Web @SC_001
  Scenario: TristhaBank|SC_001|Tristha_Bank
    Given user opens the "TRISTHABANK" application
    Then user sees the following elements under "Login" screen
      |TristhaBank|
    And user enters the following field details under "Login" screen
      |Username|
      |Password|
    When user click "SignInButton" under "Login" screen
    And user remembers the text of the following elements under "Login" screen
      |OtpMessage|
    And user enters the following field details under "Login" screen
      |OneTimePassword|
    When user click "SignIn" under "Login" screen
    Then user sees the following elements under "Dashboard" screen
      |WelcomeRaviKumar|
    When user click "FundTransfer" under "Dashboard" screen
    Then user sees the following elements under "Transfers" screen
      |FundTransferHeading|
    And user select the following field details under "Transfers" screen
      |Payee|
    And user enters the following field details under "Transfers" screen
      |Amount|
      |Remarks|
    When user click "SendOtp" under "Transfers" screen
    And user remembers the text of the following elements under "Transfers" screen
      |OtpMessage|
    And user enters the following field details under "Transfers" screen
      |OneTimePassword|
