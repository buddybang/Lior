package com.mashreq.automation.tcoe.constants;

/**
 * AUTO-GENERATED. Do not edit manually.
 * Source: OR_TristhaBank.json
 * Format: SCREEN_FIELD = "MODULE/SCREEN/FIELD"
 */
public final class TRISTHABANK {

    private TRISTHABANK() {}

    // ===== Login =====
    public static final String LOGIN_TRISTHABANK = "TRISTHABANK/Login/TristhaBank";
    public static final String LOGIN_SIGNINHEADING = "TRISTHABANK/Login/SignInHeading";
    public static final String LOGIN_USERNAMELABEL = "TRISTHABANK/Login/UsernameLabel";
    public static final String LOGIN_USERNAME = "TRISTHABANK/Login/Username";
    public static final String LOGIN_PASSWORDLABEL = "TRISTHABANK/Login/PasswordLabel";
    public static final String LOGIN_PASSWORD = "TRISTHABANK/Login/Password";
    public static final String LOGIN_SIGNIN = "TRISTHABANK/Login/SignIn";
    public static final String LOGIN_FORGOTPASSWORD = "TRISTHABANK/Login/ForgotPassword";
    public static final String LOGIN_ONETIMEPASSWORDLABEL = "TRISTHABANK/Login/OneTimePasswordLabel";
    public static final String LOGIN_ONETIMEPASSWORD = "TRISTHABANK/Login/OneTimePassword";
    public static final String LOGIN_RESENDOTP = "TRISTHABANK/Login/ResendOtp";
    public static final String LOGIN_BACKTOLOGIN = "TRISTHABANK/Login/BackToLogin";
    public static final String LOGIN_OTPMESSAGE = "TRISTHABANK/Login/OtpMessage";
    public static final String LOGIN_SIGNINBUTTON = "TRISTHABANK/Login/SignInButton";

    // ===== Dashboard =====
    public static final String DASHBOARD_MENU = "TRISTHABANK/Dashboard/Menu";
    public static final String DASHBOARD_LOGOUT = "TRISTHABANK/Dashboard/Logout";
    public static final String DASHBOARD_DASHBOARD = "TRISTHABANK/Dashboard/Dashboard";
    public static final String DASHBOARD_ESTATEMENTS = "TRISTHABANK/Dashboard/EStatements";
    public static final String DASHBOARD_FUNDTRANSFER = "TRISTHABANK/Dashboard/FundTransfer";
    public static final String DASHBOARD_BENEFICIARIES = "TRISTHABANK/Dashboard/Beneficiaries";
    public static final String DASHBOARD_APPROVALS = "TRISTHABANK/Dashboard/Approvals";
    public static final String DASHBOARD_UPI = "TRISTHABANK/Dashboard/Upi";
    public static final String DASHBOARD_BILLSRECHARGES = "TRISTHABANK/Dashboard/BillsRecharges";
    public static final String DASHBOARD_CARDS = "TRISTHABANK/Dashboard/Cards";
    public static final String DASHBOARD_INVESTMENTS = "TRISTHABANK/Dashboard/Investments";
    public static final String DASHBOARD_TAXPAYMENTS = "TRISTHABANK/Dashboard/TaxPayments";
    public static final String DASHBOARD_SERVICEREQUESTS = "TRISTHABANK/Dashboard/ServiceRequests";
    public static final String DASHBOARD_SECURITY = "TRISTHABANK/Dashboard/Security";
    public static final String DASHBOARD_WELCOMERAVIKUMAR = "TRISTHABANK/Dashboard/WelcomeRaviKumar";
    public static final String DASHBOARD_SAVINGSACCOUNT = "TRISTHABANK/Dashboard/SavingsAccount";
    public static final String DASHBOARD_STATEMENT = "TRISTHABANK/Dashboard/Statement";
    public static final String DASHBOARD_PPFACCOUNT = "TRISTHABANK/Dashboard/PpfAccount";
    public static final String DASHBOARD_STATEMENTLINK = "TRISTHABANK/Dashboard/StatementLink";
    public static final String DASHBOARD_SUKANYASAMRIDDHISSY = "TRISTHABANK/Dashboard/SukanyaSamriddhiSsy";
    public static final String DASHBOARD_STATEMENTLINK2 = "TRISTHABANK/Dashboard/StatementLink2";
    public static final String DASHBOARD_SAVINGSACCOUNTHEADING = "TRISTHABANK/Dashboard/SavingsAccountHeading";
    public static final String DASHBOARD_STATEMENTLINK3 = "TRISTHABANK/Dashboard/StatementLink3";
    public static final String DASHBOARD_FIXEDDEPOSIT = "TRISTHABANK/Dashboard/FixedDeposit";
    public static final String DASHBOARD_MANAGE = "TRISTHABANK/Dashboard/Manage";
    public static final String DASHBOARD_RECENTACTIVITY = "TRISTHABANK/Dashboard/RecentActivity";
    public static final String DASHBOARD_TABLE = "TRISTHABANK/Dashboard/Table";

    // ===== Transfers =====
    public static final String TRANSFERS_MENU = "TRISTHABANK/Transfers/Menu";
    public static final String TRANSFERS_LOGOUT = "TRISTHABANK/Transfers/Logout";
    public static final String TRANSFERS_DASHBOARD = "TRISTHABANK/Transfers/Dashboard";
    public static final String TRANSFERS_ESTATEMENTS = "TRISTHABANK/Transfers/EStatements";
    public static final String TRANSFERS_FUNDTRANSFER = "TRISTHABANK/Transfers/FundTransfer";
    public static final String TRANSFERS_BENEFICIARIES = "TRISTHABANK/Transfers/Beneficiaries";
    public static final String TRANSFERS_APPROVALS = "TRISTHABANK/Transfers/Approvals";
    public static final String TRANSFERS_UPI = "TRISTHABANK/Transfers/Upi";
    public static final String TRANSFERS_BILLSRECHARGES = "TRISTHABANK/Transfers/BillsRecharges";
    public static final String TRANSFERS_CARDS = "TRISTHABANK/Transfers/Cards";
    public static final String TRANSFERS_INVESTMENTS = "TRISTHABANK/Transfers/Investments";
    public static final String TRANSFERS_TAXPAYMENTS = "TRISTHABANK/Transfers/TaxPayments";
    public static final String TRANSFERS_SERVICEREQUESTS = "TRISTHABANK/Transfers/ServiceRequests";
    public static final String TRANSFERS_SECURITY = "TRISTHABANK/Transfers/Security";
    public static final String TRANSFERS_FUNDTRANSFERHEADING = "TRISTHABANK/Transfers/FundTransferHeading";
    public static final String TRANSFERS_NEWTRANSFER = "TRISTHABANK/Transfers/NewTransfer";
    public static final String TRANSFERS_FROMACCOUNTLABEL = "TRISTHABANK/Transfers/FromAccountLabel";
    public static final String TRANSFERS_FROMACCOUNT = "TRISTHABANK/Transfers/FromAccount";
    public static final String TRANSFERS_PAYEELABEL = "TRISTHABANK/Transfers/PayeeLabel";
    public static final String TRANSFERS_PAYEE = "TRISTHABANK/Transfers/Payee";
    public static final String TRANSFERS_CHANNEL = "TRISTHABANK/Transfers/Channel";
    public static final String TRANSFERS_NEFT = "TRISTHABANK/Transfers/Neft";
    public static final String TRANSFERS_RTGS = "TRISTHABANK/Transfers/Rtgs";
    public static final String TRANSFERS_IMPS = "TRISTHABANK/Transfers/Imps";
    public static final String TRANSFERS_AMOUNTLABEL = "TRISTHABANK/Transfers/AmountLabel";
    public static final String TRANSFERS_AMOUNT = "TRISTHABANK/Transfers/Amount";
    public static final String TRANSFERS_REMARKSLABEL = "TRISTHABANK/Transfers/RemarksLabel";
    public static final String TRANSFERS_REMARKS = "TRISTHABANK/Transfers/Remarks";
    public static final String TRANSFERS_SCHEDULEFORLATEROPTIONALLABEL = "TRISTHABANK/Transfers/ScheduleForLaterOptionalLabel";
    public static final String TRANSFERS_SCHEDULEFORLATEROPTIONAL = "TRISTHABANK/Transfers/ScheduleForLaterOptional";
    public static final String TRANSFERS_ONETIMEPASSWORDLABEL = "TRISTHABANK/Transfers/OneTimePasswordLabel";
    public static final String TRANSFERS_ONETIMEPASSWORD = "TRISTHABANK/Transfers/OneTimePassword";
    public static final String TRANSFERS_SENDOTP = "TRISTHABANK/Transfers/SendOtp";
    public static final String TRANSFERS_TRANSFER = "TRISTHABANK/Transfers/Transfer";
    public static final String TRANSFERS_TRANSFERHISTORY = "TRISTHABANK/Transfers/TransferHistory";
    public static final String TRANSFERS_TABLE = "TRISTHABANK/Transfers/Table";
    public static final String TRANSFERS_OTPMESSAGE = "TRISTHABANK/Transfers/OtpMessage";

}
