package com.mashreq.automation.tcoe.constants;

/**
 * AUTO-GENERATED. Do not edit manually.
 * Source: OR_FundTransfer.json
 * Format: SCREEN_FIELD = "MODULE/SCREEN/FIELD"
 */
public final class FUNDTRANSFER {

    private FUNDTRANSFER() {}

    // ===== Login =====
    public static final String LOGIN_TRISTHABANK = "FUNDTRANSFER/Login/TristhaBank";
    public static final String LOGIN_SIGNINHEADING = "FUNDTRANSFER/Login/SignInHeading";
    public static final String LOGIN_USERNAMELABEL = "FUNDTRANSFER/Login/UsernameLabel";
    public static final String LOGIN_USERNAME = "FUNDTRANSFER/Login/Username";
    public static final String LOGIN_PASSWORDLABEL = "FUNDTRANSFER/Login/PasswordLabel";
    public static final String LOGIN_PASSWORD = "FUNDTRANSFER/Login/Password";
    public static final String LOGIN_SIGNIN = "FUNDTRANSFER/Login/SignIn";
    public static final String LOGIN_FORGOTPASSWORD = "FUNDTRANSFER/Login/ForgotPassword";
    public static final String LOGIN_ENTEROTP = "FUNDTRANSFER/Login/EnterOtp";
    public static final String LOGIN_ONETIMEPASSWORDLABEL = "FUNDTRANSFER/Login/OneTimePasswordLabel";
    public static final String LOGIN_ONETIMEPASSWORD = "FUNDTRANSFER/Login/OneTimePassword";
    public static final String LOGIN_VERIFYSIGNIN = "FUNDTRANSFER/Login/VerifySignIn";
    public static final String LOGIN_RESENDOTP = "FUNDTRANSFER/Login/ResendOtp";
    public static final String LOGIN_BACKTOLOGIN = "FUNDTRANSFER/Login/BackToLogin";
    public static final String LOGIN_OTPMESSAGE = "FUNDTRANSFER/Login/OtpMessage";

    // ===== Dashboard =====
    public static final String DASHBOARD_MENU = "FUNDTRANSFER/Dashboard/Menu";
    public static final String DASHBOARD_LOGOUT = "FUNDTRANSFER/Dashboard/Logout";
    public static final String DASHBOARD_DASHBOARD = "FUNDTRANSFER/Dashboard/Dashboard";
    public static final String DASHBOARD_ESTATEMENTS = "FUNDTRANSFER/Dashboard/EStatements";
    public static final String DASHBOARD_FUNDTRANSFER = "FUNDTRANSFER/Dashboard/FundTransfer";
    public static final String DASHBOARD_BENEFICIARIES = "FUNDTRANSFER/Dashboard/Beneficiaries";
    public static final String DASHBOARD_APPROVALS = "FUNDTRANSFER/Dashboard/Approvals";
    public static final String DASHBOARD_UPI = "FUNDTRANSFER/Dashboard/Upi";
    public static final String DASHBOARD_BILLSRECHARGES = "FUNDTRANSFER/Dashboard/BillsRecharges";
    public static final String DASHBOARD_CARDS = "FUNDTRANSFER/Dashboard/Cards";
    public static final String DASHBOARD_INVESTMENTS = "FUNDTRANSFER/Dashboard/Investments";
    public static final String DASHBOARD_TAXPAYMENTS = "FUNDTRANSFER/Dashboard/TaxPayments";
    public static final String DASHBOARD_SERVICEREQUESTS = "FUNDTRANSFER/Dashboard/ServiceRequests";
    public static final String DASHBOARD_SECURITY = "FUNDTRANSFER/Dashboard/Security";
    public static final String DASHBOARD_WELCOMERAVIKUMAR = "FUNDTRANSFER/Dashboard/WelcomeRaviKumar";
    public static final String DASHBOARD_SAVINGSACCOUNT = "FUNDTRANSFER/Dashboard/SavingsAccount";
    public static final String DASHBOARD_STATEMENT = "FUNDTRANSFER/Dashboard/Statement";
    public static final String DASHBOARD_PPFACCOUNT = "FUNDTRANSFER/Dashboard/PpfAccount";
    public static final String DASHBOARD_STATEMENTLINK = "FUNDTRANSFER/Dashboard/StatementLink";
    public static final String DASHBOARD_SUKANYASAMRIDDHISSY = "FUNDTRANSFER/Dashboard/SukanyaSamriddhiSsy";
    public static final String DASHBOARD_STATEMENTLINK2 = "FUNDTRANSFER/Dashboard/StatementLink2";
    public static final String DASHBOARD_SAVINGSACCOUNTHEADING = "FUNDTRANSFER/Dashboard/SavingsAccountHeading";
    public static final String DASHBOARD_STATEMENTLINK3 = "FUNDTRANSFER/Dashboard/StatementLink3";
    public static final String DASHBOARD_FIXEDDEPOSIT = "FUNDTRANSFER/Dashboard/FixedDeposit";
    public static final String DASHBOARD_MANAGE = "FUNDTRANSFER/Dashboard/Manage";
    public static final String DASHBOARD_RECENTACTIVITY = "FUNDTRANSFER/Dashboard/RecentActivity";
    public static final String DASHBOARD_TABLE = "FUNDTRANSFER/Dashboard/Table";
    public static final String DASHBOARD_SAVINGSACCOUNTBALANCE = "FUNDTRANSFER/Dashboard/SavingsAccountBalance";

    // ===== Transfers =====
    public static final String TRANSFERS_MENU = "FUNDTRANSFER/Transfers/Menu";
    public static final String TRANSFERS_LOGOUT = "FUNDTRANSFER/Transfers/Logout";
    public static final String TRANSFERS_DASHBOARD = "FUNDTRANSFER/Transfers/Dashboard";
    public static final String TRANSFERS_ESTATEMENTS = "FUNDTRANSFER/Transfers/EStatements";
    public static final String TRANSFERS_FUNDTRANSFER = "FUNDTRANSFER/Transfers/FundTransfer";
    public static final String TRANSFERS_BENEFICIARIES = "FUNDTRANSFER/Transfers/Beneficiaries";
    public static final String TRANSFERS_APPROVALS = "FUNDTRANSFER/Transfers/Approvals";
    public static final String TRANSFERS_UPI = "FUNDTRANSFER/Transfers/Upi";
    public static final String TRANSFERS_BILLSRECHARGES = "FUNDTRANSFER/Transfers/BillsRecharges";
    public static final String TRANSFERS_CARDS = "FUNDTRANSFER/Transfers/Cards";
    public static final String TRANSFERS_INVESTMENTS = "FUNDTRANSFER/Transfers/Investments";
    public static final String TRANSFERS_TAXPAYMENTS = "FUNDTRANSFER/Transfers/TaxPayments";
    public static final String TRANSFERS_SERVICEREQUESTS = "FUNDTRANSFER/Transfers/ServiceRequests";
    public static final String TRANSFERS_SECURITY = "FUNDTRANSFER/Transfers/Security";
    public static final String TRANSFERS_FUNDTRANSFERHEADING = "FUNDTRANSFER/Transfers/FundTransferHeading";
    public static final String TRANSFERS_NEWTRANSFER = "FUNDTRANSFER/Transfers/NewTransfer";
    public static final String TRANSFERS_FROMACCOUNTLABEL = "FUNDTRANSFER/Transfers/FromAccountLabel";
    public static final String TRANSFERS_FROMACCOUNT = "FUNDTRANSFER/Transfers/FromAccount";
    public static final String TRANSFERS_PAYEELABEL = "FUNDTRANSFER/Transfers/PayeeLabel";
    public static final String TRANSFERS_PAYEE = "FUNDTRANSFER/Transfers/Payee";
    public static final String TRANSFERS_CHANNEL = "FUNDTRANSFER/Transfers/Channel";
    public static final String TRANSFERS_NEFT = "FUNDTRANSFER/Transfers/Neft";
    public static final String TRANSFERS_RTGS = "FUNDTRANSFER/Transfers/Rtgs";
    public static final String TRANSFERS_IMPS = "FUNDTRANSFER/Transfers/Imps";
    public static final String TRANSFERS_AMOUNTLABEL = "FUNDTRANSFER/Transfers/AmountLabel";
    public static final String TRANSFERS_AMOUNT = "FUNDTRANSFER/Transfers/Amount";
    public static final String TRANSFERS_REMARKSLABEL = "FUNDTRANSFER/Transfers/RemarksLabel";
    public static final String TRANSFERS_REMARKS = "FUNDTRANSFER/Transfers/Remarks";
    public static final String TRANSFERS_SCHEDULEFORLATEROPTIONALLABEL = "FUNDTRANSFER/Transfers/ScheduleForLaterOptionalLabel";
    public static final String TRANSFERS_SCHEDULEFORLATEROPTIONAL = "FUNDTRANSFER/Transfers/ScheduleForLaterOptional";
    public static final String TRANSFERS_ONETIMEPASSWORDLABEL = "FUNDTRANSFER/Transfers/OneTimePasswordLabel";
    public static final String TRANSFERS_ONETIMEPASSWORD = "FUNDTRANSFER/Transfers/OneTimePassword";
    public static final String TRANSFERS_SENDOTP = "FUNDTRANSFER/Transfers/SendOtp";
    public static final String TRANSFERS_TRANSFER = "FUNDTRANSFER/Transfers/Transfer";
    public static final String TRANSFERS_TRANSFERHISTORY = "FUNDTRANSFER/Transfers/TransferHistory";
    public static final String TRANSFERS_TABLE = "FUNDTRANSFER/Transfers/Table";
    public static final String TRANSFERS_OTPMESSAGE = "FUNDTRANSFER/Transfers/OtpMessage";
    public static final String TRANSFERS_TRANSFERSONETIMEPASSWORD = "FUNDTRANSFER/Transfers/TransfersOneTimePassword";

}
