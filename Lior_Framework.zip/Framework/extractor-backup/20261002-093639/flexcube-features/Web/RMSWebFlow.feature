# Made by Lior on 2026-10-02 01:50.
# The values typed or checked by these steps are in the test data file
# testdata/<NN>.RMS/US_TestData_RMS.json (look for the scenario id).
# A test recorded in several versions (other data) is one Scenario Outline: steps ending in "if ... in the test data"
# run only for the versions whose test data has that field.
# Run only this module:  mvn test -Pweb -Dcucumber.tags="@RMS"
@RMS
Feature: RMS - recorded web flow

  @Web @SC_001
  Scenario: RMS|SC_001|Create_Project
    Given user opens the "RMS" application
    And user enters the following field details under "Login" screen
      |EmployeeIdOrEmail|
      |Password|
    When user click "SignIn" under "Login" screen
    When user click "NewProject" under "Dashboard" screen
    And user enters the following field details under "New" screen
      |ClientName|
      |ProjectName|
    And user select the following field details under "New" screen
      |ServiceType|
      |StatusActiveConfirmedEngagement|
    And user enters the following field details under "New" screen
      |WinProbability|
    When user click "NumberOfWorkingDays" under "New" screen
    And user enters the following field details under "New" screen
      |NumberOfWorkingDays|
    When user click "OpenCalendar" under "New" screen
    When user click "N26" under "New" screen
    When user click "CreateProject" under "New" screen
    When user click "Back" under "Projects" screen
    When user click "AadminUserAdmin" under "Projects2" screen
    When user click "SignOut" under "Projects2" screen
