package com.mashreq.automation.tcoe.constants;

/**
 * AUTO-GENERATED. Do not edit manually.
 * Source: OR_CorpLogin.json
 * Format: SCREEN_FIELD = "MODULE/SCREEN/FIELD"
 */
public final class CORPLOGIN {

    private CORPLOGIN() {}

    // ===== WelcomeScreenSlide1 =====
    public static final String WELCOMESCREENSLIDE1_APPWELCOMEACCESSIBILITYLANGUAGEBUTTON = "CORPLOGIN/WelcomeScreenSlide1/AppWelcomeAccessibilityLanguageButton";
    public static final String WELCOMESCREENSLIDE1_ANDROIDWIDGETTEXTVIEW = "CORPLOGIN/WelcomeScreenSlide1/AndroidWidgetTextView";
    public static final String WELCOMESCREENSLIDE1_APPWELCOMEACCESSIBILITYICONBUTTON = "CORPLOGIN/WelcomeScreenSlide1/AppWelcomeAccessibilityIconButton";
    public static final String WELCOMESCREENSLIDE1_WELCOMESCREENSCAROUSEL = "CORPLOGIN/WelcomeScreenSlide1/WelcomeScreensCarousel";
    public static final String WELCOMESCREENSLIDE1_SLIDE1OF4 = "CORPLOGIN/WelcomeScreenSlide1/Slide1Of4";
    public static final String WELCOMESCREENSLIDE1_WELCOMESCREENSLIDE1 = "CORPLOGIN/WelcomeScreenSlide1/WelcomeScreenSlide1";
    public static final String WELCOMESCREENSLIDE1_CORPORATEBANKINGREIMAGINED = "CORPLOGIN/WelcomeScreenSlide1/CorporateBankingReimagined";
    public static final String WELCOMESCREENSLIDE1_BUILTFORSPEEDSECURITYANDTHE = "CORPLOGIN/WelcomeScreenSlide1/BuiltForSpeedSecurityAndThe";
    public static final String WELCOMESCREENSLIDE1_PAGE1OF4 = "CORPLOGIN/WelcomeScreenSlide1/Page1Of4";
    public static final String WELCOMESCREENSLIDE1_PAGE1 = "CORPLOGIN/WelcomeScreenSlide1/Page1";
    public static final String WELCOMESCREENSLIDE1_PAGE2 = "CORPLOGIN/WelcomeScreenSlide1/Page2";
    public static final String WELCOMESCREENSLIDE1_PAGE3 = "CORPLOGIN/WelcomeScreenSlide1/Page3";
    public static final String WELCOMESCREENSLIDE1_PAGE4 = "CORPLOGIN/WelcomeScreenSlide1/Page4";
    public static final String WELCOMESCREENSLIDE1_APPWELCOMEACCESSIBILITYLOGINBUTTON = "CORPLOGIN/WelcomeScreenSlide1/AppWelcomeAccessibilityLoginButton";
    public static final String WELCOMESCREENSLIDE1_LOGIN = "CORPLOGIN/WelcomeScreenSlide1/Login";
    public static final String WELCOMESCREENSLIDE1_VIEWGROUP = "CORPLOGIN/WelcomeScreenSlide1/ViewGroup";
    public static final String WELCOMESCREENSLIDE1_SLIDE3OF4 = "CORPLOGIN/WelcomeScreenSlide1/Slide3Of4";
    public static final String WELCOMESCREENSLIDE1_WELCOMESCREENSLIDE3 = "CORPLOGIN/WelcomeScreenSlide1/WelcomeScreenSlide3";
    public static final String WELCOMESCREENSLIDE1_APPROVEPAYMENTSINSTANTLY = "CORPLOGIN/WelcomeScreenSlide1/ApprovePaymentsInstantly";
    public static final String WELCOMESCREENSLIDE1_REVIEWANDAUTHORIZETRANSACTIONSWITHSECURE = "CORPLOGIN/WelcomeScreenSlide1/ReviewAndAuthorizeTransactionsWithSecure";

    // ===== LoginToMashreqNeoCorp =====
    public static final String LOGINTOMASHREQNEOCORP_SCROLLVIEW = "CORPLOGIN/LoginToMashreqNeoCorp/ScrollView";
    public static final String LOGINTOMASHREQNEOCORP_APPCOMMONBACK = "CORPLOGIN/LoginToMashreqNeoCorp/AppCommonBack";
    public static final String LOGINTOMASHREQNEOCORP_APPCOMMONHELP = "CORPLOGIN/LoginToMashreqNeoCorp/AppCommonHelp";
    public static final String LOGINTOMASHREQNEOCORP_ANDROIDWIDGETBUTTON = "CORPLOGIN/LoginToMashreqNeoCorp/AndroidWidgetButton";
    public static final String LOGINTOMASHREQNEOCORP_ANDROIDWIDGETTEXTVIEW = "CORPLOGIN/LoginToMashreqNeoCorp/AndroidWidgetTextView";
    public static final String LOGINTOMASHREQNEOCORP_LOGINTOMASHREQNEOCORP = "CORPLOGIN/LoginToMashreqNeoCorp/LoginToMashreqNeoCorp";
    public static final String LOGINTOMASHREQNEOCORP_CHOOSETHELOGINOPTIONTOCONTINUE = "CORPLOGIN/LoginToMashreqNeoCorp/ChooseTheLoginOptionToContinue";
    public static final String LOGINTOMASHREQNEOCORP_LOGINWITHPASSWORD = "CORPLOGIN/LoginToMashreqNeoCorp/LoginWithPassword";
    public static final String LOGINTOMASHREQNEOCORP_LOGINWITHPASSWORDLABEL = "CORPLOGIN/LoginToMashreqNeoCorp/LoginWithPasswordLabel";
    public static final String LOGINTOMASHREQNEOCORP_VIEWGROUP = "CORPLOGIN/LoginToMashreqNeoCorp/ViewGroup";
    public static final String LOGINTOMASHREQNEOCORP_VERIFYUSERNAMEINPUTTEXTINPUT = "CORPLOGIN/LoginToMashreqNeoCorp/VerifyUsernameInputTextInput";
    public static final String LOGINTOMASHREQNEOCORP_USERID = "CORPLOGIN/LoginToMashreqNeoCorp/UserId";
    public static final String LOGINTOMASHREQNEOCORP_LOGIN = "CORPLOGIN/LoginToMashreqNeoCorp/Login";
    public static final String LOGINTOMASHREQNEOCORP_LOGINLABEL = "CORPLOGIN/LoginToMashreqNeoCorp/LoginLabel";
    public static final String LOGINTOMASHREQNEOCORP_SIGNINWITHYOURCREDENTIALSTO = "CORPLOGIN/LoginToMashreqNeoCorp/SignInWithYourCredentialsTo";
    public static final String LOGINTOMASHREQNEOCORP_VERIFYUSERNAMEINPUTRIGHTICONBUTTON = "CORPLOGIN/LoginToMashreqNeoCorp/VerifyUsernameInputRightIconButton";
    public static final String LOGINTOMASHREQNEOCORP_N00 = "CORPLOGIN/LoginToMashreqNeoCorp/N00";
    public static final String LOGINTOMASHREQNEOCORP_LOGINWITHPINBIOMETRICS = "CORPLOGIN/LoginToMashreqNeoCorp/LoginWithPinBiometrics";
    public static final String LOGINTOMASHREQNEOCORP_LOGINWITHPINBIOMETRICSLABEL = "CORPLOGIN/LoginToMashreqNeoCorp/LoginWithPinBiometricsLabel";

    // ===== LoginToMashreqNeoCorp2 =====
    public static final String LOGINTOMASHREQNEOCORP2_SCROLLVIEW = "CORPLOGIN/LoginToMashreqNeoCorp2/ScrollView";
    public static final String LOGINTOMASHREQNEOCORP2_APPCOMMONBACK = "CORPLOGIN/LoginToMashreqNeoCorp2/AppCommonBack";
    public static final String LOGINTOMASHREQNEOCORP2_APPCOMMONHELP = "CORPLOGIN/LoginToMashreqNeoCorp2/AppCommonHelp";
    public static final String LOGINTOMASHREQNEOCORP2_ANDROIDWIDGETBUTTON = "CORPLOGIN/LoginToMashreqNeoCorp2/AndroidWidgetButton";
    public static final String LOGINTOMASHREQNEOCORP2_ANDROIDWIDGETTEXTVIEW = "CORPLOGIN/LoginToMashreqNeoCorp2/AndroidWidgetTextView";
    public static final String LOGINTOMASHREQNEOCORP2_LOGINTOMASHREQNEOCORP = "CORPLOGIN/LoginToMashreqNeoCorp2/LoginToMashreqNeoCorp";
    public static final String LOGINTOMASHREQNEOCORP2_SIGNINWITHYOURCREDENTIALSTO = "CORPLOGIN/LoginToMashreqNeoCorp2/SignInWithYourCredentialsTo";
    public static final String LOGINTOMASHREQNEOCORP2_MAKERFT2 = "CORPLOGIN/LoginToMashreqNeoCorp2/Makerft2";
    public static final String LOGINTOMASHREQNEOCORP2_USERID = "CORPLOGIN/LoginToMashreqNeoCorp2/UserId";
    public static final String LOGINTOMASHREQNEOCORP2_PASSWORDINPUTTEXTINPUT = "CORPLOGIN/LoginToMashreqNeoCorp2/PasswordInputTextInput";
    public static final String LOGINTOMASHREQNEOCORP2_PASSWORD = "CORPLOGIN/LoginToMashreqNeoCorp2/Password";
    public static final String LOGINTOMASHREQNEOCORP2_PASSWORDINPUTPASSWORDTOGGLE = "CORPLOGIN/LoginToMashreqNeoCorp2/PasswordInputPasswordToggle";
    public static final String LOGINTOMASHREQNEOCORP2_FORGOTPASSWORDBUTTON = "CORPLOGIN/LoginToMashreqNeoCorp2/ForgotPasswordButton";
    public static final String LOGINTOMASHREQNEOCORP2_FORGOTPASSWORD = "CORPLOGIN/LoginToMashreqNeoCorp2/ForgotPassword";
    public static final String LOGINTOMASHREQNEOCORP2_LOGIN = "CORPLOGIN/LoginToMashreqNeoCorp2/Login";
    public static final String LOGINTOMASHREQNEOCORP2_LOGINLABEL = "CORPLOGIN/LoginToMashreqNeoCorp2/LoginLabel";
    public static final String LOGINTOMASHREQNEOCORP2_VIEWGROUP = "CORPLOGIN/LoginToMashreqNeoCorp2/ViewGroup";
    public static final String LOGINTOMASHREQNEOCORP2_N00 = "CORPLOGIN/LoginToMashreqNeoCorp2/N00";

    // ===== LoginToMashreqNeoCorp3 =====
    public static final String LOGINTOMASHREQNEOCORP3_SCROLLVIEW = "CORPLOGIN/LoginToMashreqNeoCorp3/ScrollView";
    public static final String LOGINTOMASHREQNEOCORP3_LOGINTOMASHREQNEOCORP = "CORPLOGIN/LoginToMashreqNeoCorp3/LoginToMashreqNeoCorp";
    public static final String LOGINTOMASHREQNEOCORP3_SIGNINWITHYOURCREDENTIALSTO = "CORPLOGIN/LoginToMashreqNeoCorp3/SignInWithYourCredentialsTo";
    public static final String LOGINTOMASHREQNEOCORP3_MAKERFT2 = "CORPLOGIN/LoginToMashreqNeoCorp3/Makerft2";
    public static final String LOGINTOMASHREQNEOCORP3_USERID = "CORPLOGIN/LoginToMashreqNeoCorp3/UserId";
    public static final String LOGINTOMASHREQNEOCORP3_PASSWORDINPUTTEXTINPUT = "CORPLOGIN/LoginToMashreqNeoCorp3/PasswordInputTextInput";
    public static final String LOGINTOMASHREQNEOCORP3_PASSWORD = "CORPLOGIN/LoginToMashreqNeoCorp3/Password";
    public static final String LOGINTOMASHREQNEOCORP3_PASSWORDINPUTPASSWORDTOGGLE = "CORPLOGIN/LoginToMashreqNeoCorp3/PasswordInputPasswordToggle";

    // ===== SetUpYourLoginPin =====
    public static final String SETUPYOURLOGINPIN_SCROLLVIEW = "CORPLOGIN/SetUpYourLoginPin/ScrollView";
    public static final String SETUPYOURLOGINPIN_BACK = "CORPLOGIN/SetUpYourLoginPin/Back";
    public static final String SETUPYOURLOGINPIN_SETUPYOURLOGINPIN = "CORPLOGIN/SetUpYourLoginPin/SetUpYourLoginPin";
    public static final String SETUPYOURLOGINPIN_SETUPA6DIGITPINLABEL = "CORPLOGIN/SetUpYourLoginPin/SetUpA6DigitPinLabel";
    public static final String SETUPYOURLOGINPIN_PININPUTSECTIONWITH6OF = "CORPLOGIN/SetUpYourLoginPin/PinInputSectionWith6Of";
    public static final String SETUPYOURLOGINPIN_SETUPA6DIGITPIN = "CORPLOGIN/SetUpYourLoginPin/SetUpA6DigitPin";
    public static final String SETUPYOURLOGINPIN_MPINSETUPSECTIONPRESSABLE = "CORPLOGIN/SetUpYourLoginPin/MpinSetupSectionPressable";
    public static final String SETUPYOURLOGINPIN_PININPUTWITH6OF6 = "CORPLOGIN/SetUpYourLoginPin/PinInputWith6Of6";
    public static final String SETUPYOURLOGINPIN_PINDIGIT1OF6 = "CORPLOGIN/SetUpYourLoginPin/PinDigit1Of6";
    public static final String SETUPYOURLOGINPIN_N2 = "CORPLOGIN/SetUpYourLoginPin/N2";
    public static final String SETUPYOURLOGINPIN_PINDIGIT2OF6 = "CORPLOGIN/SetUpYourLoginPin/PinDigit2Of6";
    public static final String SETUPYOURLOGINPIN_N4 = "CORPLOGIN/SetUpYourLoginPin/N4";
    public static final String SETUPYOURLOGINPIN_PINDIGIT3OF6 = "CORPLOGIN/SetUpYourLoginPin/PinDigit3Of6";
    public static final String SETUPYOURLOGINPIN_N7 = "CORPLOGIN/SetUpYourLoginPin/N7";
    public static final String SETUPYOURLOGINPIN_PINDIGIT4OF6 = "CORPLOGIN/SetUpYourLoginPin/PinDigit4Of6";
    public static final String SETUPYOURLOGINPIN_N9 = "CORPLOGIN/SetUpYourLoginPin/N9";
    public static final String SETUPYOURLOGINPIN_PINDIGIT5OF6 = "CORPLOGIN/SetUpYourLoginPin/PinDigit5Of6";
    public static final String SETUPYOURLOGINPIN_N9LABEL = "CORPLOGIN/SetUpYourLoginPin/N9Label";
    public static final String SETUPYOURLOGINPIN_PINDIGIT6OF6 = "CORPLOGIN/SetUpYourLoginPin/PinDigit6Of6";
    public static final String SETUPYOURLOGINPIN_N6 = "CORPLOGIN/SetUpYourLoginPin/N6";
    public static final String SETUPYOURLOGINPIN_PINGUIDELINESAVOIDREPEATEDORSEQUENTIAL = "CORPLOGIN/SetUpYourLoginPin/PinGuidelinesAvoidRepeatedOrSequential";
    public static final String SETUPYOURLOGINPIN_PINGUIDELINES = "CORPLOGIN/SetUpYourLoginPin/PinGuidelines";
    public static final String SETUPYOURLOGINPIN_AVOIDREPEATEDORSEQUENTIALNUMBERSEG = "CORPLOGIN/SetUpYourLoginPin/AvoidRepeatedOrSequentialNumbersEg";
    public static final String SETUPYOURLOGINPIN_CONTINUE = "CORPLOGIN/SetUpYourLoginPin/Continue";
    public static final String SETUPYOURLOGINPIN_CONTINUELABEL = "CORPLOGIN/SetUpYourLoginPin/ContinueLabel";
    public static final String SETUPYOURLOGINPIN_VIEWGROUP = "CORPLOGIN/SetUpYourLoginPin/ViewGroup";

    // ===== ConfirmYourLoginPin =====
    public static final String CONFIRMYOURLOGINPIN_SCROLLVIEW = "CORPLOGIN/ConfirmYourLoginPin/ScrollView";
    public static final String CONFIRMYOURLOGINPIN_BACK = "CORPLOGIN/ConfirmYourLoginPin/Back";
    public static final String CONFIRMYOURLOGINPIN_CONFIRMYOURLOGINPIN = "CORPLOGIN/ConfirmYourLoginPin/ConfirmYourLoginPin";
    public static final String CONFIRMYOURLOGINPIN_CONFIRMYOUR6DIGITPINLABEL = "CORPLOGIN/ConfirmYourLoginPin/ConfirmYour6DigitPinLabel";
    public static final String CONFIRMYOURLOGINPIN_PININPUTSECTIONWITH0OF = "CORPLOGIN/ConfirmYourLoginPin/PinInputSectionWith0Of";
    public static final String CONFIRMYOURLOGINPIN_CONFIRMYOUR6DIGITPIN = "CORPLOGIN/ConfirmYourLoginPin/ConfirmYour6DigitPin";
    public static final String CONFIRMYOURLOGINPIN_MPINCONFIRMSECTIONPRESSABLE = "CORPLOGIN/ConfirmYourLoginPin/MpinConfirmSectionPressable";
    public static final String CONFIRMYOURLOGINPIN_PININPUTWITH0OF6 = "CORPLOGIN/ConfirmYourLoginPin/PinInputWith0Of6";
    public static final String CONFIRMYOURLOGINPIN_PINDIGIT1OF6 = "CORPLOGIN/ConfirmYourLoginPin/PinDigit1Of6";
    public static final String CONFIRMYOURLOGINPIN_PINDIGIT2OF6 = "CORPLOGIN/ConfirmYourLoginPin/PinDigit2Of6";
    public static final String CONFIRMYOURLOGINPIN_PINDIGIT3OF6 = "CORPLOGIN/ConfirmYourLoginPin/PinDigit3Of6";
    public static final String CONFIRMYOURLOGINPIN_PINDIGIT4OF6 = "CORPLOGIN/ConfirmYourLoginPin/PinDigit4Of6";
    public static final String CONFIRMYOURLOGINPIN_PINDIGIT5OF6 = "CORPLOGIN/ConfirmYourLoginPin/PinDigit5Of6";
    public static final String CONFIRMYOURLOGINPIN_PINDIGIT6OF6 = "CORPLOGIN/ConfirmYourLoginPin/PinDigit6Of6";
    public static final String CONFIRMYOURLOGINPIN_PINGUIDELINESAVOIDREPEATEDORSEQUENTIAL = "CORPLOGIN/ConfirmYourLoginPin/PinGuidelinesAvoidRepeatedOrSequential";
    public static final String CONFIRMYOURLOGINPIN_PINGUIDELINES = "CORPLOGIN/ConfirmYourLoginPin/PinGuidelines";
    public static final String CONFIRMYOURLOGINPIN_AVOIDREPEATEDORSEQUENTIALNUMBERSEG = "CORPLOGIN/ConfirmYourLoginPin/AvoidRepeatedOrSequentialNumbersEg";

    // ===== ConfirmYourLoginPin2 =====
    public static final String CONFIRMYOURLOGINPIN2_SCROLLVIEW = "CORPLOGIN/ConfirmYourLoginPin2/ScrollView";
    public static final String CONFIRMYOURLOGINPIN2_BACK = "CORPLOGIN/ConfirmYourLoginPin2/Back";
    public static final String CONFIRMYOURLOGINPIN2_CONFIRMYOURLOGINPIN = "CORPLOGIN/ConfirmYourLoginPin2/ConfirmYourLoginPin";
    public static final String CONFIRMYOURLOGINPIN2_CONFIRMYOUR6DIGITPINLABEL = "CORPLOGIN/ConfirmYourLoginPin2/ConfirmYour6DigitPinLabel";
    public static final String CONFIRMYOURLOGINPIN2_PININPUTSECTIONWITH6OF = "CORPLOGIN/ConfirmYourLoginPin2/PinInputSectionWith6Of";
    public static final String CONFIRMYOURLOGINPIN2_CONFIRMYOUR6DIGITPIN = "CORPLOGIN/ConfirmYourLoginPin2/ConfirmYour6DigitPin";
    public static final String CONFIRMYOURLOGINPIN2_MPINCONFIRMSECTIONPRESSABLE = "CORPLOGIN/ConfirmYourLoginPin2/MpinConfirmSectionPressable";
    public static final String CONFIRMYOURLOGINPIN2_PININPUTWITH6OF6 = "CORPLOGIN/ConfirmYourLoginPin2/PinInputWith6Of6";
    public static final String CONFIRMYOURLOGINPIN2_PINDIGIT1OF6 = "CORPLOGIN/ConfirmYourLoginPin2/PinDigit1Of6";
    public static final String CONFIRMYOURLOGINPIN2_N2 = "CORPLOGIN/ConfirmYourLoginPin2/N2";
    public static final String CONFIRMYOURLOGINPIN2_PINDIGIT2OF6 = "CORPLOGIN/ConfirmYourLoginPin2/PinDigit2Of6";
    public static final String CONFIRMYOURLOGINPIN2_N4 = "CORPLOGIN/ConfirmYourLoginPin2/N4";
    public static final String CONFIRMYOURLOGINPIN2_PINDIGIT3OF6 = "CORPLOGIN/ConfirmYourLoginPin2/PinDigit3Of6";
    public static final String CONFIRMYOURLOGINPIN2_N7 = "CORPLOGIN/ConfirmYourLoginPin2/N7";
    public static final String CONFIRMYOURLOGINPIN2_PINDIGIT4OF6 = "CORPLOGIN/ConfirmYourLoginPin2/PinDigit4Of6";
    public static final String CONFIRMYOURLOGINPIN2_N9 = "CORPLOGIN/ConfirmYourLoginPin2/N9";
    public static final String CONFIRMYOURLOGINPIN2_PINDIGIT5OF6 = "CORPLOGIN/ConfirmYourLoginPin2/PinDigit5Of6";
    public static final String CONFIRMYOURLOGINPIN2_N9LABEL = "CORPLOGIN/ConfirmYourLoginPin2/N9Label";
    public static final String CONFIRMYOURLOGINPIN2_PINDIGIT6OF6 = "CORPLOGIN/ConfirmYourLoginPin2/PinDigit6Of6";
    public static final String CONFIRMYOURLOGINPIN2_N6 = "CORPLOGIN/ConfirmYourLoginPin2/N6";
    public static final String CONFIRMYOURLOGINPIN2_PINGUIDELINESAVOIDREPEATEDORSEQUENTIAL = "CORPLOGIN/ConfirmYourLoginPin2/PinGuidelinesAvoidRepeatedOrSequential";
    public static final String CONFIRMYOURLOGINPIN2_PINGUIDELINES = "CORPLOGIN/ConfirmYourLoginPin2/PinGuidelines";
    public static final String CONFIRMYOURLOGINPIN2_AVOIDREPEATEDORSEQUENTIALNUMBERSEG = "CORPLOGIN/ConfirmYourLoginPin2/AvoidRepeatedOrSequentialNumbersEg";
    public static final String CONFIRMYOURLOGINPIN2_CONTINUE = "CORPLOGIN/ConfirmYourLoginPin2/Continue";
    public static final String CONFIRMYOURLOGINPIN2_CONTINUELABEL = "CORPLOGIN/ConfirmYourLoginPin2/ContinueLabel";
    public static final String CONFIRMYOURLOGINPIN2_VIEWGROUP = "CORPLOGIN/ConfirmYourLoginPin2/ViewGroup";

    // ===== SetUpBiometrics =====
    public static final String SETUPBIOMETRICS_SETUPBIOMETRICS = "CORPLOGIN/SetUpBiometrics/SetUpBiometrics";
    public static final String SETUPBIOMETRICS_ENABLEBIOMETRICSFORFASTERANDSECURE = "CORPLOGIN/SetUpBiometrics/EnableBiometricsForFasterAndSecure";
    public static final String SETUPBIOMETRICS_CONTINUE = "CORPLOGIN/SetUpBiometrics/Continue";
    public static final String SETUPBIOMETRICS_CONTINUELABEL = "CORPLOGIN/SetUpBiometrics/ContinueLabel";
    public static final String SETUPBIOMETRICS_SETUPBIOMETRICSLATER = "CORPLOGIN/SetUpBiometrics/SetUpBiometricsLater";
    public static final String SETUPBIOMETRICS_SETUPBIOMETRICSLATERLABEL = "CORPLOGIN/SetUpBiometrics/SetUpBiometricsLaterLabel";
    public static final String SETUPBIOMETRICS_VIEWGROUP = "CORPLOGIN/SetUpBiometrics/ViewGroup";

    // ===== YourDeviceIsSetUp =====
    public static final String YOURDEVICEISSETUP_SUCCESSSCREEN = "CORPLOGIN/YourDeviceIsSetUp/SuccessScreen";
    public static final String YOURDEVICEISSETUP_SUCCESSICON = "CORPLOGIN/YourDeviceIsSetUp/SuccessIcon";
    public static final String YOURDEVICEISSETUP_YOURDEVICEISSETUP = "CORPLOGIN/YourDeviceIsSetUp/YourDeviceIsSetUp";
    public static final String YOURDEVICEISSETUP_YOURPINANDBIOMETRICSHAVEBEEN = "CORPLOGIN/YourDeviceIsSetUp/YourPinAndBiometricsHaveBeen";
    public static final String YOURDEVICEISSETUP_LOGIN = "CORPLOGIN/YourDeviceIsSetUp/Login";
    public static final String YOURDEVICEISSETUP_LOGINLABEL = "CORPLOGIN/YourDeviceIsSetUp/LoginLabel";
    public static final String YOURDEVICEISSETUP_VIEWGROUP = "CORPLOGIN/YourDeviceIsSetUp/ViewGroup";

    // ===== EndUserLicenseAgreement =====
    public static final String ENDUSERLICENSEAGREEMENT_HEADERENDUSERLICENSEAGREEMENT = "CORPLOGIN/EndUserLicenseAgreement/HeaderEndUserLicenseAgreement";
    public static final String ENDUSERLICENSEAGREEMENT_ENDUSERLICENSEAGREEMENT = "CORPLOGIN/EndUserLicenseAgreement/EndUserLicenseAgreement";
    public static final String ENDUSERLICENSEAGREEMENT_PDFDOCUMENTVIEWER = "CORPLOGIN/EndUserLicenseAgreement/PdfDocumentViewer";
    public static final String ENDUSERLICENSEAGREEMENT_TERMSANDCONDITIONSFOOTERWITHAGREEMENT = "CORPLOGIN/EndUserLicenseAgreement/TermsAndConditionsFooterWithAgreement";
    public static final String ENDUSERLICENSEAGREEMENT_IAGREETOTHETERMSCONDITIONS = "CORPLOGIN/EndUserLicenseAgreement/IAgreeToTheTermsConditions";
    public static final String ENDUSERLICENSEAGREEMENT_IAGREETOTHETERMSCONDITIONSLABEL = "CORPLOGIN/EndUserLicenseAgreement/IAgreeToTheTermsConditionsLabel";
    public static final String ENDUSERLICENSEAGREEMENT_AGREECONTINUE = "CORPLOGIN/EndUserLicenseAgreement/AgreeContinue";
    public static final String ENDUSERLICENSEAGREEMENT_AGREECONTINUELABEL = "CORPLOGIN/EndUserLicenseAgreement/AgreeContinueLabel";
    public static final String ENDUSERLICENSEAGREEMENT_VIEWGROUP = "CORPLOGIN/EndUserLicenseAgreement/ViewGroup";

    // ===== Tada =====
    public static final String TADA_HOME = "CORPLOGIN/Tada/Home";
    public static final String TADA_HOMELABEL = "CORPLOGIN/Tada/HomeLabel";
    public static final String TADA_ACCOUNTS = "CORPLOGIN/Tada/Accounts";
    public static final String TADA_ACCOUNTSLABEL = "CORPLOGIN/Tada/AccountsLabel";
    public static final String TADA_TADA = "CORPLOGIN/Tada/Tada";
    public static final String TADA_TADALABEL = "CORPLOGIN/Tada/TadaLabel";
    public static final String TADA_PAYTRANSFER = "CORPLOGIN/Tada/PayTransfer";
    public static final String TADA_PAYTRANSFERLABEL = "CORPLOGIN/Tada/PayTransferLabel";
    public static final String TADA_MORE = "CORPLOGIN/Tada/More";
    public static final String TADA_MORELABEL = "CORPLOGIN/Tada/MoreLabel";
    public static final String TADA_VIEWGROUP = "CORPLOGIN/Tada/ViewGroup";

    // ===== HelloMakerft2 =====
    public static final String HELLOMAKERFT2_USERNAME = "CORPLOGIN/HelloMakerft2/UserName";
    public static final String HELLOMAKERFT2_ANDROIDWIDGETTEXTVIEW = "CORPLOGIN/HelloMakerft2/AndroidWidgetTextView";
    public static final String HELLOMAKERFT2_COUNTRYSELECTOR = "CORPLOGIN/HelloMakerft2/CountrySelector";
    public static final String HELLOMAKERFT2_CUSTOMERSUPPORT = "CORPLOGIN/HelloMakerft2/CustomerSupport";
    public static final String HELLOMAKERFT2_NOTIFICATION = "CORPLOGIN/HelloMakerft2/Notification";
    public static final String HELLOMAKERFT2_HELLOMAKERFT2 = "CORPLOGIN/HelloMakerft2/HelloMakerft2";
    public static final String HELLOMAKERFT2_SEGMENTEDTABAPPROVALS = "CORPLOGIN/HelloMakerft2/SegmentedTabApprovals";
    public static final String HELLOMAKERFT2_APPROVALS = "CORPLOGIN/HelloMakerft2/Approvals";
    public static final String HELLOMAKERFT2_SEGMENTEDTABRELEASE = "CORPLOGIN/HelloMakerft2/SegmentedTabRelease";
    public static final String HELLOMAKERFT2_RELEASE = "CORPLOGIN/HelloMakerft2/Release";
    public static final String HELLOMAKERFT2_SEGMENTEDTABACCOUNTS = "CORPLOGIN/HelloMakerft2/SegmentedTabAccounts";
    public static final String HELLOMAKERFT2_ACCOUNTSLABEL = "CORPLOGIN/HelloMakerft2/AccountsLabel";
    public static final String HELLOMAKERFT2_SEGMENTEDTABTRADEFINANCE = "CORPLOGIN/HelloMakerft2/SegmentedTabTradeFinance";
    public static final String HELLOMAKERFT2_TRADEFINANCE = "CORPLOGIN/HelloMakerft2/TradeFinance";
    public static final String HELLOMAKERFT2_PENDINGAPPROVALS0 = "CORPLOGIN/HelloMakerft2/PendingApprovals0";
    public static final String HELLOMAKERFT2_PENDINGAPPROVALS = "CORPLOGIN/HelloMakerft2/PendingApprovals";
    public static final String HELLOMAKERFT2_N0 = "CORPLOGIN/HelloMakerft2/N0";
    public static final String HELLOMAKERFT2_MYAPPROVALS = "CORPLOGIN/HelloMakerft2/MyApprovals";
    public static final String HELLOMAKERFT2_NOAPPROVALREQUESTSAVAILABLETOREVIEW = "CORPLOGIN/HelloMakerft2/NoApprovalRequestsAvailableToReview";
    public static final String HELLOMAKERFT2_SERVICEITEMPAYMENTTRACKER = "CORPLOGIN/HelloMakerft2/ServiceItemPaymentTracker";
    public static final String HELLOMAKERFT2_PAYMENTTRACKER = "CORPLOGIN/HelloMakerft2/PaymentTracker";
    public static final String HELLOMAKERFT2_SERVICEITEMTRADETRACKER = "CORPLOGIN/HelloMakerft2/ServiceItemTradeTracker";
    public static final String HELLOMAKERFT2_TRADETRACKER = "CORPLOGIN/HelloMakerft2/TradeTracker";
    public static final String HELLOMAKERFT2_SERVICEITEMCOLLECTIONTRACKER = "CORPLOGIN/HelloMakerft2/ServiceItemCollectionTracker";
    public static final String HELLOMAKERFT2_COLLECTIONTRACKER = "CORPLOGIN/HelloMakerft2/CollectionTracker";
    public static final String HELLOMAKERFT2_SERVICEITEMLIQUIDITYMONITOR = "CORPLOGIN/HelloMakerft2/ServiceItemLiquidityMonitor";
    public static final String HELLOMAKERFT2_LIQUIDITYMONITOR = "CORPLOGIN/HelloMakerft2/LiquidityMonitor";
    public static final String HELLOMAKERFT2_QUICKACTIONSSECTION = "CORPLOGIN/HelloMakerft2/QuickActionsSection";
    public static final String HELLOMAKERFT2_QUICKACTIONMAKEPAYMENT = "CORPLOGIN/HelloMakerft2/QuickActionMakePayment";
    public static final String HELLOMAKERFT2_MAKEPAYMENT = "CORPLOGIN/HelloMakerft2/MakePayment";
    public static final String HELLOMAKERFT2_QUICKACTIONREQUESTTRADELOAN = "CORPLOGIN/HelloMakerft2/QuickActionRequestTradeLoan";
    public static final String HELLOMAKERFT2_REQUESTTRADELOAN = "CORPLOGIN/HelloMakerft2/RequestTradeLoan";
    public static final String HELLOMAKERFT2_QUICKACTIONPAYBILLS = "CORPLOGIN/HelloMakerft2/QuickActionPayBills";
    public static final String HELLOMAKERFT2_PAYBILLS = "CORPLOGIN/HelloMakerft2/PayBills";
    public static final String HELLOMAKERFT2_HOME = "CORPLOGIN/HelloMakerft2/Home";
    public static final String HELLOMAKERFT2_HOMELABEL = "CORPLOGIN/HelloMakerft2/HomeLabel";
    public static final String HELLOMAKERFT2_ACCOUNTS = "CORPLOGIN/HelloMakerft2/Accounts";
    public static final String HELLOMAKERFT2_ACCOUNTSLABEL2 = "CORPLOGIN/HelloMakerft2/AccountsLabel2";
    public static final String HELLOMAKERFT2_TADA = "CORPLOGIN/HelloMakerft2/Tada";
    public static final String HELLOMAKERFT2_TADALABEL = "CORPLOGIN/HelloMakerft2/TadaLabel";
    public static final String HELLOMAKERFT2_PAYTRANSFER = "CORPLOGIN/HelloMakerft2/PayTransfer";
    public static final String HELLOMAKERFT2_PAYTRANSFERLABEL = "CORPLOGIN/HelloMakerft2/PayTransferLabel";
    public static final String HELLOMAKERFT2_MORE = "CORPLOGIN/HelloMakerft2/More";
    public static final String HELLOMAKERFT2_MORELABEL = "CORPLOGIN/HelloMakerft2/MoreLabel";
    public static final String HELLOMAKERFT2_VIEWGROUP = "CORPLOGIN/HelloMakerft2/ViewGroup";

    // ===== MashreqAccounts =====
    public static final String MASHREQACCOUNTS_MASHREQACCOUNTS = "CORPLOGIN/MashreqAccounts/MashreqAccounts";
    public static final String MASHREQACCOUNTS_CLOSEPAYMENTSELECTION = "CORPLOGIN/MashreqAccounts/ClosePaymentSelection";
    public static final String MASHREQACCOUNTS_TOTALACCOUNTS = "CORPLOGIN/MashreqAccounts/TotalAccounts";
    public static final String MASHREQACCOUNTS_N3 = "CORPLOGIN/MashreqAccounts/N3";
    public static final String MASHREQACCOUNTS_ALLCURRENCIES = "CORPLOGIN/MashreqAccounts/AllCurrencies";
    public static final String MASHREQACCOUNTS_ALLCURRENCIESLABEL = "CORPLOGIN/MashreqAccounts/AllCurrenciesLabel";
    public static final String MASHREQACCOUNTS_EXPANDORCOLLAPSECURRENCYLIST = "CORPLOGIN/MashreqAccounts/ExpandOrCollapseCurrencyList";
    public static final String MASHREQACCOUNTS_SHOWALL = "CORPLOGIN/MashreqAccounts/ShowAll";
    public static final String MASHREQACCOUNTS_SEARCHICON = "CORPLOGIN/MashreqAccounts/SearchIcon";
    public static final String MASHREQACCOUNTS_SEARCHICONTEXTBOX = "CORPLOGIN/MashreqAccounts/SearchIconTextbox";
    public static final String MASHREQACCOUNTS_CLOSEPAYMENTSELECTIONBUTTON = "CORPLOGIN/MashreqAccounts/ClosePaymentSelectionButton";
    public static final String MASHREQACCOUNTS_N019000077019AEDYPWBBURAYHISAYYURGGBKW = "CORPLOGIN/MashreqAccounts/N019000077019AedYpwbbUrayhisAyyurggBkw";
    public static final String MASHREQACCOUNTS_N019000077019AED = "CORPLOGIN/MashreqAccounts/N019000077019Aed";
    public static final String MASHREQACCOUNTS_YPWBBURAYHISAYYURGGBKW = "CORPLOGIN/MashreqAccounts/YpwbbUrayhisAyyurggBkw";
    public static final String MASHREQACCOUNTS_CONVENTIONAL = "CORPLOGIN/MashreqAccounts/Conventional";
    public static final String MASHREQACCOUNTS_ANDROIDWIDGETTEXTVIEW = "CORPLOGIN/MashreqAccounts/AndroidWidgetTextView";
    public static final String MASHREQACCOUNTS_N1098596 = "CORPLOGIN/MashreqAccounts/N1098596";
    public static final String MASHREQACCOUNTS_N019000079351EURYPWBBURAYHISAYYURGGBKW = "CORPLOGIN/MashreqAccounts/N019000079351EurYpwbbUrayhisAyyurggBkw";
    public static final String MASHREQACCOUNTS_N019000079351EUR = "CORPLOGIN/MashreqAccounts/N019000079351Eur";
    public static final String MASHREQACCOUNTS_YPWBBURAYHISAYYURGGBKWLABEL = "CORPLOGIN/MashreqAccounts/YpwbbUrayhisAyyurggBkwLabel";
    public static final String MASHREQACCOUNTS_CONVENTIONALLABEL = "CORPLOGIN/MashreqAccounts/ConventionalLabel";
    public static final String MASHREQACCOUNTS_EUR = "CORPLOGIN/MashreqAccounts/Eur";
    public static final String MASHREQACCOUNTS_N9444 = "CORPLOGIN/MashreqAccounts/N9444";
    public static final String MASHREQACCOUNTS_N019000077020USDYPWBBURAYHISAYYURGGBKW = "CORPLOGIN/MashreqAccounts/N019000077020UsdYpwbbUrayhisAyyurggBkw";
    public static final String MASHREQACCOUNTS_N019000077020USD = "CORPLOGIN/MashreqAccounts/N019000077020Usd";
    public static final String MASHREQACCOUNTS_YPWBBURAYHISAYYURGGBKWLABEL2 = "CORPLOGIN/MashreqAccounts/YpwbbUrayhisAyyurggBkwLabel2";
    public static final String MASHREQACCOUNTS_CONVENTIONALLABEL2 = "CORPLOGIN/MashreqAccounts/ConventionalLabel2";
    public static final String MASHREQACCOUNTS_USD = "CORPLOGIN/MashreqAccounts/Usd";
    public static final String MASHREQACCOUNTS_N295193425 = "CORPLOGIN/MashreqAccounts/N295193425";
    public static final String MASHREQACCOUNTS_HOME = "CORPLOGIN/MashreqAccounts/Home";
    public static final String MASHREQACCOUNTS_HOMELABEL = "CORPLOGIN/MashreqAccounts/HomeLabel";
    public static final String MASHREQACCOUNTS_ACCOUNTS = "CORPLOGIN/MashreqAccounts/Accounts";
    public static final String MASHREQACCOUNTS_ACCOUNTSLABEL = "CORPLOGIN/MashreqAccounts/AccountsLabel";
    public static final String MASHREQACCOUNTS_TADA = "CORPLOGIN/MashreqAccounts/Tada";
    public static final String MASHREQACCOUNTS_TADALABEL = "CORPLOGIN/MashreqAccounts/TadaLabel";
    public static final String MASHREQACCOUNTS_PAYTRANSFER = "CORPLOGIN/MashreqAccounts/PayTransfer";
    public static final String MASHREQACCOUNTS_PAYTRANSFERLABEL = "CORPLOGIN/MashreqAccounts/PayTransferLabel";
    public static final String MASHREQACCOUNTS_MORE = "CORPLOGIN/MashreqAccounts/More";
    public static final String MASHREQACCOUNTS_MORELABEL = "CORPLOGIN/MashreqAccounts/MoreLabel";
    public static final String MASHREQACCOUNTS_VIEWGROUP = "CORPLOGIN/MashreqAccounts/ViewGroup";

    // ===== PaymentTracker =====
    public static final String PAYMENTTRACKER_PAYMENTTRACKER = "CORPLOGIN/PaymentTracker/PaymentTracker";
    public static final String PAYMENTTRACKER_SEGMENTEDTABALL = "CORPLOGIN/PaymentTracker/SegmentedTabAll";
    public static final String PAYMENTTRACKER_ALL = "CORPLOGIN/PaymentTracker/All";
    public static final String PAYMENTTRACKER_SEGMENTEDTABINTERNALSELFTRANSFER = "CORPLOGIN/PaymentTracker/SegmentedTabInternalSelfTransfer";
    public static final String PAYMENTTRACKER_INTERNALSELFTRANSFER = "CORPLOGIN/PaymentTracker/InternalSelfTransfer";
    public static final String PAYMENTTRACKER_SEGMENTEDTABINTERNALTHIRDPARTYTRANSFER = "CORPLOGIN/PaymentTracker/SegmentedTabInternalThirdPartyTransfer";
    public static final String PAYMENTTRACKER_INTERNALTHIRDPARTYTRANSFER = "CORPLOGIN/PaymentTracker/InternalThirdPartyTransfer";
    public static final String PAYMENTTRACKER_SEARCHICON = "CORPLOGIN/PaymentTracker/SearchIcon";
    public static final String PAYMENTTRACKER_SEARCHICONTEXTBOX = "CORPLOGIN/PaymentTracker/SearchIconTextbox";
    public static final String PAYMENTTRACKER_CLOSEPAYMENTSELECTION = "CORPLOGIN/PaymentTracker/ClosePaymentSelection";
    public static final String PAYMENTTRACKER_CLOSEPAYMENTSELECTIONBUTTON = "CORPLOGIN/PaymentTracker/ClosePaymentSelectionButton";
    public static final String PAYMENTTRACKER_SHOWINGLAST20TRANSACTIONS = "CORPLOGIN/PaymentTracker/ShowingLast20Transactions";
    public static final String PAYMENTTRACKER_SHOWINGLAST20TRANSACTIONSLABEL = "CORPLOGIN/PaymentTracker/ShowingLast20TransactionsLabel";
    public static final String PAYMENTTRACKER_N00 = "CORPLOGIN/PaymentTracker/N00";
    public static final String PAYMENTTRACKER_HOME = "CORPLOGIN/PaymentTracker/Home";
    public static final String PAYMENTTRACKER_HOMELABEL = "CORPLOGIN/PaymentTracker/HomeLabel";
    public static final String PAYMENTTRACKER_ACCOUNTS = "CORPLOGIN/PaymentTracker/Accounts";
    public static final String PAYMENTTRACKER_ACCOUNTSLABEL = "CORPLOGIN/PaymentTracker/AccountsLabel";
    public static final String PAYMENTTRACKER_TADA = "CORPLOGIN/PaymentTracker/Tada";
    public static final String PAYMENTTRACKER_TADALABEL = "CORPLOGIN/PaymentTracker/TadaLabel";
    public static final String PAYMENTTRACKER_PAYTRANSFER = "CORPLOGIN/PaymentTracker/PayTransfer";
    public static final String PAYMENTTRACKER_PAYTRANSFERLABEL = "CORPLOGIN/PaymentTracker/PayTransferLabel";
    public static final String PAYMENTTRACKER_MORE = "CORPLOGIN/PaymentTracker/More";
    public static final String PAYMENTTRACKER_MORELABEL = "CORPLOGIN/PaymentTracker/MoreLabel";
    public static final String PAYMENTTRACKER_VIEWGROUP = "CORPLOGIN/PaymentTracker/ViewGroup";
    public static final String PAYMENTTRACKER_SHOWINGLAST0TRANSACTIONS = "CORPLOGIN/PaymentTracker/ShowingLast0Transactions";

    // ===== PaymentTracker2 =====
    public static final String PAYMENTTRACKER2_PAYMENTTRACKER = "CORPLOGIN/PaymentTracker2/PaymentTracker";
    public static final String PAYMENTTRACKER2_SEGMENTEDTABALL = "CORPLOGIN/PaymentTracker2/SegmentedTabAll";
    public static final String PAYMENTTRACKER2_ALL = "CORPLOGIN/PaymentTracker2/All";
    public static final String PAYMENTTRACKER2_SEGMENTEDTABINTERNALSELFTRANSFER = "CORPLOGIN/PaymentTracker2/SegmentedTabInternalSelfTransfer";
    public static final String PAYMENTTRACKER2_INTERNALSELFTRANSFER = "CORPLOGIN/PaymentTracker2/InternalSelfTransfer";
    public static final String PAYMENTTRACKER2_SEGMENTEDTABINTERNALTHIRDPARTYTRANSFER = "CORPLOGIN/PaymentTracker2/SegmentedTabInternalThirdPartyTransfer";
    public static final String PAYMENTTRACKER2_INTERNALTHIRDPARTYTRANSFER = "CORPLOGIN/PaymentTracker2/InternalThirdPartyTransfer";
    public static final String PAYMENTTRACKER2_SEARCHICON = "CORPLOGIN/PaymentTracker2/SearchIcon";
    public static final String PAYMENTTRACKER2_SEARCHICONTEXTBOX = "CORPLOGIN/PaymentTracker2/SearchIconTextbox";
    public static final String PAYMENTTRACKER2_CLOSEPAYMENTSELECTION = "CORPLOGIN/PaymentTracker2/ClosePaymentSelection";
    public static final String PAYMENTTRACKER2_CLOSEPAYMENTSELECTIONBUTTON = "CORPLOGIN/PaymentTracker2/ClosePaymentSelectionButton";
    public static final String PAYMENTTRACKER2_SHOWINGLAST20TRANSACTIONS = "CORPLOGIN/PaymentTracker2/ShowingLast20Transactions";
    public static final String PAYMENTTRACKER2_SHOWINGLAST20TRANSACTIONSLABEL = "CORPLOGIN/PaymentTracker2/ShowingLast20TransactionsLabel";
    public static final String PAYMENTTRACKER2_PAYMENTTRACKERLIST = "CORPLOGIN/PaymentTracker2/PaymentTrackerList";
    public static final String PAYMENTTRACKER2_INTERNALTHIRDPARTYTRANSFERVALUEDATE = "CORPLOGIN/PaymentTracker2/InternalThirdPartyTransferValueDate";
    public static final String PAYMENTTRACKER2_INTERNALTHIRDPARTYTRANSFERLABEL = "CORPLOGIN/PaymentTracker2/InternalThirdPartyTransferLabel";
    public static final String PAYMENTTRACKER2_VALUEDATE = "CORPLOGIN/PaymentTracker2/ValueDate";
    public static final String PAYMENTTRACKER2_N09OCT2026 = "CORPLOGIN/PaymentTracker2/N09Oct2026";
    public static final String PAYMENTTRACKER2_ANDROIDWIDGETTEXTVIEW = "CORPLOGIN/PaymentTracker2/AndroidWidgetTextView";
    public static final String PAYMENTTRACKER2_N0110DDF7DE82 = "CORPLOGIN/PaymentTracker2/N0110Ddf7De82";
    public static final String PAYMENTTRACKER2_TO = "CORPLOGIN/PaymentTracker2/To";
    public static final String PAYMENTTRACKER2_AGAPEGENERALTRADINGFZE = "CORPLOGIN/PaymentTracker2/AgapeGeneralTradingFze";
    public static final String PAYMENTTRACKER2_FROMACCOUNT = "CORPLOGIN/PaymentTracker2/FromAccount";
    public static final String PAYMENTTRACKER2_N019000077020 = "CORPLOGIN/PaymentTracker2/N019000077020";
    public static final String PAYMENTTRACKER2_PENDINGFORAPPROVAL = "CORPLOGIN/PaymentTracker2/PendingForApproval";
    public static final String PAYMENTTRACKER2_AED1000 = "CORPLOGIN/PaymentTracker2/Aed1000";
    public static final String PAYMENTTRACKER2_INTERNALTHIRDPARTYTRANSFERVALUEDATEBUTTON = "CORPLOGIN/PaymentTracker2/InternalThirdPartyTransferValueDateButton";
    public static final String PAYMENTTRACKER2_INTERNALTHIRDPARTYTRANSFERLABEL2 = "CORPLOGIN/PaymentTracker2/InternalThirdPartyTransferLabel2";
    public static final String PAYMENTTRACKER2_VALUEDATELABEL = "CORPLOGIN/PaymentTracker2/ValueDateLabel";
    public static final String PAYMENTTRACKER2_N02OCT2026 = "CORPLOGIN/PaymentTracker2/N02Oct2026";
    public static final String PAYMENTTRACKER2_ANDROIDWIDGETTEXTVIEWLABEL = "CORPLOGIN/PaymentTracker2/AndroidWidgetTextViewLabel";
    public static final String PAYMENTTRACKER2_N0110B50A6FBE = "CORPLOGIN/PaymentTracker2/N0110B50A6Fbe";
    public static final String PAYMENTTRACKER2_TOLABEL = "CORPLOGIN/PaymentTracker2/ToLabel";
    public static final String PAYMENTTRACKER2_AGAPEGENERALTRADINGFZELABEL = "CORPLOGIN/PaymentTracker2/AgapeGeneralTradingFzeLabel";
    public static final String PAYMENTTRACKER2_FROMACCOUNTLABEL = "CORPLOGIN/PaymentTracker2/FromAccountLabel";
    public static final String PAYMENTTRACKER2_N019000077020LABEL = "CORPLOGIN/PaymentTracker2/N019000077020Label";
    public static final String PAYMENTTRACKER2_PENDINGFORAPPROVALLABEL = "CORPLOGIN/PaymentTracker2/PendingForApprovalLabel";
    public static final String PAYMENTTRACKER2_AED1000LABEL = "CORPLOGIN/PaymentTracker2/Aed1000Label";
    public static final String PAYMENTTRACKER2_INTERNALSELFTRANSFERVALUEDATE02 = "CORPLOGIN/PaymentTracker2/InternalSelfTransferValueDate02";
    public static final String PAYMENTTRACKER2_INTERNALSELFTRANSFERLABEL = "CORPLOGIN/PaymentTracker2/InternalSelfTransferLabel";
    public static final String PAYMENTTRACKER2_VALUEDATELABEL2 = "CORPLOGIN/PaymentTracker2/ValueDateLabel2";
    public static final String PAYMENTTRACKER2_N02OCT2026LABEL = "CORPLOGIN/PaymentTracker2/N02Oct2026Label";
    public static final String PAYMENTTRACKER2_ANDROIDWIDGETTEXTVIEWLABEL2 = "CORPLOGIN/PaymentTracker2/AndroidWidgetTextViewLabel2";
    public static final String PAYMENTTRACKER2_N02101E6308C6 = "CORPLOGIN/PaymentTracker2/N02101E6308C6";
    public static final String PAYMENTTRACKER2_TOLABEL2 = "CORPLOGIN/PaymentTracker2/ToLabel2";
    public static final String PAYMENTTRACKER2_FJWHDBTDLWIAPIRUTXIOTBUB = "CORPLOGIN/PaymentTracker2/FjwhdbtDlwiapiRutxiotBub";
    public static final String PAYMENTTRACKER2_FROMACCOUNTLABEL2 = "CORPLOGIN/PaymentTracker2/FromAccountLabel2";
    public static final String PAYMENTTRACKER2_N019000077020LABEL2 = "CORPLOGIN/PaymentTracker2/N019000077020Label2";
    public static final String PAYMENTTRACKER2_AED50000 = "CORPLOGIN/PaymentTracker2/Aed50000";
    public static final String PAYMENTTRACKER2_HOME = "CORPLOGIN/PaymentTracker2/Home";
    public static final String PAYMENTTRACKER2_HOMELABEL = "CORPLOGIN/PaymentTracker2/HomeLabel";
    public static final String PAYMENTTRACKER2_ACCOUNTS = "CORPLOGIN/PaymentTracker2/Accounts";
    public static final String PAYMENTTRACKER2_ACCOUNTSLABEL = "CORPLOGIN/PaymentTracker2/AccountsLabel";
    public static final String PAYMENTTRACKER2_TADA = "CORPLOGIN/PaymentTracker2/Tada";
    public static final String PAYMENTTRACKER2_TADALABEL = "CORPLOGIN/PaymentTracker2/TadaLabel";
    public static final String PAYMENTTRACKER2_PAYTRANSFER = "CORPLOGIN/PaymentTracker2/PayTransfer";
    public static final String PAYMENTTRACKER2_PAYTRANSFERLABEL = "CORPLOGIN/PaymentTracker2/PayTransferLabel";
    public static final String PAYMENTTRACKER2_MORE = "CORPLOGIN/PaymentTracker2/More";
    public static final String PAYMENTTRACKER2_MORELABEL = "CORPLOGIN/PaymentTracker2/MoreLabel";
    public static final String PAYMENTTRACKER2_VIEWGROUP = "CORPLOGIN/PaymentTracker2/ViewGroup";
    public static final String PAYMENTTRACKER2_INTERNALSELFTRANSFERVALUEDATE01 = "CORPLOGIN/PaymentTracker2/InternalSelfTransferValueDate01";
    public static final String PAYMENTTRACKER2_INTERNALSELFTRANSFERVALUEDATE01BUTTON = "CORPLOGIN/PaymentTracker2/InternalSelfTransferValueDate01Button";

    // ===== N3ActiveApps =====
    public static final String N3ACTIVEAPPS_FGSBUTTONCONTAINER = "CORPLOGIN/N3ActiveApps/FgsButtonContainer";
    public static final String N3ACTIVEAPPS_N3ACTIVEAPPS = "CORPLOGIN/N3ActiveApps/N3ActiveApps";
    public static final String N3ACTIVEAPPS_MOREOPTIONS = "CORPLOGIN/N3ActiveApps/MoreOptions";
    public static final String N3ACTIVEAPPS_BROWSERSTACKREVERSETETHER = "CORPLOGIN/N3ActiveApps/BrowserStackReverseTether";
    public static final String N3ACTIVEAPPS_CONTACTS = "CORPLOGIN/N3ActiveApps/Contacts";
    public static final String N3ACTIVEAPPS_CHROME = "CORPLOGIN/N3ActiveApps/Chrome";
    public static final String N3ACTIVEAPPS_BROWSERSTACK = "CORPLOGIN/N3ActiveApps/BrowserStack";
    public static final String N3ACTIVEAPPS_ADVANCEDOPTIONSBROWSERSTACKBUTTON = "CORPLOGIN/N3ActiveApps/AdvancedOptionsBrowserStackButton";
    public static final String N3ACTIVEAPPS_MASHREQCIBGSIT = "CORPLOGIN/N3ActiveApps/MashreqCibgSit";
    public static final String N3ACTIVEAPPS_CLOSEALL = "CORPLOGIN/N3ActiveApps/CloseAll";
    public static final String N3ACTIVEAPPS_MESSAGES = "CORPLOGIN/N3ActiveApps/Messages";
    public static final String N3ACTIVEAPPS_MESSAGESLABEL = "CORPLOGIN/N3ActiveApps/MessagesLabel";
    public static final String N3ACTIVEAPPS_FACEBOOK = "CORPLOGIN/N3ActiveApps/Facebook";
    public static final String N3ACTIVEAPPS_FACEBOOKLABEL = "CORPLOGIN/N3ActiveApps/FacebookLabel";
    public static final String N3ACTIVEAPPS_PLAYSTORE = "CORPLOGIN/N3ActiveApps/PlayStore";
    public static final String N3ACTIVEAPPS_PLAYSTORELABEL = "CORPLOGIN/N3ActiveApps/PlayStoreLabel";
    public static final String N3ACTIVEAPPS_GMAIL = "CORPLOGIN/N3ActiveApps/Gmail";
    public static final String N3ACTIVEAPPS_GMAILLABEL = "CORPLOGIN/N3ActiveApps/GmailLabel";

    // ===== Products =====
    public static final String PRODUCTS_BOTTOMSHEETBACKDROP = "CORPLOGIN/Products/BottomSheetBackdrop";
    public static final String PRODUCTS_BOTTOMSHEET = "CORPLOGIN/Products/BottomSheet";
    public static final String PRODUCTS_BOTTOMSHEETELEMENT = "CORPLOGIN/Products/BottomSheetElement";
    public static final String PRODUCTS_CLOSE = "CORPLOGIN/Products/Close";
    public static final String PRODUCTS_CLOSEPAYMENTSELECTION = "CORPLOGIN/Products/ClosePaymentSelection";
    public static final String PRODUCTS_MOREOPTIONS = "CORPLOGIN/Products/MoreOptions";
    public static final String PRODUCTS_MORETABSECTIONDRAWERSCROLL = "CORPLOGIN/Products/MoreTabSectionDrawerScroll";
    public static final String PRODUCTS_PRODUCTS = "CORPLOGIN/Products/Products";
    public static final String PRODUCTS_MANAGEYOURCORPORATEBANKINGPRODUCTSIN = "CORPLOGIN/Products/ManageYourCorporateBankingProductsIn";
    public static final String PRODUCTS_TRADETRACKER = "CORPLOGIN/Products/TradeTracker";
    public static final String PRODUCTS_TRADETRACKERLABEL = "CORPLOGIN/Products/TradeTrackerLabel";
    public static final String PRODUCTS_TRADELOANFINANCESETTLEMENT = "CORPLOGIN/Products/TradeLoanFinanceSettlement";
    public static final String PRODUCTS_TRADELOANFINANCESETTLEMENTLABEL = "CORPLOGIN/Products/TradeLoanFinanceSettlementLabel";
    public static final String PRODUCTS_TERMDEPOSITS = "CORPLOGIN/Products/TermDeposits";
    public static final String PRODUCTS_TERMDEPOSITSLABEL = "CORPLOGIN/Products/TermDepositsLabel";
    public static final String PRODUCTS_COLLECTIONTRACKER = "CORPLOGIN/Products/CollectionTracker";
    public static final String PRODUCTS_COLLECTIONTRACKERLABEL = "CORPLOGIN/Products/CollectionTrackerLabel";
    public static final String PRODUCTS_SERVICES = "CORPLOGIN/Products/Services";
    public static final String PRODUCTS_MANAGEAPPROVALSANDGETSUPPORTWHENEVER = "CORPLOGIN/Products/ManageApprovalsAndGetSupportWhenever";
    public static final String PRODUCTS_SERVICEITEMAPPROVALS = "CORPLOGIN/Products/ServiceItemApprovals";
    public static final String PRODUCTS_APPROVALS = "CORPLOGIN/Products/Approvals";
    public static final String PRODUCTS_SERVICEITEMCUSTOMERSUPPORT = "CORPLOGIN/Products/ServiceItemCustomerSupport";
    public static final String PRODUCTS_CUSTOMERSUPPORT = "CORPLOGIN/Products/CustomerSupport";
    public static final String PRODUCTS_PROFILESETTINGS = "CORPLOGIN/Products/ProfileSettings";
    public static final String PRODUCTS_HOME = "CORPLOGIN/Products/Home";
    public static final String PRODUCTS_HOMELABEL = "CORPLOGIN/Products/HomeLabel";
    public static final String PRODUCTS_ACCOUNTS = "CORPLOGIN/Products/Accounts";
    public static final String PRODUCTS_ACCOUNTSLABEL = "CORPLOGIN/Products/AccountsLabel";
    public static final String PRODUCTS_TADA = "CORPLOGIN/Products/Tada";
    public static final String PRODUCTS_TADALABEL = "CORPLOGIN/Products/TadaLabel";
    public static final String PRODUCTS_PAYTRANSFER = "CORPLOGIN/Products/PayTransfer";
    public static final String PRODUCTS_PAYTRANSFERLABEL = "CORPLOGIN/Products/PayTransferLabel";
    public static final String PRODUCTS_MORE = "CORPLOGIN/Products/More";
    public static final String PRODUCTS_MORELABEL = "CORPLOGIN/Products/MoreLabel";
    public static final String PRODUCTS_VIEWGROUP = "CORPLOGIN/Products/ViewGroup";

}
