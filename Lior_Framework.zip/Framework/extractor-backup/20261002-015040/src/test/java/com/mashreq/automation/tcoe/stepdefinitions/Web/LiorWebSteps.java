package com.mashreq.automation.tcoe.stepdefinitions.Web;

import com.mashreq.automation.tcoe.constants.FrameworkConstants;
import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.driver.DriverManager;
import com.mashreq.automation.tcoe.keywords.WebUI;
import com.mashreq.automation.tcoe.pages.CommonPage;
import com.mashreq.automation.tcoe.utils.DataHandler;
import com.mashreq.automation.tcoe.utils.FeatureStepCollector;
import com.mashreq.automation.tcoe.utils.LocatorUtils;
import com.mashreq.automation.tcoe.utils.LogUtils;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

/**
 * Added by Lior (generated - Lior rewrites this file; put your own steps in another class).
 *
 * 1. Opens any web application whose address is in urls-<ENV>.properties as url.<REGION>.<APPLICATION>.
 *    The browser itself is started by ApplicationHooks for every scenario that is not @Mobile / @API.
 * 2. Steps that run only when the scenario's test data has the field ("... if they are in the test data"). A test recorded in
 *    several versions (other data that shows other fields) is one Scenario Outline; a field that only one version uses is only in that
 *    version's test data, so the step is skipped for the others.
 * 3. File upload; the file path comes from the test data (relative paths are taken from the project folder).
 */
public class LiorWebSteps {

    private final ScenarioContext ctx;
    private final WebUI webUI;
    private final CommonPage commonPage;
    private final DataHandler dataHandler = new DataHandler();

    public LiorWebSteps(ScenarioContext ctx) {
        this.ctx = ctx;
        this.webUI = new WebUI(ctx, new FeatureStepCollector());
        this.commonPage = new CommonPage(webUI);
    }

    @Given("user opens the {string} application")
    public void userOpensTheApplication(String application) {
        String url = FrameworkConstants.getBaseUrl(application);
        LogUtils.info("Opening " + application + ": " + url);
        DriverManager.getPage().navigate(url);
    }

    @And("user enters the following field details under {string} screen if they are in the test data")
    public void userEntersFieldsIfInTestData(String screen, DataTable table) {
        for (String field : table.asList()) {
            String value = valueOrNull(field);
            if (value == null) {
                LogUtils.info("Skipped '" + field + "' on " + screen + ": not in the test data of " + ctx.getScenarioId());
                continue;
            }
            commonPage.enterFieldAndTab(ctx.getCurrentModule(), screen, field, value);
        }
    }

    @And("user select the following field details under {string} screen if they are in the test data")
    public void userSelectsFieldsIfInTestData(String screen, DataTable table) {
        for (String field : table.asList()) {
            String value = valueOrNull(field);
            if (value == null) {
                LogUtils.info("Skipped '" + field + "' on " + screen + ": not in the test data of " + ctx.getScenarioId());
                continue;
            }
            commonPage.selectField(ctx.getCurrentModule(), screen, field, value);
        }
    }

    @Then("user verify the following field details under {string} screen if they are in the test data")
    public void userVerifiesFieldsIfInTestData(String screen, DataTable table) {
        for (String field : table.asList()) {
            String value = valueOrNull(field);
            if (value == null) {
                LogUtils.info("Skipped check of '" + field + "' on " + screen + ": not in the test data of " + ctx.getScenarioId());
                continue;
            }
            commonPage.verifyField(ctx.getCurrentModule(), screen, field, value);
        }
    }

    @And("user click {string} under {string} screen if it is in the test data")
    public void userClicksIfInTestData(String element, String screen) {
        if (valueOrNull(element) == null) {
            LogUtils.info("Skipped click on '" + element + "' on " + screen + ": not in the test data of " + ctx.getScenarioId());
            return;
        }
        commonPage.clickButtonMod(ctx.getCurrentModule(), screen, element);
    }

    @And("user uploads the following files under {string} screen")
    public void userUploadsFiles(String screen, DataTable table) {
        for (String field : table.asList()) {
            String path = dataHandler.getTestDataOrThrow(ctx.getCurrentModule(), ctx.getScenarioId(), field);
            upload(screen, field, path);
        }
    }

    @And("user uploads the following files under {string} screen if they are in the test data")
    public void userUploadsFilesIfInTestData(String screen, DataTable table) {
        for (String field : table.asList()) {
            String path = valueOrNull(field);
            if (path == null) {
                LogUtils.info("Skipped upload '" + field + "' on " + screen + ": not in the test data of " + ctx.getScenarioId());
                continue;
            }
            upload(screen, field, path);
        }
    }

    private void upload(String screen, String field, String path) {
        String locator = LocatorUtils.byPath(ctx.getCurrentModule() + "/" + screen + "/" + field);
        webUI.uploadFile(locator, path);
    }

    /** The scenario's test data value for the field, or null when this scenario (version) does not have it. */
    private String valueOrNull(String field) {
        try {
            String v = dataHandler.getTestDataOrThrow(ctx.getCurrentModule(), ctx.getScenarioId(), field);
            return v == null || v.trim().isEmpty() ? null : v;
        } catch (RuntimeException notThere) {
            return null;
        }
    }
}
