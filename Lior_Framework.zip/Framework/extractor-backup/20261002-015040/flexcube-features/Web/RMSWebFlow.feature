# Made by Lior on 2026-10-02 01:11.
# The values typed or checked by these steps are in the test data file
# testdata/<NN>.RMS/US_TestData_RMS.json (look for the scenario id).
# A test recorded in several versions (other data) is one Scenario Outline: steps ending in "if ... in the test data"
# run only for the versions whose test data has that field.
Feature: RMS - recorded web flow

  @Web @SC_001
  Scenario: RMS|SC_001|Loading
    Given user opens the "RMS" application
    And user enters the following field details under "Login" screen
      |EmployeeIdOrEmail|
      |Password|
    # CHECK: 'Span' is not in the object repository for screen 'Login'
    When user click "Span" under "Login" screen
    When user click "NewProject" under "New" screen
    And user enters the following field details under "New" screen
      |ClientName|
      |ProjectName|
    And user select the following field details under "New" screen
      |ServiceType|
      |StatusActiveConfirmedEngagement|
    When user click "WinProbability" under "New" screen
    And user enters the following field details under "New" screen
      |WinProbability|
      |NumberOfWorkingDays|
    # CHECK: 'Span' is not in the object repository for screen 'New'
    When user click "Span" under "New" screen
    # CHECK: 'Span' is not in the object repository for screen 'New'
    When user click "Span" under "New" screen
    # CHECK: 'N2' is not in the object repository for screen 'New'
    When user click "N2" under "New" screen
    # CHECK: 'Span' is not in the object repository for screen 'New'
    When user click "Span" under "New" screen
    # CHECK: 'ArrowBack' is not in the object repository for screen 'Projects'
    When user click "ArrowBack" under "Projects" screen
    # CHECK: 'AdminUser' is not in the object repository for screen 'Projects2'
    When user click "AdminUser" under "Projects2" screen
    # CHECK: 'SignOut' is not in the object repository for screen 'Projects2'
    When user click "SignOut" under "Projects2" screen
