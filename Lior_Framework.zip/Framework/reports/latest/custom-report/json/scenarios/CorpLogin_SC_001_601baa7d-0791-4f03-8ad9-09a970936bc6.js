loadScenarioData({
  "featureUUID" : "c4afdff9-fa78-36e8-b6bc-06ce6587ef48",
  "featureName" : "CorpLogin - recorded mobile flow",
  "featureDescription" : null,
  "featureKeyword" : "Feature",
  "featureUri" : "file:///C:/Uday/RD/Automation/Framework/flexcube-features/Mobile/CorpLoginFlow.feature",
  "featureTags" : [ "@CorpLogin" ],
  "scenarioUUID" : "601baa7d-0791-4f03-8ad9-09a970936bc6",
  "scenarioName" : "CorpLogin|SC_001|Corp_Just_View",
  "description" : null,
  "tags" : [ "@CorpLogin", "@Mobile", "@SC_001" ],
  "startTime" : "2026-10-02T18:20:37.933335Z",
  "endTime" : "2026-10-02T18:22:00.061335Z",
  "durationMillis" : 82128,
  "totalSteps" : 45,
  "passedSteps" : 45,
  "failedSteps" : 0,
  "skippedSteps" : 0,
  "undefinedSteps" : 0,
  "pendingSteps" : 0,
  "ambiguousSteps" : 0,
  "moduleName" : "CorpLogin",
  "scenarioId" : "SC_001",
  "videoPath" : null,
  "steps" : [ {
    "keyword" : "Given ",
    "text" : "the mobile app is launched",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 797,
    "actions" : [ {
      "action" : "Mobile app launched successfully",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 583,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_1_1_1790965252843.png",
      "result" : "PASSED"
    } ],
    "dataTable" : null
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"WelcomeScreenSlide3\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1255,
    "actions" : [ {
      "action" : "Verify element state: AndroidWidgetTextView|//android.widget.TextView[@text='عربي'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1212,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_2_1_1790965254356.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "AndroidWidgetTextView" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user clicks the \"AppWelcomeAccessibilityLoginButton\" button under \"WelcomeScreenSlide3\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1365,
    "actions" : [ {
      "action" : "Click: AppWelcomeAccessibilityLoginButton|//android.widget.Button[@resource-id='login-cta-button']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1360,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_3_1_1790965255713.png",
      "result" : null
    } ],
    "dataTable" : null
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"LoginToMashreqNeoCorp\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1585,
    "actions" : [ {
      "action" : "Verify element state: AndroidWidgetTextView|//android.widget.TextView[@resource-id='navigation-header-language-switcher-text'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1583,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_4_1_1790965257484.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "AndroidWidgetTextView" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user clicks the \"LoginWithPassword\" button under \"LoginToMashreqNeoCorp\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1283,
    "actions" : [ {
      "action" : "Click: LoginWithPassword|//android.widget.Button[@resource-id='password-login-button']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1282,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_5_1_1790965258656.png",
      "result" : null
    } ],
    "dataTable" : null
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"LoginToMashreqNeoCorp\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1491,
    "actions" : [ {
      "action" : "Verify element state: AndroidWidgetTextView|//android.widget.TextView[@resource-id='navigation-header-language-switcher-text'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1491,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_6_1_1790965260296.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "AndroidWidgetTextView" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user enters the following Mobile field details under \"LoginToMashreqNeoCorp\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 2464,
    "actions" : [ {
      "action" : "Type 'makerft2' into: VerifyUsernameInputTextInput|//android.widget.EditText[@resource-id='verify-username-input-text-input']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 2457,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_7_1_1790965262567.png",
      "result" : null
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "VerifyUsernameInputTextInput" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"LoginToMashreqNeoCorp\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 829,
    "actions" : [ {
      "action" : "Verify element state: AndroidWidgetTextView|//android.widget.TextView[@resource-id='navigation-header-language-switcher-text'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 828,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_8_1_1790965263584.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "AndroidWidgetTextView" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user clicks the \"VerifyUsernameInputRightIconButton\" button under \"LoginToMashreqNeoCorp\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1229,
    "actions" : [ {
      "action" : "Click: VerifyUsernameInputRightIconButton|//android.widget.Button[@resource-id='verify-username-input-right-icon-button']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1228,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_9_1_1790965264731.png",
      "result" : null
    } ],
    "dataTable" : null
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"LoginToMashreqNeoCorp\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1469,
    "actions" : [ {
      "action" : "Verify element state: AndroidWidgetTextView|//android.widget.TextView[@resource-id='navigation-header-language-switcher-text'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1468,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_10_1_1790965266286.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "AndroidWidgetTextView" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"LoginToMashreqNeoCorp2\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1419,
    "actions" : [ {
      "action" : "Verify element state: AndroidWidgetTextView|//android.widget.TextView[@resource-id='navigation-header-language-switcher-text'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1418,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_11_1_1790965267714.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "AndroidWidgetTextView" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user enters the following Mobile field details under \"LoginToMashreqNeoCorp2\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 2369,
    "actions" : [ {
      "action" : "Type 'Password@1' into: PasswordInputTextInput|//android.widget.EditText[@resource-id='password-input-text-input']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 2366,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_12_1_1790965269997.png",
      "result" : null
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "PasswordInputTextInput" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"LoginToMashreqNeoCorp2\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 855,
    "actions" : [ {
      "action" : "Verify element state: AndroidWidgetTextView|//android.widget.TextView[@resource-id='navigation-header-language-switcher-text'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 855,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_13_1_1790965270939.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "AndroidWidgetTextView" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user clicks the \"Login\" button under \"LoginToMashreqNeoCorp2\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1251,
    "actions" : [ {
      "action" : "Click: Login|//android.widget.Button[@resource-id='login-button']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1250,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_14_1_1790965272082.png",
      "result" : null
    } ],
    "dataTable" : null
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"LoginToMashreqNeoCorp2\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1484,
    "actions" : [ {
      "action" : "Verify element state: AndroidWidgetTextView|//android.widget.TextView[@resource-id='navigation-header-language-switcher-text'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1484,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_15_1_1790965273683.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "AndroidWidgetTextView" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user enters the following Mobile field details under \"SetUpYourLoginPin\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 4423,
    "actions" : [ {
      "action" : "Type '247996' into: SetUpA6DigitPin|//android.widget.EditText[@resource-id='mpin-setup-section-hidden-input']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 4421,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_16_1_1790965277226.png",
      "result" : null
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "SetUpA6DigitPin" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"SetUpYourLoginPin\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 2037,
    "actions" : [ {
      "action" : "Verify element state: SetUpYourLoginPin|//android.widget.TextView[@text='Set up your login PIN'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1171,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_17_1_1790965279275.png",
      "result" : "true"
    }, {
      "action" : "Verify element state: SetUpYourLoginPin|//android.widget.TextView[@text='Set up your login PIN'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 864,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_17_2_1790965280138.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "SetUpYourLoginPin" ],
        "status" : "PASSED"
      }, {
        "data" : [ "SetUpYourLoginPin" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user clicks the \"Continue\" button under \"SetUpYourLoginPin\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1148,
    "actions" : [ {
      "action" : "Click: Continue|//android.widget.Button[@resource-id='continue-button']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1147,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_18_1_1790965281194.png",
      "result" : null
    } ],
    "dataTable" : null
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"ConfirmYourLoginPin\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 2023,
    "actions" : [ {
      "action" : "Verify element state: ConfirmYourLoginPin|//android.widget.TextView[@text='Confirm your login PIN'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 2022,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_19_1_1790965283315.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "ConfirmYourLoginPin" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user enters the following Mobile field details under \"ConfirmYourLoginPin\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 3437,
    "actions" : [ {
      "action" : "Type '247996' into: ConfirmYour6DigitPin|//android.widget.EditText[@resource-id='mpin-confirm-section-hidden-input']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 3435,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_20_1_1790965285936.png",
      "result" : null
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "ConfirmYour6DigitPin" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"ConfirmYourLoginPin\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1939,
    "actions" : [ {
      "action" : "Verify element state: ConfirmYourLoginPin|//android.widget.TextView[@text='Confirm your login PIN'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1142,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_21_1_1790965287902.png",
      "result" : "true"
    }, {
      "action" : "Verify element state: ConfirmYourLoginPin|//android.widget.TextView[@text='Confirm your login PIN'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 797,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_21_2_1790965288696.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "ConfirmYourLoginPin" ],
        "status" : "PASSED"
      }, {
        "data" : [ "ConfirmYourLoginPin" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user clicks the \"Continue\" button under \"ConfirmYourLoginPin\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1160,
    "actions" : [ {
      "action" : "Click: Continue|//android.widget.Button[@resource-id='continue-button']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1158,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_22_1_1790965289756.png",
      "result" : null
    } ],
    "dataTable" : null
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"SetUpBiometrics\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 2000,
    "actions" : [ {
      "action" : "Verify element state: SetUpBiometrics|//android.widget.TextView[@text='Set Up Biometrics'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1999,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_23_1_1790965291859.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "SetUpBiometrics" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user clicks the \"SetUpBiometricsLater\" button under \"SetUpBiometrics\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1305,
    "actions" : [ {
      "action" : "Click: SetUpBiometricsLater|//android.widget.Button[@resource-id='skip-biometric-button']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1303,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_24_1_1790965293050.png",
      "result" : null
    } ],
    "dataTable" : null
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"YourDeviceIsSetUp\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1219,
    "actions" : [ {
      "action" : "Verify element state: YourDeviceIsSetUp|//android.widget.TextView[@resource-id='device-registered-success-screen-header-title'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1215,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_25_1_1790965294415.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "YourDeviceIsSetUp" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user clicks the \"Login\" button under \"YourDeviceIsSetUp\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 933,
    "actions" : [ {
      "action" : "Click: Login|//android.widget.Button[@resource-id='device-registered-login-button']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 932,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_26_1_1790965295244.png",
      "result" : null
    } ],
    "dataTable" : null
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"LoginToMashreqNeoCorp\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1496,
    "actions" : [ {
      "action" : "Verify element state: AndroidWidgetTextView|//android.widget.TextView[@resource-id='navigation-header-language-switcher-text'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1496,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_27_1_1790965296809.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "AndroidWidgetTextView" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user clicks the \"LoginWithPinBiometrics\" button under \"LoginToMashreqNeoCorp\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1167,
    "actions" : [ {
      "action" : "Click: LoginWithPinBiometrics|//android.widget.Button[@resource-id='biometric-login-button']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1166,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_28_1_1790965297889.png",
      "result" : null
    } ],
    "dataTable" : null
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"LoginToMashreqNeoCorp4\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 3091,
    "actions" : [ {
      "action" : "Verify element state: LoginToMashreqNeoCorp|//android.widget.TextView[@text='Login to Mashreq\nNEO CORP'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 3090,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_29_1_1790965301070.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "LoginToMashreqNeoCorp" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user enters the following Mobile field details under \"LoginToMashreqNeoCorp4\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 3421,
    "actions" : [ {
      "action" : "Type '247996' into: EnterYour6DigitPin|//android.widget.EditText[@resource-id='mpin-enter-section-hidden-input']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 3418,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_30_1_1790965303679.png",
      "result" : null
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "EnterYour6DigitPin" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"LoginToMashreqNeoCorp4\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 2050,
    "actions" : [ {
      "action" : "Verify element state: LoginToMashreqNeoCorp|//android.widget.TextView[@text='Login to Mashreq\nNEO CORP'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1186,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_31_1_1790965305672.png",
      "result" : "true"
    }, {
      "action" : "Verify element state: LoginToMashreqNeoCorp|//android.widget.TextView[@text='Login to Mashreq\nNEO CORP'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 863,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_31_2_1790965306549.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "LoginToMashreqNeoCorp" ],
        "status" : "PASSED"
      }, {
        "data" : [ "LoginToMashreqNeoCorp" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user clicks the \"Continue\" button under \"LoginToMashreqNeoCorp4\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1168,
    "actions" : [ {
      "action" : "Click: Continue|//android.widget.Button[@resource-id='enter-continue-button']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1168,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_32_1_1790965307623.png",
      "result" : null
    } ],
    "dataTable" : null
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"LoginToMashreqNeoCorp4\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1432,
    "actions" : [ {
      "action" : "Verify element state: LoginToMashreqNeoCorp|//android.widget.TextView[@text='Login to Mashreq\nNEO CORP'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1431,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_33_1_1790965309153.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "LoginToMashreqNeoCorp" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"EndUserLicenseAgreement\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1082,
    "actions" : [ {
      "action" : "Verify element state: EndUserLicenseAgreement|//android.widget.TextView[@text='End User License Agreement'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1081,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_34_1_1790965310264.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "EndUserLicenseAgreement" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user swipes up 5 times and clicks the \"IAgreeToTheTermsConditions\" button under \"EndUserLicenseAgreement\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 6312,
    "actions" : [ {
      "action" : "Swipe up",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1105,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_35_1_1790965311458.png",
      "result" : null
    }, {
      "action" : "Swipe up",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1109,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_35_2_1790965312567.png",
      "result" : null
    }, {
      "action" : "Swipe up",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1109,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_35_3_1790965313676.png",
      "result" : null
    }, {
      "action" : "Swipe up",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 959,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_35_4_1790965314635.png",
      "result" : null
    }, {
      "action" : "Swipe up",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 940,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_35_5_1790965315575.png",
      "result" : null
    }, {
      "action" : "Click: IAgreeToTheTermsConditions|//android.view.ViewGroup[@resource-id='checkbox-container']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1088,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_35_6_1790965316467.png",
      "result" : null
    } ],
    "dataTable" : null
  }, {
    "keyword" : "And ",
    "text" : "user clicks the \"IAgreeToTheTermsConditions\" button under \"EndUserLicenseAgreement\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1664,
    "actions" : [ {
      "action" : "Click: IAgreeToTheTermsConditions|//android.view.ViewGroup[@resource-id='checkbox-container']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1664,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_36_1_1790965318132.png",
      "result" : null
    } ],
    "dataTable" : null
  }, {
    "keyword" : "And ",
    "text" : "user clicks the \"IAgreeToTheTermsConditions\" button under \"EndUserLicenseAgreement\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1665,
    "actions" : [ {
      "action" : "Click: IAgreeToTheTermsConditions|//android.view.ViewGroup[@resource-id='checkbox-container']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1665,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_37_1_1790965319820.png",
      "result" : null
    } ],
    "dataTable" : null
  }, {
    "keyword" : "And ",
    "text" : "user clicks the \"AgreeContinue\" button under \"EndUserLicenseAgreement\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1634,
    "actions" : [ {
      "action" : "Click: AgreeContinue|//android.widget.Button[@resource-id='file-viewer-footer-accept-button']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1633,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_38_1_1790965321445.png",
      "result" : null
    } ],
    "dataTable" : null
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"Tada\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1540,
    "actions" : [ {
      "action" : "Verify element state: HomeLabel|//android.widget.TextView[@text='Home'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1539,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_39_1_1790965323032.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "HomeLabel" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"HelloMakerft2\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 2529,
    "actions" : [ {
      "action" : "Verify element state: AndroidWidgetTextView|//android.widget.TextView[@text='عربي'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 2528,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_40_1_1790965325565.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "AndroidWidgetTextView" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user clicks the \"Accounts\" button under \"HelloMakerft2\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1354,
    "actions" : [ {
      "action" : "Click: Accounts|//android.view.View[@content-desc='Accounts']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1353,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_41_1_1790965326808.png",
      "result" : null
    } ],
    "dataTable" : null
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"MashreqAccounts\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 2606,
    "actions" : [ {
      "action" : "Verify element state: MashreqAccounts|//android.widget.TextView[@text='Mashreq Accounts'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 2606,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_42_1_1790965329543.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "MashreqAccounts" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "And ",
    "text" : "user clicks the \"PayTransfer\" button under \"MashreqAccounts\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1289,
    "actions" : [ {
      "action" : "Click: PayTransfer|//android.view.View[@content-desc='Pay & Transfer']",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1289,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_43_1_1790965330736.png",
      "result" : null
    } ],
    "dataTable" : null
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"PaymentTracker\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 2743,
    "actions" : [ {
      "action" : "Verify element state: PaymentTracker|//android.widget.TextView[@text='Payment Tracker'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 2742,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_44_1_1790965333563.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "PaymentTracker" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  }, {
    "keyword" : "Then ",
    "text" : "the user verifies the following elements should be \"visible\" under \"PaymentTracker2\" screen",
    "status" : "PASSED",
    "error" : null,
    "durationMillis" : 1116,
    "actions" : [ {
      "action" : "Verify element state: PaymentTracker|//android.widget.TextView[@text='Payment Tracker'] | Expected: visible",
      "status" : "PASSED",
      "error" : null,
      "durationMillis" : 1115,
      "screenshotPath" : "./reports/latest/custom-report/screenshots/SC_001/SC_001_45_1_1790965334686.png",
      "result" : "true"
    } ],
    "dataTable" : {
      "header" : [ "Fields" ],
      "rows" : [ {
        "data" : [ "PaymentTracker" ],
        "status" : "PASSED"
      } ],
      "singleColumnIteration" : true
    }
  } ],
  "status" : "PASSED"
});