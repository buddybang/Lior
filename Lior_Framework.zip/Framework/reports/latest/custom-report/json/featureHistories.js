window.__allFeatureHistories = {
  "features" : [ {
    "featureUUID" : "c4afdff9-fa78-36e8-b6bc-06ce6587ef48",
    "moduleName" : "CorpLogin",
    "scenarios" : [ {
      "scenarioUUID" : "601baa7d-0791-4f03-8ad9-09a970936bc6",
      "scenarioId" : "SC_001",
      "moduleName" : "CorpLogin",
      "history" : [ {
        "status" : "PASSED",
        "buildNumber" : "local_20261002_235216",
        "runDateMillis" : 1790965237933,
        "runDate" : "2026-10-02T18:20:37.933Z",
        "durationMillis" : 82128
      }, {
        "status" : "PASSED",
        "buildNumber" : "local_20261002_234536",
        "runDateMillis" : null,
        "runDate" : "local_20261002_234536",
        "durationMillis" : 89000
      }, {
        "status" : "FAILED",
        "buildNumber" : "local_20261002_234018",
        "runDateMillis" : null,
        "runDate" : "local_20261002_234018",
        "durationMillis" : 96829
      }, {
        "status" : "FAILED",
        "buildNumber" : "local_20261002_232804",
        "runDateMillis" : null,
        "runDate" : "local_20261002_232804",
        "durationMillis" : 114439
      }, {
        "status" : "FAILED",
        "buildNumber" : "local_20261002_231024",
        "runDateMillis" : null,
        "runDate" : "local_20261002_231024",
        "durationMillis" : 115156
      } ]
    } ]
  } ]
};