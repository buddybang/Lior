package com.mashreq.automation.tcoe.driver;

import com.mashreq.automation.tcoe.utils.LogUtils;

import com.mashreq.automation.tcoe.constants.FrameworkConstants;
import com.microsoft.playwright.*;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.Duration;

/**
 * DriverManager manages the lifecycle of Playwright objects (Playwright, Browser, Context, Page).
 * It uses a ThreadLocal approach to ensure thread safety for parallel test execution.
 * This class is designed as a singleton utility and should not be instantiated.
 */
public final class DriverManager {

    private static final ThreadLocal<Playwright> playwright = new ThreadLocal<>();
    private static final ThreadLocal<Browser> browser = new ThreadLocal<>();
    private static final ThreadLocal<BrowserContext> context = new ThreadLocal<>();
    private static final ThreadLocal<Page> page = new ThreadLocal<>();
    private static final ThreadLocal<String> globalBrowserVersion = new ThreadLocal<>();
    /** The last browser started by any thread: for the end-of-run reports, which run on a thread without a browser. */
    private static volatile String lastBrowserVersion;

    /**
     * Browser name and version of the current thread's browser (e.g. "Chrome 125.0.6422.142"); on a thread without one (the
     * reports after the run) the last browser started, or null when no browser was started.
     */
    public static String getBrowserVersion() {
        String own = globalBrowserVersion.get();
        return own != null ? own : lastBrowserVersion;
    }

    /**
     * Private constructor to prevent instantiation of this utility class.
     */
    private DriverManager() {}

    /**
     * Initializes the Playwright driver for the current thread.
     * It creates and configures Playwright, Browser, BrowserContext, and Page instances based on the provided settings.
     */
    public static void initDriver() {
        initDriver(null);
    }

    /**
     * Same as {@link #initDriver()}, in the given browser (chrome, edge, firefox, webkit) instead of BROWSER from the config.
     * Used for scenarios tagged with a browser: Lior tags a recorded test @Chrome when it was recorded in Chrome.
     * Null or blank = BROWSER from the config.
     */
    public static void initDriver(String browserForScenario) {

        // This check prevents re-initialization on the same thread.
        // If a browser instance already exists in the ThreadLocal variable for the current thread,
        // we skip the setup process to avoid creating a duplicate browser.
        if (browser.get() != null) {
            LogUtils.info(
                    "-----> DEBUG: initDriver() was called, but a browser already exists for this thread. Skipping initialization."
            );
            return;
        }
        LogUtils.info(
                "-----> DEBUG: Initializing a new browser for Thread: " + Thread.currentThread().getName()
        );

        // Read values directly from the config
        String browserName = browserForScenario != null && !browserForScenario.isBlank() ? browserForScenario.trim()
                : FrameworkConstants.BROWSER != null ? FrameworkConstants.BROWSER : "chromium";
        boolean isHeadless = FrameworkConstants.HEADLESS;
        int defaultTimeout = FrameworkConstants.DEFAULT_TIMEOUT_MS;
        boolean recordVideo = FrameworkConstants.VIDEO_RECORD;

        Playwright pw = Playwright.create();
        playwright.set(pw);

        Browser br = launchBrowser(pw, browserName, isHeadless);
        browser.set(br);

        String fullBrowserInfo = browserName.substring(0, 1).toUpperCase() + browserName.substring(1) + " " + br.version();
        globalBrowserVersion.set(fullBrowserInfo);
        lastBrowserVersion = fullBrowserInfo;

        BrowserContext ctx = createBrowserContext(br, recordVideo);
        context.set(ctx);

        Page pg = ctx.newPage();
        pg.setDefaultTimeout(defaultTimeout);
        page.set(pg);
    }

    /**
     * Retrieves the Page object for the current thread.
     *
     * @return The Page object. Throws an IllegalStateException if the driver is not initialized.
     */
    public static Page getPage() {
        if (page.get() == null) {
            throw new IllegalStateException("DriverManager.page is null. Please call initDriver() first.");
        }
        return page.get();
    }

    /**
     * Closes all Playwright resources in the correct order for the current thread.
     * This includes closing the context, browser, and the Playwright instance itself.
     * It also cleans up the ThreadLocal variables to prevent memory leaks.
     */
    public static Path closeDriver(String scenarioUUID) {
        Page pg = page.get();
        Video vid = null;

        // 1) Close page to finalize the video
        try {
            if (pg != null) {
                vid = pg.video();     // capture handle before closing (safer)
                pg.close();           // this triggers video finalization
            }
        } catch (Exception ignored) {
            // still try to close the rest
        }

        // 2) Resolve source video path (only valid after close)
        Path src = null;
        if (vid != null) {
            try {
                src = vid.path();     // will throw if page wasn't closed successfully
            } catch (Exception ignored) {
                // src will remain null
            }
        }

        // 3) Close context → browser → Playwright, and clear ThreadLocals
        try {
            if (context.get() != null) context.get().close();
        } catch (Exception ignored) {
        } finally {
            context.remove();
        }
        try {
            if (browser.get() != null) browser.get().close();
        } catch (Exception ignored) {
        } finally {
            browser.remove();
            page.remove();
        }
        try {
            if (playwright.get() != null) playwright.get().close();
        } catch (Exception ignored) {
        } finally {
            playwright.remove();
        }

        // 4) If no video recorded, we’re done
        if (src == null) {
            return null;
        }

        // 5) Wait until the file is visible & stable on disk (handles CI/fs lag)
        try {
            waitForFileReady(src, Duration.ofSeconds(60), Duration.ofMillis(300));
        } catch (Exception e) {
            // If it still doesn't appear, bail
            return null;
        }

        // 6) Build destination path using scenario UUID and original extension
        try {
            Path targetDir = Paths.get("reports/latest/custom-report/videos");
            Files.createDirectories(targetDir);

            String ext = getExtensionWithDot(src.getFileName().toString()); // like ".webm" / ".mp4" or ""
            Path dest = targetDir.resolve(scenarioUUID + ext);

            Files.move(src, dest, StandardCopyOption.REPLACE_EXISTING);
            return dest;
        } catch (Exception e) {
            return null;
        }
    }

    /** Waits until file exists and its size is stable across two consecutive polls. */
    private static void waitForFileReady(Path path, Duration timeout, Duration pollEvery) throws Exception {
        long deadline = System.nanoTime() + timeout.toNanos();
        long lastSize = -1L;
        int stableReads = 0;

        while (System.nanoTime() < deadline) {
            if (Files.exists(path)) {
                long size = Files.size(path);
                if (size > 0 && size == lastSize) {
                    stableReads++;
                    if (stableReads >= 2) return; // stable twice in a row -> good
                } else {
                    stableReads = 0;
                }
                lastSize = size;
            }
            Thread.sleep(pollEvery.toMillis());
        }
        if (!Files.exists(path)) {
            throw new java.io.IOException("Video not found within timeout: " + path);
        }
    }

    /** Returns extension including dot (".webm") or empty string if none. */
    private static String getExtensionWithDot(String filename) {
        int dot = filename.lastIndexOf('.');
        return (dot >= 0) ? filename.substring(dot) : "";
    }


    // --- Private Helper Methods ---

    private static Browser launchBrowser(Playwright playwright, String browserName, boolean headless) {
        BrowserType.LaunchOptions launchOptions = new BrowserType.LaunchOptions()
                .setHeadless(headless)
                .setArgs(java.util.List.of("--start-maximized"));

        switch (browserName.toLowerCase().trim()) {
            case "chrome":
                launchOptions.setChannel("chrome");
                return playwright.chromium().launch(launchOptions);
            case "edge":
                launchOptions.setChannel("msedge");
                return playwright.chromium().launch(launchOptions);
            case "firefox":
                return playwright.firefox().launch(launchOptions);
            case "safari":
            case "webkit":
                return playwright.webkit().launch(launchOptions);
            case "chromium":
            default:
                return playwright.chromium().launch(launchOptions);
        }
    }

    private static BrowserContext createBrowserContext(Browser browser, boolean recordVideo) {
        Browser.NewContextOptions contextOptions = new Browser.NewContextOptions()
                .setViewportSize(null) // null for maximized viewport
                .setAcceptDownloads(true)
                .setIgnoreHTTPSErrors(true);

        if (recordVideo) {
            contextOptions.setRecordVideoDir(Paths.get("reports/latest/videos/"));
            contextOptions.setRecordVideoSize(1280, 720);
        }

        return browser.newContext(contextOptions);
    }
}