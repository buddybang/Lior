package com.mashreq.automation.tcoe.constants;

/**
 * AUTO-GENERATED. Do not edit manually.
 * Source: OR_OAT.json
 * Format: SCREEN_FIELD = "MODULE/SCREEN/FIELD"
 */
public final class OAT {

    private OAT() {}

    // ===== Loginflow =====
    public static final String LOGINFLOW_PAGE1TITLE = "OAT/Loginflow/Page1title";
    public static final String LOGINFLOW_PAGE1SUBTITLE = "OAT/Loginflow/Page1subtitle";
    public static final String LOGINFLOW_PAGE2TITLE = "OAT/Loginflow/Page2title";
    public static final String LOGINFLOW_PAGE2SUBTITLE = "OAT/Loginflow/Page2subtitle";
    public static final String LOGINFLOW_PAGE3TITLE = "OAT/Loginflow/Page3title";
    public static final String LOGINFLOW_PAGE3SUBTITLE = "OAT/Loginflow/Page3subtitle";
    public static final String LOGINFLOW_PAGE4TITLE = "OAT/Loginflow/Page4title";
    public static final String LOGINFLOW_PAGE4SUBTITLE = "OAT/Loginflow/Page4subtitle";
    public static final String LOGINFLOW_USERID = "OAT/Loginflow/Userid";
    public static final String LOGINFLOW_LOGINWITHPASSWORD = "OAT/Loginflow/Loginwithpassword";
    public static final String LOGINFLOW_LOGIN = "OAT/Loginflow/Login";
    public static final String LOGINFLOW_PASSWORD = "OAT/Loginflow/Password";
    public static final String LOGINFLOW_FORWARDARROW = "OAT/Loginflow/ForwardArrow";
    public static final String LOGINFLOW_LOGIN1 = "OAT/Loginflow/Login1";
    public static final String LOGINFLOW_LOGINPIN = "OAT/Loginflow/Loginpin";
    public static final String LOGINFLOW_SETUPYOURLOGINPIN = "OAT/Loginflow/Setupyourloginpin";
    public static final String LOGINFLOW_CONFIRMLOGINPIN = "OAT/Loginflow/Confirmloginpin";
    public static final String LOGINFLOW_CONTINUE = "OAT/Loginflow/Continue";
    public static final String LOGINFLOW_PINCONTINUE = "OAT/Loginflow/PINContinue";
    public static final String LOGINFLOW_BIOMETRICSLATER = "OAT/Loginflow/Biometricslater";
    public static final String LOGINFLOW_LOGIN2 = "OAT/Loginflow/Login2";
    public static final String LOGINFLOW_LOGINWITHPIN = "OAT/Loginflow/LoginwithPIN";
    public static final String LOGINFLOW_ENTERSIXDIGITPIN = "OAT/Loginflow/EntersixdigitPIN";
    public static final String LOGINFLOW_TERMSANDCONDITION = "OAT/Loginflow/Termsandcondition";
    public static final String LOGINFLOW_AGREEANDCONTINUE = "OAT/Loginflow/Agreeandcontinue";
    public static final String LOGINFLOW_BACK = "OAT/Loginflow/Back";
    public static final String LOGINFLOW_BACKARROW = "OAT/Loginflow/Backarrow";
    public static final String LOGINFLOW_HELP = "OAT/Loginflow/Help";
    public static final String LOGINFLOW_LANGUAGE = "OAT/Loginflow/Language";
    public static final String LOGINFLOW_NEWCORPTEXT = "OAT/Loginflow/Newcorptext";
    public static final String LOGINFLOW_SIGINTEXT = "OAT/Loginflow/sigintext";
    public static final String LOGINFLOW_HELPICON = "OAT/Loginflow/Helpicon";
    public static final String LOGINFLOW_HELPYOU = "OAT/Loginflow/Helpyou";
    public static final String LOGINFLOW_PHONE = "OAT/Loginflow/Phone";
    public static final String LOGINFLOW_EMAIL = "OAT/Loginflow/Email";
    public static final String LOGINFLOW_ASKEDQUESTIONS = "OAT/Loginflow/Askedquestions";
    public static final String LOGINFLOW_ARROW = "OAT/Loginflow/Arrow";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONS1 = "OAT/Loginflow/Frequentlyaskedquestions1";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONSSUBTITLE1 = "OAT/Loginflow/Frequentlyaskedquestionssubtitle1";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONS2 = "OAT/Loginflow/Frequentlyaskedquestions2";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONSSUBTITLE2 = "OAT/Loginflow/Frequentlyaskedquestionssubtitle2";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONS3 = "OAT/Loginflow/Frequentlyaskedquestions3";
    public static final String LOGINFLOW_VIEWALLFAQS = "OAT/Loginflow/ViewallFAQs";
    public static final String LOGINFLOW_ERRORMESSAGE = "OAT/Loginflow/Errormessage";

    // ===== Make_Payment =====
    public static final String MAKE_PAYMENT_MAKEPAYMENT = "OAT/Make_Payment/MakePayment";
    public static final String MAKE_PAYMENT_BENEFICIARYACCOUNT = "OAT/Make_Payment/BeneficiaryAccount";
    public static final String MAKE_PAYMENT_OTHERSELFACCOUNTS = "OAT/Make_Payment/OtherSelfAccounts";
    public static final String MAKE_PAYMENT_SEARCHVALUECREDIT = "OAT/Make_Payment/SearchvalueCredit";
    public static final String MAKE_PAYMENT_SELECTACCNUMBERDEBIT = "OAT/Make_Payment/SelectAccNumberDebit";
    public static final String MAKE_PAYMENT_SELECTACCNUMBERCREDIT = "OAT/Make_Payment/SelectAccNumberCredit";
    public static final String MAKE_PAYMENT_CONTINUE = "OAT/Make_Payment/Continue";
    public static final String MAKE_PAYMENT_DEBITACCOUNT = "OAT/Make_Payment/DebitAccount";
    public static final String MAKE_PAYMENT_CONVENTIONALACCOUNTS = "OAT/Make_Payment/ConventionalAccounts";
    public static final String MAKE_PAYMENT_SEARCHVALUEDEBIT = "OAT/Make_Payment/SearchvalueDebit";
    public static final String MAKE_PAYMENT_DEBIT_ACCOUNT_CCY = "OAT/Make_Payment/debit_account_CCY";
    public static final String MAKE_PAYMENT_CREDIT_ACCOUNT_CURRENCY = "OAT/Make_Payment/Credit_Account_Currency";
    public static final String MAKE_PAYMENT_SELECTCURRENCY = "OAT/Make_Payment/SelectCurrency";
    public static final String MAKE_PAYMENT_DEBIT_ACCOUNT_CURRENCY = "OAT/Make_Payment/Debit_Account_Currency";
    public static final String MAKE_PAYMENT_SELECT_DEBIT_CURRENCY = "OAT/Make_Payment/Select_Debit_Currency";
    public static final String MAKE_PAYMENT_RETRIEVEDEBITACC = "OAT/Make_Payment/RetrieveDebitAcc";
    public static final String MAKE_PAYMENT_RETRIEVECREDITACC = "OAT/Make_Payment/RetrieveCreditAcc";
    public static final String MAKE_PAYMENT_TRANSFERAMOUNT = "OAT/Make_Payment/TransferAmount";
    public static final String MAKE_PAYMENT_RET_TRANSFER_AMOUNT = "OAT/Make_Payment/Ret_Transfer_Amount";
    public static final String MAKE_PAYMENT_VALUEDATE = "OAT/Make_Payment/ValueDate";
    public static final String MAKE_PAYMENT_CALENDAR_TODAY = "OAT/Make_Payment/Calendar_Today";
    public static final String MAKE_PAYMENT_RET_VALUE_DATE = "OAT/Make_Payment/Ret_Value_Date";
    public static final String MAKE_PAYMENT_RETRIEVEEXCHANGERATE = "OAT/Make_Payment/RetrieveExchangeRate";
    public static final String MAKE_PAYMENT_RETRIEVETRANSFERAMT = "OAT/Make_Payment/RetrieveTransferAmt";
    public static final String MAKE_PAYMENT_RETRIEVECREDITAMT = "OAT/Make_Payment/RetrieveCreditAmt";
    public static final String MAKE_PAYMENT_RET_DEBIT_AMT = "OAT/Make_Payment/Ret_Debit_Amt";
    public static final String MAKE_PAYMENT_DEAL_REFERENCE = "OAT/Make_Payment/Deal_Reference";
    public static final String MAKE_PAYMENT_INPUT_DEAL_ID = "OAT/Make_Payment/Input_Deal_ID";
    public static final String MAKE_PAYMENT_VERIFY_DEAL = "OAT/Make_Payment/Verify_Deal";
    public static final String MAKE_PAYMENT_VERIFY = "OAT/Make_Payment/verify";
    public static final String MAKE_PAYMENT_EXCHANGE_RATE = "OAT/Make_Payment/exchange_rate";
    public static final String MAKE_PAYMENT_TRANSFER_AMOUNT = "OAT/Make_Payment/Transfer_Amount";
    public static final String MAKE_PAYMENT_CREDIT_AMOUNT = "OAT/Make_Payment/Credit_Amount";
    public static final String MAKE_PAYMENT_DEBIT_AMOUNT = "OAT/Make_Payment/Debit_Amount";
    public static final String MAKE_PAYMENT_CUSTOMER_REFERENCE_CONTINUE = "OAT/Make_Payment/Customer_Reference_Continue";
    public static final String MAKE_PAYMENT_CUSTOMER_REF_NUM = "OAT/Make_Payment/Customer_Ref_Num";
    public static final String MAKE_PAYMENT_RET_CUSTOMER_REF_NUM = "OAT/Make_Payment/Ret_Customer_Ref_Num";
    public static final String MAKE_PAYMENT_CUSTOMER_REFERENCE_FINAL_CONTINUE = "OAT/Make_Payment/Customer_Reference_Final_Continue";
    public static final String MAKE_PAYMENT_VERIFY_CREDIT_ACC = "OAT/Make_Payment/Verify_Credit_Acc";
    public static final String MAKE_PAYMENT_VERIFY_DEBIT_ACC = "OAT/Make_Payment/Verify_Debit_Acc";
    public static final String MAKE_PAYMENT_VERIFY_VALUE_DATE = "OAT/Make_Payment/Verify_Value_Date";
    public static final String MAKE_PAYMENT_VERIFY_CUSTOMER_REF_NUM = "OAT/Make_Payment/Verify_Customer_Ref_Num";
    public static final String MAKE_PAYMENT_VERIFY_EXCHANGE_RATE = "OAT/Make_Payment/Verify_Exchange_Rate";
    public static final String MAKE_PAYMENT_VERIFY_TRANSFER_AMT = "OAT/Make_Payment/Verify_Transfer_Amt";
    public static final String MAKE_PAYMENT_VERIFY_DEBIT_AMT = "OAT/Make_Payment/Verify_Debit_Amt";
    public static final String MAKE_PAYMENT_VERIFY_CREDIT_AMT = "OAT/Make_Payment/Verify_Credit_Amt";
    public static final String MAKE_PAYMENT_CONFIRM = "OAT/Make_Payment/Confirm";
    public static final String MAKE_PAYMENT_MAKSUCCESSMESSAGE = "OAT/Make_Payment/MakSuccessmessage";
    public static final String MAKE_PAYMENT_TRANSACTIONREFERENCENUMBER = "OAT/Make_Payment/TransactionReferenceNumber";
    public static final String MAKE_PAYMENT_SUBMIT = "OAT/Make_Payment/Submit";

    // ===== Payment Tracker =====
    public static final String PAYMENT_TRACKER_PAYMENT_TRACKER = "OAT/Payment Tracker/Payment Tracker";
    public static final String PAYMENT_TRACKER_SEARCH = "OAT/Payment Tracker/Search";
    public static final String PAYMENT_TRACKER_TRANSACTION_DETAILS = "OAT/Payment Tracker/transaction details";
    public static final String PAYMENT_TRACKER_JOURNEY_HISTORY = "OAT/Payment Tracker/Journey History";
    public static final String PAYMENT_TRACKER_TRANSACTION_STATUS_HISTORY = "OAT/Payment Tracker/transaction status history";
    public static final String PAYMENT_TRACKER_DOWNLOAD = "OAT/Payment Tracker/Download";

}
