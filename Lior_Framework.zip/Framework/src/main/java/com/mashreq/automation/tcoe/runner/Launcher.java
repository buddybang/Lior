package com.mashreq.automation.tcoe.runners;

public class Launcher {
    public static void main(String[] args) {
        String[] defaults = new String[] {
                "--glue", "com.mashreq.automation.tcoe.steps",
                "--plugin", "pretty",
                "--plugin", "json:target/cucumber-reports/cucumber.json",
                "--plugin", "html:target/cucumber-reports/cucumber-report.html"
        };

        String[] merged = new String[defaults.length + args.length];
        System.arraycopy(defaults, 0, merged, 0, defaults.length);
        System.arraycopy(args, 0, merged, defaults.length, args.length);

        // Explicit FQN avoids class name clashes
        byte status = io.cucumber.core.cli.Main.run(
                merged,
                Thread.currentThread().getContextClassLoader()
        );
        System.exit(status);
    }
}

