package com.mashreq.automation.tcoe.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.mashreq.automation.tcoe.constants.FrameworkConstants;
import com.mashreq.automation.tcoe.context.Platform;
import com.mashreq.automation.tcoe.context.ScenarioContext;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public final class DataHandler {

    private static final Logger LOGGER = LogManager.getLogger(DataHandler.class);

    // Jackson ObjectMapper is thread-safe after configuration.
    private static final ObjectMapper objectMapper = new ObjectMapper();

    // Cache resolved locators by OR path ("MODULE/Screen/Field") to avoid repeated
    // file reads.
    private static final Map<String, String> LOCATOR_CACHE = new ConcurrentHashMap<>();

    private final String currentRegion = FrameworkConstants.REGION;
    private final String baseRoot = "test_data";
    private final String prereqbaseRoot = "prereq_test_data";
    private ScenarioContext ctx;

    @Getter
    @Setter
    private String scenarioId;
    private String datasetId;

    /*
     * =========================================================
     * LOCATOR RESOLUTION (PATH-BASED)
     * =========================================================
     */

    /**
     * Resolve a path-based OR key like
     * {@code "CASA/AccountOpening/CompositeMISCode"}
     * to the actual locator (XPath/CSS) from {@code OR_<MODULE>.json}.
     *
     * @param path module/screen/field (e.g.,
     *             "CASA/AccountOpening/CompositeMISCode")
     * @return Optional locator string
     */
    public Optional<String> getLocatorByPath(String path) {
        if (path == null || path.isBlank())
            return Optional.empty();

        // Web and mobile have separate object repositories, so the cache is per platform too
        Platform platform = Platform.current();
        String cacheKey = (platform == null ? "ANY" : platform.name()) + ":" + path;
        String cached = LOCATOR_CACHE.get(cacheKey);
        if (cached != null)
            return Optional.of(cached);

        String[] parts = path.split("/", 3);
        if (parts.length != 3) {
            LogUtils.error("Invalid OR path (expected MODULE/SCREEN/FIELD): " + path);
            return Optional.empty();
        }
        String module = parts[0];
        String screen = parts[1];
        String field = parts[2]; // supports dotted sub-keys, e.g., "Header.CompositeMISCode"

        Optional<String> resolved = getLocatorInternal(module, screen, field, platform);
        resolved.ifPresent(val -> LOCATOR_CACHE.put(cacheKey, val));
        return resolved;
    }

    /**
     * Clear the in-memory locator cache (e.g., if OR files are hot-swapped
     * mid-run).
     */
    public void clearLocatorCache() {
        LOCATOR_CACHE.clear();
    }

    // Internal: resolve using module/screen/field, reading OR_<module>.json
    // (case-insensitive).
    private Optional<String> getLocatorInternal(String module, String screenName, String fieldName, Platform platform) {
        try {
            File orFile = resolveObjectRepoFile(module, platform);
            if (orFile == null || !orFile.isFile()) {
                LogUtils.error("OR file OR_" + module + ".json not found for this "
                        + (platform == null ? "" : platform.name().toLowerCase(Locale.ROOT) + " ") + "scenario in "
                        + (platform == null ? FrameworkConstants.OBJECT_REPO_WEB_PATH + " or " + FrameworkConstants.OBJECT_REPO_MOBILE_PATH
                        : FrameworkConstants.objectRepoPath(platform))
                        + " (web and mobile scenarios each read only their own folder).");
                return Optional.empty();
            }

            JsonNode rootNode = objectMapper.readTree(orFile);

            if (rootNode.isArray()) {
                for (JsonNode locatorObject : rootNode) {
                    if (locatorObject.has(screenName)) {
                        JsonNode screenNode = locatorObject.get(screenName);

                        // support nested field path with dots
                        String[] fieldPath = (fieldName == null) ? new String[0] : fieldName.split("\\.");
                        JsonNode currentNode = screenNode;
                        String lastExistingPathPart = null; // Rajendra Updates

                        for (String pathPart : fieldPath) {
                            if (currentNode != null && currentNode.has(pathPart)) {
                                currentNode = currentNode.get(pathPart);
                                lastExistingPathPart = pathPart; // track last key that existed
                            } else {
                                currentNode = null;
                                break;
                            }
                        }

                        // Object Repository entries store the actual "locator" under a
                        // platform-specific sub-node (e.g. "android" / "ios") rather than
                        // directly on the field node. If the resolved field node has no
                        // direct "locator" key, descend into the current mobile platform
                        // sub-node before giving up. This is what makes paths like
                        // "Mobile/Loginflow/toLoginPage" resolve correctly.
                        if (currentNode != null && !currentNode.has("locator") && platform != Platform.WEB) {
                            JsonNode platformNode = resolvePlatformNode(currentNode);
                            if (platformNode != null) {
                                currentNode = platformNode;
                            }
                        }

                        if (currentNode != null && currentNode.has("locator")) {
                            // compute field name (final part)
                            String finalField = (lastExistingPathPart != null && !lastExistingPathPart.isEmpty())
                                    ? lastExistingPathPart
                                    : (fieldPath.length > 0 ? fieldPath[fieldPath.length - 1] : "");

                            String locatorText = currentNode.get("locator").asText(null);

                            // Return combined "field|locator"
                            String combined = finalField + "|" + (locatorText == null ? "" : locatorText);
                            return Optional.of(combined);
                        }
                    }
                }
            }
        } catch (IOException e) {
            LogUtils.error("Error reading OR file for module '" + module + "': " + e.getMessage());
        }
        return Optional.empty();
    }

    /**
     * Determine the current mobile platform (android/ios) sub-node that actually
     * contains the {@code locator} for a field entry. Object Repository entries are
     * shaped like:
     *
     * <pre>
     * "toLoginPage": {
     *     "android": { "locator": "...", "type": "BUTTON" },
     *     "ios":     { "locator": "...", "type": "BUTTON" }
     * }
     * </pre>
     *
     * The platform is taken from {@code FrameworkConstants.MOBILE_PLATFORM} (or the
     * {@code -Dplatform} system property) and falls back gracefully to whichever
     * platform node is present.
     *
     * @param fieldNode the resolved field node (e.g. the "toLoginPage" node)
     * @return the platform sub-node that has a {@code locator}, or {@code null}
     */
    private JsonNode resolvePlatformNode(JsonNode fieldNode) {
        if (fieldNode == null || !fieldNode.isObject()) {
            return null;
        }

        // Preferred platform: framework constant first, then -Dplatform, default android.
        String platform = FrameworkConstants.MOBILE_PLATFORM;
        if (platform == null || platform.isBlank()) {
            platform = System.getProperty("platform");
        }
        if (platform == null || platform.isBlank()) {
            platform = "android";
        }
        platform = platform.trim().toLowerCase(Locale.ROOT);

        // Try the preferred platform, then the common alternatives as a fallback so a
        // locator is still resolved even if the preferred platform node is absent.
        String[] platformCandidates = new String[] { platform, "android", "ios" };
        for (String candidate : platformCandidates) {
            if (fieldNode.has(candidate)) {
                JsonNode node = fieldNode.get(candidate);
                if (node != null && node.has("locator")) {
                    return node;
                }
            }
        }
        return null;
    }

    /**
     * Resolve OR file for a module in a case-insensitive way.
     * Tries multiple casings and a directory scan as a fallback.
     *
     * <p>
     * NOTE: {@link FrameworkConstants#OBJECT_REPO_PATH} is derived from
     * {@code System.getProperty("user.dir")}, which on some environments comes back
     * URL-encoded (e.g. spaces appear as {@code %20} for a folder like
     * "Native Mobile Apps"). A raw {@code %20} in the path prevents the OR JSON
     * file
     * from ever being located on disk, which surfaces as a misleading
     * "OR path not found" error. To be resilient we try BOTH the raw base path and
     * a
     * URL-decoded variant of it.
     * </p>
     */
    private File resolveObjectRepoFile(String module, Platform platform) {
        // the folder of the running scenario's platform only; both folders only outside a scenario (tools / generators)
        java.util.List<String> folders = new java.util.ArrayList<>();
        if (platform == null) {
            folders.add(FrameworkConstants.OBJECT_REPO_WEB_PATH);
            folders.add(FrameworkConstants.OBJECT_REPO_MOBILE_PATH);
        } else {
            folders.add(FrameworkConstants.objectRepoPath(platform));
        }
        // Build a robust, de-duplicated list of base directories to search. On some
        // environments System.getProperty("user.dir") is URL-encoded (spaces come back
        // as "%20" for a folder like "Native Mobile Apps"). A literal "%20" in the path
        // means Java's File API can never locate the OR JSON on disk, which surfaces as
        // the misleading "OR path not found" error. We therefore try BOTH the raw base
        // and a decoded variant, and additionally fall back to the compiled classpath
        // copy under target/classes/objectrepo.
        java.util.LinkedHashSet<String> baseCandidates = new java.util.LinkedHashSet<>();
        for (String rawBase : folders) {
            baseCandidates.add(rawBase);
            baseCandidates.add(decodePath(rawBase));
        }
        String[] fileCandidates = new String[] {
                "OR_" + module + ".json",
                "OR_" + module.toUpperCase(Locale.ROOT) + ".json",
                "OR_" + module.toLowerCase(Locale.ROOT) + ".json",
                "OR_" + capitalize(module) + ".json"
        };
        for (String base : baseCandidates) {
            if (base == null || base.isBlank())
                continue;
            for (String name : fileCandidates) {
                File f = new File(base, name);
                if (f.isFile())
                    return f;
            }
            // Fallback: scan directory for case-insensitive match
            File dir = new File(base);
            File[] matches = dir.listFiles(
                    (d, n) -> n.toLowerCase(Locale.ROOT).equals(("OR_" + module + ".json").toLowerCase(Locale.ROOT)));
            if (matches != null && matches.length > 0)
                return matches[0];
        }

        // Final fallback: load the OR file from the runtime classpath (target/classes
        // or a packaged jar), which is immune to any user.dir encoding problems.
        for (String folder : folders) {
            String sub = new File(folder).getName(); // "Web" or "Mobile"
            File classpathFile = resolveObjectRepoFromClasspath(sub, fileCandidates);
            if (classpathFile != null)
                return classpathFile;
        }

        return null;
    }

    /**
     * Resolve the OR JSON for a module from the runtime classpath (e.g.
     * {@code target/classes/objectrepo/OR_TermDeposit.json}). This is used as a last
     * resort when the filesystem base derived from {@code user.dir} cannot be
     * located (for example because it is URL-encoded and contains {@code %20}).
     */
    private File resolveObjectRepoFromClasspath(String platformFolder, String[] fileCandidates) {
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        if (cl == null) {
            cl = DataHandler.class.getClassLoader();
        }
        for (String name : fileCandidates) {
            java.net.URL resource = cl.getResource("objectrepo/" + platformFolder + "/" + name);
            if (resource == null)
                continue;
            if (!"file".equalsIgnoreCase(resource.getProtocol()))
                continue; // packaged in a jar; readTree(File) cannot be used
            try {
                File f = new File(resource.toURI());
                if (f.isFile())
                    return f;
            } catch (java.net.URISyntaxException ignored) {
                // fall through and try the next candidate
            }
        }
        return null;
    }

    /**
     * Decode a filesystem path that may contain URL-encoded characters (e.g.
     * {@code %20}
     * for spaces). If the input is not encoded or cannot be decoded, the original
     * value
     * is returned unchanged.
     */
    private static String decodePath(String path) {
        if (path == null || path.isBlank())
            return path;
        try {
            String decoded = java.net.URLDecoder.decode(path, java.nio.charset.StandardCharsets.UTF_8);
            return decoded;
        } catch (Exception e) {
            return path;
        }
    }

    private static String capitalize(String s) {
        if (s == null || s.isEmpty())
            return s;
        return s.substring(0, 1).toUpperCase(Locale.ROOT) + s.substring(1).toLowerCase(Locale.ROOT);
    }

    /*
     * =========================================================
     * TEST DATA (unchanged logic, path-friendly)
     * =========================================================
     */

    public String getTestDataOrThrow(String module, String scenarioId, String fieldPath) {

        File testDataJsonPath = getTestDatapath(module);
        return getTestData(module, scenarioId, fieldPath, testDataJsonPath)
                .orElseThrow(() -> new IllegalArgumentException(
                        String.format("Missing test data for module='%s', scenario='%s', field='%s' in file='%s'",
                                module, scenarioId, fieldPath, testDataJsonPath.getAbsolutePath())));
    }

    public File getTestDatapath(String module) {
        String moduleUpper = module.toUpperCase();

        // Matches: 00., 01., 02., ..., 99. (followed by your module name)
        String regexFolder = "\\d{2}\\." + moduleUpper + ".*";

        File root = new File(FrameworkConstants.TEST_DATA_PATH);

        File[] matchedFolders = root.listFiles((dir, name) -> name.matches(regexFolder));

        if (matchedFolders == null || matchedFolders.length == 0) {
            throw new RuntimeException("No folder found matching pattern: " + regexFolder
                    + " under " + root.getAbsolutePath());
        }

        Arrays.sort(matchedFolders, (a, b) -> {
            int na = Integer.parseInt(a.getName().substring(0, 2)); // "00" -> 0
            int nb = Integer.parseInt(b.getName().substring(0, 2));
            return Integer.compare(nb, na); // descending (pick largest)
        });

        File moduleFolder = matchedFolders[0];

        File testDataJsonPath = new File(moduleFolder, currentRegion + "_TestData_" + module.toUpperCase() + ".json");

        LOGGER.info("Resolved Path = " + testDataJsonPath.getAbsolutePath());
        return testDataJsonPath;
    }

    private Optional<String> getTestData(String module, String scenarioId, String fieldPath, File testDataJsonPath) {
        String effectiveScenarioId = (scenarioId == null || scenarioId.isBlank())
                ? this.getScenarioId()
                : scenarioId;
        String tmpreferenceScenarioId = effectiveScenarioId;
        datasetId = "";
        String effectiveModule = module;
        // Setting datasetId if scenarioId starts with "Prereq"
        if (tmpreferenceScenarioId.toLowerCase().startsWith("prereq")) {
            String[] subparts = tmpreferenceScenarioId.trim().split("\\_");
            datasetId = subparts[1].trim();
            tmpreferenceScenarioId = subparts[2].trim() + "_" + subparts[3].trim();
            module = subparts[0].trim().toLowerCase().replace("prereq", "");
            if (module.isBlank()) {
                module = effectiveModule;
            }
        }
        testDataJsonPath = getTestDatapath(module);

        try {
            JsonNode root = objectMapper.readTree(testDataJsonPath);

            JsonNode scenarioNode;
            if (datasetId == null || datasetId.isBlank() || module.equalsIgnoreCase("common")) {
                scenarioNode = root.path(baseRoot).path(tmpreferenceScenarioId);
            } else {
                scenarioNode = root.path(prereqbaseRoot).path(tmpreferenceScenarioId).path(datasetId);
            }
            if (scenarioNode.isMissingNode() || scenarioNode.isNull()) {
                return Optional.empty();
            }

            JsonNode current = scenarioNode;
            for (String part : fieldPath.split("\\.")) {
                if (current.isObject()) {
                    current = current.path(part);
                } else if (current.isArray()) {
                    try {
                        int idx = Integer.parseInt(part);
                        current = current.path(idx);
                    } catch (NumberFormatException nfe) {
                        return Optional.empty();
                    }
                } else {
                    return Optional.empty();
                }

                if (current.isMissingNode() || current.isNull()) {
                    return Optional.empty();
                }
            }

            if (current.isValueNode()) {

                String value = current.asText(null);
                /*
                 * Start - Added to check if test data is in format{{referencedField}}, if so
                 * get test data using
                 * getTestData using referencedField- Kumaran 29-Sep-25
                 */
                if (value != null && value.matches("\\{\\{(.+?)}}")) {
                    String innerContent = value.substring(2, value.length() - 2).trim();
                    String referenceScenarioId;

                    String referencedField;
                    if (innerContent.contains("|")) {
                        String[] parts = innerContent.split("\\|");
                        if (parts.length == 3) {
                            datasetId = parts[0].trim() + "_" + parts[1].trim();
                            referenceScenarioId = datasetId + "_" + tmpreferenceScenarioId; // Use the reference
                            // scenarioId in parameter
                            referencedField = parts[2].trim(); // Use the reference field in parameter
                        } else {
                            referenceScenarioId = parts[0].trim(); // Use the reference scenarioId in parameter
                            referencedField = parts[1].trim(); // Use the reference field in parameter
                        }
                    } else {
                        referenceScenarioId = effectiveScenarioId; // Use the default scenario ID
                        referencedField = innerContent;
                    }
                    return getTestData(module, referenceScenarioId, referencedField, testDataJsonPath);
                }
                // End - Kumaran 29-Sep-25

                return Optional.ofNullable(TestDataTokens.resolve(value)); // ${unique}, ${today:+5} ...
            }
            return Optional.of(current.toString());

        } catch (IOException e) {
            return Optional.empty();
        }
    }

    /**
     * Writes/updates a value in the test data file for the given scenario.
     */
    public void writeTestData(String module, String scenarioId, String fieldName, String newValue) {
        try {
            if (scenarioId == null) {
                LogUtils.debug("Scenario id is set to null. Kindly recheck");
                scenarioId = "";
            }
            // Setting datasetId if scenarioId starts with "Prereq"
            if (scenarioId.toLowerCase().startsWith("prereq")) {
                String[] subparts = scenarioId.trim().split("\\_");
                datasetId = subparts[1].trim();
                scenarioId = subparts[2].trim() + "_" + subparts[3].trim();
                module = subparts[0].trim().toLowerCase().replace("prereq", "");
            }

            File testDataJsonPath = getTestDatapath(module);

            JsonNode rootNode = objectMapper.readTree(testDataJsonPath);
            ObjectNode testDataNode = null;

            if (datasetId == null || datasetId.isBlank()) {
                testDataNode = (ObjectNode) rootNode.path(baseRoot);
            } else {
                testDataNode = (ObjectNode) rootNode.path(prereqbaseRoot);
            }
            if (testDataNode.has(scenarioId)) {
                ObjectNode scenarioNode = (ObjectNode) testDataNode.get(scenarioId);
                if (scenarioNode.has(datasetId)) {
                    scenarioNode = (ObjectNode) testDataNode.get(scenarioId).get(datasetId);
                } else {
                    scenarioNode = (ObjectNode) testDataNode.get(scenarioId);
                }
                String[] fieldPath = fieldName.split("\\.");
                ObjectNode parentNode = scenarioNode;
                String leaf = fieldPath[fieldPath.length - 1];

                for (int i = 0; i < fieldPath.length - 1; i++) {
                    String part = fieldPath[i];
                    if (parentNode.has(part) && parentNode.get(part).isObject()) {
                        parentNode = (ObjectNode) parentNode.get(part);
                    } else {
                        LogUtils.error("Path not found: " + fieldName);
                        return;
                    }
                }

                if (parentNode.has(leaf) && parentNode.get(leaf).isArray()) {
                    ArrayNode newArray = objectMapper.createArrayNode();
                    newArray.add(newValue);
                    parentNode.set(leaf, newArray);

                } else {
                    parentNode.put(leaf, newValue);

                }

                objectMapper.writerWithDefaultPrettyPrinter()
                        .writeValue(testDataJsonPath, rootNode);

            } else {
                LogUtils.error("Scenario ID not found: " + scenarioId);
            }
        } catch (IOException e) {
            LogUtils.error("Error writing to test data file: " + e.getMessage());
        }
    }

    public String getScenarioId() {
        return scenarioId;
    }

}