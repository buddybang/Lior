package com.mashreq.automation.tcoe.utils;

import com.mashreq.automation.tcoe.context.ScreenshotContextHolder;
import com.microsoft.playwright.Page;
import com.mashreq.automation.tcoe.driver.DriverManager;
import io.cucumber.java.Scenario;


import com.mashreq.automation.tcoe.context.ScreenshotContextHolder;
import com.microsoft.playwright.Page;
import com.mashreq.automation.tcoe.driver.DriverManager;
import io.appium.java_client.AppiumDriver;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public final class CaptureHelpers {

    private CaptureHelpers() {}

    public static String takeScreenshot(Page page, String scenarioId) {
        try {
            Integer step = ScreenshotContextHolder.getStepNo();
            Integer action = ScreenshotContextHolder.getActionNo();

            if (step == null || action == null) {
                throw new IllegalStateException("Step or Action number not set in ScreenshotContextHolder.");
            }

            // Prepare folder structure
            Path projectRoot = Paths.get(System.getProperty("user.dir")).toAbsolutePath();
            Path reportsRoot = projectRoot.resolve("reports").resolve("latest").resolve("custom-report");
            Path screenshotsDir = reportsRoot.resolve("screenshots").resolve(scenarioId);
            Files.createDirectories(screenshotsDir);

            // Sanitize scenarioId
            String safeScenarioId = (scenarioId == null || scenarioId.isBlank())
                    ? "scenario"
                    : scenarioId.replaceAll("[^a-zA-Z0-9._-]", "_");

            // File name: <scenarioId>_<stepNo>_<actionNo>.png
            long currentTimeMillis = System.currentTimeMillis();
            String fileName = String.format("%s_%d_%d_%d.png", safeScenarioId, step, action, currentTimeMillis);
            Path destinationPath = screenshotsDir.resolve(fileName);

            // Capture screenshot
            page.screenshot(new Page.ScreenshotOptions().setPath(destinationPath));

            // Return relative path
            Path relativePath = projectRoot.relativize(destinationPath.toAbsolutePath());
            return "./" + relativePath.toString().replace("\\", "/");
        } catch (Exception e) {
            LogUtils.error("Exception while taking screenshot: " + e.getMessage(), e);
            return "";
        }
    }

// ---------------------------------------------------------------
    // SHARED HELPERS
    // ---------------------------------------------------------------

    /**
     * Builds and creates the directory structure for a screenshot file.
     * Pattern: {projectRoot}/reports/latest/custom-report/screenshots/{scenarioId}/{scenarioId}_{step}_{action}_{ts}.png
     *
     * @param scenarioId Raw scenario ID (sanitised internally).
     * @param step       Current step number.
     * @param action     Current action number within the step.
     * @return Fully resolved {@link Path} to the target screenshot file.
     */
    private static Path buildScreenshotPath(String scenarioId, int step, int action)
            throws Exception {
        String safeId = (scenarioId == null || scenarioId.isBlank())
                ? "scenario"
                : scenarioId.replaceAll("[^a-zA-Z0-9._-]", "_");

        Path projectRoot    = Paths.get(System.getProperty("user.dir")).toAbsolutePath();
        Path screenshotsDir = projectRoot
                .resolve("reports")
                .resolve("latest")
                .resolve("custom-report")
                .resolve("screenshots")
                .resolve(safeId);

        Files.createDirectories(screenshotsDir);

        String fileName = String.format("%s_%d_%d_%d.png",
                safeId, step, action, System.currentTimeMillis());

        return screenshotsDir.resolve(fileName);
    }

    public static String takeMobileScreenshot(AppiumDriver driver, String scenarioId) {
        if (driver == null) {
            LogUtils.warn("Skipping mobile screenshot — AppiumDriver is null.");
            return "";
        }

        try {
            Integer step   = ScreenshotContextHolder.getStepNo();
            Integer action = ScreenshotContextHolder.getActionNo();

            // Gracefully fall back to 0/0 if context hasn't been set yet
            // (e.g. screenshot triggered from a hook before any step runs).
            int safeStep   = (step   != null) ? step   : 0;
            int safeAction = (action != null) ? action : 0;

            // Appium drivers implement TakesScreenshot — cast and capture.
            byte[] screenshotBytes = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);

            Path destinationPath = buildScreenshotPath(scenarioId, safeStep, safeAction);
            Files.write(destinationPath, screenshotBytes);

            Path relativePath = Paths.get(System.getProperty("user.dir"))
                    .toAbsolutePath()
                    .relativize(destinationPath.toAbsolutePath());
            String result = "./" + relativePath.toString().replace("\\", "/");
            LogUtils.info("Mobile screenshot saved: " + result);
            return result;

        } catch (Exception e) {
            LogUtils.error("Failed to capture mobile screenshot: " + e.getMessage(), e);
            return "";
        }
    }

}