package com.mashreq.automation.tcoe.utils;

import com.mashreq.automation.tcoe.context.ScenarioContext;

public final class LocatorUtils {

    private static final DataHandler DATA = new DataHandler();

    private LocatorUtils() {}

    /** Use when you already have a full OR path or a generated constant (e.g., CASA.ACCOUNTOPENING_CUSTOMERID). */
    public static String byPath(String path) {
        return DATA.getLocatorByPath(path)
                .orElseThrow(() -> new IllegalArgumentException("OR path not found: " + path));
    }

    /** Use when the feature step gives you screen + field (module comes from TestContextHolder). */
    public static String byScreenField(String screen, String field) {
        String module = requireModule();
        String effectiveScreen = (screen == null || screen.isBlank()) ? requireScreen() : screen;
        String path = module + "/" + effectiveScreen + "/" + field;
        return byPath(path);
    }

    /** Use when the feature step gives only the field; module + screen are taken from TestContextHolder. */
    public static String byField(String field) {
        String module = requireModule();
        String screen = requireScreen();
        String path = module + "/" + screen + "/" + field;
        return byPath(path);
    }

    // ---- internal guards ----
    private static String requireModule() {
        String module = ScenarioContext.get().getCurrentModule();
        if (module == null || module.isBlank())
            throw new IllegalStateException("Current module not set in context. Set it after navigation.");
        return module;
    }

    private static String requireScreen() {
        String screen = ScenarioContext.get().getCurrentScreen();
        if (screen == null || screen.isBlank())
            throw new IllegalStateException("Current screen not set in context. Provide explicitly or set in context.");
        return screen;
    }
}
