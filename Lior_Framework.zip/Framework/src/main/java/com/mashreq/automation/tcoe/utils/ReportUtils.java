package com.mashreq.automation.tcoe.utils;

import com.mashreq.automation.tcoe.constants.FrameworkConstants;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

/**
 * A utility class for managing report directories, including backup and cleanup.
 */
public final class ReportUtils {

    private ReportUtils() {}


    /**
     * Cleans the main report directory by backing it up and then deleting contents.
     * Also removes older backups beyond a configured threshold.
     */


    // === ONE PUBLIC ENTRYPOINT: backs up BOTH reports and logs ===
    public static void backupReportsAndLogsDirectories() throws IOException {
        // Reports
        backupOneArtifactFlat(
                Paths.get("./" + FrameworkConstants.REPORT_BASE_FOLDER_NAME),
                Paths.get("./" + FrameworkConstants.REPORT_BACKUP_BASE_FOLDER_NAME),
                "reports",
                FrameworkConstants.REPORT_BACKUP_COUNT
        );

        // Logs (use "logs/latest" if that's the live folder)
        backupOneArtifactFlat(
                Paths.get("./" + FrameworkConstants.LOGS_BASE_FOLDER_NAME),
                Paths.get("./" + FrameworkConstants.LOGS_BACKUP_BASE_FOLDER_NAME),
                "logs",
                FrameworkConstants.LOGS_BACKUP_COUNT
        );
    }

    /* ================== impl ================== */

    // UTC, pattern: yyyyMMMdd_HHmmss'Z'  -> e.g. 2025Sep07_143012Z
    private static final DateTimeFormatter TS = DateTimeFormatter
            .ofPattern("yyyyMMMdd_HHmmss'Z'")
            .withZone(ZoneOffset.UTC);

    private static void backupOneArtifactFlat(Path sourceDir,
                                              Path backupRoot,
                                              String artifact,  // "reports" or "logs"
                                              int keepCount) throws IOException {
        Files.createDirectories(sourceDir);
        Files.createDirectories(backupRoot);

        String name = artifact + "__" + TS.format(Instant.now()); // e.g. reports__2025Sep07_143012Z
        Path backupDir = backupRoot.resolve(name);
        Files.createDirectories(backupDir);

        if (directoryHasContent(sourceDir)) {
            copyDirectoryContents(sourceDir, backupDir);  // copy contents only
            deleteDirectoryContents(sourceDir);           // keep source folder
            LogUtils.info("Backup: " + backupDir.toAbsolutePath());
        } else {
            LogUtils.info("No content to back up in: " + sourceDir.toAbsolutePath());
        }

        enforceFlatRetention(backupRoot, artifact, keepCount);
    }

    private static boolean directoryHasContent(Path dir) throws IOException {
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir)) {
            return ds.iterator().hasNext();
        }
    }

    private static void copyDirectoryContents(Path src, Path dst) throws IOException {
        Files.walkFileTree(src, new SimpleFileVisitor<>() {
            @Override public FileVisitResult preVisitDirectory(Path d, BasicFileAttributes a) throws IOException {
                Path rel = src.relativize(d);
                Files.createDirectories(dst.resolve(rel));
                return FileVisitResult.CONTINUE;
            }
            @Override public FileVisitResult visitFile(Path f, BasicFileAttributes a) throws IOException {
                Path rel = src.relativize(f);
                Files.copy(f, dst.resolve(rel),
                        StandardCopyOption.COPY_ATTRIBUTES,
                        StandardCopyOption.REPLACE_EXISTING);
                return FileVisitResult.CONTINUE;
            }
        });
    }

    /**
     * Recursively deletes all contents of a folder.
     */
    private static void deleteDirectoryContents(Path dir) throws IOException {
        File folder = new File(dir.toUri());
        File[] files = folder.listFiles();

        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    deleteDirectoryContents(Path.of(file.toURI()));
                } else {
                    file.delete();
                }
            }
        }
        folder.delete();
    }

    /** keep newest keepCount folders for a given artifact; delete older ones */
    private static void enforceFlatRetention(Path backupRoot, String artifact, int keepCount) throws IOException {
        if (!Files.exists(backupRoot)) return;

        // matches: reports__2025Sep07_143012Z  or logs__2025Sep07_143012Z
        Pattern pat = Pattern.compile(
                Pattern.quote(artifact) + "__\\d{4}[A-Za-z]{3}\\d{2}_\\d{6}Z"
        );

        List<Path> folders;
        try (var s = Files.list(backupRoot)) {
            folders = s.filter(Files::isDirectory)
                    .filter(d -> pat.matcher(d.getFileName().toString()).matches())
                    .sorted((a, b) -> {
                        try {
                            return Files.getLastModifiedTime(b).compareTo(Files.getLastModifiedTime(a));
                        } catch (IOException e) { return 0; }
                    })
                    .toList();
        }

        for (int i = keepCount; i < folders.size(); i++) {
            deleteRecursively(folders.get(i));
            LogUtils.info("Deleted old backup: " + folders.get(i).toAbsolutePath());
        }
    }

    private static void deleteRecursively(Path root) throws IOException {
        if (!Files.exists(root)) return;
        try (var s = Files.walk(root)) {
            for (Path p : s.sorted(Comparator.reverseOrder()).toList()) {
                Files.deleteIfExists(p);
            }
        }
    }


    public static void generateCucumberReport() {
        try {
            File reportOutputDir = new File("target/cucumber-reports/advanced-reports");
            File reportsDir = new File("target/cucumber-reports");

            // Wait until all JSON files are ready
            if (waitForAllJsonReady(reportsDir)) { // 10 minutes
                List<String> jsonFiles = Arrays.stream(reportsDir.listFiles((dir, name) -> name.endsWith(".json")))
                        .map(File::getAbsolutePath)
                        .collect(Collectors.toList());

                if (!jsonFiles.isEmpty()) {
                    Configuration config = new Configuration(reportOutputDir, "TCoE Playwright BDD Framework");
                    config.setBuildNumber("1.0");
                    config.addClassifications("Platform", System.getProperty("os.name"));
                    config.addClassifications("Java", System.getProperty("java.version"));

                    ReportBuilder reportBuilder = new ReportBuilder(jsonFiles, config);
                    reportBuilder.generateReports();
                    LogUtils.info("Cucumber HTML report generated successfully with " + jsonFiles.size() + " JSON file(s).");
                } else {
                    LogUtils.warn("No Cucumber JSON files found after waiting.");
                }
            } else {
                LogUtils.warn("Cucumber JSON files were not ready in time. Skipping report generation.");
            }
        } catch (Exception e) {
            LogUtils.error("Failed to generate Cucumber report: " + e.getMessage(), e);
        }
    }

    private static boolean waitForAllJsonReady(File dir) {
        long start = System.currentTimeMillis();
        Map<String, Long> lastSizes = new HashMap<>();

        while (System.currentTimeMillis() - start < (long) 600000) {
            File[] jsonFiles = dir.listFiles((d, name) -> name.endsWith(".json"));
            if (jsonFiles != null && jsonFiles.length > 0) {
                boolean allStable = true;

                for (File json : jsonFiles) {
                    long size = json.length();
                    Long prevSize = lastSizes.get(json.getName());

                    if (size == 0 || (prevSize != null && prevSize != size)) {
                        allStable = false; // still growing or empty
                    }
                    lastSizes.put(json.getName(), size);
                }

                if (allStable) {
                    return true; // all JSON files are stable
                }
            }
            try {
                Thread.sleep(500); // poll interval while the report files are still being written
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
        return false; // timed out
    }
}