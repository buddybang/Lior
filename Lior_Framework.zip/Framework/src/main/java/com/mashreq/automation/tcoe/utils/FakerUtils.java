package com.mashreq.automation.tcoe.utils;

import net.datafaker.Faker;
import org.apache.commons.lang3.ArrayUtils;

import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class FakerUtils {

    private static final Faker faker =
            new Faker(Locale.forLanguageTag("en-PK"),
                    new Random(UUID.randomUUID().getMostSignificantBits()));
    static final Map<String, String> fakerCache = new HashMap<>();

    private static final DateTimeFormatter dobFmt =
            DateTimeFormatter.ofPattern("dd-MM-yyyy");

    // 🔥 Store generated values per run to avoid duplicates
    private static final Set<String> generatedValues =
            ConcurrentHashMap.newKeySet();

    public static String generateField(String fieldName) {
        String value;

        int attempts = 0;
        do {
            value = generateRawValue(fieldName);
            attempts++;

            if (attempts > 10) {
                throw new RuntimeException(
                        "Unable to generate unique value for field: " + fieldName);
            }

        } while (!generatedValues.add(fieldName + ":" + value)); // prevents duplicate per field

        return value;
    }

    private static String generateRawValue(String fieldName) {

        switch (fieldName.toLowerCase()) {

            case "fullname":
                String fullName = faker.name().fullName();
                return Arrays.stream(fullName.split(" "))
                        .map(name -> name.substring(0, 1).toUpperCase()
                                + name.substring(1).toLowerCase())
                        .collect(Collectors.joining(""));

            case "shortname":
                // Get Faker last name in lowercase
                String last = faker.name().lastName().toLowerCase();

                // Add 2 random lowercase letters
                char letter1 = (char) ('a' + faker.number().numberBetween(0, 26));
                char letter2 = (char) ('a' + faker.number().numberBetween(0, 26));
                String shortName = last + letter1 + letter2;

                return shortName;

            case "email":
                return faker.name().firstName().toLowerCase()
                        + "." + faker.name().lastName().toLowerCase()
                        + System.nanoTime()
                        + "@example.com";

            case "phone":
                String prefix = "03"
                        + faker.number().numberBetween(0, 9)
                        + faker.number().numberBetween(0, 9);
                return prefix + "-" + faker.number().digits(7);

            case "referencenumber":
                String number = "03"
                        + "a"
                        + faker.number().numberBetween(0, 9);
                return number + "a" + faker.number().digits(7);

            case "batchno":
                return ""
                        + faker.number().numberBetween(0, 9)
                        + faker.letterify("?").toUpperCase()
                        + faker.number().numberBetween(0, 9)
                        +  faker.letterify("?").toUpperCase();


            case "dob":
                return faker.date().birthday(18, 65)
                        .toInstant()
                        .atZone(ZoneId.systemDefault())
                        .toLocalDate()
                        .format(dobFmt);

            case "companyname":
                String company = faker.company().name();
                return Arrays.stream(company.split(" "))
                        .map(word -> word.substring(0, 1).toUpperCase()
                                + word.substring(1).toLowerCase())
                        .collect(Collectors.joining(""));

            case "city":
                String city = faker.address().city();
                return capitalize(city);

            case "country":
                String country = faker.address().country();
                return capitalize(country);

            case "streetaddress":
                return Arrays.stream(faker.address().streetAddress().split(" "))
                        .map(FakerUtils::capitalize)
                        .collect(Collectors.joining(" "));

            case "jobtitle":
                return Arrays.stream(faker.job().title().split(" "))
                        .map(FakerUtils::capitalize)
                        .collect(Collectors.joining(" "));

            case "addressline":
            case "addressline2":
            case "addressline3":
                return faker.address().streetAddress() + ", "
                        + faker.address().city() + ", "
                        + faker.address().country();

            default:
                throw new IllegalArgumentException("Invalid field name: " + fieldName);
        }
    }

    private static String capitalize(String word) {
        return word.substring(0, 1).toUpperCase()
                + word.substring(1).toLowerCase();
    }

    //  Optional: Call this at start of each test run
    public static void resetGeneratedValues() {
        generatedValues.clear();
    }
}
