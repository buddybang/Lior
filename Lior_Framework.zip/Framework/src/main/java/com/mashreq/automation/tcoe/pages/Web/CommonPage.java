package com.mashreq.automation.tcoe.pages;

import com.mashreq.automation.tcoe.constants.COMMON; // generated from OR_COMMON.json
import com.mashreq.automation.tcoe.keywords.WebUI;
import com.mashreq.automation.tcoe.utils.DataHandler;
import com.mashreq.automation.tcoe.utils.LocatorUtils;
import com.mashreq.automation.tcoe.utils.LogUtils;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.mashreq.automation.tcoe.driver.DriverManager.getPage;

public class CommonPage {

    private final WebUI webUI;

    public CommonPage(WebUI webUI) {
        this.webUI = webUI;
    }

    // -------------------- Login --------------------

    public void navigateToLoginPage(String url) {
        webUI.navigateToUrl(url);
        webUI.waitForPageToLoad();
    }

    public void navigateToOBPMLoginPage(String url) {
        webUI.navigateToUrl(url);
        webUI.waitForPageToLoad();
        String okLocator = LocatorUtils.byPath(COMMON.LOGINSCREEN_LOGINOK);
        webUI.click(okLocator);
    }

    public void login(String username, String password) {
        String userNameLocator = LocatorUtils.byPath(COMMON.LOGINSCREEN_USERNAME);
        String passwordLocator = LocatorUtils.byPath(COMMON.LOGINSCREEN_PASSWORD);
        String loginBtnLocator = LocatorUtils.byPath(COMMON.LOGINSCREEN_LOGIN);

        webUI.sendKeys(userNameLocator, username);
        webUI.sendKeys(passwordLocator, password);

        webUI.click(loginBtnLocator);
        webUI.waitForPageToLoad();

        handleClearUser(password);

        String okLocator = LocatorUtils.byPath(COMMON.LOGINSCREEN_LOGINOK);
        webUI.click(okLocator);
    }

    // -------------------- Navigation --------------------

    public void navigateFastpath(String fastpath) {
        String fastPathLocator = LocatorUtils.byPath(COMMON.FASTPATH_FASTPATH);
        String goLocator = LocatorUtils.byPath(COMMON.FASTPATH_GO);

        webUI.sendKeys(fastPathLocator, fastpath);
        webUI.click(goLocator);
        webUI.waitForPageToLoad();
    }

    public void verifyScreenName(String expected) {
        String windowTitleLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_WINDOWTITLE);
        windowTitleLocator = windowTitleLocator.replace("testdata", expected);
        webUI.verifyText(windowTitleLocator, expected, false);
    }

    // -------------------- Branch Date --------------------

    public String retrieveBranchDate(String keyName) {
        String branchDateLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_BRANCHDATE);
        return webUI.retrieveText(branchDateLocator, keyName);
    }

    // -------------------- Generic Field Actions (feature provides screen + field) --------------------
    // Keep inline for brevity; they're used a lot and self-explanatory.

    public void enterField(String modulename, String screen, String field, String value) {
        String locator = LocatorUtils.byPath(modulename + "/" + screen + "/" + field);
        webUI.sendKeys(locator, value);
    }


    public void enterFieldAndTab(String modulename, String screen, String field, String value) {
        String locator = LocatorUtils.byPath(modulename + "/" + screen + "/" + field);
        webUI.sendKeysTab(locator, value);
    }

    public void selectField(String modulename, String screen, String field, String value) {
        String locator = LocatorUtils.byPath(modulename + "/" + screen + "/" + field);
        webUI.selectOption(locator, value);
    }

    public String retrieveField(String modulename, String screen, String field, String keyName) {
        String locator = LocatorUtils.byPath(modulename + "/" + screen + "/" + field);
        return webUI.retrieveText(locator, keyName);
    }

    public void verifyField(String modulename, String screen, String field, String expected) {
        String locator = LocatorUtils.byPath(modulename + "/" + screen + "/" + field);
        webUI.verifyText(locator, expected, false);
    }

    // -------------------- Common Buttons --------------------

    public void clickNewButton() {
        String locator = LocatorUtils.byPath(COMMON.COMMONSCREEN_NEW);
        webUI.click(locator);
    }

    public void clickFetchButton() {
        String locator = LocatorUtils.byPath(COMMON.SWITCHBRANCH_FETCH);
        webUI.click(locator);
    }

    /**
     * Generic "button by key" under CommonScreen.
     */
    public void clickButton(String buttonKey) {
        String locator;
        if (buttonKey.contains("/")) {
            locator = buttonKey;
        } else {
            String buttonPath = "COMMON/CommonScreen/" + buttonKey;
            locator = LocatorUtils.byPath(buttonPath);
        }
        webUI.waitForPageToLoad();
        webUI.click(locator);
        webUI.waitForPageToLoad();
    }

    /**
     * Generic "button by key" under Module specific screen.
     */
    public void clickButtonMod(String moduleName, String screenname, String buttonKey) {
        String buttonPath = moduleName+"/"+screenname+"/" + buttonKey;
        String locator = LocatorUtils.byPath(buttonPath);
        webUI.click(locator);
    }

    /**
     * Generic "button by key" under CommonScreen.
     */
    public void clickFirstVisibleElement(String buttonKey) {
        String locator;
        if (buttonKey.contains("/")) {
            locator = buttonKey;
        } else {
            String buttonPath = "COMMON/CommonScreen/" + buttonKey;
            locator = LocatorUtils.byPath(buttonPath);
        }

        webUI.clickFirstVisibleElement(locator);
    }

    public void verifyPopupMessage(String expectedMessage) {
        String popupLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_POPUPMESSAGE);
        popupLocator = popupLocator.replace("testdata", expectedMessage);
        webUI.verifyText(popupLocator, expectedMessage, false);
    }

    public void verifyAuthStatus(String expectedStatus) {
        String authStatusLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_AUTHSTATUS);
        webUI.verifyText(authStatusLocator, expectedStatus, false);
    }

    public void verifyFinalAuthStatus(String expectedStatus) {
        String FinalAuthStatusLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_FINALAUTHSTATUS);
        webUI.verifyText(FinalAuthStatusLocator, expectedStatus, false);
    }

    public void verifyCloseAuthStatus(String expectedStatus) {
        String CloseAuthStatusLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_CLOSEAUTHSTATUS);
        webUI.verifyText(CloseAuthStatusLocator, expectedStatus, false);
    }
    public void verifyCustomerAuthStatus(String expectedStatus) {
        String CustomerAuthStatusLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_CUSTOMERAUTHSTATUS);
        webUI.verifyText(CustomerAuthStatusLocator, expectedStatus, false);
    }

    // -------------------- Branch Switching --------------------

    public void switchBranch(String branchCode) {
        String branchMenu = LocatorUtils.byPath(COMMON.SWITCHBRANCH_BRANCHMENU);
        String selectBranch = LocatorUtils.byPath(COMMON.SWITCHBRANCH_SELECTBRANCH);
        String branchCodeLocator = LocatorUtils.byPath(COMMON.SWITCHBRANCH_BRANCHCODE);
        String fetchLocator = LocatorUtils.byPath(COMMON.SWITCHBRANCH_FETCH);
        String selectDataLocator = LocatorUtils.byPath(COMMON.SWITCHBRANCH_SELECTDATA);
        String infoOkLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_INFOOK);
        webUI.click(branchMenu);
        webUI.click(selectBranch);
        webUI.sendKeys(branchCodeLocator, branchCode);
        webUI.click(fetchLocator);
        webUI.click(selectDataLocator);
        webUI.click(infoOkLocator);
        webUI.waitForPageToLoad();
    }


    public void clickEnterQuery() {
        String locator = LocatorUtils.byPath(COMMON.COMMONSCREEN_ENTERQUERY);
        webUI.click(locator);
    }

    public void clickExecuteQuery() {
        String locator = LocatorUtils.byPath(COMMON.COMMONSCREEN_EXECUTEQUERY);
        webUI.click(locator);
    }

    public void switchToHomeBranch(String homeBranchKey) {
        // Try dynamic key under SwitchBranch; if not present, fallback to HomeBranch
        String branchMenu = LocatorUtils.byPath(COMMON.SWITCHBRANCH_BRANCHMENU);
        String homeBranch = LocatorUtils.byPath(COMMON.SWITCHBRANCH_HOMEBRANCH);
        String okButton = LocatorUtils.byPath(COMMON.COMMONSCREEN_INFOOK);

        webUI.click(branchMenu);
        webUI.click(homeBranch);
        webUI.click(okButton);
        webUI.waitForPageToLoad();
    }

    // -------------------- Workflow helpers (moved from steps) --------------------

    /**
     * Accept the "Override" two-step dialog.
     */
    public void acceptOverrideMessage() {
        String remarksOK = LocatorUtils.byPath(COMMON.COMMONSCREEN_REMARKSOK);
        String acceptandoverride = LocatorUtils.byPath(COMMON.COMMONSCREEN_ACCEPTANDOVERRIDE);
        clickButton(remarksOK);
        clickButton(acceptandoverride);
    }

    /**
     * Logout through user menu.
     */
    public void logout() {
        String userNameLink = LocatorUtils.byPath(COMMON.COMMONSCREEN_USER);
        String sigoffButton = LocatorUtils.byPath(COMMON.COMMONSCREEN_SIGNOFF);

        clickButton(userNameLink);
        clickButton(sigoffButton);
        String okLocator = LocatorUtils.byPath(COMMON.LOGINSCREEN_LOGINOK);
        webUI.click(okLocator);
        webUI.waitForPageToLoad();
    }

    public void selectOption(String locator,String testdata){
        webUI.selectOption(locator,testdata);
    }
    public void verifyEventFields(String eventName, String moduleName, String screen, String field, String expectedValue){
        String locator = LocatorUtils.byPath(moduleName + "/" + screen + "/" + field);
        locator = locator.replace("testdata", eventName);
        webUI.verifyText(locator, expectedValue, false);
    }

    //Rajendra Updates
    public void verifyAccountingEntries(String eventName,
                                        Map<String, String> resolvedRow,
                                        String scenarioId,
                                        String moduleName,
                                        DataHandler dataHandler,
                                        int occurrence) {

        final Pattern placeholderPattern = Pattern.compile("\\{\\{(.+?)}}");

        for (Map.Entry<String, String> entry : resolvedRow.entrySet()) {
            String field = entry.getKey().trim();
            String expected = entry.getValue() == null ? "" : entry.getValue().trim();

            // 1 Get locator template
            String locatorTemplate = LocatorUtils.byPath(moduleName + "/AccountingEntries/" + field);

            // 2 Replace standard placeholders
            locatorTemplate = locatorTemplate
                    .replace("{{DebitOrCredit}}", xpathSafeForInsertion(resolvedRow.getOrDefault("DebitOrCredit", "")))
                    .replace("{{AmountTag}}", xpathSafeForInsertion(resolvedRow.getOrDefault("AmountTag", "")))
                    .replace("{{AccountCurrency}}", xpathSafeForInsertion(resolvedRow.getOrDefault("AccountCurrency", "")));

            // 3 Replace any remaining {{...}} placeholders dynamically
            Matcher m = placeholderPattern.matcher(locatorTemplate);
            StringBuffer sb = new StringBuffer();
            while (m.find()) {
                String token = m.group(1).trim();
                String replacement = resolvedRow.getOrDefault(token, "");
                if (replacement.isEmpty()) {
                    try {
                        String fromData = dataHandler.getTestDataOrThrow(moduleName, scenarioId, token);
                        replacement = (fromData == null) ? "" : fromData.trim();
                    } catch (Exception ignored) {
                        replacement = "";
                    }
                }
                m.appendReplacement(sb, Matcher.quoteReplacement(xpathSafeForInsertion(replacement)));
            }
            m.appendTail(sb);
            String locator = sb.toString();

            // 4 Apply index only to the part AFTER the "|" separator
            String indexedLocator;
            if (locator.contains("|")) {
                String[] parts = locator.split("\\|", 2); // Split only into 2 parts (fieldName|xpath)
                String fieldName = parts[0];
                String xpathPart = parts[1];

                // Add index to the XPath part only
                indexedLocator = fieldName + "|(" + xpathPart + ")[" + occurrence + "]";
            } else {
                // No "|" found, fallback: apply index to the entire locator
                indexedLocator = "(" + locator + ")[" + occurrence + "]";
            }


            // 5 Verify text — webUi handles element find + check
            // ====================================================================
            // LOGIC: RATE Calculation
            // ====================================================================
            if ("Rate".equalsIgnoreCase(field)) {

                if (!expected.isEmpty()) {
                    try {

                        String lcaStr = resolvedRow.getOrDefault("LocalCurrencyAmount", "0").replaceAll(",", "").trim();
                        String fcaStr = resolvedRow.getOrDefault("ForeignCurrencyAmount", "0").replaceAll(",", "").trim();

                        if (lcaStr.isEmpty()) lcaStr = "0";
                        if (fcaStr.isEmpty()) fcaStr = "0";

                        BigDecimal lca = new BigDecimal(lcaStr);
                        BigDecimal fca = new BigDecimal(fcaStr);

                        if (fca.compareTo(BigDecimal.ZERO) != 0) {
                            // 1. Divide: Scale 7, DOWN = Truncate (e.g. 0.88971299 -> 0.8897129)
                            BigDecimal calculatedRate = lca.divide(fca, 7, RoundingMode.DOWN);

                            // 2. Strip Zeros & Force Plain String (e.g. 100.00 -> 100, NOT 1E+2)
                            expected = calculatedRate.stripTrailingZeros().toPlainString();
                        }
                    } catch (Exception e) {
                        LogUtils.info("WARN: Rate calc failed. Using provided value: " + expected);
                    }
                }
                LogUtils.info("Expected Rate value:" + expected);

                // Verify with precision 5
                // The 'expected' string (now 7 digits) will be compared against the UI (truncated to 5 digits)
                webUI.verifyText(indexedLocator, expected, true, 5);
            }
            else {
                // ====================================================================
                // LOGIC: Standard Fields
                // ====================================================================
                // Call standard verify (uses -1 internally)
                webUI.verifyText(indexedLocator, expected, true);
            }
        }
    }

    /**
     * Returns a string suitable for direct insertion into an XPath that already uses single quotes:
     * - If value contains no single quote -> returns the raw value (e.g. C)
     * - If value contains single quotes -> returns a concat(...) expression (no outer quotes)
     */
    private String xpathSafeForInsertion(String value) {
        if (value == null || value.isEmpty()) {
            return ""; // empty insertion (template likely has @value='') -> becomes @value=''
        }
        if (!value.contains("'")) {
            // plain value, safe to insert into @value='...'
            return value;
        }
        // build concat('part1', "'", 'part2', ...)
        String[] parts = value.split("'",-1);
        StringBuilder sb = new StringBuilder();
        sb.append("concat(");
        for (int i = 0; i < parts.length; i++) {
            sb.append("'").append(parts[i]).append("'");
            if (i < parts.length - 1) {
                sb.append(", \"'\", ");
            }
        }
        sb.append(")");
        return sb.toString();
    }


    // -------------------- Internal helpers --------------------

    private void handleClearUser(String password) {
        String dashboardLogo = null;
        try {
            dashboardLogo = LocatorUtils.byPath(COMMON.COMMONSCREEN_DASHBOARD);
        } catch (IllegalArgumentException ignore) { /* optional */ }
        webUI.waitForPageToLoad();
        boolean visible = dashboardLogo != null
                && getPage().locator("xpath=" + dashboardLogo).isVisible();
        webUI.waitForPageToLoad();
        if (!visible) {
            LogUtils.info("FCUBS - User already logged In....Clearing user.....");
            webUI.waitForPageToLoad();

            String okLocator = LocatorUtils.byPath(COMMON.LOGINSCREEN_LOGINOK);
            String rePwdLocator = LocatorUtils.byPath(COMMON.LOGINSCREEN_REENTERPASSWORD);
            String reOkLocator = LocatorUtils.byPath(COMMON.LOGINSCREEN_REENTEROK);

            webUI.click(okLocator);
            webUI.sendKeys(rePwdLocator, password);
            webUI.click(reOkLocator);
            webUI.waitForPageToLoad();
            LogUtils.info("User Cleared.....");
        } else {
            LogUtils.info("FCUBS - User already in dashboard...");
        }
    }

    // -------------------- Internal helpers --------------------

    public void handleLastPages() {

        String lastPage = "";
        try {
            lastPage = LocatorUtils.byPath(COMMON.COMMONSCREEN_LASTPAGE);

            boolean displayed = webUI.verifyIsDisplayed(lastPage, true);
            LogUtils.info(displayed + "displayed----------------");
            if (!displayed) {
                LogUtils.info("User already in dashboard");
            } else {
                LogUtils.info("FCUBS - User on  last page...");
                webUI.click(lastPage);
            }
        } catch (IllegalArgumentException ignore) { /* optional */ }
    }

    public void verifyIsDisplayed() {
        String dashboardLogo = LocatorUtils.byPath(COMMON.COMMONSCREEN_DASHBOARD);
        webUI.verifyIsDisplayed(dashboardLogo, false);
    }

    public void switchEntity(String entityCode) {
        String entityMenu = LocatorUtils.byPath(COMMON.SWITCHENTITY_ENTITYMENU);
        String selectBranch = LocatorUtils.byPath(COMMON.SWITCHENTITY_SELECTBRANCH);
        String entityCodeLocator = LocatorUtils.byPath(COMMON.SWITCHENTITY_ENTITYCODE);
        String fetchLocator = LocatorUtils.byPath(COMMON.SWITCHENTITY_FETCH);
        String selectDataLocator = LocatorUtils.byPath(COMMON.SWITCHENTITY_SELECTDATA);
        String infoOkLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_INFOOK);
        String okLocator = LocatorUtils.byPath(COMMON.LOGINSCREEN_LOGINOK);

        webUI.click(entityMenu);
        webUI.click(selectBranch);
        webUI.sendKeys(entityCodeLocator, entityCode);
        webUI.click(fetchLocator);
        webUI.click(selectDataLocator);
        webUI.click(infoOkLocator);
        webUI.waitForPageToLoad();
        webUI.click(okLocator);
    }

    public void verifyRadioCheckboxbtn(String button) {
        String buttonLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_RADIOCHECKBTN);
        buttonLocator = buttonLocator.replace("testdata", button);
        webUI.verifyIsDisplayed(buttonLocator,false);
    }

    public void clickRadioCheckboxbtn(String button) {
        String buttonLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_RADIOCHECKBTN);
        buttonLocator = buttonLocator.replace("testdata", button);
        webUI.click(buttonLocator);
    }

    public void invalidlogin(String username, String password) {
        String userNameLocator = LocatorUtils.byPath(COMMON.LOGINSCREEN_USERNAME);
        String passwordLocator = LocatorUtils.byPath(COMMON.LOGINSCREEN_PASSWORD);
        String loginBtnLocator = LocatorUtils.byPath(COMMON.LOGINSCREEN_LOGIN);

        webUI.sendKeys(userNameLocator, username);
        webUI.sendKeys(passwordLocator, password);

        webUI.click(loginBtnLocator);
        webUI.waitForPageToLoad();

    }
    //Added by gowtham for TD
    public void DoubleclickButton(String moduleName,String screenName, String buttonKey) {
        String buttonPath = moduleName +"/" + screenName + "/" + buttonKey;
        String locator = LocatorUtils.byPath(buttonPath);
        webUI.doubleClick(locator);
    }

    //added by gowtham for Trade

    public void OBTFPMlogin(String username, String password) {
        String userNameLocator = LocatorUtils.byPath(COMMON.OBTFPMLOGINSCREEN_OBTFPMUSERNAME);
        String passwordLocator = LocatorUtils.byPath(COMMON.OBTFPMLOGINSCREEN_OBTFPMPASSWORD);
        String loginBtnLocator = LocatorUtils.byPath(COMMON.OBTFPMLOGINSCREEN_OBTFPSIGNIN);

        webUI.sendKeys(userNameLocator, username);
        webUI.sendKeys(passwordLocator, password);

        webUI.click(loginBtnLocator);
        webUI.waitForPageToLoad();

        OBTFPMLoginClickProceed();

    }


    public void navigateToOBTFPMLoginPage(String url) {
        webUI.navigateToUrl(url);

    }


    private void OBTFPMLoginClickProceed() {
        String proceedLocator = LocatorUtils.byPath(COMMON.OBTFPMLOGINSCREEN_OBTFPMPROCEED);
        Locator proceed = getPage().locator("xpath=" + proceedLocator);
        // Small helper to click if a locator becomes visible within timeout
        clickIfVisible(proceed, 3000, "Info dialog detected and closed.", "No info dialog appeared.");
    }

    private void clickIfVisible(Locator locator, int timeoutMs, String successMsg, String missMsg) {
        try {
            locator.waitFor(new Locator.WaitForOptions()
                    .setState(WaitForSelectorState.VISIBLE)
                    .setTimeout(timeoutMs));
            locator.click(new Locator.ClickOptions().setTimeout(2000)); // short, safe click timeout
            LogUtils.info(successMsg);
        } catch (Exception e) {
            LogUtils.info(missMsg);
        }
    }

    public void navigateToOBTFLoginPage(String url) {
        webUI.navigateToUrl(url);
    }


    public void OBTFLogin(String username, String password) throws InterruptedException {
        webUI.waitForPageToLoad(); // the info dialog below is then waited for by click()
        String InfookLocator = LocatorUtils.byPath(COMMON.OBTFLOGINSCREEN_INFOOK);
        String userNameLocator = LocatorUtils.byPath(COMMON.OBTFLOGINSCREEN_USERNAME);
        String passwordLocator = LocatorUtils.byPath(COMMON.OBTFLOGINSCREEN_PASSWORD);
        String loginBtnLocator = LocatorUtils.byPath(COMMON.OBTFLOGINSCREEN_LOGIN);
        webUI.click(InfookLocator);
        webUI.sendKeys(userNameLocator, username);
        webUI.sendKeys(passwordLocator, password);

        webUI.click(loginBtnLocator);
        webUI.waitForPageToLoad();

        OBTFhandleClearUser(password);

        String okLocator = LocatorUtils.byPath(COMMON.OBTFLOGINSCREEN_INFOOK);
        webUI.click(okLocator);
    }

    private void OBTFhandleClearUser(String password) {
        String dashboardLogo = null;
        try {
            dashboardLogo = LocatorUtils.byPath(COMMON.COMMONSCREEN_DASHBOARD);
        } catch (IllegalArgumentException ignore) { /* optional */ }
        webUI.waitForPageToLoad();
        boolean visible = dashboardLogo != null
                && getPage().locator("xpath=" + dashboardLogo).isVisible();
        webUI.waitForPageToLoad();
        if (!visible) {
            LogUtils.info("OBTF - User already logged In....Clearing user.....");
            webUI.waitForPageToLoad();

            String okLocator = LocatorUtils.byPath(COMMON.LOGINSCREEN_LOGINOK);
            String rePwdLocator = LocatorUtils.byPath(COMMON.LOGINSCREEN_REENTERPASSWORD);
            String reOkLocator = LocatorUtils.byPath(COMMON.LOGINSCREEN_REENTEROK);

            webUI.click(okLocator);
            webUI.sendKeys(rePwdLocator, password);
            webUI.click(reOkLocator);
            webUI.waitForPageToLoad();
            LogUtils.info("User Cleared.....");
        } else {
            LogUtils.info("OBTF - User already in dashboard...");
        }
    }


    public void OBTFPMverifyScreenName(String expected) {
        String windowTitleLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_OBTFPMWINDOWTITLE);
        windowTitleLocator = windowTitleLocator.replace("testdata", expected);
        webUI.verifyText(windowTitleLocator, expected, false);
    }

    public String OBTFPMretrieveBranchDate(String keyName) {
        String branchDateLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_OBTFPMBRANCHDATE);
        return webUI.retrieveText(branchDateLocator, keyName);
    }

    public void verifyOBTFPMPopupMessage(String expectedMessage) {

        String popupLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_OBTFPMPOPUPMESSAGE);
        popupLocator = popupLocator.replace("testdata", expectedMessage);
        webUI.verifyText(popupLocator, expectedMessage, false);
    }

    public void OBTFPMlogout() throws InterruptedException {
        String userNameLink = LocatorUtils.byPath(COMMON.OBTFPMLOGOUTSCREEN_OBTFPUSER);
        String sigoffButton = LocatorUtils.byPath(COMMON.OBTFPMLOGOUTSCREEN_OBTFPMLOGOUT);
        webUI.click(userNameLink);
        webUI.click(sigoffButton); // click() waits until the sign-off entry of the opened menu is visible
        webUI.waitForPageToLoad();

    }

    public void OBPAYlogin(String username, String password) {
        String InfoOklocator = LocatorUtils.byPath(COMMON.OBPAYLOGINSCREEN_INFOOK );
        webUI.click(InfoOklocator);
        String userNameLocator = LocatorUtils.byPath(COMMON.OBPAYLOGINSCREEN_USERNAME );
        String passwordLocator = LocatorUtils.byPath(COMMON.OBPAYLOGINSCREEN_PASSWORD );
        String loginBtnLocator = LocatorUtils.byPath(COMMON.OBPAYLOGINSCREEN_LOGIN);

        webUI.sendKeys(userNameLocator, username);
        webUI.sendKeys(passwordLocator, password);

        webUI.click(loginBtnLocator);
        webUI.waitForPageToLoad();

        handleClearUserOBPAY(password);

        String okLocator = LocatorUtils.byPath(COMMON.OBPAYLOGINSCREEN_LOGINOK );
        webUI.click(okLocator);
    }

    public void OBPAYlogout() {

        String userNameLink = LocatorUtils.byPath(COMMON.OBPAYLOGOUT_USER);
        String sigoffButton = LocatorUtils.byPath(COMMON.OBPAYLOGOUT_SIGNOFF);
        clickButton(userNameLink);
        clickButton(sigoffButton);
    }
    private void handleClearUserOBPAY(String password) {

        String dashboardLogo = null;
        try {
            dashboardLogo = LocatorUtils.byPath(COMMON.COMMONSCREEN_DASHBOARD);
        } catch (IllegalArgumentException ignore) { /* optional */ }
        webUI.waitForPageToLoad();
        boolean visible = dashboardLogo != null
                && getPage().locator("xpath=" + dashboardLogo).isVisible();
        webUI.waitForPageToLoad();
        if (!visible) {
            LogUtils.info("OBPAY - User already logged In....Clearing user.....");
            webUI.waitForPageToLoad();

            String okLocator = LocatorUtils.byPath(COMMON.OBPAYLOGINSCREEN_LOGINOK );
            String rePwdLocator = LocatorUtils.byPath(COMMON.OBPAYLOGINSCREEN_REENTERPASSWORD);
            String reOkLocator = LocatorUtils.byPath(COMMON.OBPAYLOGINSCREEN_REENTEROK );
            webUI.click(okLocator);
            webUI.sendKeys(rePwdLocator, password);
            webUI.click(reOkLocator);
            webUI.waitForPageToLoad();
            LogUtils.info("User Cleared.....");
        } else {
            LogUtils.info("OBPAY - User already in dashboard...");

        }
    }

}