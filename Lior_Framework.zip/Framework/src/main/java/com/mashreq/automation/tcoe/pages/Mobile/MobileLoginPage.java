package com.mashreq.automation.tcoe.pages.Mobile;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.keywords.IActionLogger;
import com.mashreq.automation.tcoe.keywords.MobileUI;
import com.mashreq.automation.tcoe.utils.LocatorUtils;
import org.testng.Assert;

public class MobileLoginPage {
    private final MobileUI mobile;


    public MobileLoginPage(ScenarioContext ctx, IActionLogger logger) {

        this.mobile = new MobileUI(ctx, logger);
    }

    /**
     * Generic "input by key" for Mobile JSON (Login Flow)
     */
    public void enterthevalue(String fieldKey, String value) {

        if (fieldKey == null || fieldKey.trim().isEmpty()) {
            throw new IllegalArgumentException("Field key cannot be null or empty");
        }

        if (value == null) {
            throw new IllegalArgumentException("Value cannot be null");
        }

        String locator;

        try {

            // Build JSON path
            String fieldPath = "Mobile/Loginflow/" + fieldKey;
            locator = LocatorUtils.byPath(fieldPath);


            if (locator == null || locator.isEmpty()) {
                throw new RuntimeException("Locator not found for key: " + fieldKey);
            }

            // Wait + Send Keys

            mobile.sendKeys(locator, value);

        } catch (Exception e) {
            throw new RuntimeException(
                    "Failed to enter value in field: " + fieldKey + " | Reason: " + e.getMessage(), e
            );
        }
    }

    /**
     * Press Android Back button
     */
    public void pressBackButton() {

        try {

            mobile.pressBack();

        } catch (Exception e) {

            throw new RuntimeException(
                    "Failed to press Android Back button | Reason: "
                            + e.getMessage(),
                    e
            );
        }
    }

    /**
     * Press Android Home button
     */
    public void pressHomeButton() {

        try {

            mobile.pressHome();

        } catch (Exception e) {

            throw new RuntimeException(
                    "Failed to press Android Home button | Reason: "
                            + e.getMessage(),
                    e
            );
        }
    }

    /**
     * Open Android Recent Apps
     */
    public void openRecentAppsScreen() {

        try {

            mobile.openRecentApps();

        } catch (Exception e) {

            throw new RuntimeException(
                    "Failed to open Android Recent Apps | Reason: "
                            + e.getMessage(),
                    e
            );
        }
    }

    /**
     * Generic Mobile Input Method
     */
    public void enter(String moduleName,
                      String screenName,
                      String fieldName,
                      String value) {

        if (fieldName == null || fieldName.trim().isEmpty()) {
            throw new IllegalArgumentException("Field name cannot be null or empty");
        }

        if (value == null) {
            throw new IllegalArgumentException("Value cannot be null");
        }

        try {

            // Build JSON Path
            String fieldPath = moduleName + "/" + screenName + "/" + fieldName;

            String locator = LocatorUtils.byPath(fieldPath);

            if (locator == null || locator.isEmpty()) {
                throw new RuntimeException(
                        "Locator not found for field: " + fieldName);
            }

            // Enter Value
            mobile.sendKeys(locator, value);



        } catch (Exception e) {

            throw new RuntimeException(
                    "Failed to enter value for field: "
                            + fieldName
                            + " | Reason: "
                            + e.getMessage(),
                    e);
        }
    }


    /**
     * Generic "button by key" for Mobile JSON (Login Flow)
     */







}


