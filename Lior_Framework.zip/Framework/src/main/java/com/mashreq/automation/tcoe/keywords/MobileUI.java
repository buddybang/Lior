package com.mashreq.automation.tcoe.keywords;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.context.ScreenshotContextHolder;
import com.mashreq.automation.tcoe.utils.LocatorUtils;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.*;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.remote.RemoteWebElement;
import com.mashreq.automation.tcoe.utils.CaptureHelpers;
import com.mashreq.automation.tcoe.utils.LogUtils;
import com.mashreq.automation.tcoe.constants.FrameworkConstants;
import com.microsoft.playwright.Page;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.HasOnScreenKeyboard;
import io.appium.java_client.HidesKeyboard;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import com.mashreq.automation.tcoe.pages.Mobile.CommonMobilePage;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;
import java.util.*;
import java.util.List;
import java.util.function.Supplier;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;

/**
 * A keyword-driven engine for Mobile Automation using Appium.
 * A keyword-driven engine for Mobile Automation using Appium.
 * Provides high-level keywords for Android and iOS interactions.
 *
 * Locator format: "strategy|value"
 *   xpath|//android.widget.EditText[@content-desc='username']
 *   id|com.example:id/btnLogin
 *   accessibility|login-button
 *   class|android.widget.TextView
 *
 * If no prefix is provided, the string is treated as a raw XPath (backward-compatible).
 */
public final class MobileUI {

    private final IActionLogger logger;
    private final ScenarioContext ctx;
    private final Duration timeout;


    // ---------------------------------------------------------------
    // CONSTRUCTION
    // ---------------------------------------------------------------

    /**
     * Creates a MobileUI engine with a custom explicit-wait timeout.
     *
     * @param ctx     Active scenario context (provides the AppiumDriver).
     * @param logger  Action logger; falls back to NoOp if null.
     * @param timeout Explicit wait duration applied to every element lookup.
     */
    public MobileUI(ScenarioContext ctx, IActionLogger logger, Duration timeout) {
        this.ctx = ctx;
        this.logger = (logger != null) ? logger : new NoOpActionLogger();
        this.timeout = (timeout != null) ? timeout : Duration.ofSeconds(20);
    }

    /**
     * Convenience constructor — uses a default 20-second timeout.
     */
    public MobileUI(ScenarioContext ctx, IActionLogger logger) {
        this(ctx, logger, Duration.ofSeconds(20));
    }

    // ---------------------------------------------------------------
    // DRIVER ACCESS
    // ---------------------------------------------------------------

    private AppiumDriver driver() {
        AppiumDriver d = ctx.getMobileDriver();
        if (d == null) {
            throw new IllegalStateException(
                    "AppiumDriver is null. Ensure @Before hook initialises the mobile driver correctly.");
        }
        return d;
    }

    // ---------------------------------------------------------------
    // LOCATOR RESOLUTION
    // ---------------------------------------------------------------

    /**
     * Parses a prefixed locator string into an OpenQA {@link By} instance.
     * Supported prefixes: xpath|, id|, accessibility|, class|
     * Falls back to raw XPath if no recognised prefix is found.
     *
     * @param locator Prefixed locator string.
     * @return Resolved {@link By} strategy.
     */
    private By resolveLocator(String locator) {
        if (locator == null || locator.isBlank()) {
            throw new IllegalArgumentException("Locator must not be null or blank.");
        }
        if (locator.startsWith("xpath|")) {
            return AppiumBy.xpath(locator.substring(6));
        } else if (locator.startsWith("id|")) {
            return AppiumBy.id(locator.substring(3));
        } else if (locator.startsWith("accessibility|")) {
            return AppiumBy.accessibilityId(locator.substring(14));
        } else if (locator.startsWith("class|")) {
            return AppiumBy.className(locator.substring(6));
        }
        // No recognised prefix — fall back to raw XPath for backward compatibility.
        LogUtils.warn("No locator prefix found, defaulting to XPath: " + locator);
        return AppiumBy.xpath(locator);
    }

    // ---------------------------------------------------------------
    // ELEMENT LOOKUP
    // ---------------------------------------------------------------

    /**
     * Waits for an element to be present in the DOM and returns it.
     * Captures a screenshot automatically on failure.
     *
     * @param locator Prefixed locator string (e.g. "xpath|//...")
     * @return The located {@link WebElement}.
     * @throws org.openqa.selenium.TimeoutException if the element is not found within the timeout.
     */
    public WebElement findElement(String locator) {
        // FIX: resolveLocator() was called twice — once stored in 'by' (unused) and once
        //      inline. Now resolved once and reused to avoid double-parsing overhead.
        By by = resolveLocator(locator);
        WebDriverWait wait = new WebDriverWait(driver(), timeout);
        try {
            // FIX: switched from presenceOfElementLocated (DOM only) to
            //      visibilityOfElementLocated so the returned element is
            //      guaranteed to be visible and interactable.
            return wait.until(ExpectedConditions.visibilityOfElementLocated(by));
        } catch (Exception e) {
            LogUtils.error("Element not found within " + timeout.getSeconds() + "s: " + locator);

            captureScreenshot();
            throw e;
        }
    }


    /**
     * Highlights a mobile element before action execution.
     * Works for Native Android/iOS apps by drawing temporary overlay effect
     * using Appium supported operations.
     *
     * Screenshot is captured AFTER highlight and BEFORE action.
     */
    // ---------------------------------------------------------------
    // ACTION KEYWORDS
    // ---------------------------------------------------------------

    /**
     * Taps / clicks a mobile element.
     *
     * @param locator Prefixed locator string.
     */
    public void click(String locator) {
        logger.logAction("Click: " + locator, () -> {
            try {
                // clickable, and no longer moving (a screen transition can make an element clickable while it still slides in)
                WebElement ele = new WebDriverWait(driver(), timeout)
                        .until(ExpectedConditions.elementToBeClickable(resolveLocator(locator)));
                waitUntilStill(ele);
                captureScreenshot(ele);
                ele.click();

                LogUtils.info("Clicked: " + locator);
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to click element [" + locator + "]: " + e.getMessage());
            }
        });
    }

    /** Waits (at most 2 s) until the element is in the same place twice in a row, i.e. an animation has finished. */
    private void waitUntilStill(WebElement ele) {
        org.openqa.selenium.Rectangle last = null;
        long end = System.currentTimeMillis() + 2000;
        while (System.currentTimeMillis() < end) {
            org.openqa.selenium.Rectangle now = ele.getRect();
            if (now.equals(last)) {
                return;
            }
            last = now;
            try {
                Thread.sleep(150); // poll interval of the condition, not a fixed wait
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }

    /** Waits until the element exists and is enabled; false when that does not happen within {@code max}. */
    public boolean waitUntilEnabled(String locator, java.time.Duration max) {
        try {
            new WebDriverWait(driver(), max).until(d -> isElementEnabled(locator));
            return true;
        } catch (org.openqa.selenium.TimeoutException notYet) {
            return false;
        }
    }

    /** Non-asserting check: true if the element exists and is enabled. */
    public boolean isElementEnabled(String locator) {
        try {
            List<WebElement> elements = driver().findElements(resolveLocator(locator));
            return !elements.isEmpty() && elements.get(0).isEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    public void swipeHorizontalUntilVisibleClick(String locator) {

        List<WebElement> elements =
                driver().findElements(resolveLocator(locator));

        if (!elements.isEmpty() && elements.get(0).isDisplayed()) {
            elements.get(0).click();
            return;
        }

        for (int i = 0; i < 10; i++) {

            swipeLeft();

            elements = driver().findElements(resolveLocator(locator));

            if (!elements.isEmpty() && elements.get(0).isDisplayed()) {
                elements.get(0).click();
                return;
            }
        }

        Assert.fail("Element not found after swiping: " + locator);
    }

    /**
     * Presses the Android Back button.
     */
    public void pressBack() {

        logger.logAction("Press Android Back Button", () -> {

            try {

                ((AndroidDriver) driver())
                        .pressKey(new KeyEvent(AndroidKey.BACK));

                captureScreenshot();

                LogUtils.info("Pressed Android Back button");

            } catch (Exception e) {

                captureScreenshot();

                Assert.fail(
                        "Failed to press Android Back button: "
                                + e.getMessage()
                );
            }
        });
    }

    /**
     * Presses the Android Home button.
     */
    public void pressHome() {

        logger.logAction("Press Android Home Button", () -> {

            try {

                ((AndroidDriver) driver())
                        .pressKey(new KeyEvent(AndroidKey.HOME));

                captureScreenshot();

                LogUtils.info("Pressed Android Home button");

            } catch (Exception e) {

                captureScreenshot();

                Assert.fail(
                        "Failed to press Android Home button: "
                                + e.getMessage()
                );
            }
        });
    }

    /**
     * Opens Android Recent Apps screen.
     */
    public void openRecentApps() {

        logger.logAction("Open Android Recent Apps", () -> {

            try {

                ((AndroidDriver) driver())
                        .pressKey(new KeyEvent(AndroidKey.APP_SWITCH));

                captureScreenshot();

                LogUtils.info("Opened Android Recent Apps");

            } catch (Exception e) {

                captureScreenshot();

                Assert.fail(
                        "Failed to open Android Recent Apps: "
                                + e.getMessage()
                );
            }
        });
    }


    /**
     * Clears a field and types the given text.
     *
     * @param locator Prefixed locator string.
     * @param text    Text to enter.
     */
    public void sendKeys(String locator, String text) {
        logger.logAction("Type '" + text + "' into: " + locator, () -> {
            try {
                // FIX: switched to elementToBeClickable so the field is
                //      ready for interaction on both Android and iOS before
                //      clear() / sendKeys() are called.
                WebDriverWait wait = new WebDriverWait(driver(), timeout);
                WebElement element = wait.until(
                        ExpectedConditions.elementToBeClickable(resolveLocator(locator)));
                element.clear();
                element.sendKeys(text);
                captureScreenshot(element);
                LogUtils.info("Typed into [" + locator + "]: " + text);
                // The on-screen keyboard can cover buttons below the field (e.g. Continue on the PIN screen),
                // which Appium then cannot find.
                hideKeyboardIfShown();
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to type into element [" + locator + "]: " + e.getMessage());
            }
        });
    }

    /**
     * Closes the on-screen keyboard if it is open. Never fails the step.
     */
    public void hideKeyboardIfShown() {
        try {
            AppiumDriver d = driver();
            if (d instanceof HasOnScreenKeyboard kb && kb.isKeyboardShown()
                    && d instanceof HidesKeyboard hk) {
                hk.hideKeyboard();
                LogUtils.info("On-screen keyboard hidden");
            }
        } catch (Exception e) {
            LogUtils.warn("Could not hide the on-screen keyboard: " + e.getMessage());
        }
    }

    /**
     * Retrieves the visible text of an element.
     *
     * @param locator Prefixed locator string.
     * @return Visible text, or an empty string if retrieval fails.
     */
    public String getText(String locator) {
        return logger.logAction("Get text from: " + locator, () -> {
            try {
                WebElement ele = findElement(locator);
                String text = ele.getText();
                captureScreenshot(ele);
                LogUtils.info("Text retrieved from [" + locator + "]: " + text);
                return text;
            } catch (Exception e) {
                LogUtils.error("Failed to get text from [" + locator + "]: " + e.getMessage());
                captureScreenshot();
                return "";
            }
        });
    }

    public boolean verifyElementState(
            String locator,
            String expectedState) {

        return logger.logAction(
                "Verify element state: "
                        + locator
                        + " | Expected: "
                        + expectedState,
                () -> {

                    try {

                        if (locator == null || locator.trim().isEmpty()) {
                            throw new IllegalArgumentException(
                                    "Locator cannot be null or empty");
                        }

                        if (expectedState == null
                                || expectedState.trim().isEmpty()) {

                            throw new IllegalArgumentException(
                                    "Expected state cannot be null or empty");
                        }

                        String state =
                                expectedState.trim().toLowerCase();

                        /*
                         * Special handling for negative visibility.
                         *
                         * Element absent:
                         *      not visible/not displayed = PASS
                         *
                         * Element present but hidden:
                         *      not visible/not displayed = PASS
                         *
                         * Element present and visible:
                         *      FAIL
                         */
                        if ("not visible".equals(state)
                                || "not displayed".equals(state)) {

                            List<WebElement> elements =
                                    driver().findElements(
                                            resolveLocator(locator));

                            if (elements.isEmpty()) {

                                LogUtils.info(
                                        "Verified: Element '"
                                                + locator
                                                + "' is "
                                                + state + ".");

                                return true;
                            }

                            WebElement element = elements.get(0);

                            boolean actualDisplayed =
                                    element.isDisplayed();

                            captureScreenshot(element);

                            Assert.assertFalse(
                                    actualDisplayed,
                                    "Element was expected to be "
                                            + state
                                            + " but is displayed: "
                                            + locator);

                            LogUtils.info(
                                    "Successfully verified element '"
                                            + locator
                                            + "' is "
                                            + state + ".");

                            return true;
                        }

                        WebElement element =
                                findElement(locator);

                        boolean actualState;
                        boolean expectedResult;

                        switch (state) {

                            case "enabled":

                                actualState = element.isEnabled();
                                expectedResult = true;
                                break;

                            case "disabled":

                                actualState = element.isEnabled();
                                expectedResult = false;
                                break;

                            case "checked":
                            case "selected":

                                actualState = element.isSelected();
                                expectedResult = true;
                                break;

                            case "unchecked":
                            case "not selected":

                                actualState = element.isSelected();
                                expectedResult = false;
                                break;

                            case "visible":
                            case "displayed":

                                actualState = element.isDisplayed();
                                expectedResult = true;
                                break;

                            default:

                                throw new IllegalArgumentException(
                                        "Unsupported element state: "
                                                + expectedState);
                        }

                        captureScreenshot(element);

                        LogUtils.info(
                                "Element: " + locator
                                        + " | Expected State: " + state
                                        + " | Actual Result: " + actualState);

                        Assert.assertEquals(
                                actualState,
                                expectedResult,
                                "Element state verification failed for: "
                                        + locator
                                        + " | Expected State: "
                                        + state);

                        LogUtils.info(
                                "Successfully verified element '"
                                        + locator
                                        + "' is "
                                        + state + ".");

                        return true;

                    } catch (AssertionError e) {

                        throw e;

                    } catch (Exception e) {

                        captureScreenshot();

                        String errorMessage =
                                "Failed to verify element state: "
                                        + locator
                                        + " | Expected State: "
                                        + expectedState
                                        + " | Reason: "
                                        + e.getMessage();

                        LogUtils.error(
                                errorMessage,
                                e);

                        Assert.fail(errorMessage);

                        return false;
                    }
                });
    }

    /**
     * Scrolls through a list and taps the item matching {@code targetText} (case-insensitive).
     * FIX: now uses resolveLocator() so prefixed locators (e.g. "xpath|//...") work correctly
     *      instead of passing the raw string to AppiumBy.xpath().
     *
     * @param listLocator Prefixed locator for the repeating list items.
     * @param targetText  Visible text of the item to select.
     */
    public void selectByText(String listLocator, String targetText) {
        logger.logAction("Select '" + targetText + "' from list: " + listLocator, () -> {
            try {
                By by = resolveLocator(listLocator);
                List<WebElement> elements = driver().findElements(by);

                if (elements.isEmpty()) {
                    Assert.fail("List is empty — no items found at: " + listLocator);
                }

                for (WebElement el : elements) {
                    if (el.getText().equalsIgnoreCase(targetText)) {
                        el.click();
                        captureScreenshot(el);
                        LogUtils.info("Selected '" + targetText + "' from list: " + listLocator);
                        return;
                    }
                }
                Assert.fail("Item '" + targetText + "' not found in list: " + listLocator);
            } catch (AssertionError ae) {
                throw ae; // Let TestNG assertion propagate cleanly.
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Error selecting from list [" + listLocator + "]: " + e.getMessage());
            }
        });
    }

    /**
     * Sets a checkbox to the desired state without unnecessary clicks.
     *
     * @param locator  Prefixed locator string.
     * @param testdata "check" or "true" to check; any other value unchecks.
     */
    public void selectCheckbox(String locator, String testdata) {
        logger.logAction("Checkbox [" + locator + "] set to: " + testdata, () -> {
            try {
                WebElement checkbox = findElement(locator);
                boolean shouldBeChecked = testdata != null &&
                        ("check".equalsIgnoreCase(testdata) || "true".equalsIgnoreCase(testdata));
                boolean isChecked = checkbox.isSelected();
                if (shouldBeChecked != isChecked) {
                    checkbox.click();
                    LogUtils.info((shouldBeChecked ? "Checked" : "Unchecked") + " checkbox: " + locator);
                } else {
                    LogUtils.info("Checkbox already in desired state (" + testdata + "): " + locator);
                }
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to set checkbox state [" + locator + "]: " + e.getMessage());
            }
        });
    }

    /**
     * Waits for the given number of seconds (supports fractional values).
     *
     * @param secondsStr Duration in seconds as a string (e.g. "2" or "0.5").
     */
    public void waitForDuration(String secondsStr) {
        logger.logAction("Wait for: " + secondsStr + " seconds", () -> {
            try {
                double seconds = Double.parseDouble(secondsStr.trim());
                long millis = (long) (seconds * 1000);
                captureScreenshot();
                LogUtils.info("Waiting for " + seconds + " seconds...");
                Thread.sleep(millis);
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Invalid wait duration [" + secondsStr + "]: " + e.getMessage());
            }
        });
    }

    // ---------------------------------------------------------------
    // VALIDATION KEYWORDS
    // ---------------------------------------------------------------

    /**
     * Asserts that an element's text matches the expected value.
     *
     * @param locator       Prefixed locator string.
     * @param expectedText  Text the element is expected to display.
     */

    public void verifyText(String locator, String expectedText) {
        logger.logAction("Verify text '" + expectedText + "' on: " + locator, () -> {
            WebElement ele = findElement(locator);
            String actualText = ele.getText();
            captureScreenshot(ele);
            LogUtils.info("Text — expected: '" + expectedText + "', actual: '" + actualText + "'");
            Assert.assertEquals(actualText, expectedText,
                    "Text mismatch on [" + locator + "]. Expected '" + expectedText
                            + "' but got '" + actualText + "'.");
        });
    }

    /**
     * Soft-assertion variant of {@link #verifyText(String, String)}.
     * If {@code soft} is true, logs the failure without stopping the test.
     *
     * @param locator       Prefixed locator string.
     * @param expectedText  Text the element is expected to contain.
     * @param soft          true = log-only on failure; false = hard fail.
     * @return PASSED/FAILED result string.
     */
    public String verifyText(String locator, String expectedText, boolean soft) {
        return logger.logAction("Verify text '" + expectedText + "' on: " + locator, () -> {
            try {
                WebElement ele = findElement(locator);
                String actualText = ele.getText();
                captureScreenshot(ele);
                LogUtils.info("Text — expected: '" + expectedText + "', actual: '" + actualText + "'");
                if (actualText.contains(expectedText)) {
                    String successMsg = "PASSED | Expected='" + expectedText + "' | Actual='" + actualText + "'";

                    LogUtils.info(successMsg);
                    return successMsg;
                } else {
                    String failMsg = "FAILED | Expected='" + expectedText + "' | Actual='" + actualText + "'";
                    LogUtils.error(failMsg);
                    if (!soft) Assert.fail(failMsg);
                    return failMsg;
                }
            } catch (AssertionError ae) {
                throw ae;
            } catch (Exception e) {
                captureScreenshot();
                String errorMsg = "ERROR verifying text for [" + locator + "]: " + e.getMessage();
                LogUtils.error(errorMsg);
                if (!soft) Assert.fail(errorMsg);
                return errorMsg;
            }
        });
    }

    // ---------------------------------------------------------------
    // RETRIEVAL KEYWORDS
    // ---------------------------------------------------------------

    /**
     * Retrieves the visible text of an element and logs the variable name it is stored under.
     *
     * @param locator Prefixed locator string.
     * @param varName Logical name of the variable for logging purposes.
     * @return Retrieved text, or null on failure.
     */
    public String retrieveText(String locator, String varName) {
        return logger.logAction("Retrieve text from: " + locator, () -> {
            try {
                WebElement ele = findElement(locator);
                String retrievedData = ele.getText();
                if (retrievedData == null || retrievedData.isEmpty()) {
                    String msg = "Could not retrieve any text from element: " + locator;
                    LogUtils.error(msg);
                    Assert.fail(msg);
                    return null;
                }
                captureScreenshot(ele);
                LogUtils.info("Retrieved '" + retrievedData + "' from [" + locator + "] stored as: '" + varName + "'");
                return retrievedData;
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to retrieve text from element [" + locator + "]: " + e.getMessage());
                return null;
            }
        });
    }

    public String retrieveText(String locator) {

        return logger.logAction(
                "Retrieve text from element: " + locator,
                () -> {

                    try {

                        WebElement element = findElement(locator);

                        String text = element.getText();

                        captureScreenshot(element);

                        LogUtils.info(
                                "Retrieved text from element '" +
                                        locator +
                                        "': " +
                                        text);

                        return text;

                    } catch (Exception e) {

                        captureScreenshot();

                        String errorMessage =
                                "Unexpected error while retrieving text from: "
                                        + locator
                                        + " | Reason: "
                                        + e.getMessage();

                        LogUtils.error(errorMessage, e);

                        throw new RuntimeException(
                                errorMessage,
                                e);
                    }
                });
    }


    // ---------------------------------------------------------------
    // GESTURE KEYWORDS
    // ---------------------------------------------------------------

    /**
     * Swipes vertically like a finger: "up" moves the finger up (the content scrolls down), "down" the other way.
     * {@code times} > 0: exactly that many swipes. {@code times} <= 0: quick long swipes (a fling) until nothing on the screen
     * moves any more (the end of the content), at most 25. Returns the number of swipes made.
     */
    public int swipeVertically(boolean up, int times) {
        if (times > 0) {
            // the same quick swipe a person makes (the content flings on); the slow scrollDown/scrollUp drag moves only
            // 40% of the screen, so N of them fall short of N recorded swipes (NeoCorp EULA: page 4 of 6 after 5)
            for (int i = 0; i < times; i++) {
                flick(up);
            }
            LogUtils.info("Swiped " + (up ? "up" : "down") + " " + times + " time(s)");
            return times;
        }
        // compared by picture: a PDF / image viewer scrolls without changing the page source
        byte[] before = driver().getScreenshotAs(OutputType.BYTES);
        int done = 0;
        while (done < 25) {
            flick(up);
            done++;
            byte[] after = driver().getScreenshotAs(OutputType.BYTES);
            if (Arrays.equals(after, before)) {
                break; // nothing moved: the end is reached
            }
            before = after;
        }
        LogUtils.info("Swiped " + (up ? "up" : "down") + " " + done + " time(s) (until the screen stopped moving)");
        return done;
    }

    /**
     * One quick, long swipe (the content keeps moving after the finger lifts). Stays between 15% and 72% of the screen height,
     * so it starts inside the content and not on a footer (tick box, buttons) at the bottom.
     */
    private void flick(boolean up) {
        logger.logAction(up ? "Swipe up" : "Swipe down", () -> {
            try {
                Dimension size = driver().manage().window().getSize();
                int x = size.getWidth() / 2;
                int low = (int) (size.getHeight() * 0.72);
                int high = (int) (size.getHeight() * 0.15);
                performSwipe(x, up ? low : high, x, up ? high : low, 300);
                captureScreenshot();
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to swipe " + (up ? "up" : "down") + ": " + e.getMessage(), e);
            }
        });
    }

    /**
     * Scrolls the screen downward (finger moves up — content moves down).
     * Swipes from 70% to 30% of screen height at the horizontal centre.
     */

    public void scrollDown() {
        logger.logAction("Scroll down", () -> {
            try {
                Dimension size = driver().manage().window().getSize();
                int x = size.getWidth() / 2;
                performSwipe(x, (int) (size.getHeight() * 0.70),
                        x, (int) (size.getHeight() * 0.30), 600);
                captureScreenshot();
                LogUtils.info("Scrolled down.");
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to scroll down: " + e.getMessage(), e);
            }
        });
    }

    /**
     * Scrolls the screen upward (finger moves down — content moves up).
     * Swipes from 30% to 70% of screen height at the horizontal centre.
     */
    public void scrollUp() {
        logger.logAction("Scroll up", () -> {
            try {
                Dimension size = driver().manage().window().getSize();
                int x = size.getWidth() / 2;
                performSwipe(x, (int) (size.getHeight() * 0.30),
                        x, (int) (size.getHeight() * 0.70), 600);
                captureScreenshot();
                LogUtils.info("Scrolled up.");
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to scroll up: " + e.getMessage(), e);
            }
        });
    }

    /**
     * Scrolls down repeatedly until the element identified by {@code locator} is visible,
     * up to 10 attempts.
     *
     * @param locator Prefixed locator string of the target element.
     */
    public void scrollToElement(String locator) {
        logger.logAction("Scroll to element: " + locator, () -> {
            try {
                By by = resolveLocator(locator);
                int maxAttempts = 10;
                for (int i = 0; i < maxAttempts; i++) {
                    List<WebElement> found = driver().findElements(by);
                    if (!found.isEmpty() && found.get(0).isDisplayed()) {
                        captureScreenshot(found.get(0));
                        LogUtils.info("Element visible after " + i + " scroll(s): " + locator);
                        return;
                    }
                    scrollDown();
                }
                Assert.fail("Element not visible after " + maxAttempts + " scroll attempts: " + locator);
            } catch (AssertionError ae) {
                throw ae;
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Error scrolling to element [" + locator + "]: " + e.getMessage());
            }
        });
    }

    /**
     * Swipes left (finger moves left — content/page moves right, e.g. next tab).
     * Swipes from 80% to 20% of screen width at the vertical centre.
     */
    public void swipeLeft() {
        logger.logAction("Swipe left", () -> {
            try {
                Dimension size = driver().manage().window().getSize();
                int y = size.getHeight() / 2;
                performSwipe((int) (size.getWidth() * 0.80), y,
                        (int) (size.getWidth() * 0.20), y, 400);
                captureScreenshot();
                LogUtils.info("Swiped left.");
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to swipe left: " + e.getMessage());
            }
        });
    }

    /**
     * Swipes right (finger moves right — content/page moves left, e.g. previous tab).
     * Swipes from 20% to 80% of screen width at the vertical centre.
     */
    public void swipeRight() {
        logger.logAction("Swipe right", () -> {
            try {
                Dimension size = driver().manage().window().getSize();
                int y = size.getHeight() / 2;
                performSwipe((int) (size.getWidth() * 0.20), y,
                        (int) (size.getWidth() * 0.80), y, 400);
                captureScreenshot();
                LogUtils.info("Swiped right.");
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to swipe right: " + e.getMessage());
            }
        });
    }

    /**
     * Fast upward swipe (finger moves up) — shorter duration than {@link #scrollDown()}.
     */
    public void swipeUp() {
        logger.logAction("Swipe up", () -> {
            try {
                Dimension size = driver().manage().window().getSize();
                int x = size.getWidth() / 2;
                performSwipe(x, (int) (size.getHeight() * 0.70),
                        x, (int) (size.getHeight() * 0.30), 300);
                captureScreenshot();
                LogUtils.info("Swiped up.");
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to swipe up: " + e.getMessage());
            }
        });
    }

    /**
     * Fast downward swipe (finger moves down) — shorter duration than {@link #scrollUp()}.
     */
    public void swipeDown() {
        logger.logAction("Swipe down", () -> {
            try {
                Dimension size = driver().manage().window().getSize();
                int x = size.getWidth() / 2;
                performSwipe(x, (int) (size.getHeight() * 0.30),
                        x, (int) (size.getHeight() * 0.70), 300);
                captureScreenshot();
                LogUtils.info("Swiped down.");
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to swipe down: " + e.getMessage());
            }
        });
    }

    /**
     * Performs a pull-to-refresh gesture — fast downward swipe from the top third
     * of the screen, mimicking a native pull-to-refresh.
     */
    public void pullToRefresh() {
        logger.logAction("Pull to refresh", () -> {
            try {
                Dimension size = driver().manage().window().getSize();
                int x = size.getWidth() / 2;
                performSwipe(x, (int) (size.getHeight() * 0.20),
                        x, (int) (size.getHeight() * 0.80), 800);
                captureScreenshot();
                LogUtils.info("Pull-to-refresh performed.");
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to pull-to-refresh: " + e.getMessage());
            }
        });
    }

    /**
     * Long-presses an element for 2 seconds using the W3C PointerInput API.
     *
     * @param locator Prefixed locator string.
     */
    public void longPress(String locator) {
        logger.logAction("Long press: " + locator, () -> {
            try {
                WebElement element = findElement(locator);
                PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
                Sequence longPress = new Sequence(finger, 1);
                longPress.addAction(finger.createPointerMove(
                        Duration.ZERO, PointerInput.Origin.fromElement(element), 0, 0));
                longPress.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
                longPress.addAction(new Pause(finger, Duration.ofSeconds(2)));
                longPress.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
                driver().perform(Arrays.asList(longPress));
                captureScreenshot(element);
                LogUtils.info("Long pressed: " + locator);
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to long press [" + locator + "]: " + e.getMessage());
            }
        });
    }

    /**
     * Taps at the given absolute screen coordinates.
     *
     * @param x Horizontal pixel coordinate.
     * @param y Vertical pixel coordinate.
     */
    public void tapByCoordinates(int x, int y) {
        logger.logAction("Tap at coordinates: (" + x + ", " + y + ")", () -> {
            try {
                PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
                Sequence tap = new Sequence(finger, 1);
                tap.addAction(finger.createPointerMove(
                        Duration.ZERO, PointerInput.Origin.viewport(), x, y));
                tap.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
                tap.addAction(new Pause(finger, Duration.ofMillis(100)));
                tap.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
                driver().perform(Arrays.asList(tap));
                captureScreenshot();
                LogUtils.info("Tapped at (" + x + ", " + y + ").");
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to tap at (" + x + ", " + y + "): " + e.getMessage());
            }
        });
    }

    // ---------------------------------------------------------------
    // APP LIFECYCLE KEYWORDS
    // ---------------------------------------------------------------

    /**
     * Brings the app to the foreground (activates it by package/bundle ID).
     *
     * @param appId Android package name or iOS bundle ID (e.g. "com.example.app").
     */
    /**
     * Brings the app to the foreground (activates it by package/bundle ID).
     *
     * @param appId Android package name or iOS bundle ID.
     */
    public void launchApp(String appId) {
        logger.logAction("Launch app: " + appId, () -> {
            try {
                Map<String, Object> params = new HashMap<>();
                params.put("appId", appId);

                driver().executeScript("mobile: activateApp", params);

                captureScreenshot();

                LogUtils.info("App launched: " + appId);
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to launch app [" + appId + "]: " + e.getMessage());
            }
        });
    }

    /**
     * Terminates (force-closes) the app by package/bundle ID.
     *
     * @param appId Android package name or iOS bundle ID.
     */
    public void closeApp(String appId) {
        logger.logAction("Close app: " + appId, () -> {
            try {
                Map<String, Object> params = new HashMap<>();
                params.put("appId", appId);

                driver().executeScript("mobile: terminateApp", params);

                captureScreenshot();

                LogUtils.info("App closed: " + appId);
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to close app [" + appId + "]: " + e.getMessage());
            }
        });
    }

    /**
     * Terminates the app then reactivates it — simulates a full cold restart.
     *
     * @param appId Android package name or iOS bundle ID.
     */
    public void restartApp(String appId) {
        logger.logAction("Restart app: " + appId, () -> {
            try {
                Map<String, Object> params = new HashMap<>();
                params.put("appId", appId);

                driver().executeScript("mobile: terminateApp", params);
                driver().executeScript("mobile: activateApp", params);

                captureScreenshot();

                LogUtils.info("App restarted: " + appId);
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to restart app [" + appId + "]: " + e.getMessage());
            }
        });
    }

    /**
     * Sends the app to the background for the given number of seconds, then
     * automatically brings it back to the foreground.
     *
     * @param seconds Duration to keep the app backgrounded.
     */
    public void runAppInBackground(int seconds) {
        logger.logAction("Run app in background for " + seconds + "s", () -> {
            try {
                Map<String, Object> params = new HashMap<>();
                params.put("seconds", seconds);

                driver().executeScript("mobile: backgroundApp", params);

                captureScreenshot();

                LogUtils.info("App backgrounded for " + seconds + " second(s).");
            } catch (Exception e) {
                captureScreenshot();
                Assert.fail("Failed to background app: " + e.getMessage());
            }
        });
    }


    // ---------------------------------------------------------------
// SCREENSHOT HELPER
// ---------------------------------------------------------------

    /**
     * Captures screenshot for both Web and Mobile
     * and publishes path to ScreenshotContextHolder.
     */

    public void captureScreenshot() {

        try {

            String path = "";

            // MOBILE
            if (driver() instanceof AppiumDriver) {
                path = CaptureHelpers.takeMobileScreenshot(
                        (AppiumDriver) driver(),
                        ctx.getScenarioId()
                );
            }

            ScreenshotContextHolder
                    .publishLastScreenshotPath(path);

        } catch (Exception e) {

            LogUtils.warn(
                    "Failed to capture screenshot: "
                            + e.getMessage()
            );
        }
    }

    public void sendKeyswithEnter(String locator, String text) {

        logger.logAction("Type '" + text + "' into: " + locator, () -> {

            try {
                WebDriverWait wait = new WebDriverWait(driver(), timeout);

                WebElement element = wait.until(
                        ExpectedConditions.elementToBeClickable(
                                resolveLocator(locator)
                        )
                );

                // Focus the PIN field
                element.click();

                // Clear existing value
                element.clear();

                // Enter PIN
                element.sendKeys(text);

                String platform = driver()
                        .getCapabilities()
                        .getPlatformName()
                        .toString();

                if (platform.equalsIgnoreCase("ANDROID")) {

                    // Android keyboard shows "Done"
                    Map<String, Object> params = new HashMap<>();
                    params.put("action", "done");

                    ((JavascriptExecutor) driver())
                            .executeScript(
                                    "mobile: performEditorAction",
                                    params
                            );

                    LogUtils.info("Android: Done action performed");

                } else if (platform.equalsIgnoreCase("IOS")) {

                    element.sendKeys(Keys.ENTER);

                    LogUtils.info(
                            "iOS: PIN entered successfully"
                    );

                } else {

                    throw new RuntimeException(
                            "Unsupported platform: " + platform
                    );
                }

                captureScreenshot(element);

                LogUtils.info(
                        "Typed [" + text + "] into [" + locator + "]"
                );

            } catch (Exception e) {

                captureScreenshot();

                Assert.fail(
                        "Failed to type into [" +
                                locator + "]: " +
                                e.getMessage()
                );
            }
        });
    }


    public void scrollandVerifyText(
            String messageKey,
            String expectedValue,
            String screenName,
            String moduleName) {

        logger.logAction(
                "Verify account detail field: " + messageKey
                        + " | Expected value: " + expectedValue,
                () -> {

                    try {

                        String locator = LocatorUtils.byPath(
                                moduleName + "/"
                                        + screenName + "/"
                                        + messageKey);

                        boolean isFieldFound = false;
                        String previousPageSource = "";

                        while (true) {

                            List<WebElement> elements =
                                    driver().findElements(
                                            resolveLocator(locator));

                            if (!elements.isEmpty()) {

                                for (WebElement element : elements) {

                                    String actualValue =
                                            element.getText().trim();

                                    captureScreenshot(element);

                                    LogUtils.info(
                                            "Field: " + messageKey
                                                    + " | Expected: "
                                                    + expectedValue
                                                    + " | Actual: "
                                                    + actualValue);

                                    Assert.assertEquals(
                                            actualValue,
                                            expectedValue,
                                            "Value mismatch for field: "
                                                    + messageKey);

                                    LogUtils.info(
                                            "Successfully verified field: "
                                                    + messageKey);

                                    isFieldFound = true;
                                    break;
                                }

                                if (isFieldFound) {
                                    break;
                                }
                            }

                            String currentPageSource =
                                    driver().getPageSource();

                            if (currentPageSource.equals(previousPageSource)) {
                                break;
                            }

                            previousPageSource = currentPageSource;

                            scrollDown();
                        }

                        Assert.assertTrue(
                                isFieldFound,
                                "Unable to find account detail field: "
                                        + messageKey);

                    } catch (Exception e) {

                        captureScreenshot();

                        Assert.fail(
                                "Failed to verify account detail field ["
                                        + messageKey + "]. Error: "
                                        + e.getMessage());
                    }

                    return null;
                });
    }

    public void doubleClick(String locator) {
        logger.logAction("Double-tap: " + locator, () -> {
            try {
                WebElement element = findElement(locator);

                captureScreenshot(element);

                Rectangle rect = element.getRect();

                int centerX = rect.getX() + rect.getWidth() / 2;
                int centerY = rect.getY() + rect.getHeight() / 2;

                PointerInput finger =
                        new PointerInput(PointerInput.Kind.TOUCH, "finger");

                Sequence doubleTap = new Sequence(finger, 0);

                // First tap
                doubleTap.addAction(
                        finger.createPointerMove(
                                Duration.ZERO,
                                PointerInput.Origin.viewport(),
                                centerX,
                                centerY
                        )
                );

                doubleTap.addAction(
                        finger.createPointerDown(
                                PointerInput.MouseButton.LEFT.asArg()
                        )
                );

                doubleTap.addAction(
                        finger.createPointerUp(
                                PointerInput.MouseButton.LEFT.asArg()
                        )
                );

                // Delay between taps
                doubleTap.addAction(
                        new Pause(finger, Duration.ofMillis(100))
                );

                // Second tap
                doubleTap.addAction(
                        finger.createPointerDown(
                                PointerInput.MouseButton.LEFT.asArg()
                        )
                );

                doubleTap.addAction(
                        finger.createPointerUp(
                                PointerInput.MouseButton.LEFT.asArg()
                        )
                );

                driver().perform(
                        Collections.singletonList(doubleTap)
                );

                LogUtils.info("Double-tapped: " + locator);

            } catch (Exception e) {
                captureScreenshot();

                Assert.fail(
                        "Failed to double-tap element [" +
                                locator + "]: " + e.getMessage()
                );
            }
        });
    }

    // Screenshot with highlighter
    public void captureScreenshot(WebElement element) {

        try {

            String path = "";

            // MOBILE
            if (driver() instanceof AppiumDriver) {
                Rectangle logicalRect = element.getRect();

                Dimension logicalScreenSize = driver().manage().window().getSize();

                path = CaptureHelpers.takeMobileScreenshot(
                        (AppiumDriver) driver(),
                        ctx.getScenarioId()
                );

                BufferedImage fullImg = ImageIO.read(new File(path));

                // This handles high-density displays (Retina, 2x, 3x, 4x screens)
                double scaleFactor = (double) fullImg.getWidth() / logicalScreenSize.getWidth();

                int physicalX = (int) (logicalRect.getX() * scaleFactor);
                int physicalY = (int) (logicalRect.getY() * scaleFactor);
                int physicalWidth = (int) (logicalRect.getWidth() * scaleFactor);
                int physicalHeight = (int) (logicalRect.getHeight() * scaleFactor);

                Graphics2D g2d = fullImg.createGraphics();
                // Setup styling: Red box, 8px thick
                g2d.setColor(Color.GREEN);
                g2d.setStroke(new BasicStroke(8.0f));
                // Draw the rectangle
                g2d.drawRect(physicalX, physicalY, physicalWidth, physicalHeight);
                // Optional: Add a semi-transparent fill to make the element pop

                g2d.dispose(); // Release graphics resources

                File finalImage = new File(path);
                ImageIO.write(fullImg, "png", finalImage);
            }


            ScreenshotContextHolder
                    .publishLastScreenshotPath(path);

        } catch (Exception e) {

            LogUtils.warn(
                    "Failed to capture screenshot: "
                            + e.getMessage()
            );
        }
    }

    /** @deprecated Use {@link #captureScreenshot()} instead. */
    @Deprecated
    public void capturescreenshot() {
        captureScreenshot();
    }


    // ---------------------------------------------------------------
    // PRIVATE: GESTURE HELPER
    // ---------------------------------------------------------------

    /**
     * Executes a single-finger swipe using the W3C PointerInput API.
     * All public gesture methods delegate to this helper to avoid duplication.
     *
     * @param startX     Starting X pixel coordinate (viewport-relative).
     * @param startY     Starting Y pixel coordinate (viewport-relative).
     * @param endX       Ending X pixel coordinate.
     * @param endY       Ending Y pixel coordinate.
     * @param durationMs Duration of the swipe motion in milliseconds.
     */
    private void performSwipe(int startX, int startY, int endX, int endY, long durationMs) {
        PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
        Sequence swipe = new Sequence(finger, 1);
        swipe.addAction(finger.createPointerMove(
                Duration.ZERO, PointerInput.Origin.viewport(), startX, startY));
        swipe.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
        swipe.addAction(finger.createPointerMove(
                Duration.ofMillis(durationMs), PointerInput.Origin.viewport(), endX, endY));
        swipe.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
        driver().perform(Arrays.asList(swipe));
    }

    // ---------------------------------------------------------------
    // PRIVATE: NO-OP LOGGER
    // ---------------------------------------------------------------

    private static class NoOpActionLogger implements IActionLogger {
        @Override
        public <T> T logAction(String description, Supplier<T> action) {
            return action.get();
        }
    }
}