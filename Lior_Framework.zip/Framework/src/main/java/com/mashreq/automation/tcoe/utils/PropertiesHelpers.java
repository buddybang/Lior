package com.mashreq.automation.tcoe.utils;

import java.io.*;
import java.net.URISyntaxException;
import java.nio.file.*;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Properties;

import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import com.mashreq.automation.tcoe.utils.CustomExceptions.*;

/**
 * Properties helper that supports IDE runs, packaged JARs, and external overrides.
 */
public class PropertiesHelpers {

    @Getter
    private static Properties properties;

    /** Where we'll write updates (null means classpath source; we then write to ./config). */
    private static Path writableFilePath;

    private static String currentFileName;

    private static final String DEFAULT_FILE_NAME = "config.properties";
    /** Optional, git-ignored: secrets (BrowserStack key ...) kept out of the repository. Wins over config.properties. */
    private static final String SECRETS_FILE_NAME = "secrets.local.properties";
    private static final String CLASSPATH_CONFIG_DIR = "config";

    // ===================== Public API =====================

    public static Properties loadAllFiles() {
        // 1) Load base config first (gives us defaults + ENV/REGION if not passed via -D)
        Properties base = loadFileInternal(DEFAULT_FILE_NAME);
        if (base == null) base = new Properties(); // stay resilient

        // 2) Resolve ENV from system property first, fallback to base config (default SIT)
        String env = System.getProperty("ENV", base.getProperty("ENV", "SIT")).trim();

        // (optional) also pre-read REGION here if you will use urls-<ENV>-<REGION>.properties later
         String region = System.getProperty("REGION", base.getProperty("REGION", "US")).trim();

        // 3) Merge order: base → env URLs (urls-<ENV>.properties)
        LinkedList<String> files = new LinkedList<>();
        files.add(DEFAULT_FILE_NAME);                       // config.properties
        files.add(String.format("urls-%s.properties", env));// env-specific URL map

        Properties merged = new Properties();
        for (String f : files) {
            Properties p = loadFileInternal(f);
            if (p != null) merged.putAll(p);
        }

        merged.putAll(loadSecrets());
        properties = merged;
        return properties;
    }

    /**
     * secrets.local.properties (git-ignored) from ./config or src/main/resources/config; empty when there is none. Read on its own so
     * it never becomes the file that setValue() writes to.
     */
    private static Properties loadSecrets() {
        Properties p = new Properties();
        String dir = System.getProperty("user.dir");
        for (Path f : new Path[]{Paths.get(dir, "config", SECRETS_FILE_NAME),
                Paths.get(dir, "src", "main", "resources", CLASSPATH_CONFIG_DIR, SECRETS_FILE_NAME)}) {
            if (Files.exists(f)) {
                try (InputStream in = Files.newInputStream(f)) {
                    p.load(in);
                    return p;
                } catch (IOException e) {
                    System.err.println("Could not read " + f + ": " + e.getMessage());
                }
            }
        }
        return p;
    }


    /** Load a specific properties file name (e.g. "config.qa.properties"). */
    public static void setFile(String fileName) {
        Properties p = loadFileInternal(fileName);
        if (p != null) properties = p;
        else System.err.println("Failed to set custom config file: " + fileName);
    }

    /** Load the default file (config/config.properties on classpath or external overrides). */
    public static void setDefaultFile() {
        Properties p = loadFileInternal(DEFAULT_FILE_NAME);
        if (p != null) properties = p;
        else System.err.println("Failed to load default config file.");
    }

    /**
     * Returns the value for a mandatory key, or fails immediately with a clear message.
     * A -D system property of the same name wins over the properties file.
     */
    public static String getRequiredValue(String key) {
        String override = overrideOf(key);
        if (StringUtils.isNotBlank(override)) {
            return override.trim();
        }
        ensureLoaded();
        if (!properties.containsKey(key)) {
            throw new KeyNotFoundException("Required key '" + key + "' is missing. Add it to config/config.properties"
                    + " (or urls-<ENV>.properties) or pass it with -D" + key + "=<value>.");
        }
        String value = properties.getProperty(key);
        if (StringUtils.isBlank(value)) {
            throw new FrameworkException("Required key '" + key + "' is present but empty. Set a value in the"
                    + " properties file or pass -D" + key + "=<value>.");
        }
        return value.trim();
    }

    /** -D<key> first, then an environment variable of the same name (e.g. BROWSERSTACK_ACCESS_KEY on a build server). */
    private static String overrideOf(String key) {
        String v = System.getProperty(key);
        return StringUtils.isNotBlank(v) ? v : System.getenv(key);
    }

    public static String getValue(String key) {
        String keyValue = null;
        // A -D system property overrides the file value (as documented in config.properties).
        String override = overrideOf(key);
        if (StringUtils.isNotBlank(override)) {
            return override.trim();
        }
        try {
            ensureLoaded();
            if (properties.containsKey(key)) {
                keyValue = properties.getProperty(key);
                if (StringUtils.isBlank(keyValue)) {
                    throw new FrameworkException("Value is empty or missing for key: " + key);
                }
                return keyValue.trim();
            } else {
                throw new KeyNotFoundException("Key not found in properties file: " + key);
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
            return keyValue;
        }
    }

    /** Persist an updated key/value. */
    public static void setValue(String key, String keyValue) {
        try {
            ensureLoaded();

            Path target = getWritablePathForCurrentFile();
            Files.createDirectories(Objects.requireNonNull(target).getParent());

            properties.setProperty(key, keyValue);

            try (OutputStream out = Files.newOutputStream(target)) {
                properties.store(out, "Updated by PropertiesHelpers");
            }
            writableFilePath = target; // keep writing to the same place
            System.out.println("Updated property: " + key + " = " + keyValue + " -> " + target);
        } catch (Exception e) {
            System.err.println("Failed to write to properties file: " + e.getMessage());
        }
    }

    // ===================== Internals =====================

    /**
     * Lookup order:
     * 1) ./config/<fileName>
     * 2) ./src/main/resources/config/<fileName>
     * 3) <jarDir>/config/<fileName>
     * 4) <jarDir>/<fileName>
     * 5) classpath:config/<fileName>
     */
    private static Properties loadFileInternal(String fileName) {
        currentFileName = fileName;

        // 1) Working-dir external override
        Path externalPath = Paths.get(System.getProperty("user.dir"), "config", fileName);
        if (Files.exists(externalPath)) return loadFromPath(externalPath, true);

        // 2) IDE convenience path
        Path idePath = Paths.get(System.getProperty("user.dir"), "src", "main", "resources", CLASSPATH_CONFIG_DIR, fileName);
        if (Files.exists(idePath)) return loadFromPath(idePath, true);

        // 3) JAR folder /config
        Path jarFolder = getJarFolder();
        if (jarFolder != null) {
            Path jarConfig = jarFolder.resolve("config").resolve(fileName);
            if (Files.exists(jarConfig)) return loadFromPath(jarConfig, true);

            // 4) JAR folder flat
            Path jarFlat = jarFolder.resolve(fileName);
            if (Files.exists(jarFlat)) return loadFromPath(jarFlat, true);
        }

        // 5) Classpath
        String cpLocation = CLASSPATH_CONFIG_DIR + "/" + fileName;
        try (InputStream in = PropertiesHelpers.class.getClassLoader().getResourceAsStream(cpLocation)) {
            if (in != null) {
                Properties p = new Properties();
                p.load(in);
                properties = p;
                writableFilePath = null; // classpath-backed (read-only)
                System.out.println("Loaded properties from classpath: " + cpLocation);
                return p;
            }
        } catch (IOException e) {
            System.err.println("Failed to load properties from classpath: " + e.getMessage());
        }

        System.err.println("Could not find properties in external paths, JAR folder, or classpath: " + fileName);
        return null;
    }

    private static Properties loadFromPath(Path path, boolean writable) {
        try (InputStream is = Files.newInputStream(path)) {
            Properties p = new Properties();
            p.load(is);
            properties = p;
            writableFilePath = writable ? path : null;
            System.out.println("Loaded properties file: " + path);
            return p;
        } catch (IOException e) {
            System.err.println("Failed to load properties from " + path + ": " + e.getMessage());
            return null;
        }
    }

    /**
     * Gets the folder of the currently executing JAR or class file.
     * Useful when running tests in packaged or CI/CD environments.
     */
    private static Path getJarFolder() {
        try {
            File jarFile = new File(PropertiesHelpers.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            File parent = jarFile.getParentFile();
            return (parent != null) ? parent.toPath() : null;
        } catch (URISyntaxException e) {
            System.err.println("Could not determine JAR folder: " + e.getMessage());
            return null;
        }
    }

    /** If not yet loaded, load the default. */
    private static void ensureLoaded() {
        if (properties == null) {
            setDefaultFile();
            if (properties == null) properties = new Properties();
        }
    }

    /** If loaded from classpath, write to ./config/<name>; otherwise write back where we loaded from. */
    private static Path getWritablePathForCurrentFile() {
        if (writableFilePath != null) return writableFilePath;
        return Paths.get(System.getProperty("user.dir"), "config",
                currentFileName != null ? currentFileName : DEFAULT_FILE_NAME);
    }
}
