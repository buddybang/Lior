package com.mashreq.automation.tcoe.utils;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.List;

//final -> We do not want any class to extend this class
public final class DateUtils {

    private DateUtils() {
        super();
    }

    /**
     * @return lấy ra ngày tháng năm hiện tại của máy theo cấu trúc mặc định
     */
    public static String getCurrentDate() {
        Date date = new Date();
        return date.toString().replace(":", "_").replace(" ", "_");
    }

    public static String getCurrentDateInMMDDYYYY() {
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        return sdf.format(date);
    }
    /**
     * @return Get the current date, month, year, hour, minute, second of the device according to the structure dd/MM/yyyy HH:mm:ss
     */
    public static String getCurrentDateTime() {
        Date now = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        return formatter.format(now);
    }

    public static String getCurrentDateTimeCustom(String separator_Character) {
        Date now = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        String timeStamp = formatter.format(now).replace("/", separator_Character);
        timeStamp = timeStamp.replace(" ", separator_Character);
        timeStamp = timeStamp.replace(":", separator_Character);
        return timeStamp;
    }

    /**
     * Returns the current system time in milliseconds since epoch.
     *
     * @return system time in milliseconds
     */
    public static long getCurrentTimeInMillis() {
        return Instant.now().toEpochMilli();
    }
    //Rajendra Updates
    // Common input date formats — extend as needed
    private static final List<DateTimeFormatter> DEFAULT_INPUT_FORMATS = List.of(
            DateTimeFormatter.ofPattern("MM/dd/yyyy"),
            DateTimeFormatter.ofPattern("M/d/yyyy"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy"),
            DateTimeFormatter.ofPattern("d/M/yyyy"),
            DateTimeFormatter.ISO_LOCAL_DATE,
            DateTimeFormatter.ofPattern("yyyy/MM/dd")
    );

    /**
     * Generic formatter that tries to parse a date string using multiple formats and
     * convert it into the required output pattern.
     *
     * @param rawValue       the input value (from JSON/test data)
     * @param outputPattern  desired output format (e.g. "yyyy-MM-dd")
     * @return formatted value if convertible, otherwise the original raw value
     */
    public static String formatDateIfPossible(String rawValue, String outputPattern) {
        if (rawValue == null || rawValue.isBlank()) {
            return rawValue;
        }

        String trimmed = rawValue.trim();
        // if it's already in correct format, no change
        if (trimmed.matches("\\d{4}-\\d{2}-\\d{2}") && outputPattern.equals("yyyy-MM-dd")) {
            return trimmed;
        }

        for (DateTimeFormatter inputFmt : DEFAULT_INPUT_FORMATS) {
            try {
                LocalDate date = LocalDate.parse(trimmed, inputFmt);
                return date.format(DateTimeFormatter.ofPattern(outputPattern));
            } catch (DateTimeParseException ignored) {
            }
        }

        // not a date or parsing failed — return as-is
        return rawValue;
    }

    /**
     * Quickly detect if a string looks like a date (digits + separator).
     */
    public static boolean looksLikeDate(String value) {
        if (value == null) return false;
        String s = value.trim();
        return s.matches(".*\\d.*") && s.matches("[0-9/\\-\\.\\s]+");
    }
}