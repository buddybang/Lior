


package com.mashreq.automation.tcoe.driver;

import com.mashreq.automation.tcoe.utils.LogUtils;

import com.mashreq.automation.tcoe.constants.FrameworkConstants;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import org.openqa.selenium.remote.http.ClientConfig;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.time.Duration;
import java.util.Map;

/**
 * MobileDriverManager
 *
 * Supports:
 *
 * LOCAL
 *   - Android
 *   - iOS
 *
 * BROWSERSTACK
 *   - Android
 *   - iOS
 *   - Corporate / Zscaler proxy
 *
 * Configuration is controlled through FrameworkConstants,
 * which reads values from config.properties and/or system properties.
 *
 * ThreadLocal is used so the driver and execution mode are safe
 * for parallel execution.
 *
 * NOTE:
 *   Video / screen recording has been completely removed.
 */
public final class MobileDriverManager {

    private static final ThreadLocal<AppiumDriver> DRIVER =
            new ThreadLocal<>();

    private static final ThreadLocal<String> EXECUTION_MODE =
            new ThreadLocal<>();

    /** Per thread: parallel scenarios run on different devices. */
    private static final ThreadLocal<String> DEVICE_DETAILS = new ThreadLocal<>();

    /** The current thread's device, e.g. "ANDROID [BROWSERSTACK] - RZGL412B8DJ"; null before a driver is started. */
    public static String getDeviceDetails() {
        return DEVICE_DETAILS.get();
    }

    private MobileDriverManager() {
        // Utility class
    }

    // ================================================================
    // INIT DRIVER
    // ================================================================

    /**
     * Initializes the Appium driver for the current thread.
     */
    public static void initDriver() {

        if (DRIVER.get() != null) {

            LogUtils.info(
                    "-----> Mobile driver already exists for current thread."
            );

            return;
        }

        String executionMode =
                getExecutionMode();

        String platform =
                getPlatform();

        EXECUTION_MODE.set(
                executionMode
        );

        LogUtils.info("");
        LogUtils.info(
                "=================================================="
        );
        LogUtils.info(
                "Mobile Execution Mode : " + executionMode
        );
        LogUtils.info(
                "Mobile Platform       : " + platform
        );
        LogUtils.info(
                "=================================================="
        );

        try {

            AppiumDriver appiumDriver;

            if ("browserstack".equals(executionMode)) {

                LogUtils.info(
                        "-----> Starting BrowserStack App Automate session"
                );

                FrameworkConstants.validateBrowserStackConfig();

                appiumDriver =
                        createBrowserStackDriver(
                                platform
                        );

            } else if ("local".equals(executionMode)) {

                LogUtils.info(
                        "-----> Starting local Appium session"
                );

                appiumDriver =
                        createLocalDriver(
                                platform
                        );

            } else {

                throw new IllegalArgumentException(
                        "Unsupported MOBILE_EXECUTION_MODE: "
                                + executionMode
                                + ". Supported values: local, browserstack"
                );
            }

            DRIVER.set(
                    appiumDriver
            );

            updateDeviceDetails(
                    appiumDriver,
                    platform
            );

            LogUtils.info(
                    "-----> Mobile Driver started successfully"
            );

            LogUtils.info(
                    "-----> Device Details: "
                            + DEVICE_DETAILS.get()
            );

            LogUtils.info(
                    "-----> Session ID: "
                            + appiumDriver.getSessionId()
            );

        } catch (Exception e) {

            try {

                AppiumDriver currentDriver =
                        DRIVER.get();

                if (currentDriver != null) {
                    currentDriver.quit();
                }

            } catch (Exception ignored) {
                // Ignore cleanup failure
            } finally {

                DRIVER.remove();
                EXECUTION_MODE.remove();
                DEVICE_DETAILS.remove();
            }

            throw new RuntimeException(
                    "Failed to initialize Mobile Driver "
                            + "[mode=" + executionMode
                            + ", platform=" + platform + "]",
                    e
            );
        }
    }

    // ================================================================
    // GET DRIVER
    // ================================================================

    /**
     * Returns the Appium driver associated with the current thread.
     */
    public static AppiumDriver getDriver() {
        return DRIVER.get();
    }

    /**
     * Returns true if a driver exists for the current thread.
     */
    public static boolean isDriverAvailable() {
        return DRIVER.get() != null;
    }

    // ================================================================
    // EXECUTION MODE / PLATFORM
    // ================================================================

    private static String getExecutionMode() {

        String value =
                System.getProperty(
                        "MOBILE_EXECUTION_MODE",
                        FrameworkConstants.MOBILE_EXECUTION_MODE
                );

        if (value == null || value.isBlank()) {
            return "local";
        }

        return value.trim().toLowerCase();
    }

    private static String getPlatform() {

        String value =
                System.getProperty(
                        "MOBILE_PLATFORM",
                        FrameworkConstants.MOBILE_PLATFORM
                );

        if (value == null || value.isBlank()) {
            return "android";
        }

        return value.trim().toLowerCase();
    }

    // ================================================================
    // LOCAL DRIVER
    // ================================================================

    private static AppiumDriver createLocalDriver(
            String platform
    ) throws Exception {

        String serverUrl =
                FrameworkConstants.APPIUM_SERVER_URL;

        if (serverUrl == null || serverUrl.isBlank()) {

            throw new IllegalStateException(
                    "APPIUM_SERVER_URL is not configured."
            );
        }

        URL appiumUrl =
                new URL(serverUrl);

        if ("android".equals(platform)) {

            LogUtils.info(
                    "-----> Local Android Appium URL: "
                            + serverUrl
            );

            return new AndroidDriver(
                    appiumUrl,
                    getLocalAndroidOptions()
            );

        } else if ("ios".equals(platform)) {

            LogUtils.info(
                    "-----> Local iOS Appium URL: "
                            + serverUrl
            );

            return new IOSDriver(
                    appiumUrl,
                    getLocalIosOptions()
            );

        } else {

            throw new IllegalArgumentException(
                    "Unsupported MOBILE_PLATFORM: "
                            + platform
            );
        }
    }

    // ================================================================
    // BROWSERSTACK DRIVER
    // ================================================================

    /**
     * Creates BrowserStack App Automate driver.
     *
     * BrowserStack credentials are embedded in the endpoint URL
     * because this matches the standalone BrowserStack implementation
     * used in the corporate proxy environment.
     *
     * Credentials are never printed.
     */
    private static AppiumDriver createBrowserStackDriver(
            String platform
    ) throws Exception {

        validateBrowserStackConfiguration();

        ClientConfig clientConfig =
                createBrowserStackClientConfig();

        if ("android".equals(platform)) {

            UiAutomator2Options options =
                    getBrowserStackAndroidOptions();

            return new AndroidDriver(
                    clientConfig,
                    options
            );

        } else if ("ios".equals(platform)) {

            XCUITestOptions options =
                    getBrowserStackIosOptions();

            return new IOSDriver(
                    clientConfig,
                    options
            );

        } else {

            throw new IllegalArgumentException(
                    "Unsupported MOBILE_PLATFORM: "
                            + platform
                            + ". Supported values: android, ios"
            );
        }
    }

    // ================================================================
    // BROWSERSTACK CLIENT CONFIG
    // ================================================================

    /**
     * Creates the Selenium HTTP client configuration used by Appium.
     *
     * Corporate / Zscaler proxy is applied here.
     */
    private static ClientConfig createBrowserStackClientConfig()
            throws Exception {

        String username =
                FrameworkConstants.BROWSERSTACK_USERNAME;

        String accessKey =
                FrameworkConstants.BROWSERSTACK_ACCESS_KEY;

        /*
         * Credentials are intentionally included in the endpoint.
         *
         * DO NOT print this URL.
         */
        URL browserStackUrl =
                new URL(
                        "https://"
                                + username
                                + ":"
                                + accessKey
                                + "@hub-cloud.browserstack.com/wd/hub"
                );

        /*
         * Read timeout above the length of a test (default 180 s): with 90 s, every session that was busy 90 s after it was created
         * lost its connection ("connection closed locally" from the HTTP client's own response timer, while the request
         * that failed had just started) - NeoCorp runs of 2026-10-02, two sessions at the same second.
         * Override with -DBS_READ_TIMEOUT_SECONDS=... or BS_READ_TIMEOUT_SECONDS in config.properties.
         */
        long readTimeoutSeconds =
                Long.parseLong(getProperty("BS_READ_TIMEOUT_SECONDS", "180").trim());

        ClientConfig clientConfig =
                ClientConfig.defaultConfig()
                        .baseUrl(browserStackUrl)
                        .connectionTimeout(
                                Duration.ofSeconds(30)
                        )
                        .readTimeout(
                                Duration.ofSeconds(readTimeoutSeconds)
                        );

        Proxy proxy =
                getBrowserStackProxy();

        if (proxy != null) {

            clientConfig =
                    clientConfig.proxy(proxy);

            LogUtils.info(
                    "-----> BrowserStack proxy enabled"
            );

        } else {

            LogUtils.info(
                    "-----> BrowserStack proxy disabled"
            );
        }

        return clientConfig;
    }

    // ================================================================
    // BROWSERSTACK PROXY
    // ================================================================

    /**
     * Returns the corporate/Zscaler HTTP proxy.
     */
    private static Proxy getBrowserStackProxy() {

        // -DBS_USE_PROXY=false skips the corporate proxy (e.g. when working outside the client network).
        // The JDK then falls back to the OS proxy settings if -Djava.net.useSystemProxies=true is also passed.
        if ("false".equalsIgnoreCase(getProperty("BS_USE_PROXY", "true"))) {
            return null;
        }

        String proxyHost =
                getProperty(
                        "BS_PROXY_HOST",
                        FrameworkConstants.BS_PROXY_HOST
                );

        String proxyPortValue =
                getProperty(
                        "BS_PROXY_PORT",
                        FrameworkConstants.BS_PROXY_PORT
                );

        if (proxyHost == null
                || proxyHost.isBlank()
                || proxyPortValue == null
                || proxyPortValue.isBlank()) {

            return null;
        }

        try {

            int proxyPort =
                    Integer.parseInt(
                            proxyPortValue.trim()
                    );

            return new Proxy(
                    Proxy.Type.HTTP,
                    new InetSocketAddress(
                            proxyHost.trim(),
                            proxyPort
                    )
            );

        } catch (NumberFormatException e) {

            throw new IllegalStateException(
                    "Invalid BS_PROXY_PORT: "
                            + proxyPortValue,
                    e
            );
        }
    }

    // ================================================================
    // BROWSERSTACK ANDROID OPTIONS
    // ================================================================

    private static UiAutomator2Options
    getBrowserStackAndroidOptions() {

        UiAutomator2Options options =
                new UiAutomator2Options();

        options.setPlatformName(
                "Android"
        );

        options.setAutomationName(
                "UiAutomator2"
        );

        options.setDeviceName(
                FrameworkConstants.BS_DEVICE_NAME
        );

        options.setPlatformVersion(
                FrameworkConstants.BS_OS_VERSION
        );

        options.setApp(
                FrameworkConstants.BROWSERSTACK_APP_URL
        );

        /*
         * BrowserStack authentication capabilities.
         */
        options.setCapability(
                "userName",
                FrameworkConstants.BROWSERSTACK_USERNAME
        );

        options.setCapability(
                "accessKey",
                FrameworkConstants.BROWSERSTACK_ACCESS_KEY
        );

        /*
         * BrowserStack metadata.
         */
        options.setCapability(
                "bstack:options",
                Map.of(
                        "projectName",
                        FrameworkConstants.BS_PROJECT,

                        "buildName",
                        FrameworkConstants.BS_BUILD,

                        "sessionName",
                        FrameworkConstants.BS_TEST_NAME
                )
        );

        options.setCapability(
                "autoGrantPermissions",
                true
        );

        options.setCapability(
                "noReset",
                false
        );

        return options;
    }

    // ================================================================
    // BROWSERSTACK IOS OPTIONS
    // ================================================================

    private static XCUITestOptions
    getBrowserStackIosOptions() {

        XCUITestOptions options =
                new XCUITestOptions();

        options.setPlatformName(
                "iOS"
        );

        options.setAutomationName(
                "XCUITest"
        );

        options.setDeviceName(
                FrameworkConstants.BS_DEVICE_NAME
        );

        options.setPlatformVersion(
                FrameworkConstants.BS_OS_VERSION
        );

        options.setApp(
                FrameworkConstants.BROWSERSTACK_APP_URL
        );

        options.setCapability(
                "userName",
                FrameworkConstants.BROWSERSTACK_USERNAME
        );

        options.setCapability(
                "accessKey",
                FrameworkConstants.BROWSERSTACK_ACCESS_KEY
        );

        options.setCapability(
                "bstack:options",
                Map.of(
                        "projectName",
                        FrameworkConstants.BS_PROJECT,

                        "buildName",
                        FrameworkConstants.BS_BUILD,

                        "sessionName",
                        FrameworkConstants.BS_TEST_NAME
                )
        );

        options.setCapability(
                "noReset",
                false
        );

        return options;
    }

    // ================================================================
    // LOCAL ANDROID OPTIONS
    // ================================================================

    private static UiAutomator2Options
    getLocalAndroidOptions() {

        UiAutomator2Options options =
                new UiAutomator2Options();

        options.setPlatformName(
                "Android"
        );

        options.setDeviceName(
                FrameworkConstants.DEVICE_NAME
        );

        if (FrameworkConstants.DEVICE_UDID != null
                && !FrameworkConstants.DEVICE_UDID.isBlank()) {

            options.setUdid(
                    FrameworkConstants.DEVICE_UDID
            );
        }

        options.setAutomationName(
                "UiAutomator2"
        );

        options.setAppPackage(
                FrameworkConstants.APP_PACKAGE
        );

        options.setAppActivity(
                FrameworkConstants.APP_ACTIVITY
        );

        options.setNoReset(
                false
        );

        options.setNewCommandTimeout(
                Duration.ofSeconds(60)
        );

        if (FrameworkConstants.PLATFORM_VERSION != null
                && !FrameworkConstants.PLATFORM_VERSION.isBlank()) {

            options.setPlatformVersion(
                    FrameworkConstants.PLATFORM_VERSION
            );
        }

        return options;
    }

    // ================================================================
    // LOCAL IOS OPTIONS
    // ================================================================

    private static XCUITestOptions
    getLocalIosOptions() {

        XCUITestOptions options =
                new XCUITestOptions();

        options.setPlatformName(
                "iOS"
        );

        options.setDeviceName(
                FrameworkConstants.DEVICE_NAME
        );

        if (FrameworkConstants.IOS_APP_PATH != null
                && !FrameworkConstants.IOS_APP_PATH.isBlank()) {

            options.setApp(
                    FrameworkConstants.IOS_APP_PATH
            );
        }

        if (FrameworkConstants.DEVICE_UDID != null
                && !FrameworkConstants.DEVICE_UDID.isBlank()) {

            options.setUdid(
                    FrameworkConstants.DEVICE_UDID
            );
        }

        options.setAutomationName(
                "XCUITest"
        );

        options.setNoReset(
                false
        );

        options.setNewCommandTimeout(
                Duration.ofSeconds(60)
        );

        if (FrameworkConstants.PLATFORM_VERSION != null
                && !FrameworkConstants.PLATFORM_VERSION.isBlank()) {

            options.setPlatformVersion(
                    FrameworkConstants.PLATFORM_VERSION
            );
        }

        return options;
    }

    // ================================================================
    // QUIT DRIVER
    // ================================================================

    /**
     * Quits the Appium driver associated with the current thread.
     *
     * No screen recording or video processing is performed.
     */
    public static void quitDriver() {
        quitDriver(null, null);
    }

    /**
     * Marks the BrowserStack session as passed/failed (so it does not show
     * as "Unmarked"), then quits the driver.
     *
     * @param passed null to skip marking
     * @param reason short reason shown on the BrowserStack session
     */
    public static void quitDriver(Boolean passed, String reason) {

        AppiumDriver currentDriver =
                DRIVER.get();

        if (currentDriver != null
                && passed != null
                && "browserstack".equals(EXECUTION_MODE.get())) {
            try {
                String safeReason = reason == null ? ""
                        : reason.replace("\\", "\\\\").replace("\"", "'")
                                .replaceAll("[\\r\\n]+", " ");
                if (safeReason.length() > 250) {
                    safeReason = safeReason.substring(0, 250);
                }
                currentDriver.executeScript(
                        "browserstack_executor: {\"action\": \"setSessionStatus\", \"arguments\": "
                                + "{\"status\":\"" + (passed ? "passed" : "failed")
                                + "\", \"reason\": \"" + safeReason + "\"}}"
                );
            } catch (Exception e) {
                LogUtils.info(
                        "-----> WARN: Could not set BrowserStack session status: "
                                + e.getMessage()
                );
            }
        }

        if (currentDriver == null) {

            LogUtils.info(
                    "-----> DEBUG: No mobile driver found"
            );

            cleanupThreadLocal();

            return;
        }

        try {

            currentDriver.quit();

            LogUtils.info(
                    "-----> Mobile Appium driver quit successfully"
            );

        } catch (Exception e) {

            LogUtils.info(
                    "-----> WARN: Mobile driver quit failed: "
                            + e.getMessage()
            );

        } finally {

            cleanupThreadLocal();
        }
    }

    // ================================================================
    // DEVICE DETAILS
    // ================================================================

    private static void updateDeviceDetails(
            AppiumDriver appiumDriver,
            String platform
    ) {

        try {

            Object deviceNameCapability =
                    appiumDriver
                            .getCapabilities()
                            .getCapability(
                                    "deviceName"
                            );

            String deviceName;

            if (deviceNameCapability != null) {

                deviceName =
                        deviceNameCapability.toString();

            } else if (
                    "browserstack".equals(
                            EXECUTION_MODE.get()
                    )
            ) {

                deviceName =
                        FrameworkConstants.BS_DEVICE_NAME;

            } else {

                deviceName =
                        FrameworkConstants.DEVICE_NAME;
            }

            DEVICE_DETAILS.set(
                    platform.toUpperCase()
                            + " ["
                            + EXECUTION_MODE
                            .get()
                            .toUpperCase()
                            + "] - "
                            + deviceName);

        } catch (Exception e) {

            DEVICE_DETAILS.set(
                    platform.toUpperCase()
                            + " ["
                            + (
                            EXECUTION_MODE.get() == null
                                    ? "UNKNOWN"
                                    : EXECUTION_MODE
                                    .get()
                                    .toUpperCase()
                    )
                            + "]");
        }
    }

    // ================================================================
    // CONFIGURATION VALIDATION
    // ================================================================

    private static void validateBrowserStackConfiguration() {

        validateRequired(
                "BROWSERSTACK_USERNAME",
                FrameworkConstants.BROWSERSTACK_USERNAME
        );

        validateRequired(
                "BROWSERSTACK_ACCESS_KEY",
                FrameworkConstants.BROWSERSTACK_ACCESS_KEY
        );

        validateRequired(
                "BROWSERSTACK_APP_URL",
                FrameworkConstants.BROWSERSTACK_APP_URL
        );

        validateRequired(
                "BS_DEVICE_NAME",
                FrameworkConstants.BS_DEVICE_NAME
        );

        validateRequired(
                "BS_OS_VERSION",
                FrameworkConstants.BS_OS_VERSION
        );
    }

    private static void validateRequired(
            String propertyName,
            String value
    ) {

        if (value == null
                || value.isBlank()) {

            throw new IllegalStateException(
                    propertyName
                            + " is not configured."
            );
        }
    }

    // ================================================================
    // SYSTEM PROPERTY OVERRIDE
    // ================================================================

    private static String getProperty(
            String propertyName,
            String defaultValue
    ) {

        String systemValue =
                System.getProperty(
                        propertyName
                );

        if (systemValue != null
                && !systemValue.isBlank()) {

            return systemValue.trim();
        }

        return defaultValue;
    }

    // ================================================================
    // THREADLOCAL CLEANUP
    // ================================================================

    private static void cleanupThreadLocal() {

        DRIVER.remove();

        EXECUTION_MODE.remove();

        DEVICE_DETAILS.remove();
    }
}
