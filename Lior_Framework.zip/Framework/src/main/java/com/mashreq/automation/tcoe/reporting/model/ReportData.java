package com.mashreq.automation.tcoe.reporting.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReportData {
    // Getters and Setters
    @JsonProperty("buildNumber")
    private String buildNumber;
    @JsonProperty("executionTime")
    private String executionTime;
    @JsonProperty("features")
    private List<Feature> features;

    // --- Parallel Time Fix: This field holds the true wall-clock duration of the suite ---
    @JsonProperty("totalDurationMillis")
    private Long totalDurationMillis;

}