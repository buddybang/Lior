package com.mashreq.automation.tcoe.stepdefinitions.Mobile;

import com.mashreq.automation.tcoe.context.ScreenshotContextHolder;
import com.mashreq.automation.tcoe.hooks.ApplicationHooks;
import com.mashreq.automation.tcoe.utils.FeatureStepCollector;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.keywords.IActionLogger;
import com.mashreq.automation.tcoe.pages.Mobile.MobileLoginPage;
import com.mashreq.automation.tcoe.utils.DataHandler;
import com.mashreq.automation.tcoe.utils.DataTableUtils;
import com.mashreq.automation.tcoe.utils.LogUtils;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;

import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public class MobileLoginSteps {

    private final ScenarioContext ctx;
    private final MobileLoginPage loginPage;
    private final DataHandler dataHandler;
    private final String moduleName;
    private final String scenarioId;

// ✅ Action Logger connected to FeatureStepCollector
    static class LocalActionLogger implements IActionLogger {

        private final FeatureStepCollector collector =
                new FeatureStepCollector();

        @Override
        public <T> T logAction(
                String description,
                Supplier<T> action) {

            return collector.logAction(
                    description,
                    action
            );
        }
    }

    // ✅ Constructor (Aligned with Web Steps)
    public MobileLoginSteps(ScenarioContext ctx) {
        this.ctx = ctx;

        IActionLogger logger = new LocalActionLogger();
        this.loginPage = new MobileLoginPage(ctx, logger);

        this.dataHandler = new DataHandler();
        this.moduleName = ctx.getCurrentModule();
        this.scenarioId = ctx.getScenarioId();
    }

    // ========================= STEP DEFINITIONS =========================


    /**
     *  Enter field dynamically (like CommonPage.enterField)
     */

    @When("User enter the {string}")
    public void userEnterThe(String fieldName) {

        String value = dataHandler.getTestDataOrThrow(moduleName, scenarioId, fieldName);
        LogUtils.info("The Module Name is: " + moduleName);
        loginPage.enterthevalue(fieldName, value);

    }


    @And("user presses Android back button")
    public void userPressesAndroidBackButton() {

        loginPage.pressBackButton();
    }

    @And("user presses Android home button")
    public void userPressesAndroidHomeButton() {

        loginPage.pressHomeButton();
    }

    @And("user opens recent apps")
    public void userOpensRecentApps() {

        loginPage.openRecentAppsScreen();
    }

    @And("the user enters credentials from test data {string} and {string}")
    public void theUserEntersCredentialsFromTestDataAnd(String arg0, String arg1) {
        String username = dataHandler.getTestDataOrThrow(moduleName, scenarioId, arg0);

        String password = dataHandler.getTestDataOrThrow(moduleName, scenarioId, arg1);

        loginPage.enterthevalue(arg0, username);
        loginPage.enterthevalue(arg1, password);
    }

    /**
     * ✅ Verify message dynamically
     */

}
