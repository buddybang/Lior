package com.mashreq.automation.tcoe.stepdefinitions.Web;

import com.mashreq.automation.tcoe.constants.FrameworkConstants;
import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.driver.DriverManager;
import com.mashreq.automation.tcoe.keywords.WebUI;
import com.mashreq.automation.tcoe.pages.CommonPage;
import com.mashreq.automation.tcoe.users.User;
import com.mashreq.automation.tcoe.users.UserPair;
import com.mashreq.automation.tcoe.utils.*;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.PendingException;
import io.cucumber.java.en.*;

import java.time.Duration;
import java.util.Map;

import static com.mashreq.automation.tcoe.driver.DriverManager.getPage;

public class CommonSteps {

    private final ScenarioContext ctx;
    private final CommonPage commonPage;
    private final WebUI webUI;
    private final DataHandler dataHandler;

    private final String moduleName = "Common";
    private final String scenarioId = "ScenarioId";

    /**
     * Constructor
     */
    public CommonSteps(ScenarioContext ctx) {
        this.ctx = ctx;
        this.webUI = new WebUI(ctx, new FeatureStepCollector());
        this.commonPage = new CommonPage(this.webUI);
        this.dataHandler = new DataHandler();
    }



    @Given("user {string} is logged into {string} with appropriate privileges")
    public void user_is_logged_into_with_appropriate_privileges(String userRole, String application)
            throws InterruptedException {

        DriverManager.initDriver();

        Page page = DriverManager.getPage();

        ctx.setPage(page);

        LogUtils.info(
                "Web Driver started: "
                        + DriverManager.getBrowserVersion()
        );

        UserPair allocatedUserPair = ctx.getUserPair();
        if (allocatedUserPair == null) {
            throw new IllegalStateException("A UserPair was not checked out for this scenario.");
        }

        User userToLogin;

        if ("Maker".equalsIgnoreCase(userRole)) {
            userToLogin = allocatedUserPair.getMaker();
        } else if ("Checker".equalsIgnoreCase(userRole)) {
            userToLogin = allocatedUserPair.getChecker();
        } else if ("maker1".equalsIgnoreCase(userRole)) {
            userToLogin = allocatedUserPair.getMaker1();
        } else if ("Checker1".equalsIgnoreCase(userRole)) {
            userToLogin = allocatedUserPair.getChecker1();
        } else if ("makerOBPAY".equalsIgnoreCase(userRole)) {
            userToLogin = allocatedUserPair.makerOBPAY();
        } else if ("checkerOBAPY".equalsIgnoreCase(userRole)) {
            userToLogin = allocatedUserPair.checkerOBAPY();
        } else if ("usobtfpmMaker".equalsIgnoreCase(userRole)) {
            userToLogin = allocatedUserPair.usobtfpmMaker();
        } else if ("usobtfpmChecker".equalsIgnoreCase(userRole)) {
            userToLogin = allocatedUserPair.usobtfpmChecker();
        } else if ("usobtfmaker".equalsIgnoreCase(userRole)) {
            userToLogin = allocatedUserPair.usobtfmaker();
        } else if ("usobtfChecker".equalsIgnoreCase(userRole)) {
            userToLogin = allocatedUserPair.usobtfChecker();
        } else if ("ukobtfpmMaker".equalsIgnoreCase(userRole)) {
            userToLogin = allocatedUserPair.ukobtfpmMaker();
        } else if ("ukobtfpmChecker".equalsIgnoreCase(userRole)) {
            userToLogin = allocatedUserPair.ukobtfpmChecker();
        } else if ("ukobtfmaker".equalsIgnoreCase(userRole)) {
            userToLogin = allocatedUserPair.ukobtfmaker();
        } else if ("ukobtfChecker".equalsIgnoreCase(userRole)) {
            userToLogin = allocatedUserPair.ukobtfChecker();
        } else {
            throw new IllegalArgumentException("Unsupported user role: '" + userRole + "'");
        }

        if (userToLogin == null || userToLogin.getUserName() == null) {
            throw new RuntimeException("User object for role '" + userRole + "' is not configured in users.json.");
        }

        String username = userToLogin.getUserName();
        String password = userToLogin.getPassword();

        if (application.equalsIgnoreCase("OBDX")) {
            commonPage.navigateToLoginPage(FrameworkConstants.getBaseUrl(application));
            commonPage.login(username, password);

        } else if (application.equalsIgnoreCase("OBPM")) {
            commonPage.navigateToOBPMLoginPage(FrameworkConstants.getBaseUrl(application));
            commonPage.login(username, password);

        } else if (application.equalsIgnoreCase("OBTFPM")) {
            commonPage.navigateToOBTFPMLoginPage(FrameworkConstants.getBaseUrl(application));
            commonPage.OBTFPMlogin(username, password);

        } else if (application.equalsIgnoreCase("OBTF")) {
            commonPage.navigateToOBTFLoginPage(FrameworkConstants.getBaseUrl(application));
            commonPage.OBTFLogin(username, password);

        } else if (application.equalsIgnoreCase("OBPAY")) {
            commonPage.navigateToOBTFLoginPage(FrameworkConstants.getBaseUrl(application));
            commonPage.OBPAYlogin(username, password);
        }
    }


    // -------------------- NAVIGATION --------------------
    @When("user navigates to the {string} screen using {string}")
    public void user_navigates_to_the_screen_using(String expectedScreen, String fastpath) {
        commonPage.navigateFastpath(fastpath);
    }

    @Then("user verify {string} is displayed successfully")
    public void user_verify_is_displayed_successfully(String expectedScreen) {
        commonPage.verifyScreenName(expectedScreen);
    }

    @And("user selectOption {string} under {string} screen")
    public void userSelectOptionunderscreen(String fieldName, String screenName) {
        String testData = dataHandler.getTestDataOrThrow(moduleName, scenarioId, fieldName);
        String locator = LocatorUtils.byPath(moduleName + "/" + screenName + "/" + fieldName);

        commonPage.selectOption(locator,testData);
    }

    // -------------------- BRANCH DATE --------------------
    @Then("user retrieves the Branch date {string}")
    public void user_retrieves_the_branch_date(String branchdate) {
        String branchDateVal = commonPage.retrieveBranchDate(branchdate);
        String module = ctx.getCurrentModule();
        String scId = ctx.getScenarioId();
        dataHandler.writeTestData(module, scId, branchdate, branchDateVal);
    }


    // -------------------- DATA ENTRY --------------------

    @And("user enters the following field details under {string} screen")
    public void userEntersFieldDetails(String screenName, DataTable dataTable) {

        Locator preloader = getPage().locator("//div[@id='common-preloader']");
        Locator progressCircle = getPage().locator("(//*[@id='progressCircle'])[2]");

        waitForSpinnerToDisappear(preloader);
        waitForSpinnerToDisappear(progressCircle);

        String module = ctx.getCurrentModule();
        Map<String, String> dataToEnter = DataTableUtils.toMap(dataTable, dataHandler, module);

        dataToEnter.forEach((field, value) -> {
            commonPage.enterFieldAndTab(module, screenName, field, value);
            handleInfoPopupIfVisible();
        });
    }

    private void handleInfoPopupIfVisible() {
        String locatorStr = "(//*[contains(@id,'alertDialogId')]//*[@id='okBtn '])[1]";
        Locator infoBtn = getPage().locator(locatorStr);
        clickIfVisible(infoBtn, 3000, "Info dialog closed.", "No info dialog appeared.");
    }

    private void clickIfVisible(Locator locator, int timeoutMs, String successMsg, String missMsg) {
        try {
            locator.waitFor(new Locator.WaitForOptions()
                    .setState(WaitForSelectorState.VISIBLE)
                    .setTimeout(timeoutMs));
            locator.click(new Locator.ClickOptions().setTimeout(2000));
            LogUtils.info(successMsg);
        } catch (Exception e) {
            LogUtils.info(missMsg);
        }
    }

    @And("user enters and tab out the following field details under {string} screen")
    public void userEntersAndTabOut(String screenName, DataTable dataTable) {
        String module = ctx.getCurrentModule();
        Map<String, String> data = DataTableUtils.toMap(dataTable, dataHandler, module);
        data.forEach((field, value) -> commonPage.enterFieldAndTab(module, screenName, field, value));
    }

    @And("user select the following field details under {string} screen")
    public void userSelectFieldDetails(String screenName, DataTable dataTable) {
        String module = ctx.getCurrentModule();
        Map<String, String> data = DataTableUtils.toMap(dataTable, dataHandler, module);
        data.forEach((field, value) -> commonPage.selectField(module, screenName, field, value));
    }

    @And("user enters the following field details under {string} screen for another credit account")
    public void userEntersSIFields(String screenName, DataTable dataTable) {
        String module = ctx.getCurrentModule();
        Map<String, String> data = DataTableUtils.toMap(dataTable, dataHandler, module);

        data.forEach((field, value) -> {
            String actualField = field.endsWith("_1") ? field.substring(0, field.length() - 2) : field;
            commonPage.enterField(module, screenName, actualField, value);
        });
    }

    @And("user modifies the following field details under {string} screen")
    public void userModifiesFields(String screenName, DataTable dataTable) {
        String module = ctx.getCurrentModule();
        Map<String, String> data = DataTableUtils.toMap(dataTable, dataHandler, module);

        data.forEach((field, value) -> {
            String actualField = field.endsWith("_1") ? field.substring(0, field.length() - 2) : field;
            commonPage.enterField(module, screenName, actualField, value);
        });
    }

    @And("user verifies the modified field details under {string} screen")
    public void userVerifiesModifiedFields(String screenName, DataTable dataTable) {
        String module = ctx.getCurrentModule();
        Map<String, String> data = DataTableUtils.toMap(dataTable, dataHandler, module);

        data.forEach((field, value) -> {
            String actualField = field.endsWith("_1") ? field.substring(0, field.length() - 2) : field;
            commonPage.verifyField(module, screenName, actualField, value);
        });
    }

    @When("user retrieves the following field value under {string} screen")
    public void userRetrievesFieldValue(String screenName, DataTable dataTable)
            throws InterruptedException {

        waitUntilScreenSettled();

        String module = ctx.getCurrentModule();
        String scId = ctx.getScenarioId();

        Map<String, String> data = DataTableUtils.toMap(dataTable, dataHandler, module);

        data.forEach((field, unused) -> {
            String value = commonPage.retrieveField(module, screenName, field, field);
            dataHandler.writeTestData(module, scId, field, value);
        });
    }


    // -------------------- COMMON BUTTONS --------------------

    @Then("user click {string}")
    public void user_click(String buttonName) {
        commonPage.clickButton(buttonName);
    }

    @Then("user Accepts the Override message")
    public void userAcceptsOverride() {
        commonPage.acceptOverrideMessage();
    }

    @Then("user verify the pop up for {string} message {string}")
    public void userVerifyPopupMessage(String messageType, String expectedMsg) {
        commonPage.verifyPopupMessage(expectedMsg);
    }

    @Then("user logout of the FCUBS application")
    public void userLogoutFCUBS() {
        commonPage.logout();
    }

    @Then("user is able to validate authorization status as {string}")
    public void userValidateAuthStatus(String expectedStatus) {
        commonPage.verifyAuthStatus(expectedStatus);
    }


    // -------------------- BRANCH SWITCH --------------------

    @Then("user switch to branch")
    public void userSwitchToBranch() throws InterruptedException {
        webUI.waitForPageToLoad();
        String branchCode = dataHandler.getTestDataOrThrow(moduleName, "CommonData", "BranchCode");
        commonPage.switchBranch(branchCode);
    }

    @And("user switch to {string}")
    public void userSwitchTo(String homeBranch) {
        commonPage.switchToHomeBranch(homeBranch);
    }


    // -------------------- FIELD VERIFICATIONS --------------------
    @And("user verify the following field details under {string} screen")
    public void userVerifyFields(String screenName, DataTable dataTable) {
        String module = ctx.getCurrentModule();
        Map<String, String> expected = DataTableUtils.toMap(dataTable, dataHandler, module);
        expected.forEach((field, value) -> commonPage.verifyField(module, screenName, field, value));
    }

    @Then("user verify {string} is visible")
    public void userVerifyIsVisible(String label) {
        commonPage.verifyIsDisplayed();
    }

    @Then("user is able to validate the close authorization status as {string}")
    public void userValidateCloseAuthStatus(String expectedStatus) {
        commonPage.verifyCloseAuthStatus(expectedStatus);
    }

    @Then("user is able to validate customer authorization status as {string}")
    public void userValidateCustomerAuthStatus(String expectedStatus) {
        commonPage.verifyCustomerAuthStatus(expectedStatus);
    }

    @Then("user verify the pop up for confirmation message {string}")
    public void userVerifyConfirmationPopup(String expectedMsg) {
        commonPage.verifyPopupMessage(expectedMsg);
    }

    @And("user verify the {string} checkbox")
    public void userVerifyCheckbox(String fieldName) {
        commonPage.verifyRadioCheckboxbtn(fieldName);
    }


    // -------------------- ENTITY SWITCH --------------------
    @When("user switch to Entity")
    public void userSwitchToEntity() {
        String entityCode = dataHandler.getTestDataOrThrow(moduleName, "CommonData", "Entity");
        commonPage.switchEntity(entityCode);
    }

    @When("user click {string} under {string} screen")
    public void userClickUnderScreen(String buttonName, String screenName) {
        String module = ctx.getCurrentModule();
        commonPage.clickButtonMod(module, screenName, buttonName);
    }


    // -------------------- DATE HANDLING --------------------
    @When("user calculate dayoffset as {string} for {string}")
    public void userCalculateDayOffset(String dayOffset, String fieldName) {

        String module = ctx.getCurrentModule();
        String scId = ctx.getScenarioId();

        String branchDate = commonPage.retrieveBranchDate("");
        String adjustedDate = WebUI.adjustDate(branchDate, Integer.parseInt(dayOffset), "MM/dd/yyyy");

        dataHandler.writeTestData(module, scId, fieldName, adjustedDate);
    }

    @And("user select the {string} option")
    public void userSelectRadioOption(String button) {
        commonPage.clickRadioCheckboxbtn(button);
    }

    @Then("user Doubleclick {string} under {string} screen")
    public void userDoubleClick(String buttonName, String screenName) {
        String module = ctx.getCurrentModule();
        commonPage.DoubleclickButton(module, screenName, buttonName);
    }


    // -------------------- SPINNER HANDLING --------------------

    private void waitForSpinnerToDisappear(Locator locator) {
        try {
            locator.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN));
        } catch (Exception stillVisible) {
            LogUtils.warn("Loading indicator " + locator + " is still visible after the wait (" + stillVisible.getMessage()
                    + "). Continuing: the next step waits for its own element.");
        }
    }

    /** Page loaded and the usual loading indicators gone: used instead of fixed pauses. */
    private void waitUntilScreenSettled() {
        webUI.waitForPageToLoad();
        waitForSpinnerToDisappear(getPage().locator("//div[@id='common-preloader']"));
        waitForSpinnerToDisappear(getPage().locator("(//*[@id='progressCircle'])[2]"));
    }


    // -------------------- OBTFPM --------------------

    @Then("user logout of the OBTFPM application")
    public void userLogoutOBTFPM() throws InterruptedException {
        Locator preloader = getPage().locator("//div[@id='common-preloader']");
        Locator progressCircle = getPage().locator("(//*[@id='progressCircle'])[2]");

        waitForSpinnerToDisappear(preloader);
        waitForSpinnerToDisappear(progressCircle);

        webUI.waitForPageToLoad();
        commonPage.OBTFPMlogout();
    }

    @Then("user verify {string} is displayed successfully in OBTFPM")
    public void userVerifyOBTFPMScreen(String expectedScreen) {
        commonPage.OBTFPMverifyScreenName(expectedScreen);
    }

    @Then("user retrieves the OBTFPM Branch date {string}")
    public void userRetrieveOBTFPMBranchDate(String branchdate) {
        String val = commonPage.OBTFPMretrieveBranchDate(branchdate);
        String module = ctx.getCurrentModule();
        String scId = ctx.getScenarioId();
        dataHandler.writeTestData(module, scId, branchdate, val);
    }

    /** The browser's Back button. */
    @And("user goes back to the previous page")
    public void userGoesBackToThePreviousPage() {
        webUI.navigateBack();
    }

    @Given("user navigates to the URL")
    public void userNavigatesToTheURL() {
        commonPage.navigateToLoginPage(FrameworkConstants.getBaseUrl("FCUBS"));
    }
}