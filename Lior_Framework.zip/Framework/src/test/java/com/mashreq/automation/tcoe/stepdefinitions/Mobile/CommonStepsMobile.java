package com.mashreq.automation.tcoe.stepdefinitions.Mobile;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.context.ScreenshotContextHolder;
import com.mashreq.automation.tcoe.driver.MobileDriverManager;
import com.mashreq.automation.tcoe.hooks.ApplicationHooks;
import com.mashreq.automation.tcoe.keywords.IActionLogger;
import com.mashreq.automation.tcoe.pages.Mobile.CommonMobilePage;
import com.mashreq.automation.tcoe.utils.DataHandler;
import com.mashreq.automation.tcoe.utils.DataTableUtils;
import com.mashreq.automation.tcoe.utils.LogUtils;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

import java.util.List;
import java.util.Map;

public class CommonStepsMobile {
    private final ScenarioContext ctx;
    private final CommonMobilePage CommonPage;
    private final DataHandler dataHandler;
    private final String moduleName;
    private final String scenarioId;

    public CommonStepsMobile(ScenarioContext ctx) {

        this.ctx = ctx;

        IActionLogger logger = new MobileLoginSteps.LocalActionLogger();
        this.CommonPage = new CommonMobilePage(ctx, logger);

        this.dataHandler = new DataHandler();
        this.moduleName = ctx.getCurrentModule();
        this.scenarioId = ctx.getScenarioId();
    }


    @And("user clicks the {string} button under {string} screen")
    public void userClicksTheButtonUnderScreen(String buttonName, String screenname) {

        String module = ctx.getCurrentModule();
        CommonPage.clickButton(buttonName, module, screenname);

    }


    @And("user enters the following Mobile field details under {string} screen")
    public void userEntersTheFollowingMobileFieldDetailsUnderScreen(
            String screenName,
            DataTable dataTable) {

        String module = ctx.getCurrentModule();

        Map<String, String> data =
                DataTableUtils.toMap(dataTable, dataHandler, module);

        data.forEach((field, value) ->
                CommonPage.enter(module, screenName, field, value));

    }


    @And("user enters the following input field details under {string} screen")
    public void userEntersTheFollowingInputFieldDetailsUnderScreen(
            String screenName,
            DataTable dataTable) {

        String module = ctx.getCurrentModule();

        Map<String, String> data =
                DataTableUtils.toMap(dataTable, dataHandler, module);

        data.forEach((field, value) ->
                CommonPage.inputandEnter(module, screenName, field, value));
    }

    @And("user scrolls and clicks the {string} button under {string} screen")
    public void userScrollsAndClicksButtonUnderScreen(
            String buttonName,
            String screenName) {

        String module = ctx.getCurrentModule();
        CommonPage.scrollToElementAndClick(buttonName, module, screenName);

    }

    @Then("user verifies the following mobile field details under {string} screen")

    public void userVerifiesTheFollowingMobileFieldDetailsUnderScreen(

            String screenName,

            DataTable dataTable) {

        String module = ctx.getCurrentModule();

        List<String> fields = dataTable.asList();

        fields.forEach(field -> {

            String expectedValue =

                    dataHandler.getTestDataOrThrow(

                            module,

                            scenarioId,

                            field);


            CommonPage.verifyMessage(

                    field,

                    expectedValue,

                    screenName,

                    module);

        });

    }


    @Then("the user verifies the following elements should be {string} under {string} screen")
    public void theUserVerifiesTheFollowingElementsStateUnderScreen(
            String expectedState,
            String screenName,
            DataTable dataTable) {

        String module = ctx.getCurrentModule();

        List<String> elements = dataTable.asList();

        for (String elementName : elements) {

            CommonPage.verifyElementState(
                    elementName,
                    expectedState,
                    module,
                    screenName);
        }
    }


    @Then("the user retrieves the following mobile field text under {string} screen")
    public void theUserRetrievesTheFollowingMobileFieldTextUnderScreen(
            String screenName,
            DataTable dataTable) {

        String module = ctx.getCurrentModule();
        String scId = ctx.getScenarioId();

        List<String> fields = dataTable.asList();

        for (String field : fields) {

            String actualText = CommonPage.retrieveText(
                    field,
                    module,
                    screenName);

            LogUtils.info(
                    "Retrieved text for '" + field +
                            "' : " + actualText);

            // Write to test data
            dataHandler.writeTestData(
                    module,
                    scId,
                    field,
                    actualText);
        }
    }

    /** Lior "Swipe and tap" with the number of swipes recorded, e.g. user swipes up 3 time(s) and clicks the "X" button under "S" screen. */
    @And("user swipes {word} {int} time(s) and clicks the {string} button under {string} screen")
    public void userSwipesTimesAndClicks(String direction, int times, String buttonName, String screenName) {
        CommonPage.swipeVerticallyAndClick(direction, times, buttonName, ctx.getCurrentModule(), screenName);
    }

    /** Lior "Swipe and tap" without a count (older recordings): swipes to the end of the content, then taps. */
    @And("user swipes {word} and clicks the {string} button under {string} screen")
    public void userSwipesToEndAndClicks(String direction, String buttonName, String screenName) {
        CommonPage.swipeVerticallyAndClick(direction, 0, buttonName, ctx.getCurrentModule(), screenName);
    }

    @And("user swipes and clicks the {string} button under {string} screen")
    public void userSwipesAndClicksTheButtonUnderScreen(
            String buttonName,
            String screenName) {

        String module = ctx.getCurrentModule();

        CommonPage.swipeAndClickButton(
                buttonName,
                module,
                screenName);
    }

    // Terms screens keep the checkbox (and so the confirm button) disabled until the document is scrolled to the end.
    @And("user accepts the {string} terms and clicks the {string} button under {string} screen")
    public void userAcceptsTheTermsAndClicksTheButtonUnderScreen(
            String checkboxName,
            String buttonName,
            String screenName) {

        String module = ctx.getCurrentModule();

        CommonPage.acceptTermsAndContinue(
                checkboxName,
                buttonName,
                module,
                screenName);
    }

    @Given("the mobile app is launched")
    public void verifyAppLaunched() {

        new MobileLoginSteps.LocalActionLogger().logAction(
                "Mobile app launched successfully",
                () -> {

                    String path =
                            ApplicationHooks.takeScreenshot(
                                    ctx.getScenarioId()
                            );

                    ScreenshotContextHolder
                            .publishLastScreenshotPath(path);

                    LogUtils.info(
                            "Mobile Application is ready for interaction."
                    );

                    return "PASSED";
                }
        );
    }


    @And("user logs into the application under {string} screen")
    public void userLogsIntoTheApplicationUnderScreen(String screenName) {

        String module = ctx.getCurrentModule();

        CommonPage.clickButton("Login", module, screenName);
        CommonPage.clickButton("Loginwithpassword", module, screenName);

        CommonPage.enter(
                module,
                screenName,
                "Userid",
                dataHandler.getTestDataOrThrow(module, scenarioId, "Userid"));

        CommonPage.clickButton("ForwardArrow", module, screenName);

        CommonPage.enter(
                module,
                screenName,
                "Password",
                dataHandler.getTestDataOrThrow(module, scenarioId, "Password"));

        CommonPage.clickButton("Login1", module, screenName);

        CommonPage.inputandEnter(
                module,
                screenName,
                "Loginpin",
                dataHandler.getTestDataOrThrow(module, scenarioId, "Loginpin"));

        CommonPage.clickButton("Continue", module, screenName);

        CommonPage.inputandEnter(
                module,
                screenName,
                "Confirmloginpin",
                dataHandler.getTestDataOrThrow(module, scenarioId, "Confirmloginpin"));

        CommonPage.clickButton("Continue", module, screenName);

        CommonPage.clickButton("Biometricslater", module, screenName);
        CommonPage.clickButton("Login2", module, screenName);
        CommonPage.clickButton("LoginwithPIN", module, screenName);

        CommonPage.inputandEnter(
                module,
                screenName,
                "EntersixdigitPIN",
                dataHandler.getTestDataOrThrow(module, scenarioId, "EntersixdigitPIN"));

        CommonPage.clickButton("PINContinue", module, screenName);

        CommonPage.acceptTermsAndContinue(
                "Termsandcondition",
                "Agreeandcontinue",
                module,
                screenName);
    }



    @Then("user scroll and verify with following mobile fields under {string} screen")
    public void userVerifyWithGeneralDetailsSectionUnderScreen(
            String screenName,
            DataTable dataTable) {

        String module = ctx.getCurrentModule();

        List<String> messageKeys = dataTable.asList();

        for (String messageKey : messageKeys) {

            String expectedValue =
                    dataHandler.getTestDataOrThrow(
                            module,
                            scenarioId,
                            messageKey
                    );

            CommonPage.scrollAndVerifyText(
                    messageKey,
                    expectedValue,
                    screenName,
                    module
            );
        }
    }

    @And("user double click the {string} element under {string} screen")
    public void doubleClickElementUnderScreen(
            String elementName,
            String screenname) {

        String module = ctx.getCurrentModule();

        CommonPage.doubleClick(
                elementName,
                module,
                screenname);
    }





}
