//Created by TCOE automation team - Jul-25

package com.mashreq.automation.tcoe.stepdefinitions;

import com.mashreq.automation.tcoe.utils.LogUtils;

import com.mashreq.automation.tcoe.constants.CIF;
import com.mashreq.automation.tcoe.constants.COMMON;
import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.keywords.WebUI;
import com.mashreq.automation.tcoe.pages.Web.CustomerMaintenancePage;
import com.mashreq.automation.tcoe.pages.CommonPage;
import com.mashreq.automation.tcoe.utils.DataHandler;
import com.mashreq.automation.tcoe.utils.DataTableUtils;
import com.mashreq.automation.tcoe.utils.FeatureStepCollector;
import com.mashreq.automation.tcoe.utils.LocatorUtils;
import com.microsoft.playwright.FrameLocator;
import com.microsoft.playwright.Page;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.util.Map;

import static com.mashreq.automation.tcoe.driver.DriverManager.getPage;
import static com.mashreq.automation.tcoe.keywords.WebUI.simplifyLocator;

public class CustomerMaintenanceSteps {

    private final ScenarioContext ctx;
    private final CustomerMaintenancePage customerMaintenancePage;
    private final DataHandler dataHandler;
    private final String moduleName;
    private final String scenarioId;
    private final CommonPage commonPage;


    /**
     * Constructor
     */
    public CustomerMaintenanceSteps(ScenarioContext ctx) {
        this.ctx = ctx;
        WebUI webUI = new WebUI(ctx, new FeatureStepCollector());
        this.customerMaintenancePage = new CustomerMaintenancePage(webUI);
        this.dataHandler = new DataHandler();
        this.commonPage = new CommonPage(webUI);

        this.moduleName = ctx.getCurrentModule();
        this.scenarioId = ctx.getScenarioId();
    }


    // -------------------- RETRIEVE / ENTER / MODIFY --------------------

    @Then("user retrieves the existing customer details {string}")
    public void user_retrieves_the_existing_customer_details(String fieldName) {
        // If the argument is a test-data key, resolve its value first:
        String customerNumber = dataHandler.getTestDataOrThrow(moduleName, scenarioId, fieldName);
        customerMaintenancePage.retrieveCustomerDetails(fieldName, customerNumber);
    }


    @Then("user retrieves the existing KYC details {string}")
    public void user_retrieves_the_existing_kyc_details(String fieldName) {
        // If the argument is a test-data key, resolve its value first:
        String customerFullName = dataHandler.getTestDataOrThrow(moduleName, scenarioId, "KYCCustomerFullName");
        String RiskLevel = dataHandler.getTestDataOrThrow(moduleName, scenarioId, "RiskLevel");
        String KYCRefNo = dataHandler.getTestDataOrThrow(moduleName, scenarioId, fieldName);
        customerMaintenancePage.retrieveKYCDetails(KYCRefNo,customerFullName, RiskLevel);
    }

    @Then("user retrieves the KYC Reference {string}")
    public void user_retrieves_the_kyc_ref_number(String kycRefNo) {
        String kycRefNoVal = customerMaintenancePage.retrieveKYCRef(kycRefNo);
        String moduleName = this.moduleName; //Updated code to store "BranchDate" in current scenario - Kumaran 24-Sep-25
        String scenarioId = this.scenarioId;
        dataHandler.writeTestData(moduleName, scenarioId, kycRefNo, kycRefNoVal);
    }

    @And("user verify the following linked field details under {string} screen")
    public void userVerifyTheFollowingFieldDetailsCIF(String screenName, DataTable dataTable) {
        String moduleName = this.moduleName;
        Map<String, String> dataToEnter = DataTableUtils.toMap(dataTable, dataHandler, moduleName);

        dataToEnter.forEach((field, value) -> {
            // Strip "_1" if present to match actual UI field name
            String actualField = field.endsWith("_1") ? field.substring(0, field.length() - 2) : field;

            // Pass cleaned field name to UI
            commonPage.verifyField(moduleName, screenName, actualField, value);
        });
    }


    @Then("user remove the linked enities")
    public void userRemoveTheLinkedEnities() {
        customerMaintenancePage.removeLinkedEntities();
    }

    @Then("user remove the linked entities for individual Customer Type")
    public void userRemoveTheLinkedEntitiesForIndividual() {
        customerMaintenancePage.removeLinkedEntitiesForIndividual();
    }

    @Then("user navigates to the change log details")
    public void userVerifiesTheChangeLogDetails() {
        customerMaintenancePage.verifyChangeLogForLinkedEntity();

    }

    @Then("user enters the same details {string} and {string} under {string} screen")
    public void userEntersTheSameDetailsAndUnderScreen(String customer, String Relations, String screenName) {
        String customerNumber = dataHandler.getTestDataOrThrow(moduleName, scenarioId, customer);
        String relation = dataHandler.getTestDataOrThrow(moduleName, scenarioId, Relations);
        LogUtils.info(customerNumber+ "customerNumber---");
        LogUtils.info(relation+ "relation---");
        customerMaintenancePage.enterSameDetails(customerNumber, relation);
    }
    @And("user click {string} to verify the changes")
    public void userClickToVerifyTheChanges(String arg0) {
        String expand = LocatorUtils.byPath(COMMON.COMMONSCREEN_EXPAND);
        String changeLog = LocatorUtils.byPath(COMMON.COMMONSCREEN_CHANGELOG);
        String lastPage = LocatorUtils.byPath(COMMON.COMMONSCREEN_LASTPAGE);
        String viewChanges = LocatorUtils.byPath(COMMON.COMMONSCREEN_VIEWCHANGES);
        commonPage.clickButton(expand);
        commonPage.clickButton(changeLog);
        commonPage.handleLastPages();
        commonPage.clickButton(viewChanges);
        String locator = simplifyLocator(LocatorUtils.byPath(COMMON.COMMONSCREEN_LINKEDENTITY));
        FrameLocator cmFrame = ctx.getPage().frameLocator("iframe[title*='Customer Maintenance']").nth(1);
        cmFrame.locator(locator).click();
    }
    @And("user click {string} to verify the change log details")
    public void userClickToVerifyTheChangesIFromChangeLog(String arg0) {
        String expand = LocatorUtils.byPath(COMMON.COMMONSCREEN_EXPAND);
        String changeLog = LocatorUtils.byPath(COMMON.COMMONSCREEN_CHANGELOG);
        String lastPage = LocatorUtils.byPath(COMMON.COMMONSCREEN_LASTPAGE);
        String viewChanges = LocatorUtils.byPath(COMMON.COMMONSCREEN_VIEWCHANGES);
        commonPage.clickButton(expand);
        commonPage.clickButton(changeLog);
        commonPage.handleLastPages();
        commonPage.clickButton(viewChanges);
    }

    @And("user retrieve the Customer number {string}")
    public void userRetrieveTheCustomerNumber(String customerNumber) {
        String newCustomerNumber = customerMaintenancePage.retrieveCustomerNumber(customerNumber);
        dataHandler.writeTestData(moduleName, scenarioId, customerNumber, newCustomerNumber);
    }

    @And("user retrieve the Signature id {string}")
    public void userRetrieveTheSignatureId(String signatureId) {
        String newSignatureId = customerMaintenancePage.retrieveSignatureId(signatureId);
        dataHandler.writeTestData(moduleName, scenarioId, signatureId, newSignatureId);
        dataHandler.writeTestData(moduleName, scenarioId, "SignatureIdDetails", newSignatureId);
        String CustomerNumber = dataHandler.getTestDataOrThrow(moduleName, scenarioId, "CustomerNumber");
        dataHandler.writeTestData(moduleName, scenarioId, "CustomerNumberINSignature", CustomerNumber);
    }

    @Then("user upload the signature")
    public void userUploadTheSignature() {
        String addIconSignature = LocatorUtils.byPath(COMMON.COMMONSCREEN_ADDICONSIGNATURE);
        String SignatureImage = LocatorUtils.byPath(COMMON.COMMONSCREEN_SIGNATUREIMAGE);
        String ChooseFile = LocatorUtils.byPath(COMMON.COMMONSCREEN_CHOOSEFILE);
        String Upload = LocatorUtils.byPath(COMMON.COMMONSCREEN_UPLOAD);
        String SignatureOK = LocatorUtils.byPath(COMMON.COMMONSCREEN_SIGNATUREOK);
        commonPage.clickButton(addIconSignature);
        commonPage.clickButton(SignatureImage);
        String filePathTestdata = dataHandler.getTestDataOrThrow(moduleName, scenarioId, "filePath");
        customerMaintenancePage.uploadFile(ChooseFile,filePathTestdata);
        commonPage.clickButton(Upload);
        commonPage.clickButton(SignatureOK);
    }

    @When("user retrieves the existing {string} details with SignatureId details {string}")
    public void userRetrievesTheExistingDetailsWithSignatureIdDetails(String SignatureId, String CustomerNumberINSignature) {
        String SignatureID = dataHandler.getTestDataOrThrow(moduleName, scenarioId, SignatureId);
        String CustomerNumberINSignatureTestData = dataHandler.getTestDataOrThrow(moduleName, scenarioId, CustomerNumberINSignature);
        customerMaintenancePage.retrieveSignatureDetailsForSignbatureScreen(SignatureID, CustomerNumberINSignatureTestData);
    }


    @And("user select the option {string} under {string} screen")
    public void userSelectTheOptionunderscreen(String fieldName, String screenName) {
        String testData = dataHandler.getTestDataOrThrow(moduleName, scenarioId, fieldName);
        String locator = LocatorUtils.byPath(moduleName + "/" + screenName + "/" + fieldName);
        customerMaintenancePage.selectPayintype(locator, testData);
    }

    @Then("user generated the four digit {string}")
    public void userGeneratedTheFourDigit(String fieldName) {
        String batchNumber = customerMaintenancePage.randomFourDigit("batchNumber");
        dataHandler.writeTestData(moduleName, scenarioId, fieldName, batchNumber);
    }

    @And("user close the created signature")
    public void closeSignature() {
        Page page = getPage();
        String close = simplifyLocator(LocatorUtils.byPath(COMMON.COMMONSCREEN_CLOSE));
        FrameLocator cmFrame1 = page.frameLocator("iframe[title*='Customer Signature and Image Upload']").nth(0);
        cmFrame1.locator(close).click();
    }
    @Then("user exit the signature screen")
    public void exitSignatureScreen() {
        Page page = getPage();
        String exit = simplifyLocator(LocatorUtils.byPath(COMMON.COMMONSCREEN_EXITSIGNATUREAFTERCLOSE));
        FrameLocator cmFrame1 = page.frameLocator("iframe[title*='Customer Signature and Image Upload']").nth(0);
        cmFrame1.locator(exit).click();
    }

    @And("user click on {string} tab and enter {string}")
    public void userClickTabAndEnter(String tabName, String fieldName) {
        String moduleName = this.moduleName;
        customerMaintenancePage.clickButton(moduleName, tabName, "MIS");
        String testData = dataHandler.getTestDataOrThrow(moduleName, scenarioId, fieldName);
        commonPage.enterField(moduleName, tabName, fieldName, testData);
        String popupLocator = LocatorUtils.byPath(CIF.ACCOUNTMISDETAILS_MISOK);
        commonPage.clickButton(popupLocator);
    }

    @Then("user verify the {string} field in CustomerSignatoryDetails screen")
    public void userVerifyTheRemovedFromScreen(String SignatureIdDetails) {
        customerMaintenancePage.verifyTableRow();
    }

    @Then("user verify the created {string} under {string}")
    public void userVerifyTheCreatedSignature(String fieldName, String screenName) {
        String SignatureIdTestData = dataHandler.getTestDataOrThrow(moduleName, scenarioId, fieldName);
        customerMaintenancePage.verifyTableCellValue(SignatureIdTestData);
    }

    @Then("user click unlock the account")
    public void userClickUnlockTheAccount() {
        Page page = getPage();
        String Unlock = simplifyLocator(LocatorUtils.byPath(COMMON.COMMONSCREEN_UNLOCK));
        FrameLocator cmFrame1 = page.frameLocator("iframe[title*='KYC Maintenance']").nth(0);
        cmFrame1.locator(Unlock).click();
    }

    @When("user select {string} from the LOV for {string} under {string} screen")
    public void userSelectFromTheLOVForUnderScreen(String value, String locator, String screenname) {
        customerMaintenancePage.selectLov(value,locator);
    }


    // -------------------- Freeze / Defreeze (domain helpers used by SC_009) --------------------
    @Then("the user freezes the customer")
    public void theUserFreezesTheCustomer() {
        String frozenCheckboxLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_FROZEN);
        customerMaintenancePage.checkFrozenCheckboxStatus(frozenCheckboxLocator);
    }

    @Then("the user defreezes the customer")
    public void theUserDefreezesTheCustomer() {
        // TODO: implement in CommonPage according to your UI flow
        String frozenCheckboxLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_FROZEN);
        customerMaintenancePage.checkCustomerDefreezeStatus(frozenCheckboxLocator);
    }

    @Then("user freezes the customer")
    public void userFreezesTheCustomer() {
        String additionalTab = LocatorUtils.byPath(COMMON.COMMONSCREEN_ADDITIONAL);
        String frozen = LocatorUtils.byPath(COMMON.COMMONSCREEN_FROZEN);
        commonPage.clickButton(additionalTab);
        commonPage.clickButton(frozen);
    }

    @Then("user verifies the customer is Frozen")
    public void userVerifiesTheCustomerIsFrozen() {
        customerMaintenancePage.verifyCustomerIsFrozen();
    }

    @Then("user verifies the customer is in defreeze state")
    public void userVerifiesTheCustomerDefreeze() {
        customerMaintenancePage.verifyCustomerDefreeze();
    }

}
