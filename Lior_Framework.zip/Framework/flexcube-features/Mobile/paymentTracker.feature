@Mobile @WIP
Feature: Validate the payment tracker details across the different transaction types

 # @2701760-2701777, @2701806-2701817
  # Payment transaction validation
  Scenario: Payment Tracker landing page and UI validations
    Given the mobile app is launched
    And user logs into the application under "Loginflow" screen
    Then user validate the payment page "paymentTransaction" selection at "paymentTracker"
    When user validate the 20 default transaction displayed "
    Then user validates the recent transaction details
    And user scroll down all the transactions displayed
    When user verifies all types of transaction made