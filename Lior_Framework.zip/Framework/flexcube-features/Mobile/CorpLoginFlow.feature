# Made by Lior on 2026-10-02 23:37.
# The values typed or checked by these steps are in the test data file
# testdata/<NN>.CORPLOGIN/US_TestData_CORPLOGIN.json (look for the scenario id).
# A test recorded in several versions (other data) is one Scenario Outline: steps ending in "if ... in the test data"
# run only for the versions whose test data has that field.
# Run only this module:  mvn test -Pmobile -Dcucumber.tags="@CorpLogin"
@CorpLogin
Feature: CorpLogin - recorded mobile flow

  @Mobile @SC_001
  Scenario: CorpLogin|SC_001|Corp_Just_View
    Given the mobile app is launched
    Then the user verifies the following elements should be "visible" under "WelcomeScreenSlide3" screen
      |AndroidWidgetTextView|
    And user clicks the "AppWelcomeAccessibilityLoginButton" button under "WelcomeScreenSlide3" screen
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp" screen
      |AndroidWidgetTextView|
    And user clicks the "LoginWithPassword" button under "LoginToMashreqNeoCorp" screen
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp" screen
      |AndroidWidgetTextView|
    And user enters the following Mobile field details under "LoginToMashreqNeoCorp" screen
      |VerifyUsernameInputTextInput|
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp" screen
      |AndroidWidgetTextView|
    And user clicks the "VerifyUsernameInputRightIconButton" button under "LoginToMashreqNeoCorp" screen
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp" screen
      |AndroidWidgetTextView|
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp2" screen
      |AndroidWidgetTextView|
    And user enters the following Mobile field details under "LoginToMashreqNeoCorp2" screen
      |PasswordInputTextInput|
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp2" screen
      |AndroidWidgetTextView|
    And user clicks the "Login" button under "LoginToMashreqNeoCorp2" screen
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp2" screen
      |AndroidWidgetTextView|
    And user enters the following Mobile field details under "SetUpYourLoginPin" screen
      |SetUpA6DigitPin|
    Then the user verifies the following elements should be "visible" under "SetUpYourLoginPin" screen
      |SetUpYourLoginPin|
      |SetUpYourLoginPin|
    And user clicks the "Continue" button under "SetUpYourLoginPin" screen
    Then the user verifies the following elements should be "visible" under "ConfirmYourLoginPin" screen
      |ConfirmYourLoginPin|
    And user enters the following Mobile field details under "ConfirmYourLoginPin" screen
      |ConfirmYour6DigitPin|
    Then the user verifies the following elements should be "visible" under "ConfirmYourLoginPin" screen
      |ConfirmYourLoginPin|
      |ConfirmYourLoginPin|
    And user clicks the "Continue" button under "ConfirmYourLoginPin" screen
    Then the user verifies the following elements should be "visible" under "SetUpBiometrics" screen
      |SetUpBiometrics|
    And user clicks the "SetUpBiometricsLater" button under "SetUpBiometrics" screen
    Then the user verifies the following elements should be "visible" under "YourDeviceIsSetUp" screen
      |YourDeviceIsSetUp|
    And user clicks the "Login" button under "YourDeviceIsSetUp" screen
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp" screen
      |AndroidWidgetTextView|
    And user clicks the "LoginWithPinBiometrics" button under "LoginToMashreqNeoCorp" screen
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp4" screen
      |LoginToMashreqNeoCorp|
    And user enters the following Mobile field details under "LoginToMashreqNeoCorp4" screen
      |EnterYour6DigitPin|
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp4" screen
      |LoginToMashreqNeoCorp|
      |LoginToMashreqNeoCorp|
    And user clicks the "Continue" button under "LoginToMashreqNeoCorp4" screen
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp4" screen
      |LoginToMashreqNeoCorp|
    # Swipe up (the framework has no step for a loose swipe; use "Swipe and tap" instead)
    Then the user verifies the following elements should be "visible" under "EndUserLicenseAgreement" screen
      |EndUserLicenseAgreement|
    And user swipes up 5 times and clicks the "IAgreeToTheTermsConditions" button under "EndUserLicenseAgreement" screen
    And user clicks the "IAgreeToTheTermsConditions" button under "EndUserLicenseAgreement" screen
    And user clicks the "IAgreeToTheTermsConditions" button under "EndUserLicenseAgreement" screen
    And user clicks the "AgreeContinue" button under "EndUserLicenseAgreement" screen
    Then the user verifies the following elements should be "visible" under "Tada" screen
      |HomeLabel|
    Then the user verifies the following elements should be "visible" under "HelloMakerft2" screen
      |AndroidWidgetTextView|
    And user clicks the "Accounts" button under "HelloMakerft2" screen
    Then the user verifies the following elements should be "visible" under "MashreqAccounts" screen
      |MashreqAccounts|
    And user clicks the "PayTransfer" button under "MashreqAccounts" screen
    Then the user verifies the following elements should be "visible" under "PaymentTracker" screen
      |PaymentTracker|
    Then the user verifies the following elements should be "visible" under "PaymentTracker2" screen
      |PaymentTracker|
