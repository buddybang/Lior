# Made by Lior on 2026-10-02 12:21.
# The values typed or checked by these steps are in the test data file
# testdata/<NN>.CREATEPROJECT/US_TestData_CREATEPROJECT.json (look for the scenario id).
# A test recorded in several versions (other data) is one Scenario Outline: steps ending in "if ... in the test data"
# run only for the versions whose test data has that field.
# Run only this module:  mvn test -Pweb -Dcucumber.tags="@CreateProject"
@CreateProject
Feature: CreateProject - recorded web flow

  @Web @Chrome @SC_001
  Scenario: CreateProject|SC_001|Create_Project
    Given user opens the "CREATEPROJECT" application
    Then user sees the following elements under "Login" screen
      |WelcomeBack|
    When user click "EmployeeIdOrEmail" under "Login" screen
    And user enters the following field details under "Login" screen
      |EmployeeIdOrEmail|
      |Password|
    When user click "SignIn" under "Login" screen
    Then user sees the following elements under "Dashboard" screen
      |ExecutiveDashboard|
    When user click "AddNewProject" under "Dashboard" screen
    Then user sees the following elements under "New" screen
      |NewProjectHeading|
    And user enters the following field details under "New" screen
      |ClientName|
      |ProjectName|
    And user select the following field details under "New" screen
      |ServiceType|
      |StatusActiveConfirmedEngagement|
    And user enters the following field details under "New" screen
      |WinProbability|
    And user uploads the following files under "New" screen
      |Input|
    When user click "OpenCalendar" under "New" screen
    When user click "October192026" under "New" screen
    When user click "CreateProject" under "New" screen
    Then user sees the following elements under "Projects" screen
      |Test1|
    When user click "ArrowBackBack" under "Projects" screen
    Then user sees the following elements under "Projects2" screen
      |Projects|
    When user click "DashboardDashboard" under "Projects2" screen
    Then user sees the following elements under "Dashboard" screen
      |ExecutiveDashboard|
    When user click "AadminUserAdmin" under "Dashboard" screen
    When user click "SignOut" under "Dashboard" screen
    Then user sees the following elements under "Login" screen
      |WelcomeBack|
