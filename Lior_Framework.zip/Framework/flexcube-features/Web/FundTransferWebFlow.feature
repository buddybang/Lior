# Made by Lior on 2026-10-02 11:37.
# The values typed or checked by these steps are in the test data file
# testdata/<NN>.FUNDTRANSFER/US_TestData_FUNDTRANSFER.json (look for the scenario id).
# A test recorded in several versions (other data) is one Scenario Outline: steps ending in "if ... in the test data"
# run only for the versions whose test data has that field.
# Run only this module:  mvn test -Pweb -Dcucumber.tags="@FundTransfer"
@FundTransfer
Feature: FundTransfer - recorded web flow

  @Web @Chrome @SC_001
  Scenario: FundTransfer|SC_001|Fund_Transfer
    Given user opens the "FUNDTRANSFER" application
    Then user sees the following elements under "Login" screen
      |TristhaBank|
    And user enters the following field details under "Login" screen
      |Username|
      |Password|
    When user click "SignIn" under "Login" screen
    And user remembers the text of the following elements under "Login" screen
      |OtpMessage|
    And user enters the following field details under "Login" screen
      |OneTimePassword|
    When user click "VerifySignIn" under "Login" screen
    Then user sees the following elements under "Dashboard" screen
      |WelcomePriyaKumar|
    And user remembers the number in the following elements under "Dashboard" screen
      |SavingsAccountBalance|
    When user click "FundTransfer" under "Dashboard" screen
    Then user sees the following elements under "Transfers" screen
      |FundTransferHeading|
    And user select the following field details under "Transfers" screen
      |FromAccount|
      |Payee|
    And user enters the following field details under "Transfers" screen
      |Amount|
      |Remarks|
    When user click "SendOtp" under "Transfers" screen
    And user remembers the text of the following elements under "Transfers" screen
      |OtpMessage|
    And user enters the following field details under "Transfers" screen
      |TransfersOneTimePassword|
    When user click "Transfer" under "Transfers" screen
    When user click "Dashboard" under "Transfers" screen
    Then user sees the following elements under "Dashboard" screen
      |WelcomePriyaKumar|
    Then user checks the number in "SavingsAccountBalance" under "Dashboard" screen changed by "-Amount"
    When user click "Logout" under "Dashboard" screen
    Then user sees the following elements under "Login" screen
      |TristhaBank|
