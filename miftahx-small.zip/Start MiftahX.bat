@echo off
rem Double-click this file to open MiftahX. Uses miftahx.jar (or miftahx-small.jar) next to this file, else the one in the dist folder.
rem Java 11 or newer is needed. Which Java is used, first one found:
rem   1. the folder named in MIFTAHX_JAVA (set MIFTAHX_JAVA=C:\Tools\jre-11)
rem   2. a Java unzipped next to this file: a folder named jre, java, or starting with jre / jdk (jre-11.0.25, jdk-17 ...)
rem   3. the Java on PATH
rem So a computer whose own Java is 8 needs no install: unzip a Java 11 next to this file. Java 8 stays as it is for other tools.
setlocal
set "MIFTAHX_JAVAW="
if defined MIFTAHX_JAVA if exist "%MIFTAHX_JAVA%\bin\javaw.exe" set "MIFTAHX_JAVAW=%MIFTAHX_JAVA%\bin\javaw.exe"
if not defined MIFTAHX_JAVAW for %%D in ("%~dp0jre" "%~dp0java") do (
  if not defined MIFTAHX_JAVAW if exist "%%~D\bin\javaw.exe" set "MIFTAHX_JAVAW=%%~D\bin\javaw.exe"
)
if not defined MIFTAHX_JAVAW for /d %%D in ("%~dp0jre*" "%~dp0jdk*") do (
  if not defined MIFTAHX_JAVAW if exist "%%~D\bin\javaw.exe" set "MIFTAHX_JAVAW=%%~D\bin\javaw.exe"
)
if not defined MIFTAHX_JAVAW (
  where javaw >nul 2>nul
  if errorlevel 1 (
    echo Java was not found. Unzip Java 11 or newer next to this file ^(a folder named jre or jdk...^), or install it.
    pause
    exit /b 1
  )
  set "MIFTAHX_JAVAW=javaw"
)
set "MIFTAHX_JAR="
for %%J in ("%~dp0miftahx.jar" "%~dp0miftahx-small.jar" "%~dp0dist\miftahx.jar" "%~dp0dist\miftahx-small.jar") do (
  if not defined MIFTAHX_JAR if exist "%%~J" set "MIFTAHX_JAR=%%~J"
)
if not defined MIFTAHX_JAR (
  echo No miftahx.jar found next to this file or in its dist folder.
  pause
  exit /b 1
)
if defined MIFTAHX_SHOW_JAVA (
  echo Java: %MIFTAHX_JAVAW%
  echo Jar:  %MIFTAHX_JAR%
  exit /b 0
)
start "" "%MIFTAHX_JAVAW%" -jar "%MIFTAHX_JAR%"
