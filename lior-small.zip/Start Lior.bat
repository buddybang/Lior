@echo off
rem Double-click this file to open Lior. Uses lior.jar, or lior-small.jar when only that one is here.
where javaw >nul 2>nul
if errorlevel 1 (
  echo Java is not installed or not on PATH. Please install Java 11 or newer.
  pause
  exit /b 1
)
set "LIOR_JAR=%~dp0lior.jar"
if not exist "%LIOR_JAR%" set "LIOR_JAR=%~dp0lior-small.jar"
start "" javaw -jar "%LIOR_JAR%"
