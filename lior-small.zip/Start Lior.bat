@echo off
rem Double-click this file to open Lior. Uses lior.jar (or lior-small.jar) next to this file, else the one in the dist folder.
rem Java 11 or newer is needed. Which Java is used, first one found:
rem   1. the folder named in LIOR_JAVA (set LIOR_JAVA=C:\Tools\jre-11)
rem   2. a Java unzipped next to this file: a folder named jre, java, or starting with jre / jdk (jre-11.0.25, jdk-17 ...)
rem   3. the Java on PATH
rem So a computer whose own Java is 8 needs no install: unzip a Java 11 next to this file. Java 8 stays as it is for other tools.
setlocal
set "LIOR_JAVAW="
if defined LIOR_JAVA if exist "%LIOR_JAVA%\bin\javaw.exe" set "LIOR_JAVAW=%LIOR_JAVA%\bin\javaw.exe"
if not defined LIOR_JAVAW for %%D in ("%~dp0jre" "%~dp0java") do (
  if not defined LIOR_JAVAW if exist "%%~D\bin\javaw.exe" set "LIOR_JAVAW=%%~D\bin\javaw.exe"
)
if not defined LIOR_JAVAW for /d %%D in ("%~dp0jre*" "%~dp0jdk*") do (
  if not defined LIOR_JAVAW if exist "%%~D\bin\javaw.exe" set "LIOR_JAVAW=%%~D\bin\javaw.exe"
)
if not defined LIOR_JAVAW (
  where javaw >nul 2>nul
  if errorlevel 1 (
    echo Java was not found. Unzip Java 11 or newer next to this file ^(a folder named jre or jdk...^), or install it.
    pause
    exit /b 1
  )
  set "LIOR_JAVAW=javaw"
)
set "LIOR_JAR="
for %%J in ("%~dp0lior.jar" "%~dp0lior-small.jar" "%~dp0dist\lior.jar" "%~dp0dist\lior-small.jar") do (
  if not defined LIOR_JAR if exist "%%~J" set "LIOR_JAR=%%~J"
)
if not defined LIOR_JAR (
  echo No lior.jar found next to this file or in its dist folder.
  pause
  exit /b 1
)
if defined LIOR_SHOW_JAVA (
  echo Java: %LIOR_JAVAW%
  echo Jar:  %LIOR_JAR%
  exit /b 0
)
start "" "%LIOR_JAVAW%" -jar "%LIOR_JAR%"
