<#
.SYNOPSIS
  Sends the BrowserStack session results that could not be confirmed during the run (target\browserstack-status\*.json
  with "confirmed": false) through the BrowserStack REST API.

.DESCRIPTION
  MobileDriverManager marks each session passed/failed when it quits: through the session, or through the REST API when
  the session's connection is gone. When both fail (e.g. the corporate proxy blocks api-cloud.browserstack.com) the result
  stays in the record with "confirmed": false and the session shows "Unmarked" on BrowserStack. Run this script later,
  from a network that reaches BrowserStack.
  Credentials: environment variables BROWSERSTACK_USERNAME / BROWSERSTACK_ACCESS_KEY, else the git-ignored
  src\main\resources\config\secrets.local.properties. They are never printed.
  Ported from Framework_Fixed, 2026-10-06.

.EXAMPLE
  .\scripts\Sync-BrowserStackResults.ps1
  .\scripts\Sync-BrowserStackResults.ps1 -ProxyUri http://proxy.example:8080
#>
param(
    [string]$ProxyUri,
    [string]$ResultsDirectory = (Join-Path (Split-Path $PSScriptRoot -Parent) 'target\browserstack-status')
)
$ErrorActionPreference = 'Stop'

function Get-Secret([string]$name) {
    $value = [Environment]::GetEnvironmentVariable($name)
    if (-not [string]::IsNullOrWhiteSpace($value)) { return $value.Trim() }
    $file = Join-Path (Split-Path $PSScriptRoot -Parent) 'src\main\resources\config\secrets.local.properties'
    if (Test-Path -LiteralPath $file) {
        foreach ($line in Get-Content -LiteralPath $file) {
            if ($line -match ('^\s*' + [regex]::Escape($name) + '\s*[=:]\s*(.+?)\s*$')) { return $Matches[1] }
        }
    }
    return $null
}

$user = Get-Secret 'BROWSERSTACK_USERNAME'
$key = Get-Secret 'BROWSERSTACK_ACCESS_KEY'
if (-not $user -or -not $key) {
    throw 'BrowserStack credentials not found: set BROWSERSTACK_USERNAME / BROWSERSTACK_ACCESS_KEY or secrets.local.properties.'
}
if (-not (Test-Path -LiteralPath $ResultsDirectory)) {
    Write-Output "No results to synchronise ($ResultsDirectory does not exist)."
    exit 0
}
$authorization = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($user + ':' + $key))
$pending = 0
$failedUpdates = 0
foreach ($resultFile in (Get-ChildItem -LiteralPath $ResultsDirectory -Filter '*.json' -File)) {
    try {
        $result = Get-Content -LiteralPath $resultFile.FullName -Raw | ConvertFrom-Json
        if ($result.confirmed -eq $true) { continue }
        $pending++
        if ($result.sessionId -notmatch '^[A-Za-z0-9-]+$' -or $result.status -notin @('passed', 'failed')) {
            throw 'Invalid result record.'
        }
        $request = @{
            Uri         = 'https://api-cloud.browserstack.com/app-automate/sessions/' + $result.sessionId + '.json'
            Method      = 'Put'
            Headers     = @{ Authorization = 'Basic ' + $authorization }
            ContentType = 'application/json'
            Body        = (@{ status = $result.status; reason = $result.reason } | ConvertTo-Json -Compress)
            TimeoutSec  = 15
        }
        if ($ProxyUri) { $request.Proxy = $ProxyUri }
        $null = Invoke-RestMethod @request
        $result.confirmed = $true
        $result.channel = 'rest-api-sync'
        $result.recordedAt = [DateTime]::UtcNow.ToString('o')
        $temporaryPath = $resultFile.FullName + '.sync.tmp'
        try {
            [IO.File]::WriteAllText($temporaryPath, ($result | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
            Move-Item -LiteralPath $temporaryPath -Destination $resultFile.FullName -Force
        } finally {
            if (Test-Path -LiteralPath $temporaryPath) { Remove-Item -LiteralPath $temporaryPath }
        }
        Write-Output ('Result synchronised: ' + $result.sessionId + ' = ' + $result.status)
    } catch {
        $failedUpdates++
        Write-Warning ('Result still pending: ' + $resultFile.Name + ' (' + $_.Exception.Message + ')')
    }
}
Write-Output ("$pending pending result(s), $failedUpdates still not confirmed.")
if ($failedUpdates -gt 0) { exit 1 }
