# Made by Lior on 2026-10-05 15:14.
# The values typed or checked by these steps are in the test data file
# testdata/<NN>.NEOCORPOAT/US_TestData_NEOCORPOAT.json (look for the scenario id).
# A test recorded in several versions (other data) is one Scenario Outline: steps ending in "if ... in the test data"
# run only for the versions whose test data has that field.
# Run only this module:  mvn test -Pmobile -Dcucumber.tags="@NeoCorpOAT"
@NeoCorpOAT
Feature: NeoCorpOAT - recorded mobile flow

  @Mobile @SC_001
  Scenario: NeoCorpOAT|SC_001|NeoCorp_PaymentTransfer
    Given the mobile app is launched
    Then the user verifies the following elements should be "visible" under "WelcomeScreenSlide1" screen
      |AndroidWidgetTextView|
    And user clicks the "AppWelcomeAccessibilityLoginButton" button under "WelcomeScreenSlide1" screen
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp" screen
      |AndroidWidgetTextView|
    And user clicks the "LoginWithPassword" button under "LoginToMashreqNeoCorp" screen
    And user enters the following input field details under "LoginToMashreqNeoCorp" screen
      |VerifyUsernameInputTextInput|
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp2" screen
      |AndroidWidgetTextView|
    And user enters the following input field details under "LoginToMashreqNeoCorp2" screen
      |PasswordInputTextInput|
    And user enters the following input field details under "SetUpYourLoginPin" screen
      |SetUpA6DigitPin|
    And user clicks the "Continue" button under "SetUpYourLoginPin" screen
    Then the user verifies the following elements should be "visible" under "ConfirmYourLoginPin" screen
      |ConfirmYourLoginPin|
    And user enters the following input field details under "ConfirmYourLoginPin" screen
      |ConfirmYour6DigitPin|
    Then the user verifies the following elements should be "visible" under "ConfirmYourLoginPin2" screen
      |ConfirmYourLoginPin|
    And user clicks the "Continue" button under "ConfirmYourLoginPin2" screen
    Then the user verifies the following elements should be "visible" under "SetUpBiometrics" screen
      |SetUpBiometrics|
    And user clicks the "SetUpBiometricsLater" button under "SetUpBiometrics" screen
    Then the user verifies the following elements should be "visible" under "YourDeviceIsSetUp" screen
      |YourDeviceIsSetUp|
    And user clicks the "Login" button under "YourDeviceIsSetUp" screen
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp" screen
      |AndroidWidgetTextView|
    And user clicks the "LoginWithPinBiometrics" button under "LoginToMashreqNeoCorp" screen
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp4" screen
      |LoginToMashreqNeoCorp|
    And user enters the following Mobile field details under "LoginToMashreqNeoCorp4" screen
      |EnterYour6DigitPin|
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp5" screen
      |LoginToMashreqNeoCorp|
    And user clicks the "Continue" button under "LoginToMashreqNeoCorp5" screen
    # Swipe up (the framework has no step for a loose swipe; use "Swipe and tap" instead)
    Then the user verifies the following elements should be "visible" under "EndUserLicenseAgreement" screen
      |EndUserLicenseAgreement|
    And user swipes up 5 times and clicks the "IAgreeToTheTermsConditions" button under "EndUserLicenseAgreement" screen
    And user clicks the "AgreeContinue" button under "EndUserLicenseAgreement" screen
    Then the user verifies the following elements should be "visible" under "Tada" screen
      |HomeLabel|
    Then the user verifies the following elements should be "visible" under "HelloMakerft2" screen
      |AndroidWidgetTextView|
    And user clicks the "QuickActionMakePayment" button under "HelloMakerft2" screen
    Then the user verifies the following elements should be "visible" under "Payment" screen
      |Payment|
    And user clicks the "BeneficiaryAccount" button under "Payment" screen
    Then the user verifies the following elements should be "visible" under "Payment2" screen
      |Accounts|
    And user clicks the "OtherSelfAccounts24" button under "Payment2" screen
    And user clicks the "N019000007537AedFjwhdbtDlwiapiRutxiotBub" button under "Payment2" screen
    Then the user verifies the following elements should be "visible" under "InternalSelfTransfer" screen
      |InternalSelfTransfer|
    And user clicks the "Continue" button under "InternalSelfTransfer" screen
    And user clicks the "DebitAccount" button under "InternalSelfTransfer" screen
    Then the user verifies the following elements should be "visible" under "InternalSelfTransfer2" screen
      |Accounts|
    And user clicks the "ConventionalAccounts3" button under "InternalSelfTransfer2" screen
    Then the user verifies the following elements should be "visible" under "InternalSelfTransfer3" screen
      |Accounts|
    And user clicks the "N019000077019AedYpwbbUrayhisAyyurggBkw" button under "InternalSelfTransfer3" screen
    Then the user verifies the following elements should be "visible" under "InternalSelfTransfer4" screen
      |InternalSelfTransfer|
    Then the user verifies the following elements should be "visible" under "InternalSelfTransfer5" screen
      |InternalSelfTransfer|
    And user enters the following Mobile field details under "InternalSelfTransfer5" screen
      |AmountTextbox|
    Then the user verifies the following elements should be "visible" under "InternalSelfTransfer4" screen
      |InternalSelfTransfer|
    And user clicks the "RightIcon" button under "InternalSelfTransfer4" screen
    Then the user verifies the following elements should be "visible" under "InternalSelfTransfer6" screen
      |Oct2026|
    And user clicks the "N5" button under "InternalSelfTransfer6" screen
    Then the user verifies the following elements should be "visible" under "InternalSelfTransfer4" screen
      |InternalSelfTransfer|
    And user clicks the "Continue" button under "InternalSelfTransfer4" screen
    Then the user verifies the following elements should be "visible" under "InternalSelfTransfer5" screen
      |InternalSelfTransfer|
    And user enters the following Mobile field details under "InternalSelfTransfer5" screen
      |CustomerReferenceNumberTextbox|
    Then the user verifies the following elements should be "visible" under "InternalSelfTransfer4" screen
      |InternalSelfTransfer|
    And user clicks the "Continue" button under "InternalSelfTransfer4" screen
    # Swipe right (the framework has no step for a loose swipe; use "Swipe and tap" instead)
    Then the user verifies the following elements should be "visible" under "InternalSelfTransfer7" screen
      |InternalSelfTransfer|
    And user clicks the "SlideToConfirm" button under "InternalSelfTransfer7" screen
    # Swipe right (the framework has no step for a loose swipe; use "Swipe and tap" instead)
    And user slides the "SlideToConfirm" element right under "InternalSelfTransfer7" screen
    Then the user verifies the following elements should be "visible" under "Screen" screen
      |WeAreUnableToProcessYour|
