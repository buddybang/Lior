package com.mashreq.automation.tcoe.stepdefinitions.Web;

import com.mashreq.automation.tcoe.constants.FrameworkConstants;
import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.driver.DriverManager;
import com.mashreq.automation.tcoe.keywords.WebUI;
import com.mashreq.automation.tcoe.pages.CommonPage;
import com.mashreq.automation.tcoe.utils.DataHandler;
import com.mashreq.automation.tcoe.utils.FeatureStepCollector;
import com.mashreq.automation.tcoe.utils.Journey;
import com.mashreq.automation.tcoe.utils.LocatorUtils;
import com.mashreq.automation.tcoe.utils.LogUtils;
import com.mashreq.automation.tcoe.utils.OneTimeCodes;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

import java.math.BigDecimal;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Added by Lior (generated - Lior rewrites this file; put your own steps in another class).
 *
 * 1. Opens any web application whose address is in urls-<ENV>.properties as url.<REGION>.<APPLICATION>.
 *    The browser itself is started by ApplicationHooks for every scenario that is not @Mobile / @API.
 * 2. Steps that run only when the scenario's test data has the field ("... if they are in the test data"). A test recorded in
 *    several versions (other data that shows other fields) is one Scenario Outline; a field that only one version uses is only in that
 *    version's test data, so the step is skipped for the others.
 * 3. File upload; the file path comes from the test data (relative paths are taken from the project folder).
 * 4. Amounts that must change: remember a balance, then check it went down (or up) by an amount - a number, or a typed test data
 *    value such as the transfer amount.
 * 5. Journeys (a maker on the mobile app, checkers on the web ...): keep a value such as a reference number for the later parts,
 *    and wait until a screen shows the result of an earlier part.
 */
public class LiorWebSteps {

    private final ScenarioContext ctx;
    private final WebUI webUI;
    private final CommonPage commonPage;
    private final DataHandler dataHandler = new DataHandler();

    public LiorWebSteps(ScenarioContext ctx) {
        this.ctx = ctx;
        this.webUI = new WebUI(ctx, new FeatureStepCollector());
        this.commonPage = new CommonPage(webUI);
    }

    @Given("user opens the {string} application")
    public void userOpensTheApplication(String application) {
        String url = FrameworkConstants.getBaseUrl(application);
        LogUtils.info("Opening " + application + ": " + url);
        DriverManager.getPage().navigate(url);
    }

    @And("user enters the following field details under {string} screen if they are in the test data")
    public void userEntersFieldsIfInTestData(String screen, DataTable table) {
        for (String field : table.asList()) {
            String value = valueOrNull(field);
            if (value == null) {
                LogUtils.info("Skipped '" + field + "' on " + screen + ": not in the test data of " + ctx.getScenarioId());
                continue;
            }
            commonPage.enterFieldAndTab(ctx.getCurrentModule(), screen, field, value);
        }
    }

    @And("user select the following field details under {string} screen if they are in the test data")
    public void userSelectsFieldsIfInTestData(String screen, DataTable table) {
        for (String field : table.asList()) {
            String value = valueOrNull(field);
            if (value == null) {
                LogUtils.info("Skipped '" + field + "' on " + screen + ": not in the test data of " + ctx.getScenarioId());
                continue;
            }
            commonPage.selectField(ctx.getCurrentModule(), screen, field, value);
        }
    }

    @Then("user verify the following field details under {string} screen if they are in the test data")
    public void userVerifiesFieldsIfInTestData(String screen, DataTable table) {
        for (String field : table.asList()) {
            String value = valueOrNull(field);
            if (value == null) {
                LogUtils.info("Skipped check of '" + field + "' on " + screen + ": not in the test data of " + ctx.getScenarioId());
                continue;
            }
            commonPage.verifyField(ctx.getCurrentModule(), screen, field, value);
        }
    }

    /** Waits until each element is visible: proves the screen is shown before the test acts on it. */
    @Then("user sees the following elements under {string} screen")
    public void userSeesElements(String screen, DataTable table) {
        for (String field : table.asList()) {
            String locator = LocatorUtils.byPath(ctx.getCurrentModule() + "/" + screen + "/" + field);
            try {
                webUI.findElementInFrame(locator); // waits until the element is visible
            } catch (RuntimeException notShown) {
                throw new AssertionError("The " + screen + " screen did not appear: '" + field + "' is not visible.", notShown);
            }
            LogUtils.info("The " + screen + " screen is shown ('" + field + "' is visible).");
        }
    }

    /**
     * Reads the one-time password (or any code) an element shows and keeps it for this scenario. The test data then types it with
     * ${fromScreen:Screen.Element}. Used when the code is shown on one screen and typed on another, or in a message that disappears.
     */
    @And("user remembers the text of the following elements under {string} screen")
    public void userRemembersText(String screen, DataTable table) {
        for (String field : table.asList()) {
            OneTimeCodes.remember(screen, field);
        }
    }

    private static final String NUMBER = "lior.number.";
    private static final Pattern NUMBER_IN_TEXT = Pattern.compile("-?\\d[\\d,]*(?:\\.\\d+)?");
    private static final long NUMBER_WAIT_MS = 15000;

    /** Reads the number each element shows (a balance) and keeps it for "user checks the number in ... changed by ...". */
    @And("user remembers the number in the following elements under {string} screen")
    public void userRemembersNumber(String screen, DataTable table) {
        for (String field : table.asList()) {
            BigDecimal n = readNumber(screen, field, null);
            ctx.setScenarioData(NUMBER + screen + "." + field, n.toPlainString());
            LogUtils.info("Remembered '" + field + "' on " + screen + ": " + n.toPlainString());
        }
    }

    /**
     * The number the element shows now must be the remembered one plus the change. The change is "-10", "+500", or a sign and a
     * test data field of this scenario ("-Amount": went down by the amount the test typed). Waits up to 15 seconds for the
     * screen to show the new number (balances are often loaded a moment after the screen).
     */
    @Then("user checks the number in {string} under {string} screen changed by {string}")
    public void userChecksNumberChanged(String field, String screen, String change) {
        Object kept = ctx.getScenarioData(NUMBER + screen + "." + field);
        if (kept == null) {
            throw new AssertionError("'" + field + "' on " + screen + " was not remembered earlier. Put 'user remembers the number in the following elements under \""
                    + screen + "\" screen' before the steps that change it.");
        }
        BigDecimal before = new BigDecimal(String.valueOf(kept));
        BigDecimal by = changeOf(change);
        BigDecimal expected = before.add(by);
        BigDecimal now = readNumber(screen, field, expected);
        if (now.compareTo(expected) != 0) {
            throw new AssertionError("'" + field + "' on " + screen + " shows " + now.toPlainString() + ", expected " + expected.toPlainString()
                    + " (" + before.toPlainString() + (by.signum() < 0 ? " - " : " + ") + by.abs().toPlainString() + ").");
        }
        LogUtils.info("'" + field + "' on " + screen + " changed from " + before.toPlainString() + " to " + now.toPlainString() + " as expected.");
    }

    private BigDecimal changeOf(String change) {
        String c = change == null ? "" : change.trim();
        boolean minus = c.startsWith("-");
        if (c.startsWith("-") || c.startsWith("+")) {
            c = c.substring(1).trim();
        }
        String amount = c.matches("\\d[\\d,]*(\\.\\d+)?") ? c : dataHandler.getTestDataOrThrow(ctx.getCurrentModule(), ctx.getScenarioId(), c);
        BigDecimal n = parseNumber(amount);
        if (n == null) {
            throw new AssertionError("The change '" + change + "' is not a number or a test data field with a number ('" + amount + "').");
        }
        return minus ? n.abs().negate() : n.abs();
    }

    /** The number the element shows; with {@code waitFor} it waits (up to 15 s) until it shows that number, then returns what it shows. */
    private BigDecimal readNumber(String screen, String field, BigDecimal waitFor) {
        String locator = LocatorUtils.byPath(ctx.getCurrentModule() + "/" + screen + "/" + field);
        long end = System.currentTimeMillis() + NUMBER_WAIT_MS;
        BigDecimal last = null;
        String text = "";
        while (true) {
            try {
                text = webUI.findElementInFrame(locator).innerText();
                last = parseNumber(text);
            } catch (RuntimeException notYet) {
                // not shown yet
            }
            if (last != null && (waitFor == null || last.compareTo(waitFor) == 0) || System.currentTimeMillis() > end) {
                break;
            }
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        if (last == null) {
            throw new AssertionError("'" + field + "' on " + screen + " shows no number ('" + text + "').");
        }
        return last;
    }

    static BigDecimal parseNumber(String text) {
        Matcher m = NUMBER_IN_TEXT.matcher(text == null ? "" : text);
        return m.find() ? new BigDecimal(m.group().replace(",", "")) : null;
    }

    @And("user click {string} under {string} screen if it is in the test data")
    public void userClicksIfInTestData(String element, String screen) {
        if (valueOrNull(element) == null) {
            LogUtils.info("Skipped click on '" + element + "' on " + screen + ": not in the test data of " + ctx.getScenarioId());
            return;
        }
        commonPage.clickButtonMod(ctx.getCurrentModule(), screen, element);
    }

    @And("user uploads the following files under {string} screen")
    public void userUploadsFiles(String screen, DataTable table) {
        for (String field : table.asList()) {
            String path = dataHandler.getTestDataOrThrow(ctx.getCurrentModule(), ctx.getScenarioId(), field);
            upload(screen, field, path);
        }
    }

    @And("user uploads the following files under {string} screen if they are in the test data")
    public void userUploadsFilesIfInTestData(String screen, DataTable table) {
        for (String field : table.asList()) {
            String path = valueOrNull(field);
            if (path == null) {
                LogUtils.info("Skipped upload '" + field + "' on " + screen + ": not in the test data of " + ctx.getScenarioId());
                continue;
            }
            upload(screen, field, path);
        }
    }

    /**
     * Journey (several scenarios that are one business case): reads the text an element shows - for example the reference number
     * of the transaction this part created - and keeps it for the later parts, which use it as ${journey:Name}. The test data of
     * this scenario says which part of the text to keep ("Name": "the word after 'Reference No:'"); without it Lior's guess is used.
     */
    @And("user keeps the text of {string} under {string} screen as {string} for the journey")
    public void userKeepsTextForJourney(String field, String screen, String name) {
        String text = waitForText(screen, field);
        Journey.keep(name, Journey.pick(text, valueOrNull(name), "'" + field + "' on " + screen));
    }

    /** Journey: keeps what this part typed into the field (its test data value) for the later parts, as ${journey:Name}. */
    @And("user keeps the typed value of {string} as {string} for the journey")
    public void userKeepsTypedValueForJourney(String field, String name) {
        Journey.keep(name, Journey.typed(field, () -> dataHandler.getTestDataOrThrow(ctx.getCurrentModule(), ctx.getScenarioId(), field)));
    }

    /**
     * Journey: the result of an earlier part can take a moment to show (another system approved it). Waits up to the given time
     * until each element shows its test data value, then checks it the usual way.
     */
    @Then("user waits up to {int} seconds until the following elements under {string} screen show the test data")
    public void userWaitsUntilElementsShow(int seconds, String screen, DataTable table) {
        for (String field : table.asList()) {
            String expected = dataHandler.getTestDataOrThrow(ctx.getCurrentModule(), ctx.getScenarioId(), field);
            long end = System.currentTimeMillis() + seconds * 1000L;
            String shown = "";
            while (System.currentTimeMillis() < end) {
                try {
                    shown = OneTimeCodes.shownText(screen, field);
                    if (sameText(shown, expected)) {
                        break;
                    }
                } catch (RuntimeException notYet) {
                    // not shown yet
                }
                pause(1000);
            }
            LogUtils.info("'" + field + "' on " + screen + " shows \"" + shown + "\" (expected \"" + expected + "\").");
            commonPage.verifyField(ctx.getCurrentModule(), screen, field, expected);
        }
    }

    /** The element's text; waits up to 15 seconds for it to be shown with some text. */
    private String waitForText(String screen, String field) {
        long end = System.currentTimeMillis() + NUMBER_WAIT_MS;
        RuntimeException last = null;
        while (true) {
            try {
                String t = OneTimeCodes.shownText(screen, field);
                if (t != null && !t.trim().isEmpty()) {
                    return t;
                }
            } catch (RuntimeException notYet) {
                last = notYet;
            }
            if (System.currentTimeMillis() > end) {
                if (last != null) {
                    throw last;
                }
                throw new AssertionError("'" + field + "' on " + screen + " shows no text.");
            }
            pause(500);
        }
    }

    static boolean sameText(String shown, String expected) {
        String a = shown == null ? "" : shown.replace(' ', ' ').replaceAll("\\s+", " ").trim().toLowerCase(java.util.Locale.ROOT);
        String b = expected == null ? "" : expected.replace(' ', ' ').replaceAll("\\s+", " ").trim().toLowerCase(java.util.Locale.ROOT);
        return !b.isEmpty() && a.contains(b);
    }

    private static void pause(long ms) {
        try {
            Thread.sleep(ms); // poll interval
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void upload(String screen, String field, String path) {
        String locator = LocatorUtils.byPath(ctx.getCurrentModule() + "/" + screen + "/" + field);
        webUI.uploadFile(locator, path);
    }

    /** The scenario's test data value for the field, or null when this scenario (version) does not have it. */
    private String valueOrNull(String field) {
        try {
            String v = dataHandler.getTestDataOrThrow(ctx.getCurrentModule(), ctx.getScenarioId(), field);
            return v == null || v.trim().isEmpty() ? null : v;
        } catch (OneTimeCodes.CodeException otpProblem) {
            throw otpProblem; // the field IS in the test data: its one-time password could not be worked out
        } catch (IllegalArgumentException notThere) {
            return null; // only "field not in the test data"; a missing folder / file or broken JSON fails the step
        }
    }
}
