
package com.mashreq.automation.tcoe.listeners;

import com.mashreq.automation.tcoe.utils.LogUtils;
import org.testng.IAlterSuiteListener;
import org.testng.xml.XmlSuite;

import java.util.List;

public class ParallelExecutionListener implements IAlterSuiteListener {

    @Override
    public void alter(List<XmlSuite> suites) {
        XmlSuite suite = suites.get(0);
        String parallelMode = System.getProperty("parallel");
        String threadCountStr = System.getProperty("threads");

        if ("true".equalsIgnoreCase(parallelMode) && threadCountStr != null && !threadCountStr.isEmpty()) {
            try {
                int threadCount = Integer.parseInt(threadCountStr);
                if (threadCount > 0) {
                    suite.setParallel(XmlSuite.ParallelMode.TESTS);
                    suite.setDataProviderThreadCount(threadCount);
                    LogUtils.info("SUCCESS: Test suite configured for PARALLEL execution with thread count: " + threadCount);
                } else {
                    suite.setParallel(XmlSuite.ParallelMode.NONE);
                    suite.setDataProviderThreadCount(1);
                    LogUtils.warn("Thread count must be > 0. Running in SEQUENTIAL mode.");
                }
            } catch (NumberFormatException e) {
                suite.setParallel(XmlSuite.ParallelMode.NONE);
                suite.setDataProviderThreadCount(1);
                LogUtils.error("Invalid thread count. Running in SEQUENTIAL mode.");
            }
        } else {
            suite.setParallel(XmlSuite.ParallelMode.NONE);
            suite.setDataProviderThreadCount(1);
            LogUtils.info("Running in SEQUENTIAL mode.");
        }
    }
}