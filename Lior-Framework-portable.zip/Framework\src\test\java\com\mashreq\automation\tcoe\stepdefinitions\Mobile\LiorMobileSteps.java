package com.mashreq.automation.tcoe.stepdefinitions.Mobile;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.keywords.MobileUI;
import com.mashreq.automation.tcoe.pages.Mobile.CommonMobilePage;
import com.mashreq.automation.tcoe.utils.DataHandler;
import com.mashreq.automation.tcoe.utils.Journey;
import com.mashreq.automation.tcoe.utils.LocatorUtils;
import com.mashreq.automation.tcoe.utils.LogUtils;
import com.mashreq.automation.tcoe.utils.OneTimeCodes;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;

import java.time.Duration;
import java.util.Collections;

/**
 * Added by Lior (generated - Lior rewrites this file; put your own steps in another class).
 * Mobile steps that run only when the scenario's test data has the field. A test recorded in several versions (other data)
 * is one Scenario Outline; a field that only one version uses is only in that version's test data.
 */
public class LiorMobileSteps {

    private final ScenarioContext ctx;
    private final CommonMobilePage page;
    private final DataHandler dataHandler = new DataHandler();

    public LiorMobileSteps(ScenarioContext ctx) {
        this.ctx = ctx;
        this.page = new CommonMobilePage(ctx, new MobileLoginSteps.LocalActionLogger());
    }

    @And("user enters the following Mobile field details under {string} screen if they are in the test data")
    public void userEntersFieldsIfInTestData(String screen, DataTable table) {
        for (String field : table.asList()) {
            String value = valueOrNull(field);
            if (value == null) {
                LogUtils.info("Skipped '" + field + "' on " + screen + ": not in the test data of " + ctx.getScenarioId());
                continue;
            }
            page.enter(ctx.getCurrentModule(), screen, field, value);
        }
    }

    @And("user clicks the {string} button under {string} screen if it is in the test data")
    public void userClicksIfInTestData(String element, String screen) {
        if (valueOrNull(element) == null) {
            LogUtils.info("Skipped tap on '" + element + "' on " + screen + ": not in the test data of " + ctx.getScenarioId());
            return;
        }
        page.clickButton(element, ctx.getCurrentModule(), screen);
    }

    /**
     * Reads the one-time password (or any code) an element shows and keeps it for this scenario. The test data then types it with
     * ${fromScreen:Screen.Element}. Used when the code is shown on one screen and typed on another, or in a message that disappears.
     */
    @And("user remembers the text of the following mobile elements under {string} screen")
    public void userRemembersText(String screen, DataTable table) {
        for (String field : table.asList()) {
            OneTimeCodes.remember(screen, field);
        }
    }

    /**
     * Journey (several scenarios that are one business case): reads the text a mobile element shows - for example the reference
     * number of the transaction this part created - and keeps it for the later parts, which use it as ${journey:Name}. The test
     * data of this scenario says which part of the text to keep ("Name": "the word after 'Reference No:'").
     */
    @And("user keeps the text of mobile element {string} under {string} screen as {string} for the journey")
    public void userKeepsTextForJourney(String field, String screen, String name) {
        long end = System.currentTimeMillis() + 15000;
        String text = null;
        RuntimeException last = null;
        while (text == null) {
            try {
                String t = OneTimeCodes.shownText(screen, field);
                if (t != null && !t.trim().isEmpty()) {
                    text = t;
                }
            } catch (RuntimeException notYet) {
                last = notYet;
            }
            if (text == null && System.currentTimeMillis() > end) {
                if (last != null) {
                    throw last;
                }
                throw new AssertionError("'" + field + "' on " + screen + " shows no text.");
            }
            if (text == null) {
                pause(500);
            }
        }
        Journey.keep(name, Journey.pick(text, valueOrNull(name), "'" + field + "' on " + screen));
    }

    /** Journey: keeps what this part typed into the mobile field (its test data value) for the later parts, as ${journey:Name}. */
    @And("user keeps the typed value of mobile field {string} as {string} for the journey")
    public void userKeepsTypedValueForJourney(String field, String name) {
        Journey.keep(name, Journey.typed(field, () -> dataHandler.getTestDataOrThrow(ctx.getCurrentModule(), ctx.getScenarioId(), field)));
    }

    /**
     * Journey: the result of an earlier part (approved on the web) can take a moment to reach the app. Waits up to the given time
     * until each element shows its test data value, then checks it the usual way.
     */
    @And("user waits up to {int} seconds until the following mobile elements under {string} screen show the test data")
    public void userWaitsUntilElementsShow(int seconds, String screen, DataTable table) {
        for (String field : table.asList()) {
            String expected = dataHandler.getTestDataOrThrow(ctx.getCurrentModule(), ctx.getScenarioId(), field);
            long end = System.currentTimeMillis() + seconds * 1000L;
            String shown = "";
            while (System.currentTimeMillis() < end) {
                try {
                    shown = OneTimeCodes.shownText(screen, field);
                    if (sameText(shown, expected)) {
                        break;
                    }
                } catch (RuntimeException notYet) {
                    // not shown yet
                }
                pause(1000);
            }
            LogUtils.info("'" + field + "' on " + screen + " shows \"" + shown + "\" (expected \"" + expected + "\").");
            page.verifyMessage(field, expected, screen, ctx.getCurrentModule());
        }
    }

    static boolean sameText(String shown, String expected) {
        String a = shown == null ? "" : shown.replace(' ', ' ').replaceAll("\\s+", " ").trim().toLowerCase(java.util.Locale.ROOT);
        String b = expected == null ? "" : expected.replace(' ', ' ').replaceAll("\\s+", " ").trim().toLowerCase(java.util.Locale.ROOT);
        return !b.isEmpty() && a.contains(b);
    }

    private static void pause(long ms) {
        try {
            Thread.sleep(ms); // poll interval
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * "Slide to confirm" (Lior action Slide): holds the handle, then drags it slowly to the edge of the screen. The element is
     * the handle or the whole slider bar; on a bar the handle is taken to sit at its start (left end when sliding right).
     */
    @And("user slides the {string} element {word} under {string} screen")
    public void userSlidesElement(String element, String direction, String screen) {
        String d = direction == null ? "" : direction.trim().toLowerCase(java.util.Locale.ROOT);
        if (!d.equals("right") && !d.equals("left")) {
            throw new IllegalArgumentException("Slide direction must be 'right' or 'left', not '" + direction + "'");
        }
        MobileUI mobile = new MobileUI(ctx, new MobileLoginSteps.LocalActionLogger());
        WebElement handle = mobile.findElement(LocatorUtils.byPath(ctx.getCurrentModule() + "/" + screen + "/" + element));
        Rectangle r = handle.getRect();
        Dimension size = ctx.getMobileDriver().manage().window().getSize();
        int inset = Math.min(r.getWidth() / 2, Math.max(1, r.getHeight() / 2)); // a square handle: its centre; a long bar: its end
        int y = r.getY() + r.getHeight() / 2;
        int startX = d.equals("right") ? r.getX() + inset : r.getX() + r.getWidth() - inset;
        int endX = d.equals("right") ? (int) (size.getWidth() * 0.97) : (int) (size.getWidth() * 0.03);
        PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
        Sequence slide = new Sequence(finger, 1);
        slide.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), startX, y));
        slide.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
        slide.addAction(new Pause(finger, Duration.ofMillis(250)));
        slide.addAction(finger.createPointerMove(Duration.ofMillis(900), PointerInput.Origin.viewport(), endX, y));
        slide.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
        ctx.getMobileDriver().perform(Collections.singletonList(slide));
        LogUtils.info("Slid '" + element + "' " + d + " on " + screen + " (" + startX + "," + y + " -> " + endX + "," + y + ")");
    }

    private String valueOrNull(String field) {
        try {
            String v = dataHandler.getTestDataOrThrow(ctx.getCurrentModule(), ctx.getScenarioId(), field);
            return v == null || v.trim().isEmpty() ? null : v;
        } catch (OneTimeCodes.CodeException otpProblem) {
            throw otpProblem; // the field IS in the test data: its one-time password could not be worked out
        } catch (IllegalArgumentException notThere) {
            return null; // only "field not in the test data"; a missing folder / file or broken JSON fails the step
        }
    }
}
