package com.mashreq.automation.tcoe.reporting.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties; // <-- ADD THIS IMPORT
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List; // <-- ADD THIS IMPORT

/**
 * A class to represent a feature for reporting, refactored to use Lombok's @Getter at the class level.
 * This automatically generates a getter for every non-static field.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true) // <-- ADD THIS ANNOTATION
public class Feature {
    // @Getter is applied to the class, so we don't need it on each individual field.
    @JsonProperty("featureUUID")
    private String featureUUID;

    @JsonProperty("featureName")
    private String featureName;

    @JsonProperty("moduleName")
    private String moduleName;

    @JsonProperty("status")
    private String status;

    @JsonProperty("totalScenarios")
    private int totalScenarios;

    @JsonProperty("passedScenarios")
    private int passedScenarios;

    @JsonProperty("failedScenarios")
    private int failedScenarios;

    @JsonProperty("durationMillis")
    private long durationMillis;

    @JsonProperty("totalSteps")
    private int totalSteps;

    @JsonProperty("passedSteps")
    private int passedSteps;

    @JsonProperty("failedSteps")
    private int failedSteps;

    @JsonProperty("skippedSteps")
    private int skippedSteps;

    @JsonProperty("history")
    private List<RunRecord> history;

    // The @Setter and @Getter annotations are still needed here
    // because this field is transient and not covered by the class-level @Getter.
    @Setter
    @Getter
    private String durationFormatted;
}