package com.mashreq.automation.tcoe.reporting.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Representation of a single run in history.
 * Matches the RunRecord structure produced by FeatureAggregator:
 * {
 *   "status": "PASSED",
 *   "buildNumber": "local_20250925_015635",
 *   "runDateMillis": 1695604595123,
 *   "runDate": "2025-09-24T20:09:55.123Z",
 *   "durationMillis": 67590
 * }
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RunRecord {

    @JsonProperty("status")
    private String status;

    @JsonProperty("buildNumber")
    private String buildNumber;

    /**
     * Epoch millis for this run. Used for accurate sorting on server/client.
     * Nullable for older records that did not include timestamps.
     */
    @JsonProperty("runDateMillis")
    private Long runDateMillis;

    /**
     * Human readable ISO date string for the run (e.g. "2025-09-24T20:09:55.123Z").
     * Provided for display in the history UI.
     */
    @JsonProperty("runDate")
    private String runDate;

    /**
     * Duration of the scenario/feature in milliseconds (optional).
     */
    @JsonProperty("durationMillis")
    private Long durationMillis;
}
