package com.mashreq.automation.tcoe.utils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.TreeSet;
import java.util.regex.Pattern;

/**
 * Picks the scenarios to run from run-groups.properties (project root), so the IDE run configuration never changes.
 *
 * <pre>
 *   RUN_GROUP=login                                   # group to run; -DRUN_GROUP=... wins; empty or "all" = no narrowing
 *   login=CorpLogin|SC_001, TermDeposit|SC_2741358    # "Module|SC_id" = the start of the scenario name
 *   corp=CorpLogin                                    # "Module" alone = every scenario of that module
 * </pre>
 *
 * The group becomes Cucumber's name filter (cucumber.filter.name). It is combined (AND) with the tag filter of the
 * profile (-Pmobile = "@Mobile and not @WIP"), so @WIP scenarios and the other platform stay out.
 * An explicit -Dcucumber.filter.name is left alone.
 */
public final class ScenarioGroups {

    public static final String FILE_NAME = "run-groups.properties";
    private static final String GROUP_KEY = "RUN_GROUP";

    private ScenarioGroups() {
    }

    /** Sets cucumber.filter.name from the selected group. Call before Cucumber reads its options. */
    public static void apply() {
        if (isSet(System.getProperty("cucumber.filter.name"))) {
            LogUtils.info("-----> Scenario filter from -Dcucumber.filter.name; " + FILE_NAME + " not used");
            return;
        }
        Path file = Paths.get(System.getProperty("user.dir"), FILE_NAME);
        if (!Files.exists(file)) {
            return;
        }
        String tags = System.getProperty("cucumber.filter.tags", "");
        boolean journeyRun = isJourneyRun(tags);
        Properties groups = new Properties();
        try (InputStream in = Files.newInputStream(file)) {
            groups.load(in);
        } catch (IOException e) {
            throw new IllegalStateException("Could not read " + file + ": " + e.getMessage(), e);
        }

        String group = isSet(System.getProperty(GROUP_KEY))
                ? System.getProperty(GROUP_KEY).trim()
                : groups.getProperty(GROUP_KEY, "").trim();
        if (group.isEmpty() || "all".equalsIgnoreCase(group)) {
            LogUtils.info("-----> Scenario group: all (only the tag filter applies)");
            return;
        }

        String entries = groups.getProperty(group);
        if (!isSet(entries)) {
            TreeSet<String> names = new TreeSet<>(groups.stringPropertyNames());
            names.remove(GROUP_KEY);
            String message = "Scenario group '" + group + "' is not defined in " + FILE_NAME + ". Defined groups: " + names;
            // Logged too: surefire hides an exception from a runner's static block in a .dump file
            LogUtils.error(message);
            throw new IllegalStateException(message);
        }

        List<String> scenarios = new ArrayList<>();
        List<String> journeys = new ArrayList<>();
        for (String entry : entries.split(",")) {
            String e = entry.trim();
            if (e.isEmpty()) {
                continue;
            }
            if (e.startsWith("@Journey_") || e.startsWith("Journey_")) {
                journeys.add(e.startsWith("@") ? e : "@" + e);
            } else {
                scenarios.add(Pattern.quote(e));
            }
        }
        if (journeyRun) {
            // a journey runs whole (its parts depend on each other): a group picks journeys by their tag, never single parts
            if (journeys.isEmpty()) {
                LogUtils.warn("-----> Journey run: group '" + group + "' names scenarios, not journeys (@Journey_<Name>); " + FILE_NAME
                        + " not used, every journey runs");
                return;
            }
            System.setProperty("cucumber.filter.tags", "(" + tags + ") and (" + String.join(" or ", journeys) + ")");
            LogUtils.info("-----> Journey group '" + group + "': " + journeys);
            return;
        }
        if (!journeys.isEmpty()) {
            LogUtils.warn("-----> Group '" + group + "' names journeys " + journeys + ": they run only with -Pjourney, left out of this run");
            if (scenarios.isEmpty()) {
                String message = "Scenario group '" + group + "' has only journeys " + journeys + "; run it with -Pjourney";
                LogUtils.error(message);
                throw new IllegalStateException(message);
            }
        }
        // "CorpLogin|SC_001" matches "CorpLogin|SC_001|Corp_Just_View" but not "CorpLogin|SC_0010|..."
        String nameRegex = "^\\s*(?:" + String.join("|", scenarios) + ")(?:\\||$)";
        System.setProperty("cucumber.filter.name", nameRegex);
        LogUtils.info("-----> Scenario group '" + group + "': " + Arrays.toString(entries.trim().split("\\s*,\\s*")));
    }

    /**
     * True for -Pjourney ("@Journey and not @WIP", "@Journey_TxnApproval"). Not for -Pmobile / -Pweb: their
     * "... and not @Journey" leaves journeys OUT (checking only for "@Journey" took every mobile / web run for a journey run,
     * so run-groups.properties was never used there - found 2026-10-10).
     */
    static boolean isJourneyRun(String tags) {
        if (tags == null) {
            return false;
        }
        return tags.replaceAll("(?i)\\bnot\\s+@Journey\\w*", "").contains("@Journey");
    }

    private static boolean isSet(String value) {
        return value != null && !value.isBlank();
    }
}
