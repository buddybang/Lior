# Fix log — "Make it trustworthy" (2026-09-30)

Base: source from branch `payment_tracker` copied into the Framework root. Focus: Mobile automation on BrowserStack.
Verified: `mvn -DskipTests test-compile` passes. No scenarios were executed (no BrowserStack run).

| # | File | What changed | Why |
|---|------|--------------|-----|
| 1 | `src/test/java/.../runners/TestRunner.java` | Removed hard-coded `tags = "@Mobile and @SC_2741358"`. Data provider is now always `parallel = true` (thread count is still decided by `ParallelExecutionListener`, 1 by default). | The annotation tag overrode the command line, so every run executed one scenario only. The old `parallel=false` made `-Dparallel=true` do nothing for this runner. |
| 2 | `pom.xml` | Added default properties `cucumber.tags` (empty), `parallel=false`, `threads=1`. | Surefire forwards these to Cucumber/TestNG. Without defaults an unset value could arrive as the literal text `${cucumber.tags}` and break the tag filter. Empty tags = run all. |
| 3 | `src/main/java/.../utils/PropertiesHelpers.java` | New `getRequiredValue(key)` that throws a clear message for a missing or empty key. `getValue(key)` now honours a `-D<KEY>` override first. | Missing keys used to return null and crash later with an opaque NullPointerException. The `-D` overrides documented in `config.properties` (e.g. `-DMOBILE_EXECUTION_MODE`) were not actually applied. |
| 4 | `src/main/java/.../constants/FrameworkConstants.java` | Mandatory settings use `getRequiredValue`. BrowserStack/BS_* settings use a null-safe `optionalValue`. New `validateBrowserStackConfig()` lists every missing BrowserStack setting in one message. | Fail fast with a readable error. BrowserStack settings are checked only when a BrowserStack session starts, so web or local runs are not blocked. |
| 5 | `src/main/java/.../driver/MobileDriverManager.java` | One line added: `FrameworkConstants.validateBrowserStackConfig();` before creating a BrowserStack driver. | Wires in the check from #4. |
| 6 | `src/main/java/.../users/UserCredentialsManager.java` | `checkoutUserPair()` now waits at most 300s (override `-DUSER_POOL_TIMEOUT_SECONDS=<n>`) and throws a clear error. `checkinUserPair()` no longer blocks and ignores duplicate returns. | A run could hang forever when no pair was free. A double check-in could over-fill the pool. |
| 7 | `src/test/java/.../hooks/ApplicationHooks.java` | `@Before` only checks out a user pair for scenarios that are not `@Mobile` or `@API`. Logging uses a null-safe pair id. | Only web steps use the pair. With one pair in the pool, every mobile scenario was queued behind it, which blocked parallel BrowserStack devices. |
| 8 | `src/main/java/.../context/ScenarioContext.java` | `page` changed from `static` to an instance field. | A static page was shared by all threads, so parallel web scenarios could drive each other's browser. `ScenarioContext` is created per scenario by PicoContainer. |
| 9 | `src/test/java/.../stepdefinitions/Web/CustomerMaintenanceSteps.java` | Import fixed to `pages.Web.CustomerMaintenancePage`. | Pre-existing compile error on this branch (class lives in the `pages.Web` package). Needed to compile and verify. |

## Follow-up changes (same day, after first BrowserStack run)

| # | File | What changed | Why |
|---|------|--------------|-----|
| 10 | `src/main/java/.../driver/MobileDriverManager.java` | `getBrowserStackProxy()` returns no proxy when `-DBS_USE_PROXY=false` (default `true`, so client-site behaviour is unchanged). | The configured corporate proxy host cannot be resolved outside the client network. With the switch off, the JDK connects directly, or via the OS proxy when `-Djava.net.useSystemProxies=true` is also passed. |
| 11 | `src/main/resources/config/config.properties` | `BROWSERSTACK_APP_URL` changed from `bs://e5aa30f…` to `bs://fd7d4745…` (newest upload, 2026-09-22). | The old app ID no longer exists in the BrowserStack account, so session creation hung until the 90s timeout. Replace it again whenever a new build is uploaded; BrowserStack deletes old uploads. |

| 12 | `pom.xml` | Default `cucumber.tags` is now `@Mobile` (was empty = everything). New property `bs.use.proxy` (default `true`) passed to the tests as `BS_USE_PROXY`. `java.net.useSystemProxies=true` is always passed. New Maven profile `offsite` sets `bs.use.proxy=false`. | This framework is mostly for mobile, so a plain `mvn test` runs only mobile scenarios instead of the broken web/API ones. Working outside the client network only needs `-Poffsite` (tick it in IntelliJ's Maven panel) instead of several `-D` flags. Override tags with `-Dcucumber.tags=""` (all) or `-Dcucumber.tags="@SC_xxx"`. |

| 13 | `flexcube-features/Mobile/01.MobileLogin.feature` | Scenario names `\|SC_2741351\|…` and `Mobile\|SC_2700567\|…` changed to module `TermDeposit\|…`. The step `the user verifies the following mobile elements should be visible under "X" screen` (2 places, no step definition) changed to the existing step `the user verifies the following elements should be "visible" under "X" screen`. | The module in the scenario name selects the locator and test-data files, and the old names matched none. The old step wording was undefined, so the scenarios stopped with UndefinedStepException. |

Result after #13 (`mvn test -Poffsite`, real BrowserStack devices): login and the Deposits page now work, so the scenarios run further, but all 3 failed on test content/stability: SC_2741351 has no `USDAccountNumber` in `testdata/02.TERMDEPOSIT` test data; SC_2700567 and SC_2741358 lost the BrowserStack session while typing the PIN (`Error communicating with the remote browser`). SC_2741358 passed in two earlier runs, so this looks intermittent.

Earlier result of `mvn test -Poffsite` (3 `@Mobile` scenarios, real BrowserStack sessions): 1 passed (`TermDeposit\|SC_2741358`), 2 failed with `OR path not found: /Loginflow/Login` and `Mobile/Loginflow/Login`. Cause: the scenario names in `01.MobileLogin.feature` have an empty or unknown module (`\|SC_2741351\|...`, `Mobile\|SC_2700567\|...`). The module in the name selects the object-repository file, and only `Term` / `TermDeposit` exist. Not changed yet; needs the right module name from the feature owner.

Earlier result: `SC_2741358` (`@Mobile`) passed on a BrowserStack Android device (1 run, 0 failures, about 320s) with the proxy off.
Known minor issue seen: the failure screenshot at session close logged "Error communicating with the remote browser" (scenario still passed).

## How to run now
```
mvn test -Dcucumber.tags="@Mobile and @SC_2741358"
mvn test -Dcucumber.tags="@Mobile" -Dparallel=true -Dthreads=3 -DMOBILE_EXECUTION_MODE=browserstack
mvn test                                   # no tags = all scenarios
```
Optional: `-DUSER_POOL_TIMEOUT_SECONDS=600`.
Outside the client network add `"-DBS_USE_PROXY=false" "-Djava.net.useSystemProxies=true"` (quote each `-D` in PowerShell).

## Behaviour changes to be aware of
- Runs with no `-Dcucumber.tags` now execute all scenarios (before: one mobile scenario).
- A missing mandatory config key stops the run at start-up with the key name.
- A web scenario waits at most 300s for a user pair, then fails with an explanation.

## Not changed (still open)
Secrets in `config.properties` and `testdata/Users/*.json`, git token in `.git/config`, `setIgnoreHTTPSErrors(true)`, `Thread.sleep` calls, swallowed exceptions, commented-out code in `MobileDriverManager`, pom duplicate dependencies, `Launcher` glue package.

## Web and mobile separated (2026-10-02)

Backup before these changes: `C:\Uday\RD\Automation\Framework-backup-before-web-mobile-split-20261002-002303.zip`.

| # | File | What changed | Why |
|---|------|--------------|-----|
| 14 | `src/main/java/.../context/Platform.java` (new) | `WEB` / `MOBILE` / `API`, decided from the scenario's tags (`@Mobile`, `@API`, otherwise web). | One clear answer to "what does this scenario automate", used everywhere instead of guessing. |
| 15 | `context/ScenarioContext.java`, `hooks/ApplicationHooks.java` | `ScenarioContext.platform`, set in `@Before` from the tags, before anything else runs. | The object repository lookup needs to know the platform. |
| 16 | `constants/FrameworkConstants.java` | `OBJECT_REPO_ROOT`, `OBJECT_REPO_WEB_PATH` (`objectrepo/Web`), `OBJECT_REPO_MOBILE_PATH` (`objectrepo/Mobile`), `objectRepoPath(platform)`. `OBJECT_REPO_PATH` stays (deprecated, = mobile) for older code. | Every lookup used to read `objectrepo/Mobile`, also for web scenarios, so web locators had to live in the mobile folder and `objectrepo/Web/OR_Common.json` was never found. |
| 17 | `utils/DataHandler.java` | A scenario reads only its own platform's folder (and `target/classes/objectrepo/<Web|Mobile>`). The locator cache is per platform. The android/ios sub-node lookup is done for mobile only. The "not found" message names the platform and the folder. Outside a scenario (tools) both folders are searched. | Web never sees mobile files and the other way round; no mix-ups when web and mobile use the same module name. |
| 18 | `pom.xml` | Profiles `-Pweb` (`@Web and not @WIP`, one browser at a time) and `-Pmobile` (`@Mobile and not @WIP`). Default tags `@Mobile and not @WIP`. | Run one platform without remembering tag filters. Unfinished scenarios are kept out of runs. |
| 19 | `flexcube-features/01.CIF/**` (3 files) | `@Web` added to the feature tags. | `-Pweb` runs them. |
| 20 | `flexcube-features/Mobile/paymentTracker.feature` | `@Mobile @WIP` added. | It had no `@Mobile` tag, so the hooks started a **web browser** for this mobile feature. It also has 5 steps with no step definition yet, hence `@WIP` until they are written. |

Verified: `mvn -o test-compile` OK. Dry run `-Pmobile`: 3 scenarios, all steps bound. Dry run `-Pweb`: 4 scenarios (3 CIF + 1 Lior RMS), all steps bound.
Real run (copy of the framework): Lior-generated `RMS|SC_001` with `-Pweb -DHEADLESS=true` passed; its locators came from `objectrepo/Web`.
Lookup check: mobile scenario -> `objectrepo/Mobile` (android node), web -> `objectrepo/Web` (incl. `OR_Common.json`), mobile asking for a web module and web asking for a mobile module -> not found.

How to run:
```
mvn test -Pweb
mvn test -Pmobile
mvn test -Pweb -Dcucumber.tags="@Web and @SC_001"
```

## Waits, errors, dead code, browser Back (2026-10-02)

Backup before these changes: `C:\Uday\RD\Automation\Framework-backup-before-cleanup-20261002-003800.zip` (src, features, pom, Script).

| # | Area | What changed | Why |
|---|------|--------------|-----|
| 21 | Fixed waits (web) | `CommonSteps`: 10 s / 5 s / 1.5 s sleeps -> `waitForPageToLoad()` + loading-indicator waits (`waitUntilScreenSettled`). `CommonPage`: OBTF login 5 s, OBTFPM logout 3 s + 2 s, logout 0.5 s -> page-load waits; `click()` already waits for the element. `CustomerMaintenancePage` LOV 5 s -> page-load wait. `WebUI`: 200 ms before drop-down click removed (Playwright waits), alert check waits until the alert appears instead of always the full time, paging waits until the table content changes instead of 2 s, upload fallback pause removed (and its broken JS fixed). `WebUI.sleep()` kept but deprecated. | A fixed pause is too long on a fast day and too short on a slow one: slow and flaky runs. |
| 22 | Fixed waits (mobile) | `MobileUI.click`: 500 ms pause -> waits until the element stops moving (`waitUntilStill`). New `MobileUI.waitUntilEnabled(locator, max)`. `CommonMobilePage` T&C: 1.5 s pause -> waits until the confirm button is enabled (re-taps when the tick was lost). | Same; taps no longer land mid-animation. |
| 23 | Fixed waits (hooks/reports) | `ApplicationHooks.afterAll`: 2 s grace pause removed (the file-polling loop that follows is the real wait). | Faster end of run. Polling loops (DriverManager, ReportUtils, hooks) stay: they wait for a condition. The explicit "wait N seconds" keyword stays. |
| 24 | Swallowed errors | `waitForPageToLoad` and the loading-indicator wait now log a WARN with the reason (was: silent / misleading ERROR). `FileHelpers` throws `UncheckedIOException` with the file path (was `printStackTrace`). `FeatureAggregator` logs report failures with `LogUtils.error` (was `printStackTrace`). `ReportUtils` / `WebUI.sleep` keep the thread's interrupt flag. 86 `System.out/err.println` calls in framework code now go through `LogUtils`, so they appear in the scenario logs and reports (generator tools and `PropertiesHelpers` unchanged). Two leftover debug prints in `uploadFile` removed. | Failures and warnings are visible where people look. Verification keywords already failed correctly and were not changed. |
| 25 | Dead code | 3,856 lines of commented-out code removed from 20 files (e.g. `MobileDriverManager` 3,168 -> 950 lines, `ApplicationHooks` 1,708 -> 980). Explanation comments were kept. The API layer was 100% commented out, so these 5 files had nothing left and were deleted: `keywords/WebAPI.java`, `keywords/WebAPIPlaywright.java`, `pages/API/BaseAPIPage.java`, `pages/API/UserAPIPage.java`, `stepdefinitions/API/UserAPISteps.java`. | Readable code. To get the old code back: `git show HEAD:<path>` or the backup zips. `flexcube-features/API/UserAPI.feature` had no working steps before and still has none. |
| 26 | Browser Back | New `WebUI.navigateBack()` and step `user goes back to the previous page` (`CommonSteps`). | Recorded Back presses now run; Lior generates this step (and only adds its own copy for frameworks that lack it). |

Verified: `mvn -o test-compile` OK. Dry run `-Pmobile` 3 scenarios and `-Pweb` 4 scenarios: all steps bound.
Real run (copy of the framework, `-Pweb -DHEADLESS=true`): Lior-generated `RMS|SC_001` passed - open app, click "Forgot password?", type e-mail, go back (log: "Went back from .../forgot-password to .../login"). Custom dashboard, feature report and Cucumber HTML report generated.
Not verified: mobile on a real device (BrowserStack still blocks the IP); Flexcube web scenarios (no Flexcube system here).

| 27 | `keywords/WebUI.java` `selectOption` (custom drop-downs) | Opens the list, reads each option's VISIBLE text (icon names such as `smart_toy` left out), picks the exact match, else the only option that contains the text; otherwise fails at once with the options that were shown. | Angular Material option texts contain icon names, so the exact XPath never matched; it then waited 60 s and threw, and the "fuzzy" fallback after it was never reached. Found by a real run of a Lior-recorded RMS test. |

Real run 2026-10-02 (copy of the framework, `-Pweb -Dcucumber.tags="@RMS" -DHEADLESS=true`): Lior-recorded "Create a project" passed end to end (login, New Project, 2 text fields, 2 Material drop-downs, date-picker calendar, typed date, Create Project, user menu, Sign out) in 50 s.
Run only one application: Lior tags each generated feature with its module, e.g. `mvn test -Pweb -Dcucumber.tags="@RMS"`. Plain `-Pweb` runs ALL web features, including the Flexcube CIF ones.

| 28 | `flexcube-features/01.CIF/**` (3 files) | `@Web` tag removed again (reverts #19). | `-Pweb` runs only web applications recorded with Lior (e.g. RMS). The CIF (Flexcube) features are unchanged and still run as web tests when asked for: `mvn test -Dcucumber.tags="@CIF"`. |
| 29 | `utils/TestDataTokens.java` (new), `utils/DataHandler.java` | Test data values may contain `${unique}` (new on every run), `${today}`, `${today:+5}`, `${today:+5:dd-MM-yyyy}`, `${random:6}`; resolved when a value is read. | Tests that CREATE something can run again: the RMS app rejects a second project with the same name ("already exists"), which made every re-run of "Create a project" fail. Example: `"ProjectName": "Test1 ${unique}"`. |

Real run 2026-10-02 02:29 (copy of the framework, Lior-recorded RMS "Create a project", `-Pweb -Dcucumber.tags="@RMS" -DHEADLESS=true`): passed; every screen change waited for (Login, Dashboard, New, project page, Login after Sign out), project name "Lior Project ${unique}".
| 30 | `utils/OneTimeCodes.java` (new), `utils/TestDataTokens.java` | One-time passwords (OTP) in the test data. A fixed test OTP is written as it is (`"123456"`). An OTP that changes on every run: `${fromScreen:Screen.Element}` = the code the application shows in that element ("Your OTP is 482913" gives 482913; `:3` = only the 3rd character, for one-digit OTP boxes); `${ask:question}` = a person types it in a small always-on-top window while the test runs (asked once per scenario, gives up after 5 minutes; fails at once with a clear message when there is no screen); `${totp:SECRETKEY}` = the 6-digit authenticator-app code (RFC 6238; `${totp:KEY:8}` for 8 digits; waits for the next code when the current one has under 3 s left). New Lior step `user remembers the text of the following elements under "X" screen` (LiorWebSteps / LiorMobileSteps) reads the code early - for a code shown on one screen and typed on the next, or in a message that disappears; `${fromScreen:...}` then uses the remembered code. An OTP that cannot be worked out raises `OneTimeCodes.CodeException`, which the "... if they are in the test data" steps never treat as "field not in the test data". | Sites that show a new OTP on every run made recorded tests fail on the second run. OTPs sent by SMS / e-mail: ask the application team for a fixed test OTP, or use `${ask:...}` for runs someone watches. |

Real run 2026-10-02 09:21 (copy of the framework, `-Pweb -Dcucumber.tags="@OtpDemo" -DHEADLESS=true`) against a local test site that shows NEW codes on every page load (6-digit OTP field, then 4 one-digit boxes; the site goes on only with the right code): Lior-recorded test passed. Same run with a wrong fixed OTP failed as expected ("The SecondCheck screen did not appear"). Checked separately: RFC 6238 test vectors, code extraction from messages, `${ask}` window, no-screen error.

| 31 | `keywords/WebUI.java` `selectOption` (standard `<select>`) | The option is picked in the page in one go: the visible text (spaces and line breaks ignored), else the option value, else the first option whose text contains the value; options that load a moment later are waited for (up to the timeout). The error now lists the options shown. Backup: `extractor-backup/20261002-112227-before-selectOption-fix/`. | Lior leaves the balance out of a recorded choice (`911000000001 — SAVINGS` for `911000000001 — SAVINGS (₹249,880)`), so it is a partial text. Playwright's select by label waited the full timeout for it, then by value again, before the partial match was tried: the Tristha Bank Fund Transfer looked stuck on "From account" (2026-10-02 11:17). |

Real run 2026-10-02 11:24 (copy of the framework, Lior test bank with Angular-style option text and options loaded late, `-Pweb -Dcucumber.tags="@BankDemo" -DHEADLESS=true`): passed in 27 s (was over 2.5 min); From account chosen about 3 s after the step before; balance 249880.00 -> 249870.00 checked.
| 32 | `driver/DriverManager.java` (`initDriver(String browser)`), `hooks/ApplicationHooks.java` (`browserTag`) | A web scenario tagged `@Chrome`, `@Edge`, `@Firefox` or `@Webkit`/`@Safari` runs in that browser; untagged scenarios use `BROWSER` from config.properties as before. `-DBROWSER=...` on the command line still wins for the whole run. Backup: `extractor-backup/20261002-112634-before-browser-tag/`. | Lior tags each recorded web test with the browser it was recorded in. The Tristha Bank test was recorded in Chrome but ran in Edge (`BROWSER=edge`). |

Real run 2026-10-02 11:29 (copy of the framework, config `BROWSER=edge`, Lior pack tagged `@Web @Chrome @SC_001`): "Web Driver started: Chrome 155.0.8059.27", scenario passed.
| 33 | `keywords/WebUI.java` `uploadFile`, new `findElementInFrame(selector, mustBeVisible)` | Uploads find the file box when it is in the page, also when it is hidden (the first match); other steps still wait for a visible element. Backup: `extractor-backup/20261002-120436-before-hidden-upload-fix/`. | File boxes are usually hidden behind a "Click to upload or drag & drop" area (RMS Create Project). The upload waited the full timeout for the box to become visible and failed. |

Real run 2026-10-02 12:05 (copy of the framework, Lior test bank with a drop zone and two hidden file boxes): "Successfully uploaded file to element: Input|//input[@type="file" and @accept='.xlsx,.xls']", scenario passed.

## Clean-up: shared state, swallowed errors, dependencies, secrets, git (2026-10-02 evening)

Backup of the old pom: `extractor-backup/20261002-cleanup/pom.xml`.

| # | Area | What changed | Why |
|---|------|--------------|-----|
| 34 | `driver/DriverManager`, `driver/MobileDriverManager` | `browserVersion` and `deviceDetails` were plain `static` fields (Lombok `@Getter`), shared by all threads. Now per thread (`ThreadLocal`); `getBrowserVersion()` falls back to the last browser started, for the end-of-run reports. | Parallel mobile runs (3 devices) could log another scenario's device; parallel web runs another browser. |
| 35 | `keywords/WebUI.verifyTableCell` | Fails the step when the Signature ID is on no page (it returned a "FAILED" text that the caller ignored, so the step always passed). Errors while reading the table are no longer swallowed; highlight / screenshot failures are logged as warnings. | A verification that cannot fail hides real defects. |
| 36 | `DashboardGenerator`, `ReportUtils`, `TestRunner`, `RerunTestRunner` | `printStackTrace()` / `System.err` -> `LogUtils.error(message, exception)`. | Report failures appear in the log files, with the stack trace. |
| 37 | 4 files | Last 7 commented-out code lines removed. | |
| 38 | `pom.xml` | Removed unused libraries: REST Assured (+ a commented-out second copy), BrowserStack Java SDK (the framework talks to the BrowserStack hub through Appium; no SDK agent is used), Owner, PDFBox. Appium client and AssertJ now use their version properties (`appium.version` 10.1.0, `assertj.version` 3.26.3 - the versions that were really used; the properties said 10.1.1 / 3.26.0). Unused properties removed. | Hard-coded versions that differed from the declared properties; unused jars on the classpath. |
| 39 | `utils/PropertiesHelpers`, `config/config.properties`, `.gitignore` | BrowserStack username / access key moved out of `config.properties` (now empty placeholders) into `src/main/resources/config/secrets.local.properties` (git-ignored, read last, never written to). A setting can also come from an environment variable of the same name; `-D<KEY>` still wins over everything. `extractor-backup/` git-ignored. | Keys must not be in git. On another PC / a build server: create the secrets file or set the environment variables `BROWSERSTACK_USERNAME`, `BROWSERSTACK_ACCESS_KEY`. |

Not changed: `Thread.sleep` that remain are polling intervals of condition waits and the explicit "wait N seconds" keyword. User passwords in `testdata/Users/*.json` and the git token in `.git/config` (rotate it) are still open.
Verified: `mvn -o test-compile` OK; Cucumber dry run `-Pmobile` and `-Pweb`: all steps bound; credentials load from the secrets file.

## Lior "Swipe and tap" up / down (2026-10-02 night, NeoCorp EULA)

| # | Area | What changed | Why |
|---|------|--------------|-----|
| 40 | `CommonStepsMobile`, `CommonMobilePage.swipeVerticallyAndClick`, `MobileUI.swipeVertically` + `flick` | New steps `user swipes up|down N time(s) and clicks the ... button under ... screen` and `user swipes up|down and clicks ...` (no count = quick long swipes, 72%->15% of the screen in 0.3 s so the content flings, until the screenshot stops changing, at most 25 - a PDF viewer scrolls without changing the page source; the first version used the slow 70%->30% scrollDown and needed 8+ round trips for the 6-page NeoCorp EULA). Scroll failures keep the original exception as cause. | "user swipes and clicks" only swipes sideways; on the EULA screen the PDF was never scrolled, so the tick box and "Agree & continue" stayed disabled (SC_002 / SC_003 failed). |
| 41 | `driver/MobileDriverManager.createBrowserStackClientConfig` | BrowserStack HTTP read timeout 90 s -> 180 s, configurable (`BS_READ_TIMEOUT_SECONDS`, -D or config.properties). | Two NeoCorp runs: the sessions that were busy exactly 90 s after they were created failed at the same second with `UnreachableBrowserException` / `connection closed locally` (the HTTP client's own response timer), on requests that had just started; the session that was idle at that moment passed. Looks like the 90 s timer of the session-creation request firing on the reused connection. Confirm with a run longer than 90 s. |
| 42 | `pom.xml` (defaults + `mobile` profile) | Mobile runs are sequential by default (`parallel=false`, `threads=1`); parallel on request with `-Dparallel=true -Dthreads=3`. | CorpLogin SC_001-003 all log in as the same user and register a device; run on three phones at once, the bank's server answered one of them with "Error! We're unable to complete your request" (SC_003, 2026-10-02 23:08). |
| 43 | `MobileUI.swipeVertically` (counted swipes) | `user swipes up N time(s) and clicks ...` now makes N quick swipes (`flick`, the same gesture as the uncounted step) instead of N slow `scrollDown` drags. | A person's swipe flings the content on; the slow 70%->30% drag does not. NeoCorp SC_001 (recorded `up:5`): 5 drags stopped on page 4 of the 6-page EULA, the app ignored the tick box taps and "Agree & continue" stayed disabled (`element was not enabled`, 2026-10-02 23:40). With flicks SC_001 passed (23:45). |

## BrowserStack interactive debugging (2026-10-04)

| # | Area | What changed | Why |
|---|------|--------------|-----|
| 44 | `MobileDriverManager.getBrowserStackOptions` / `logBrowserStackSessionUrl`, `FrameworkConstants.BS_INTERACTIVE_DEBUGGING`, `config.properties` | One `bstack:options` builder for Android and iOS. With `BS_INTERACTIVE_DEBUGGING=true` it adds `interactiveDebugging`, `debug` (visual logs) and `idleTimeout` 300. Every BrowserStack session now logs its session page link (`getSessionDetails` -> `browser_url`). On by default; off for one run with `-DBS_INTERACTIVE_DEBUGGING=false`. | Debug a failing step on the real device: open the logged link, stop at an IDE breakpoint and use the device by hand without BrowserStack ending the idle session after 90 s. |
| 45 | `run-groups.properties` (new, project root), `utils/ScenarioGroups` (test), `runners/TestRunner` | Scenarios to run are chosen in `run-groups.properties`: named groups of `Module|SC_id` (or `Module`) entries, `RUN_GROUP=<group>` picks one (`-DRUN_GROUP=` wins, empty / `all` = no narrowing). The runner turns the group into `cucumber.filter.name`, ANDed with the profile tags (so `@WIP` and the other platform stay out). An unknown group fails the run with the list of defined groups. Not used by `RerunTestRunner`; an explicit `-Dcucumber.filter.name` wins. | Selecting scenarios meant editing the IDE run configuration every time. `@SC_001` is not unique (CIF, CorpLogin, CreateProject, FundTransfer all have one) and recorded features must not get extra tags, so the selection uses the scenario name `Module|SC_id`. Verified with Cucumber dry runs: group `corplogin` -> 1 scenario, `all`, unknown group. |
| 46 | `FrameworkConstants.BS_BUILD_NAME`, `MobileDriverManager.getBrowserStackOptions`, `config.properties` (`BS_BUILD_TIMESTAMP`) | BrowserStack `buildName` is `<BS_BUILD> - <yyyy-MM-dd HH:mm:ss of the run>`, made once per JVM so all sessions of one run (parallel too) share one build. `BS_BUILD_TIMESTAMP=false` keeps `BS_BUILD` as it is (e.g. a pipeline passing `-DBS_BUILD=<its build number>`). | Every run used the fixed build "Build 1.0", so each new run joined the same build and BrowserStack kept it "Running" long after the run had ended in IntelliJ (2026-10-04 20:32: session quit and marked passed, build still running). |
| 47 | Removed: `flexcube-features/Mobile/*.feature` (01.MobileLogin, CorpLoginFlow, paymentTracker), `flexcube-features/Web/*.feature` (CreateProjectWebFlow, FundTransferWebFlow); their `objectrepo` files (`Mobile/OR_CorpLogin`, `Mobile/OR_TermDeposit`, `Web/OR_CreateProject`, `Web/OR_FundTransfer`), test data (`testdata/02.TERMDEPOSIT`, `03.FUNDTRANSFER`, `04.CREATEPROJECT`, `05.CORPLOGIN`) and generated constants (`CORPLOGIN`, `TERMDEPOSIT`, `MOBILE`, `CREATEPROJECT`, `FUNDTRANSFER`). Kept: `01.CIF`, `API`, `Web/OR_Common`, `Mobile/OR_OAT`, `Mobile/OR_Term`, `Mobile/locators.json`, `url.US.*` lines, `LiorWebSteps`. | 2026-10-05: all mobile and web flows are re-recorded from scratch with Lior. No Java code used the removed constants (`mvn test-compile` passes). |
| 48 | `hooks/ApplicationHooks.afterAll`, `runners/TestRunner`, `runners/RerunTestRunner` | When no scenario ran, `afterAll` logs which tags / name filter (`RUN_GROUP`) matched nothing and returns; the runners skip the custom dashboard when `master.json` was not created. | With no matching scenario the hook waited 30 s for scenario files that never come ("Scenario directory does not exist yet"), then the dashboard failed on the missing `master.json`. |
| 49 | `stepdefinitions/Mobile/LiorMobileSteps.java` (re-installed from Lior's fixed template) | The mobile "remember text" step is now `user remembers the text of the following mobile elements under {string} screen`. Fixed in Lior (`FrameworkPack` + `LiorMobileSteps.java.txt`), not by hand. | Both Lior step classes had `user remembers the text of the following elements under {string} screen`; both are on the glue path, so every scenario failed with `DuplicateStepDefinition`. |

## BrowserStack Java SDK - tried 2026-10-04, NOT adopted
Goal: close the BrowserStack build as soon as a run ends (without the SDK it stays "Running" for minutes; sessions are
marked passed/failed at once by `quitDriver`). SDK 1.75.2 as a surefire `-javaagent` + `browserstack.yml` was tried on
`CorpLogin|SC_001` and reverted (pom back as before, yml removed). Findings, for the next attempt:
- Credentials must reach the forked JVM as environment variables (the SDK starts before the framework). Reading
  `secrets.local.properties` with `properties-maven-plugin` works, but only if the keys are NOT also in pom `<properties>`.
- Without `platforms:` in the yml the SDK drops the capabilities sent by the code ("Capabilities must be set").
- It needs `selenium-java` on the classpath (`NoClassDefFoundError: org/openqa/selenium/chrome/ChromeOptions`).
- Blocker: it does not recognise Appium java-client 10.1.0 ("Couldn't find dependency class: appium"; Playwright 1.49 is
  also on the classpath) and sends legacy desktop Automate capabilities (`browserstack.user`, `device`, `os_version`,
  `isPlaywright`...), which Selenium 4.50 rejects ("Illegal key values seen in w3c capabilities"). BrowserStack's own
  sample uses java-client 8.6. Retry with a newer SDK, or ask BrowserStack support about java-client 10 support.

## Fixes.xlsx and full-framework audit (2026-10-06)

Source: `Fixes.xlsx` (sheet 1: 19 mobile items; sheet "Audit 2026-10-06": 50 items from a file-by-file review). Status per item is in the workbook.
Verified: `mvn -o test-compile`; Cucumber dry runs (`-Pmobile` 1 scenario, `@CIF` 3 scenarios: all steps bound); a mobile run
with no Appium server (dashboard now FAILED with the `@Before` failure as its own line, teardown "skipped", no web
screenshot, Appium command line in the scenario's log); 41 offline checks (locators, text match, failure kinds, masking,
history order, runtime test data) and 15 web keyword checks in headless Chromium against a local page.
Not verified on a real device / BrowserStack (iOS typing / text, alert setting, session-lost handling) or on Flexcube.

| # | Area | What changed | Why |
|---|------|--------------|-----|
| 50 | `CommonSteps` login | FCUBS branch (standard login page) and an error for an unknown application. | `user "Maker" is logged into "FCUBS"` (every CIF feature) did nothing and the next step failed with "element not found". |
| 51 | `DataHandler.getTestDatapath` | When no `NN.<MODULE>` folder exists, `<REGION>_TestData_<module>.json` is looked up in all `NN.*` folders (Common -> `00.PREREQ`). `user selectOption ...` reads the scenario's own data. | `user switch to branch` / `user switch to Entity` always failed with "No folder found". |
| 52 | `DataHandler.getTestData`, Lior `valueOrNull` (template `LiorWebSteps/LiorMobileSteps.java.txt`, re-installed) | A broken / unreadable test data file is an error; the "...if they are in the test data" steps skip only on a missing field (`IllegalArgumentException`). | A wrong module / region or broken JSON skipped every step and the scenario passed having done nothing. Rebuild Lior (`build.ps1`) to ship the template. |
| 53 | `StepEventListener`, `FeatureStepCollector`, `FeatureAggregator` | Failed hooks are a FAILED line in the report; Cucumber's own result (`cucumberStatus`) is saved and a scenario that did not pass is never counted as passed. Start time per thread, end time = real end (hooks included). Keywords rethrow the original exception type. Error texts in the report are masked. | A failed `@Before` (no device, no browser, no user) showed as PASSED on the dashboard. |
| 54 | `CommonPage.verifyAccountingEntries` | All fields are checked, then the step fails once listing every mismatch. | The soft checks' FAILED results were ignored: accounting entries could never fail. |
| 55 | `CustomerMaintenancePage.verifyTableRow` | Fails when the signatory table still has rows. | It only logged "Failed". |
| 56 | `WebUI.verifyElementNotVisible`, new `isVisibleWithin` | Passes as soon as no match is visible (page and frames), waits for a visible one to go; a broken selector fails. Optional elements (overrides table, last-page link, dashboard after login) use a short check. | Any Playwright error counted as a pass, and every real pass waited 60 s. |
| 57 | `WebUI.verifyTableCell` | At most 200 pages; stops when Next does not change the table. | Could loop forever. |
| 58 | `WebUI.clickFirstVisibleElement` | Clicks the first visible match (page or frame). | Took the 2nd element and used its description as a selector: always failed. |
| 59 | `FrameworkConstants` app paths, `MobileDriverManager` | `ANDROID_APP_PATH` / `IOS_APP_PATH` read from config / -D / env, relative to the project; checked to exist. Placeholders in config.properties cleared. | A local iOS session always got the project folder as its app. |
| 60 | `PropertiesHelpers` | `setValue` / `setFile` removed (settings are read-only). | `setValue` would have written all settings, secrets included, into the git-tracked `urls-<ENV>.properties`. |
| 61 | `MobileDriverManager` timeouts / guard | `BS_CONNECT_TIMEOUT_SECONDS` (30) and `BS_READ_TIMEOUT_SECONDS` (180) from config or -D, checked; `LOCAL_NEW_COMMAND_TIMEOUT_SECONDS` (60). A BrowserStack SDK `-javaagent` on the command line stops the run with a clear message. | Sheet 1 #1, #2. |
| 62 | Key masking (from the 2026-10-05 worktree patch) | No `userName` / `accessKey` capabilities (hub URL only); every `LogUtils` line and report error masks the access key and `user:password@` in URLs. | Sheet 1 #3, audit #30. The key was in logs and reports before: rotate it. |
| 63 | `MobileDriverManager` command log, session state | Every Appium command is logged on the test thread: name, session, thread, ms, outcome (no parameters). A command that loses the connection / session marks the session unusable: no more screenshots, no BrowserStack status update (quit and cleanup still run). `quitDriver` returns NO_DRIVER / QUIT / QUIT_FAILED and the hook logs that. | Sheet 1 #7-#10. |
| 64 | `MobileUI` failures and screenshots | `fail()` keeps the cause and prefixes the kind: `[LOCATOR]`, `[TRANSPORT]`, `[SESSION]`, `[SETUP]`, `[ACTION]` (`utils/FailureKind`). One failure screenshot per scenario (keyword or hook); after a failed screenshot none are taken for the rest of the scenario. Mobile scenarios never fall back to a web screenshot. | Sheet 1 #4-#6. |
| 65 | `MobileUI` typing / text / locators | Both typing keywords: find, (iOS: must be a text field), tap, clear, type, (Done / Enter); the error names the phase. `getText` / `verifyText` / `retrieveText` read iOS input values, then label / Android `text`; failures fail the step (no ""). New `getAttribute(locator, name)`. Locators: `predicate|`, `classchain|`, `uiautomator|`, `Field|...` handled explicitly, empty or unknown locators fail with a clear message. Back / Home work on iOS; Recent Apps says "Android only". Typed passwords / PINs are masked. | Sheet 1 #12-#19, audit #28. |
| 66 | `scripts/compare-sequential-parallel.ps1` (new) | Runs a group sequentially, then in parallel, and lists scenarios whose result differs. | Sheet 1 #11. |
| 67 | `LogUtils`, `log4j2.xml` | One routing key (`logFileName`), removed at scenario end; idle scenario log files closed after 2 min; call info via `StackWalker`. | Lines after a scenario went into that scenario's file. |
| 68 | `ReportUtils`, `DashboardGenerator`, `FeatureAggregator`, template | Backup names `yyyyMMdd_HHmmssZ` (old names still read); history sorted by run time; `master.json` has `runStartTime`; backup folder only when there is content; delete failures listed; JSON wait needs two equal sizes (`REPORT_JSON_WAIT_SECONDS`). | History in the wrong order (Sep after Oct), no run dates, empty backups pushed real ones out. |
| 69 | `ApplicationHooks` build number, rerun | `BUILD_BUILDID` (Azure DevOps) or `-DBUILD_NUMBER`. `RerunTestRunner` writes its own JSON / HTML and keeps the first run's reports. | Pipeline runs were all "local_..."; the rerun replaced the first run's results. |
| 70 | `WebUI` | Errors keep the cause (`Assert.fail(msg, e)`); read-only fallback passes the value as an argument and fires input / change; passwords masked; upload has no fake JS fallback and checks the file; `adjustDate` throws on a bad date; "contains" checks need a whole word / number and an empty expected value matches only empty text. | Audit #19-#24. Behaviour change: "10" no longer matches "100"; watch the next CIF run. |
| 71 | `DataHandler.writeTestData` | Runtime values go to `testdata/.runtime/<same path>` (git-ignored) and are merged over the recorded file on read; locked; unknown scenario / path fails the step. Object repository: unreadable file is reported as such; iOS no longer falls back to Android locators. | The recorded test data files were rewritten by every run, unsynchronised. |
| 72 | Steps | `user verify {string} is visible` checks the named element ("Dashboard" = logo); freeze / defreeze steps renamed to what they do ("the user verifies the customer is (not) frozen", unused); `the mobile app is launched` checks the session and a screen; broken `MobileLoginSteps` steps and `MobileLoginPage` removed (Back / Home / Recent steps kept); module / scenario id read at step time. | Audit #31, #32, #42, #43, #45. |
| 73 | Clean-up | Removed unused `UserImpl`, `paymentTrackerPage`, `BasePage`, `FakerUtils`, `DateUtils`, `FileHelpers`, `runner/Launcher` (broken glue), stale `META-INF/MANIFEST.MF`, unused methods / constants, empty `@AfterStep`; datafaker and assertj dependencies, and the duplicate `maven-cucumber-reporting` plugin. Unused settings optional; `PROJECT_NAME` is the dashboard title; reports written as UTF-8 with the real ENV / REGION. `MainRunner` registers `ParallelExecutionListener`. `DriverManager` closes Playwright after a failed start, names videos per test case and attaches them to the report; `IGNORE_HTTPS_ERRORS` setting (default true, as before). `IOS_ALERTS=accept|dismiss` setting (default off). | Audit #36-#49. POI stays: it pins the Extent adapter's POI. |

Still open (need a decision or input): rotate the BrowserStack key and the git token; `APP_PACKAGE` is the demo app (NeoCorp package needed for local runs); UAT HK / UK URLs are `example.com`; SIT `FUNDTRANSFER` / `CREATEPROJECT` URLs belong to removed features; `IOS_ALERTS` default; `${today}` ignores `DATE_FORMAT` (Lior data relies on MM/dd/yyyy); package names that differ from folders (Lior's template imports `pages.CommonPage`); `checkerOBAPY` role name; end-of-content detection by screenshot (needs a device to check).

## Synced with Framework_Fixed (2026-10-06 evening)

`C:\Uday\RD\Automation\Framework_Fixed` is another engineer's copy (commit d2b0643 + uncommitted mobile/BrowserStack
hardening, where Fixes.xlsx came from). It was only READ; nothing there was changed. Its changes were compared with this
framework item by item; most were already here in another form (#41, #61-#66). What was missing was ported into this
framework's design (not copied file by file). Not taken: its feature / OR / test data files (removed here on purpose,
#47; recorded data is never hand-edited), the old payment-tracker / TermDeposit classes, default parallel=true / threads=3
(#42), fixed sleeps in click / T&C, "[redacted]" for every typed value (here only secret fields are masked), its old
CHANGELOG / CLAUDE.md copies.
Verified: `mvn -o test-compile`; new offline suite `mvn test -Pmobile-regression` 20/20 passed; Cucumber dry runs
(-Pmobile 1, @CIF 3); earlier checks (41 offline, 15 web) still pass; no-Appium-server run still FAILED with clean teardown.

| # | Area | What changed | Why / from |
|---|------|--------------|------------|
| 74 | `driver/BrowserStackRestStatus` (new), `MobileDriverManager.quitDriver` | Status through the session while it is usable; otherwise, or when that fails, through the REST API (`PUT api-cloud.browserstack.com/app-automate/sessions/<id>.json`, same proxy, credentials in a header). Every result is recorded in `target/browserstack-status/<session>.json` (`confirmed`, `channel`); quit always runs once, with its duration logged. New `scripts/Sync-BrowserStackResults.ps1` sends unconfirmed results later (credentials from env or secrets.local.properties). | Sessions whose connection was lost stayed "Unmarked" (#63 skipped them). Framework_Fixed `BrowserStackResultReporter`. |
| 75 | `ApplicationHooks` | BrowserStack "passed" only for Cucumber status PASSED; the reason says the status. | `!isFailed()` reported SKIPPED / UNDEFINED / PENDING scenarios as passed. |
| 76 | `utils/FailureKind` | Any `IOException`, `java.util.concurrent.TimeoutException` or `HttpTimeoutException` in the cause chain is TRANSPORT. | An HTTP read timeout (Selenium TimeoutException with that cause) was LOCATOR, so the session was not marked unusable. |
| 77 | `MobileDriverManager` authentication / session | Credentials in a preemptive `Authorization` header (`withCredentials`), not in the hub URL. A leftover session on the thread is refused (was reused). Session creation time logged (success and failure). `sessionName` = `Module | SC_id`. `BS_IDLE_TIMEOUT_SECONDS` (1-300, default 90; interactive debugging still 300). Status JSON built with Jackson. | Framework_Fixed `MobileDriverManager`. |
| 78 | `LogUtils`, `FeatureStepCollector` | `mask()` also hides `Authorization: Basic/Bearer ...`, `accessKey:`, `password=`, `authToken`, `apiKey` values and the BrowserStack user name. An exception that contains a secret reaches Cucumber / Allure / Extent as a masked copy (`LogUtils.sanitized`: type names, frames, causes kept); others keep their type. | The exception given to Cucumber was not masked. Framework_Fixed `SafeDiagnostics`. |
| 79 | `MobileUI` | After the session is unusable every keyword fails at once with `[SESSION]`; `isElementEnabled` rethrows lost-connection errors (`waitUntilEnabled` polled a dead session); a screenshot that returned "" now counts as failed (#64's "no more screenshots" never triggered: CaptureHelpers swallows the error); iOS text fields read their value also when empty (not the label); iOS typing refuses an element without a type; `iospredicate|`, `iosclasschain|`, `androiduiautomator|` accepted. | Framework_Fixed `MobileUI` / `NativeElementSupport` / `MobileFailureSupport`. |
| 80 | Tests (new): `src/test/java/.../driver/FakeAppium`, `MobileSessionRegressionTest` (14), `NativeKeywordRegressionTest` (6); `suites/mobile-regression.xml`, `mobile-regression-log4j2.xml`; pom profile `mobile-regression` | A fake Appium + BrowserStack REST server on 127.0.0.1 drives the real Selenium / Appium HTTP code: failure kinds, setup failure, leftover session, masking, no credentials in URL / capabilities, header auth, one failure screenshot, broken screenshot, lost connection -> fail fast, REST fallback, pending record, parallel isolation, typing order, clear failure, iOS label rejected, iOS value / label / Android text, locator prefixes. Records go to `target/offline-regression/` (never synced). `mvn test -Pmobile-regression`. | Framework_Fixed's 18 tests, rewritten for this framework's API. |
| 81 | `pom.xml` | Selenium modules pinned to 4.50.0 (the version verified here; Framework_Fixed pins 4.41.0 - Appium's published matrix - change `selenium.version` to move); `<release>17`; Lombok as annotation processor; `log4j.configurationFile` per profile. Not taken: selenium-bom and maven-enforcer (not in the offline Maven cache). | Appium allows Selenium [4.40, 5.0): a newer Selenium could arrive unnoticed. |
| 82 | `scripts/compare-sequential-parallel.ps1`, `docs/browserstack-session-diagnosis.md` | Script: `-Iterations`, copies only a run's fresh report, `summary.csv` (exit code, threads, seconds) + `comparison.csv`, credential check. Doc: Framework_Fixed's evidence (90 s read timeout during session creation; "may have died" = a failed HTTP request, not proof the session ended). | Framework_Fixed `Compare-BrowserStackExecution.ps1` and docs. |

Still open from Framework_Fixed's gap matrix: per-session `systemPort` / `wdaLocalPort` for parallel LOCAL devices (MW-12),
Playwright tracing (MW-15), Maven wrapper + CI pipeline (MW-19), README (MW-20), agreed browser / device matrix (MW-23).

## Journeys: one business case over web and mobile (2026-10-08)

A journey is several scenarios, each on ONE platform, that run in order and hand values to each other - e.g. the maker creates a
transfer on the mobile app, checker 1 and checker 2 approve it on the web, the maker sees it approved on the app. Made by Lior
("Journey..." in the Automation pack tab): `flexcube-features/Journey/<Name>Journey.feature`, tags `@Journey @Journey_<Name>` and
`@JourneyPart_<n>` per scenario. Run: `mvn test -Pjourney -Dcucumber.tags="@Journey_<Name>"`.

| # | Area | What changed | Why / from |
|---|------|--------------|------------|
| 83 | `utils/Journey` (new), `ApplicationHooks` | Before its browser / app starts, a part waits for the part before it (parallel runs: up to `-DJOURNEY_WAIT_MINUTES`, default 30) and is SKIPPED (`SkipException`, reason logged) when that part failed or was skipped. After the scenario its status is recorded for the next part. | A checker part without the maker's transaction can only fail with a misleading error; skipping says where it really broke. |
| 84 | `utils/Journey`, `TestDataTokens`, `DataHandler`, `OneTimeCodes.shownText` | `${journey:Name}` in test data and in locators (e.g. `//a[normalize-space()='${journey:ReferenceNo}']`) = a value an earlier part kept. `Journey.pick` takes it out of a screen text by a plain rule in the test data ("the word after 'Reference No:'", "the whole text", "the first word", empty = worked out). Kept values are also written to `testdata/.runtime/journeys/<Name>.json`, used only when the earlier parts did not run in this JVM (a rerun of one later part). Values a part typed are remembered exactly (also `${random:6}`). | Reference numbers change every run; the next part must use THIS run's. |
| 85 | `LiorWebSteps` / `LiorMobileSteps` (Lior templates) | `user keeps the text of "F" under "S" screen as "Name" for the journey` (mobile: `... of mobile element ...`), `user keeps the typed value of "F" as "Name" for the journey` (mobile: `... of mobile field ...`), `user waits up to N seconds until the following (mobile) elements under "S" screen show the test data` (polls, then the usual verify once). | Steps the journey pack writes. |
| 86 | `pom.xml` | Profile `journey` (`@Journey and not @WIP`, sequential). Default, `-Pweb` and `-Pmobile` add `and not @Journey`. | On their own the later parts have no reference number. |
| 87 | `utils/ScenarioGroups` | A tag filter with `@Journey` ignores `run-groups.properties` (unless `-DRUN_GROUP` is given), and says so in the log. | `RUN_GROUP=corplogin` turned `-Pjourney` into a run of 0 scenarios. |

Verified 2026-10-08 on a COPY of this framework against Lior's local journey bank (fake Appium app on 127.0.0.1 + web approval portal,
`MOBILE_EXECUTION_MODE=local`; no BrowserStack): `mvn -o test -Pjourney -Dcucumber.tags=@Journey_TxnApproval` - 4/4 parts passed on a new
reference number (kept on the app, searched and clicked by checker 1, clicked by checker 2, row tapped by the maker, "Status: Approved"
waited for); with checker 1's approval failing: part 2 FAILED (expected "Approval saved.", shown "System error: the approval was not saved." - Lior records the message a button shows as a check), parts 3 and 4 SKIPPED, build failed. Not yet run on a real device /
BrowserStack or on the real approval application.

## Portable: another machine, folder, network or OS (2026-10-08)

| # | Area | What changed | Why |
|---|------|--------------|-----|
| 88 | `DriverManager` | Edge / Chrome not installed: the other one, then Playwright's Chromium, with a warning (only for "not installed" errors; a crash still fails). No screen (Linux agent without DISPLAY / WAYLAND_DISPLAY, `java.awt.headless=true`): headless with a warning. For Edge / Chrome, `Playwright.create` gets `PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1` (your own -D / env value wins). | `BROWSER=edge` failed on machines without Edge; HEADLESS=false failed on agents; Playwright tried to download ~400 MB of browsers on machines without internet even when the test used installed Edge / Chrome. |
| 89 | `MobileDriverManager.getBrowserStackProxy` | A proxy name that is not known on this network (BS_PROXY_HOST is the client's) -> no proxy, with a warning (same as -Poffsite). | Every BrowserStack session failed outside the client network until someone remembered -Poffsite. |
| 90 | `DataHandler.getTestDatapath` | Test data folder (`NN.MODULE`) and file (`<REGION>_TestData_<MODULE>.json`) found in any case, with the file's real name. | Windows ignores case, Linux / macOS agents do not: `US_TestData_Approvals.json` worked here only. |
| 91 | `pom.xml` (surefire argLine), `ORGenerator` | Test JVMs use UTF-8 (`-Dfile.encoding`, `sun.stdout/stderr.encoding`); ORGenerator reads UTF-8. | Java 17 used the system code page (Windows-1252 here, UTF-8 on Linux): logs showed `Text �` and non-English test data could differ between machines. |
| 92 | Tests: `driver/PortabilityRegressionTest` (6, in `-Pmobile-regression`) | Fallback order, "browser missing" vs crash, no download for installed browsers, no screen, unknown proxy, test data file in another case + UTF-8. | |

Verified 2026-10-08: the framework copied to `%TEMP%\claude\Port Test\TCoE Framework` (another folder, spaces in the path):
`mvn -o test -Pmobile-regression` 26/26; Lior's journey (JourneyProbe) installed there and run with `-Pjourney`: 4/4 parts passed,
and the failure run failed part 2 and skipped 3 and 4. Already portable before this (checked): no machine paths in code, every setting
can be given per machine as -D or an environment variable, paths come from the project folder, OR file lookup ignores case.
Not done: a Maven wrapper (each machine needs Maven 3.9+ and JDK 17+; client machines need the Maven repository or a mirror),
the two `scripts/*.ps1` helpers are PowerShell (pwsh runs them on Linux / macOS too), no run on Linux / macOS here (none available).

| # | Area | What changed | Why / from |
|---|------|--------------|------------|
| 93 | `DriverManager` | Before asking for a video, the framework looks for Playwright's ffmpeg (PLAYWRIGHT_BROWSERS_PATH, else %LOCALAPPDATA%\ms-playwright, ~/.cache/ms-playwright, ~/Library/Caches/ms-playwright). Missing -> the test runs without a video, with one warning. If a video still fails (ffmpeg of another version), Playwright is started again from scratch without one. Tests: `PortabilityRegressionTest` (ffmpeg looked for first, message from the remote machine), `VideoWithoutFfmpegCheck` + `suites/browser-portability.xml` (real Chrome with an empty Playwright folder: first proves the video error, then that the framework runs). | Remote machine 2026-10-08: "Executable doesn't exist at ...\ms-playwright\ffmpeg-1010\ffmpeg-win64.exe" - #88 skips Playwright's download for Edge / Chrome, so ffmpeg never arrives; asking for a video without it KILLS Playwright's connection ("pipe closed"), so a retry on the same connection cannot work. |
| 94 | `WebUI.findElementInFrame` / `findFirstVisibleInFrames` (`locateNow`, `page()`) | An element is looked for in EVERY open window (the test's own first, then pop-ups, newest first) and all their frames; of several matches the first VISIBLE one is used (logged "2 of 2 matches"). Found in a pop-up -> the test carries on in that window; that window closed -> the test carries on in the newest open one. Not found -> the message says whether it was in a page but never visible, how many windows were searched and what the window shows. Test: `WebElementSearchCheck` (real Chrome, in `suites/browser-portability.xml`): hidden copy + visible BTN_OK, a button in a frame of a pop-up that closes itself, back in the main window, a clear "not found". With the previous WebUI the same check failed with exactly the remote machine's error. | Remote machine 2026-10-08, FLEXCUBE: "Element not found with selector: [Password\|//input[@id='BTN_OK']] within 60000ms". A locator matching a hidden copy and the real button threw Playwright's strict-mode error inside `isVisible()`, which was swallowed until the 60 s ran out; and elements in pop-up windows (FLEXCUBE sub-screens, recorded by Lior) were never searched. |
| 95 | `WebUI.click` (`alreadyDoneByTheClickBefore`) | A click on the same button (same window, same locator) as the click just before, which is not visible within 5 s, counts as done by that click (warning in the log) instead of waiting 60 s and failing. Shown again within 5 s -> clicked again. Test: `WebElementSearchCheck` (FLEXCUBE-like branch box closing on the first Ok with a hidden BTN_OK left; a button that stays is clicked twice). | Remote machine 2026-10-08, FLEXCUBE SMMDIFRM "Transaction Branch Code" box: the recording clicked Ok twice (the first click while in the branch field only checks the branch); at replay the first click closed the box and "[Ok2\|//input[@id='BTN_OK']] ... in the page but never became visible" failed the test. |

## Mobile replay on BrowserStack, NeoCorp OAT (2026-10-10)

| # | Area | What changed | Why / from |
|---|------|--------------|------------|
| 96 | `MobileUI.captureScreenshot` / `suppressScreenshots` | An element that re-renders while its highlight box is drawn (StaleElement / NoSuchElement) gives a plain screenshot; only an unusable session switches screenshots off for the rest of the scenario. | OAT run 11:57: one stale "عربي" header switched off every screenshot, so the later failure had none. |
| 97 | `MobileUI.findElement` / `click` (`untilOnDevice`), `verifyElementState`, `captureScreenshot` | Element already there: one call, as before. Not there yet: the device waits for it (Appium implicit wait, at most 5 s per lookup, switched off again afterwards) instead of one BrowserStack round trip every 500 ms. "visible" check: no second isDisplayed. Highlight screenshot: window size read once per session, a click reuses the position it has just read. | Logs showed up to 40 `findElement ... NoSuchElementException` lines per wait; 1-2 calls fewer per step. A missing element can fail up to 5 s after the timeout. |
| 98 | `config.properties` `MOBILE_TIMEOUT_SECONDS` (default 20), `FrameworkConstants`, `MobileUI` | How long a mobile check / tap / typing step waits for its element is a setting (also `-DMOBILE_TIMEOUT_SECONDS=40`); it was a fixed 20 s in the code. | Slow screens on SIT can now get more time without a code change. |

| 99 | `MobileUI.clickAfterSwipe` / `rectNow`, `CommonMobilePage.swipeVerticallyAndClick` | After a swipe-and-tap the button is watched for 3 s: gone (next screen) or in the same place (a tick box) -> done; moved (the page was redrawn and the scroll went back) -> the tap was lost: swipe again and tap once more, with a warning. Never more than one retry; a tick box is never tapped twice. Tests: `NativeKeywordRegressionTest` (page jumps -> 2 taps + 1 swipe; next screen -> 1 tap; tick box -> 1 tap; device wait set and switched off; element already there -> no extra calls) on the extended `FakeAppium` (click moves / removes the element, timeouts recorded). | OAT on two machines, now and then: "Make Payment" tapped while shown and still, then Home redrawn at the top (failure screenshot) and "Payment" never opened. |

Verified 2026-10-10: OAT SC_001 (login, PIN set-up, licence, Make Payment, internal self transfer, slide to confirm, summary) passed on
BrowserStack (Samsung Galaxy S26 Ultra, Android 16) before #97 - #99; `mvn -o test -Pmobile-regression` 33/33 with #96 - #99
(fake Appium server); #97 - #99 not yet run on a device.
