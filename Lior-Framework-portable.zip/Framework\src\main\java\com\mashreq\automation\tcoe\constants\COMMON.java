package com.mashreq.automation.tcoe.constants;

/**
 * AUTO-GENERATED. Do not edit manually.
 * Source: OR_Common.json
 * Format: SCREEN_FIELD = "MODULE/SCREEN/FIELD"
 */
public final class COMMON {

    private COMMON() {}

    // ===== CommonScreen =====

    public static final String COMMONSCREEN_WINDOWTITLE = "COMMON/CommonScreen/WindowTitle";

    public static final String COMMONSCREEN_DASHBOARD = "COMMON/CommonScreen/Dashboard";
    public static final String COMMONSCREEN_CLEARUSERWINDOW = "COMMON/CommonScreen/ClearUserWindow";
    public static final String COMMONSCREEN_NEW = "COMMON/CommonScreen/New";
    public static final String COMMONSCREEN_INFOOK = "COMMON/CommonScreen/InfoOk";
    public static final String COMMONSCREEN_BRANCHOK = "COMMON/CommonScreen/BranchOk";
    public static final String COMMONSCREEN_BRANCHDATE = "COMMON/CommonScreen/BranchDate";
    public static final String COMMONSCREEN_SAVE = "COMMON/CommonScreen/Save";
    public static final String COMMONSCREEN_REMARKSOK = "COMMON/CommonScreen/RemarksOk";
    public static final String COMMONSCREEN_ACCEPTANDOVERRIDE = "COMMON/CommonScreen/AcceptAndOverride";
    public static final String COMMONSCREEN_POPUPMESSAGE = "COMMON/CommonScreen/PopupMessage";
    public static final String COMMONSCREEN_EXIT = "COMMON/CommonScreen/Exit";
    public static final String COMMONSCREEN_EXITCUSTOMER = "COMMON/CommonScreen/ExitCustomer";
    public static final String COMMONSCREEN_EXITSIGNATURE = "COMMON/CommonScreen/ExitSignature";
    public static final String COMMONSCREEN_EXITSIGNATUREAFTERCLOSE = "COMMON/CommonScreen/ExitSignatureAfterClose";
    public static final String COMMONSCREEN_EXITVIEWCHANGES = "COMMON/CommonScreen/ExitViewChanges";
    public static final String COMMONSCREEN_CANCEL = "COMMON/CommonScreen/Cancel";
    public static final String COMMONSCREEN_USER = "COMMON/CommonScreen/User";
    public static final String COMMONSCREEN_SIGNOFF = "COMMON/CommonScreen/Signoff";
    public static final String COMMONSCREEN_ENTERQUERY = "COMMON/CommonScreen/EnterQuery";
    public static final String COMMONSCREEN_EXECUTEQUERY = "COMMON/CommonScreen/ExecuteQuery";
    public static final String COMMONSCREEN_AUTHORIZE = "COMMON/CommonScreen/Authorize";
    public static final String COMMONSCREEN_AUTHACCEPT = "COMMON/CommonScreen/AuthAccept";
    public static final String COMMONSCREEN_AUTHSTATUS = "COMMON/CommonScreen/AuthStatus";
    public static final String COMMONSCREEN_UNLOCK = "COMMON/CommonScreen/Unlock";
    public static final String COMMONSCREEN_CONFIRM = "COMMON/CommonScreen/Confirm";
    public static final String COMMONSCREEN_HOLD = "COMMON/CommonScreen/Hold";
    public static final String COMMONSCREEN_DELETE = "COMMON/CommonScreen/Delete";
    public static final String COMMONSCREEN_INTERESTOK = "COMMON/CommonScreen/InterestOK";
    public static final String COMMONSCREEN_POPULATE = "COMMON/CommonScreen/Populate";
    public static final String COMMONSCREEN_INTEREST = "COMMON/CommonScreen/Interest";
    public static final String COMMONSCREEN_ADDROW = "COMMON/CommonScreen/AddRow";
    public static final String COMMONSCREEN_PRODUCTCODE = "COMMON/CommonScreen/ProductCode";
    public static final String COMMONSCREEN_OPEN = "COMMON/CommonScreen/Open";
    public static final String COMMONSCREEN_UDEDEFAULT = "COMMON/CommonScreen/UDEDefault";
    public static final String COMMONSCREEN_EFFECTIVEDATEADDBUTTON = "COMMON/CommonScreen/EffectiveDateAddButton";
    public static final String COMMONSCREEN_COMPUTE = "COMMON/CommonScreen/Compute";
    public static final String COMMONSCREEN_OKCOMPUTE = "COMMON/CommonScreen/OKCompute";
    public static final String COMMONSCREEN_MOVEINTERRESTTOUNCLAIMED = "COMMON/CommonScreen/MoveInterrestToUnclaimed";
    public static final String COMMONSCREEN_MOVEPRINCIPALTOUNCLAIMED = "COMMON/CommonScreen/MovePrincipalToUnclaimed";
    public static final String COMMONSCREEN_PAYINADDROW = "COMMON/CommonScreen/PayinAddRow";
    public static final String COMMONSCREEN_EXPAND = "COMMON/CommonScreen/Expand";
    public static final String COMMONSCREEN_PRINCIPAL_INTEREST = "COMMON/CommonScreen/Principal+Interest";
    public static final String COMMONSCREEN_ROLLOVERDETAILS = "COMMON/CommonScreen/RolloverDetails";
    public static final String COMMONSCREEN_INDEPENDENTTENOR = "COMMON/CommonScreen/IndependentTenor";
    public static final String COMMONSCREEN_ROLLOVEROK = "COMMON/CommonScreen/RolloverOK";
    public static final String COMMONSCREEN_POOLCODESEARCH = "COMMON/CommonScreen/PoolcodeSearch";
    public static final String COMMONSCREEN_DFLT = "COMMON/CommonScreen/DFLT";
    public static final String COMMONSCREEN_OKMIS = "COMMON/CommonScreen/OKMIS";
    public static final String COMMONSCREEN_PAYINOFFSETACCOUNT_SELECT = "COMMON/CommonScreen/PayinOffsetAccount_Select";
    public static final String COMMONSCREEN_OFFSETSEARCH = "COMMON/CommonScreen/Offsetsearch";
    public static final String COMMONSCREEN_TERMDEPOSITPAYINOPTION = "COMMON/CommonScreen/TermDepositPayinOption";
    public static final String COMMONSCREEN_DEPOSITTENORYEARS = "COMMON/CommonScreen/DepositTenorYears";
    public static final String COMMONSCREEN_CLOSEONMATURITY = "COMMON/CommonScreen/CloseOnMaturity";
    public static final String COMMONSCREEN_AUTOROLLOVER = "COMMON/CommonScreen/AutoRollover";
    public static final String COMMONSCREEN_PRODUCTCODELOV = "COMMON/CommonScreen/ProductCodeLOV";
    public static final String COMMONSCREEN_CITD = "COMMON/CommonScreen/CITD";
    public static final String COMMONSCREEN_PAYOUTADDROW = "COMMON/CommonScreen/PayoutAddrow";
    public static final String COMMONSCREEN_ROLLTYPEPRINCIPAL = "COMMON/CommonScreen/RollTypePrincipal";
    public static final String COMMONSCREEN_ROLLTYPEINTEREST = "COMMON/CommonScreen/RollTypeInterest";
    public static final String COMMONSCREEN_TDCERTIFICATELOVSEARCH = "COMMON/CommonScreen/TDCertificateLOVSearch";
    public static final String COMMONSCREEN_GENRATE = "COMMON/CommonScreen/Genrate";
    public static final String COMMONSCREEN_PRINT = "COMMON/CommonScreen/Print";
    public static final String COMMONSCREEN_TDCERTIFICATE_SELECT = "COMMON/CommonScreen/TDCertificate_Select";
    public static final String COMMONSCREEN_TD_EXIT = "COMMON/CommonScreen/TD_Exit";
    public static final String COMMONSCREEN_ADDITIONAL = "COMMON/CommonScreen/Additional";
    public static final String COMMONSCREEN_COMPOSITETAB = "COMMON/CommonScreen/CompositeTab";
    public static final String COMMONSCREEN_CLOSE = "COMMON/CommonScreen/Close";
    public static final String COMMONSCREEN_CLOSEROK = "COMMON/CommonScreen/CloserOk";
    public static final String COMMONSCREEN_SEARCH = "COMMON/CommonScreen/Search";
    public static final String COMMONSCREEN_CLOSUREFETCH = "COMMON/CommonScreen/ClosureFetch";
    public static final String COMMONSCREEN_CLOSURESELECTDATA = "COMMON/CommonScreen/ClosureSelectdata";
    public static final String COMMONSCREEN_NOCREDIT = "COMMON/CommonScreen/NoCredit";
    public static final String COMMONSCREEN_INVALIDOK = "COMMON/CommonScreen/InvalidOk";
    public static final String COMMONSCREEN_INCORRECTOK = "COMMON/CommonScreen/IncorrectOk";
    public static final String COMMONSCREEN_BATCHOK = "COMMON/CommonScreen/Batchok";
    public static final String COMMONSCREEN_JOURNALMIS = "COMMON/CommonScreen/JournalMIS";
    public static final String COMMONSCREEN_JOURNALMISOK = "COMMON/CommonScreen/JournalMISOk";
    public static final String COMMONSCREEN_TOTALCREDITAMOUNT = "COMMON/CommonScreen/TotalCreditAmount";
    public static final String COMMONSCREEN_CREDIT = "COMMON/CommonScreen/Credit";
    public static final String COMMONSCREEN_INTERESTTAB = "COMMON/CommonScreen/InterestTab";
    public static final String COMMONSCREEN_ADDPRODUCTROW = "COMMON/CommonScreen/AddProductrow";
    public static final String COMMONSCREEN_ADDEFFECTIVEROW = "COMMON/CommonScreen/AddEffectiverow";
    public static final String COMMONSCREEN_STATEMENTEXIT = "COMMON/CommonScreen/StatementExit";
    public static final String COMMONSCREEN_JOURNALAUTHORIZE = "COMMON/CommonScreen/JournalAuthorize";
    public static final String COMMONSCREEN_SUMMARY = "COMMON/CommonScreen/Summary";
    public static final String COMMONSCREEN_P = "COMMON/CommonScreen/P";
    public static final String COMMONSCREEN_POPULATECUSTOMERNO = "COMMON/CommonScreen/PopulateCustomerNo";
    public static final String COMMONSCREEN_AUTOPOPULATE = "COMMON/CommonScreen/AutoPopulate";
    public static final String COMMONSCREEN_ADDICON = "COMMON/CommonScreen/addIcon";
    public static final String COMMONSCREEN_ENRICH = "COMMON/CommonScreen/Enrich";
    public static final String COMMONSCREEN_FINALAUTHORIZE = "COMMON/CommonScreen/FinalAuthorize";
    public static final String COMMONSCREEN_FINALAUTHSTATUS = "COMMON/CommonScreen/FinalAuthStatus";
    public static final String COMMONSCREEN_CLOSEAUTHSTATUS = "COMMON/CommonScreen/closeAuthStatus";
    public static final String COMMONSCREEN_EVENTS = "COMMON/CommonScreen/Events";
    public static final String COMMONSCREEN_ACCOUNTINGENTRY1 = "COMMON/CommonScreen/AccountingEntry1";
    public static final String COMMONSCREEN_ACCOUNTINGENTRY2 = "COMMON/CommonScreen/AccountingEntry2";
    public static final String COMMONSCREEN_ACCOUNTINGENTRIES = "COMMON/CommonScreen/AccountingEntries";
    public static final String COMMONSCREEN_EVENTID = "COMMON/CommonScreen/EventID";
    public static final String COMMONSCREEN_SUSPENDEXECUTION = "COMMON/CommonScreen/SuspendExecution";
    public static final String COMMONSCREEN_LINKEDENTITY = "COMMON/CommonScreen/LinkedEntity";
    public static final String COMMONSCREEN_ADDICONLINKEDENTITY = "COMMON/CommonScreen/addIconLinkedEntity";
    public static final String COMMONSCREEN_REMOVEICONLINKEDENTITY = "COMMON/CommonScreen/removeIconLinkedEntity";
    public static final String COMMONSCREEN_LINKEDENTITIESOK = "COMMON/CommonScreen/LinkedEntitiesOk";
    public static final String COMMONSCREEN_CHECKKDELETEROW1 = "COMMON/CommonScreen/CheckkDeleteRow1";
    public static final String COMMONSCREEN_CHECKKDELETEROW2 = "COMMON/CommonScreen/CheckkDeleteRow2";
    public static final String COMMONSCREEN_CHANGELOG = "COMMON/CommonScreen/ChangeLog";
    public static final String COMMONSCREEN_VIEWCHANGES = "COMMON/CommonScreen/ViewChanges";
    public static final String COMMONSCREEN_CUSTOMER_POPULATE = "COMMON/CommonScreen/Customer_Populate";
    public static final String COMMONSCREEN_SWIFT_SELECT = "COMMON/CommonScreen/SWIFT_Select";
    public static final String COMMONSCREEN_CUSTOMER_MIS = "COMMON/CommonScreen/Customer_MIS";
    public static final String COMMONSCREEN_FATCA = "COMMON/CommonScreen/FATCA";
    public static final String COMMONSCREEN_ACTIVENFFE = "COMMON/CommonScreen/ActiveNFFE";
    public static final String COMMONSCREEN_ACCOUNTCLASSIFICATION_US = "COMMON/CommonScreen/AccountClassification_US";
    public static final String COMMONSCREEN_FATCA_OK = "COMMON/CommonScreen/FATCA_OK";
    public static final String COMMONSCREEN_LINKEDENTITYCHANGELOG = "COMMON/CommonScreen/LinkedEntityChangeLog";
    public static final String COMMONSCREEN_LASTPAGE = "COMMON/CommonScreen/LastPage";
    public static final String COMMONSCREEN_CUSTOMERAUTHSTATUS = "COMMON/CommonScreen/CustomerAuthStatus";
    public static final String COMMONSCREEN_FROZEN = "COMMON/CommonScreen/Frozen";
    public static final String COMMONSCREEN_ADDICONSIGNATURE = "COMMON/CommonScreen/addIconSignature";
    public static final String COMMONSCREEN_SIGNATUREIMAGE = "COMMON/CommonScreen/SignatureImage";
    public static final String COMMONSCREEN_CHOOSEFILE = "COMMON/CommonScreen/ChooseFile";
    public static final String COMMONSCREEN_UPLOAD = "COMMON/CommonScreen/Upload";
    public static final String COMMONSCREEN_SIGNATUREOK = "COMMON/CommonScreen/SignatureOK";
    public static final String COMMONSCREEN_CUSTOMERTYPE = "COMMON/CommonScreen/CustomerType";
    public static final String COMMONSCREEN_BANKCUSTOMERTYPE = "COMMON/CommonScreen/BankCustomerType";
    public static final String COMMONSCREEN_CUSTOMEROK = "COMMON/CommonScreen/CustomerOK";
    public static final String COMMONSCREEN_AUXILIARY = "COMMON/CommonScreen/Auxiliary";
    public static final String COMMONSCREEN_CRSCUSTOMERTYPE = "COMMON/CommonScreen/CRSCustomerType";
    public static final String COMMONSCREEN_RELATEDPARTIES = "COMMON/CommonScreen/RelatedParties";
    public static final String COMMONSCREEN_ADDICONRELATEDPARTIES = "COMMON/CommonScreen/AddIconRelatedParties";
    public static final String COMMONSCREEN_IMAGE = "COMMON/CommonScreen/Image";
    public static final String COMMONSCREEN_IMAGELINK = "COMMON/CommonScreen/ImageLink";
    public static final String COMMONSCREEN_EXITLINKEDENTITIES = "COMMON/CommonScreen/ExitLinkedEntities";
    public static final String COMMONSCREEN_MIS = "COMMON/CommonScreen/MIS";
    public static final String COMMONSCREEN_OKPOPUP = "COMMON/CommonScreen/OkPopup";
    public static final String COMMONSCREEN_ACCEPT = "COMMON/CommonScreen/Accept";
    public static final String COMMONSCREEN_NODEBIT = "COMMON/CommonScreen/NoDebit";
    public static final String COMMONSCREEN_NOCREDIT1 = "COMMON/CommonScreen/NoCredit1";
    public static final String COMMONSCREEN_UNAUTHORIZEDENTRY = "COMMON/CommonScreen/UnauthorizedEntry";
    public static final String COMMONSCREEN_DETAILS = "COMMON/CommonScreen/details";
    public static final String COMMONSCREEN_MEDIAFETCH = "COMMON/CommonScreen/MediaFetch";
    public static final String COMMONSCREEN_MEDIASEARCH = "COMMON/CommonScreen/MediaSearch";
    public static final String COMMONSCREEN_MEDIALIST = "COMMON/CommonScreen/MediaList";
    public static final String COMMONSCREEN_UPARROW = "COMMON/CommonScreen/UPArrow";
    public static final String COMMONSCREEN_STATEMENT = "COMMON/CommonScreen/Statement";
    public static final String COMMONSCREEN_STATEMENTOK = "COMMON/CommonScreen/StatementOk";
    public static final String COMMONSCREEN_STATEMENTSUMMARY = "COMMON/CommonScreen/StatementSummary";
    public static final String COMMONSCREEN_STATEMENTDETAILED = "COMMON/CommonScreen/StatementDetailed";
    public static final String COMMONSCREEN_RADIOCHECKBTN = "COMMON/CommonScreen/RadioCheckBtn";
    public static final String COMMONSCREEN_COPY = "COMMON/CommonScreen/Copy";
    public static final String COMMONSCREEN_REVERSE = "COMMON/CommonScreen/Reverse";
    public static final String COMMONSCREEN_DEFAULT = "COMMON/CommonScreen/Default";
    public static final String COMMONSCREEN_OVERRIDETABLE = "COMMON/CommonScreen/OverrideTable";
    public static final String COMMONSCREEN_OVERRIDECHECKBOX = "COMMON/CommonScreen/OverrideCheckbox";
    public static final String COMMONSCREEN_INFOOK1 = "COMMON/CommonScreen/InfoOk1";
    public static final String COMMONSCREEN_OBTFPMBRANCHDATE = "COMMON/CommonScreen/OBTFPMBranchDate";
    public static final String COMMONSCREEN_OBTFPMWINDOWTITLE = "COMMON/CommonScreen/OBTFPMWindowTitle";
    public static final String COMMONSCREEN_OBTFPMPOPUPMESSAGE = "COMMON/CommonScreen/OBTFPMPopupMessage";

    // ===== LoginScreen =====
    public static final String LOGINSCREEN_USERNAME = "COMMON/LoginScreen/UserName";
    public static final String LOGINSCREEN_PASSWORD = "COMMON/LoginScreen/Password";
    public static final String LOGINSCREEN_LOGIN = "COMMON/LoginScreen/Login";
    public static final String LOGINSCREEN_LOGINOK = "COMMON/LoginScreen/LoginOk";
    public static final String LOGINSCREEN_REENTERPASSWORD = "COMMON/LoginScreen/ReEnterPassword";
    public static final String LOGINSCREEN_REENTEROK = "COMMON/LoginScreen/ReEnterOK";
    public static final String LOGINSCREEN_LOGOUT = "COMMON/LoginScreen/Logout";

    // ===== OBTFPMLoginScreen =====
    public static final String OBTFPMLOGINSCREEN_OBTFPMUSERNAME = "COMMON/OBTFPMLoginScreen/OBTFPMUserName";
    public static final String OBTFPMLOGINSCREEN_OBTFPMPASSWORD = "COMMON/OBTFPMLoginScreen/OBTFPMPassword";
    public static final String OBTFPMLOGINSCREEN_OBTFPSIGNIN = "COMMON/OBTFPMLoginScreen/OBTFPSignIn";
    public static final String OBTFPMLOGINSCREEN_OBTFPMDASHBOARD = "COMMON/OBTFPMLoginScreen/OBTFPMDashboard";
    public static final String OBTFPMLOGINSCREEN_OBTFPMPROCEED = "COMMON/OBTFPMLoginScreen/OBTFPMProceed";

    // ===== OBTFPMLogoutScreen =====
    public static final String OBTFPMLOGOUTSCREEN_OBTFPUSER = "COMMON/OBTFPMLogoutScreen/OBTFPUser";
    public static final String OBTFPMLOGOUTSCREEN_OBTFPMLOGOUT = "COMMON/OBTFPMLogoutScreen/OBTFPMLogout";

    // ===== OBTFLoginScreen =====
    public static final String OBTFLOGINSCREEN_INFOOK = "COMMON/OBTFLoginScreen/InfoOk";
    public static final String OBTFLOGINSCREEN_USERNAME = "COMMON/OBTFLoginScreen/UserName";
    public static final String OBTFLOGINSCREEN_PASSWORD = "COMMON/OBTFLoginScreen/Password";
    public static final String OBTFLOGINSCREEN_LOGIN = "COMMON/OBTFLoginScreen/Login";
    public static final String OBTFLOGINSCREEN_LOGINOK = "COMMON/OBTFLoginScreen/LoginOk";
    public static final String OBTFLOGINSCREEN_REENTERPASSWORD = "COMMON/OBTFLoginScreen/ReEnterPassword";
    public static final String OBTFLOGINSCREEN_REENTEROK = "COMMON/OBTFLoginScreen/ReEnterOK";
    public static final String OBTFLOGINSCREEN_LOGOUT = "COMMON/OBTFLoginScreen/Logout";


    // ===== FastPath =====
    public static final String FASTPATH_FASTPATH = "COMMON/FastPath/Fastpath";
    public static final String FASTPATH_GO = "COMMON/FastPath/Go";

    // ===== SwitchBranch =====
    public static final String SWITCHBRANCH_BRANCHMENU = "COMMON/SwitchBranch/BranchMenu";
    public static final String SWITCHBRANCH_HOMEBRANCH = "COMMON/SwitchBranch/HomeBranch";
    public static final String SWITCHBRANCH_SELECTBRANCH = "COMMON/SwitchBranch/SelectBranch";
    public static final String SWITCHBRANCH_BRANCHCODE = "COMMON/SwitchBranch/BranchCode";
    public static final String SWITCHBRANCH_FETCH = "COMMON/SwitchBranch/Fetch";
    public static final String SWITCHBRANCH_SELECTDATA = "COMMON/SwitchBranch/SelectData";

    // ===== SwitchEntity =====
    public static final String SWITCHENTITY_ENTITYMENU = "COMMON/SwitchEntity/EntityMenu";
    public static final String SWITCHENTITY_HOMEBRANCH = "COMMON/SwitchEntity/HomeBranch";
    public static final String SWITCHENTITY_SELECTBRANCH = "COMMON/SwitchEntity/SelectBranch";
    public static final String SWITCHENTITY_ENTITYCODE = "COMMON/SwitchEntity/EntityCode";
    public static final String SWITCHENTITY_FETCH = "COMMON/SwitchEntity/Fetch";
    public static final String SWITCHENTITY_SELECTDATA = "COMMON/SwitchEntity/SelectData";

    // ===== fircologout =====
    public static final String FIRCOLOGOUT_LOGOUT = "COMMON/fircologout/logout";

    public static final String OBPAYLOGINSCREEN_INFOOK = "COMMON/OBPAYLoginScreen/InfoOk";
    public static final String OBPAYLOGINSCREEN_USERNAME = "COMMON/OBPAYLoginScreen/UserName";
    public static final String OBPAYLOGINSCREEN_PASSWORD = "COMMON/OBPAYLoginScreen/Password";
    public static final String OBPAYLOGINSCREEN_LOGIN = "COMMON/OBPAYLoginScreen/Login";
    public static final String OBPAYLOGINSCREEN_LOGINOK = "COMMON/OBPAYLoginScreen/LoginOk";
    public static final String OBPAYLOGINSCREEN_REENTERPASSWORD = "COMMON/OBPAYLoginScreen/ReEnterPassword";
    public static final String OBPAYLOGINSCREEN_REENTEROK = "COMMON/OBPAYLoginScreen/ReEnterOK";
    public static final String OBPAYLOGINSCREEN_LOGOUT = "COMMON/OBPAYLoginScreen/Logout";

    // ===== OBPAYLogOut =====
    public static final String OBPAYLOGOUT_USER = "COMMON/OBPAYLogOut/User";
    public static final String OBPAYLOGOUT_SIGNOFF = "COMMON/OBPAYLogOut/Signoff";

}
