package com.mashreq.automation.tcoe.driver;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.ios.options.XCUITestOptions;
import org.openqa.selenium.remote.http.ClientConfig;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/**
 * A minimal Appium (W3C) + BrowserStack REST server on 127.0.0.1, so the real Selenium / Appium HTTP code runs without a
 * device or the cloud. Adapted from Framework_Fixed's regression tests (2026-10-06).
 */
final class FakeAppium implements AutoCloseable {

    private static final String ELEMENT_KEY = "element-6066-11e4-a52e-4f735466cecf";
    /** 1x1 PNG. */
    private static final String PNG =
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==";

    private final HttpServer server;
    private final ExecutorService workers = Executors.newCachedThreadPool();

    final AtomicInteger screenshots = new AtomicInteger();
    final AtomicInteger deletes = new AtomicInteger();
    final AtomicInteger statusCalls = new AtomicInteger();
    final AtomicInteger restStatusCalls = new AtomicInteger();
    final AtomicReference<String> resultBody = new AtomicReference<>();
    final AtomicReference<String> authorization = new AtomicReference<>();
    final AtomicReference<String> sessionPath = new AtomicReference<>();
    /** Element commands in order: click, clear, value, text, attribute:<name> ... */
    final List<String> elementCalls = new CopyOnWriteArrayList<>();
    final Map<String, String> attributes = new ConcurrentHashMap<>();

    volatile String platformName = "Android";
    volatile boolean elementPresent;
    volatile String elementText = "";
    volatile boolean failStatus;
    volatile boolean failRest;
    volatile boolean failClear;
    volatile boolean truncateScreenshot;
    volatile boolean dropElements;
    /** Where the element is (its y). */
    volatile int elementY;
    /** What a click does: "stay" (a tick box), "gone" (the next screen opens), "jumpOnce" (the page is redrawn at the top). */
    volatile String afterClick = "stay";
    final AtomicInteger clicks = new AtomicInteger();
    /** Bodies of POST .../timeouts (implicit waits set by the framework). */
    final List<String> timeoutCalls = new CopyOnWriteArrayList<>();

    FakeAppium() throws IOException {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.setExecutor(workers);
        server.createContext("/", this::handle);
        server.start();
    }

    private void handle(HttpExchange exchange) throws IOException {
        String path = exchange.getRequestURI().getPath();
        String method = exchange.getRequestMethod();
        String requestBody = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        String auth = exchange.getRequestHeaders().getFirst("Authorization");
        if (auth != null) {
            authorization.set(auth);
        }
        String body = "{\"value\":null}";
        int status = 200;

        if ("PUT".equals(method) && path.startsWith("/app-automate/sessions/")) {
            restStatusCalls.incrementAndGet();
            resultBody.set(requestBody);
            status = failRest ? 503 : 200;
        } else if ("POST".equals(method) && "/session".equals(path)) {
            sessionPath.set(exchange.getRequestURI().toString());
            body = "{\"value\":{\"sessionId\":\"offline-session\",\"capabilities\":{\"platformName\":\"" + platformName + "\"}}}";
        } else if (path.endsWith("/elements")) {
            if (dropElements) {
                exchange.close(); // connection closed without an answer
                return;
            }
            body = elementPresent ? "{\"value\":[{\"" + ELEMENT_KEY + "\":\"el1\"}]}" : "{\"value\":[]}";
        } else if (path.endsWith("/element")) {
            if (elementPresent) {
                body = "{\"value\":{\"" + ELEMENT_KEY + "\":\"el1\"}}";
            } else {
                status = 404;
                body = "{\"value\":{\"error\":\"no such element\",\"message\":\"missing element\",\"stacktrace\":\"\"}}";
            }
        } else if (path.contains("/element/el1/")) {
            String command = path.substring(path.indexOf("/element/el1/") + "/element/el1/".length());
            if (command.startsWith("attribute/")) {
                String name = command.substring("attribute/".length());
                elementCalls.add("attribute:" + name);
                String value = attributes.get(name);
                body = "{\"value\":" + (value == null ? "null" : "\"" + value + "\"") + "}";
            } else {
                elementCalls.add(command);
                switch (command) {
                    case "text": body = "{\"value\":\"" + elementText + "\"}"; break;
                    case "displayed": case "enabled": body = "{\"value\":true}"; break;
                    case "selected": body = "{\"value\":false}"; break;
                    case "rect": body = "{\"value\":{\"x\":0,\"y\":" + elementY + ",\"width\":10,\"height\":10}}"; break;
                    case "click":
                        int n = clicks.incrementAndGet();
                        if ("gone".equals(afterClick)) {
                            elementPresent = false;
                        } else if ("jumpOnce".equals(afterClick) && n == 1) {
                            elementY += 900;
                        }
                        break;
                    case "clear":
                        if (failClear) {
                            status = 500;
                            body = "{\"value\":{\"error\":\"unknown error\",\"message\":\"clear failed\",\"stacktrace\":\"\"}}";
                        }
                        break;
                    default: break;
                }
            }
        } else if ("POST".equals(method) && path.endsWith("/timeouts")) {
            timeoutCalls.add(requestBody);
        } else if (path.endsWith("/window/rect")) {
            body = "{\"value\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1}}";
        } else if (path.endsWith("/screenshot")) {
            screenshots.incrementAndGet();
            if (truncateScreenshot) {
                exchange.sendResponseHeaders(200, 1000);
                exchange.getResponseBody().write("broken".getBytes(StandardCharsets.UTF_8));
                exchange.close();
                return;
            }
            body = "{\"value\":\"" + PNG + "\"}";
        } else if (path.endsWith("/source")) {
            body = "{\"value\":\"<hierarchy/>\"}";
        } else if (path.endsWith("/execute/sync")) {
            if (requestBody.contains("browserstack_executor")) {
                statusCalls.incrementAndGet();
                resultBody.set(requestBody);
                if (failStatus) {
                    status = 404;
                    body = "{\"value\":{\"error\":\"invalid session id\",\"message\":\"session died\",\"stacktrace\":\"\"}}";
                }
            } else {
                body = "{\"value\":true}"; // Selenium's isDisplayed atom
            }
        } else if ("DELETE".equals(method)) {
            deletes.incrementAndGet();
        }

        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        exchange.getResponseBody().write(bytes);
        exchange.close();
    }

    URL url() throws Exception {
        return new URL("http://127.0.0.1:" + server.getAddress().getPort());
    }

    /** The REST status API of this fake server, with credentials (header) like the real one. */
    ClientConfig apiConfig() throws Exception {
        return MobileDriverManager.withCredentials(ClientConfig.defaultConfig().baseUrl(url())
                .connectionTimeout(Duration.ofSeconds(2)).readTimeout(Duration.ofSeconds(2)), "offline-user", "offline-key");
    }

    /** A driver made the way the framework makes them (logged subclass, credentials in a header). */
    AppiumDriver driver() throws Exception {
        ClientConfig config = MobileDriverManager.withCredentials(ClientConfig.defaultConfig().baseUrl(url())
                .connectionTimeout(Duration.ofSeconds(2)).readTimeout(Duration.ofSeconds(2)), "offline-user", "offline-password");
        return "iOS".equalsIgnoreCase(platformName)
                ? MobileDriverManager.loggedIosDriver(config, new XCUITestOptions())
                : MobileDriverManager.loggedAndroidDriver(config, new UiAutomator2Options());
    }

    @Override
    public void close() {
        MobileDriverManager.quitDriver(); // while the server still answers (this thread's session, if any)
        server.stop(0);
        workers.shutdownNow();
    }
}
