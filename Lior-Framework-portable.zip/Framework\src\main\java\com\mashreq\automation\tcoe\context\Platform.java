package com.mashreq.automation.tcoe.context;

import java.util.Collection;

/**
 * What a scenario automates. Decided once per scenario from its tags (see ApplicationHooks):
 * {@code @Mobile} = MOBILE, {@code @API} = API, anything else = WEB.
 * Web and mobile never share an object repository folder: each platform reads only its own.
 */
public enum Platform {
    WEB("Web"),
    MOBILE("Mobile"),
    API("API");

    /** Folder name under src/main/resources/objectrepo. */
    private final String folder;

    Platform(String folder) {
        this.folder = folder;
    }

    public String folder() {
        return folder;
    }

    public static Platform fromTags(Collection<String> tags) {
        if (tags != null && tags.contains("@Mobile")) {
            return MOBILE;
        }
        if (tags != null && tags.contains("@API")) {
            return API;
        }
        return WEB;
    }

    /** The platform of the scenario running on this thread, or null outside a scenario (tools, generators). */
    public static Platform current() {
        ScenarioContext ctx = ScenarioContext.get();
        return ctx == null ? null : ctx.getPlatform();
    }
}
