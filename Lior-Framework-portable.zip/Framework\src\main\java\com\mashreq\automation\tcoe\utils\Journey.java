package com.mashreq.automation.tcoe.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.automation.tcoe.constants.FrameworkConstants;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A journey: several scenarios that together are one business case, for example a maker creates a transfer on the mobile app,
 * two checkers approve it on the web, and the maker sees it approved on the mobile app. Each part is a normal scenario on ONE
 * platform (web and mobile never mix inside a scenario); the parts are tagged
 * <pre>
 *   &#64;Journey &#64;Journey_TxnApproval      (feature)
 *   &#64;JourneyPart_1 ... &#64;JourneyPart_4  (scenario)
 * </pre>
 * and run in that order: mvn test -Pjourney -Dcucumber.tags="@Journey_TxnApproval".
 * <ul>
 * <li>A part starts only after the part before it PASSED; when that part failed or was skipped, this part is skipped too
 *     (it needs what the earlier part made).</li>
 * <li>Values are handed from part to part: "user keeps the text of ... as "TxnRef" for the journey" reads the reference number a
 *     screen shows; later parts use it with ${journey:TxnRef} in their test data or in a locator. "user keeps the typed value of
 *     "Remarks" as "Remarks" for the journey" keeps what a part typed (exactly, also a ${random:6}).</li>
 * <li>The values are also written to testdata/.runtime/journeys/&lt;journey&gt;.json, so a rerun of only a failed later part still
 *     has the reference number of the run before.</li>
 * </ul>
 */
public final class Journey {

    public static final String TAG = "@Journey_";
    public static final String PART_TAG = "@JourneyPart_";

    /** One part of one journey, from the scenario's tags. */
    public static final class Part {
        public final String journey;
        public final int number;

        Part(String journey, int number) {
            this.journey = journey;
            this.number = number;
        }

        @Override
        public String toString() {
            return "part " + number + " of journey " + journey;
        }
    }

    private static final class State {
        /** part number -> PASSED / FAILED / SKIPPED / RUNNING */
        final Map<Integer, String> outcome = new ConcurrentHashMap<>();
        final Map<Integer, String> scenarioName = new ConcurrentHashMap<>();
        final Map<Integer, CountDownLatch> finished = new ConcurrentHashMap<>();
        /** values kept with "keeps the text ... for the journey" */
        final Map<String, String> kept = new ConcurrentHashMap<>();
        /** values the parts read from their test data (typed, chosen ...): field name (lower case) -> value */
        final Map<String, String> used = new ConcurrentHashMap<>();

        CountDownLatch latch(int part) {
            return finished.computeIfAbsent(part, k -> new CountDownLatch(1));
        }
    }

    private static final Map<String, State> JOURNEYS = new ConcurrentHashMap<>();
    private static final ThreadLocal<Part> CURRENT = new ThreadLocal<>();
    private static final ObjectMapper JSON = new ObjectMapper();
    private static final Pattern WORD_CHARS = Pattern.compile("[A-Za-z0-9][A-Za-z0-9/_.\\-]*[A-Za-z0-9]|[A-Za-z0-9]");
    private static final Pattern REFERENCE_WORD = Pattern.compile("(?i)(reference|ref|transaction|txn|trx|request|order|id|number|no)\\b");

    private Journey() {
    }

    /** The journey part a scenario with these tags is, or null when it is not part of a journey. */
    public static Part of(Collection<String> tags) {
        if (tags == null) {
            return null;
        }
        String name = null;
        int number = 0;
        for (String t : tags) {
            if (t.startsWith(PART_TAG)) {
                try {
                    number = Integer.parseInt(t.substring(PART_TAG.length()));
                } catch (NumberFormatException ignored) {
                    // not a part number
                }
            } else if (t.startsWith(TAG)) {
                name = t.substring(TAG.length());
            }
        }
        return name == null || name.isEmpty() || number <= 0 ? null : new Part(name, number);
    }

    /** The journey part running on this thread, or null. */
    public static Part current() {
        return CURRENT.get();
    }

    // ------------------------------------------------------------------ order of the parts

    /**
     * Called before the scenario starts its browser / app. Waits until the part before it has finished (parallel runs) and
     * returns why this part must be SKIPPED, or null to run it.
     */
    public static String beforePart(Collection<String> tags, String scenarioName) {
        Part p = of(tags);
        CURRENT.remove();
        if (p == null) {
            return null;
        }
        State st = JOURNEYS.computeIfAbsent(p.journey, k -> new State());
        st.latch(p.number);
        st.outcome.put(p.number, "RUNNING");
        st.scenarioName.put(p.number, scenarioName == null ? "" : scenarioName);
        CURRENT.set(p);
        if (p.number == 1) {
            synchronized (st) {
                // a new run of the journey: nothing kept from an earlier run in this JVM
                st.kept.clear();
                st.used.clear();
            }
            LogUtils.info("Journey " + p.journey + ": part 1 starts.");
            return null;
        }
        int before = p.number - 1;
        if (!st.outcome.containsKey(before)) {
            // parallel run: the part before may be starting on another thread right now
            long grace = Boolean.parseBoolean(System.getProperty("parallel", "false")) ? 15 : 0;
            waitFor(st, before, grace, TimeUnit.SECONDS, true);
        }
        String o = st.outcome.get(before);
        if (o == null) {
            LogUtils.info("Journey " + p.journey + ": part " + before + " is not in this run; part " + p.number
                    + " uses the values kept by the last run (" + describeFile(p.journey) + ").");
            return null;
        }
        if ("RUNNING".equals(o)) {
            long minutes = Long.getLong("JOURNEY_WAIT_MINUTES", 30L);
            LogUtils.info("Journey " + p.journey + ": part " + p.number + " waits for part " + before + " to finish (at most " + minutes + " minutes).");
            if (!waitFor(st, before, minutes, TimeUnit.MINUTES, false)) {
                return "Part " + before + " of journey " + p.journey + " did not finish within " + minutes + " minutes.";
            }
            o = st.outcome.get(before);
        }
        if (!"PASSED".equals(o)) {
            return "Skipped because part " + before + " of journey " + p.journey + " (" + st.scenarioName.getOrDefault(before, "")
                    + ") " + ("SKIPPED".equals(o) ? "was skipped" : "did not pass (" + o + ")")
                    + ". This part needs what that part made.";
        }
        LogUtils.info("Journey " + p.journey + ": part " + before + " passed, part " + p.number + " starts.");
        return null;
    }

    /** Called when the scenario has finished, with its status (PASSED, FAILED, SKIPPED ...). */
    public static void afterPart(Collection<String> tags, String status) {
        Part p = of(tags);
        CURRENT.remove();
        if (p == null) {
            return;
        }
        State st = JOURNEYS.computeIfAbsent(p.journey, k -> new State());
        String s = status == null ? "FAILED" : status.toUpperCase(Locale.ROOT);
        st.outcome.put(p.number, s);
        st.latch(p.number).countDown();
        LogUtils.info("Journey " + p.journey + ": part " + p.number + " " + s + ".");
    }

    private static boolean waitFor(State st, int part, long time, TimeUnit unit, boolean onlyUntilStarted) {
        long end = System.nanoTime() + unit.toNanos(time);
        while (System.nanoTime() < end) {
            String o = st.outcome.get(part);
            if (o != null && (onlyUntilStarted || !"RUNNING".equals(o))) {
                return true;
            }
            try {
                if (o != null && st.latch(part).await(Math.min(1000, Math.max(1, (end - System.nanoTime()) / 1_000_000)), TimeUnit.MILLISECONDS)) {
                    return true;
                }
                if (o == null) {
                    Thread.sleep(200); // poll interval: the part has not started yet
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
        String o = st.outcome.get(part);
        return o != null && (onlyUntilStarted || !"RUNNING".equals(o));
    }

    // ------------------------------------------------------------------ values handed from part to part

    /** Keeps a value for the later parts of the current journey (also written to testdata/.runtime/journeys). */
    public static void keep(String name, String value) {
        Part p = requireCurrent("keep '" + name + "' for the journey");
        State st = JOURNEYS.computeIfAbsent(p.journey, k -> new State());
        st.kept.put(key(name), value);
        save(p.journey, st);
        LogUtils.info("Journey " + p.journey + ": kept " + name + " = " + value + " (part " + p.number + ").");
    }

    /** A test data value the current journey part used (typed, chosen ...); later parts can use it by its field name. */
    static void used(String field, String value) {
        Part p = CURRENT.get();
        if (p == null || field == null || value == null || value.contains("${")) {
            return;
        }
        JOURNEYS.computeIfAbsent(p.journey, k -> new State()).used.put(key(field), value);
    }

    /**
     * What the current part typed into a field: the value its test data gave while it ran (so ${random:6} is the number really
     * typed), else the test data value now.
     */
    public static String typed(String field, java.util.function.Supplier<String> fromTestData) {
        Part p = requireCurrent("keep the typed value of '" + field + "'");
        State st = JOURNEYS.get(p.journey);
        String v = st == null ? null : st.used.get(key(field));
        return v != null ? v : fromTestData.get();
    }

    /** ${journey:Name}: a value an earlier part of the current journey kept. */
    public static String value(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalStateException("${journey:...} needs the name of the value, for example ${journey:TxnRef}.");
        }
        Part p = requireCurrent("use ${journey:" + name + "}");
        State st = JOURNEYS.get(p.journey);
        String k = key(name);
        String now = st == null ? null : st.kept.get(k);
        if (now != null) {
            return now;
        }
        if (st != null && st.outcome.containsKey(1)) {
            // the journey started in this run: an older value would be another transaction
            throw new IllegalStateException("Journey " + p.journey + ": no earlier part kept '" + name + "' in this run. Check the step"
                    + " \"user keeps ... as \\\"" + name + "\\\" for the journey\" of the part that shows or types it.");
        }
        Map<String, Object> saved = load(p.journey);
        Object v = saved.get("kept") instanceof Map ? ((Map<?, ?>) saved.get("kept")).get(k) : null;
        if (v != null) {
            LogUtils.info("Journey " + p.journey + ": " + name + " = " + v + " from the run of " + saved.get("savedAt")
                    + " (the part that makes it did not run now).");
            return String.valueOf(v);
        }
        throw new IllegalStateException("Journey " + p.journey + " has no value '" + name + "' yet: an earlier part keeps it. Run the whole journey: "
                + "mvn test -Pjourney -Dcucumber.tags=\"@Journey_" + p.journey + "\"");
    }

    private static Part requireCurrent(String what) {
        Part p = CURRENT.get();
        if (p == null) {
            throw new IllegalStateException("Cannot " + what + ": this scenario is not part of a journey (tags @Journey_<name> and @JourneyPart_<n>).");
        }
        return p;
    }

    private static String key(String name) {
        return name.trim().toLowerCase(Locale.ROOT);
    }

    // ------------------------------------------------------------------ the value inside a text

    /**
     * The part of a screen text a journey keeps. The rule comes from the test data (Lior writes it from the recording):
     * <pre>
     *   the whole text
     *   the word after 'Reference No:'     the first word after these words (also "the word after Reference No:")
     *   the first word
     *   (empty)                            worked out: a word with digits after Reference / Ref / Transaction / ID / No ...
     * </pre>
     */
    public static String pick(String text, String rule, String where) {
        String t = text == null ? "" : text.replace(' ', ' ').replaceAll("\\s+", " ").trim();
        if (t.isEmpty()) {
            throw new IllegalStateException(where + " shows no text, so there is nothing to keep for the journey.");
        }
        String r = rule == null ? "" : rule.trim();
        String lower = r.toLowerCase(Locale.ROOT);
        if (lower.equals("the whole text") || lower.equals("whole text")) {
            return t;
        }
        if (lower.equals("the first word") || lower.equals("first word")) {
            Matcher m = WORD_CHARS.matcher(t);
            if (m.find()) {
                return m.group();
            }
            throw new IllegalStateException(where + " shows \"" + t + "\": no word in it.");
        }
        Matcher after = Pattern.compile("(?i)^(?:the )?word after\\s+(.+)$").matcher(r);
        if (after.matches()) {
            String words = after.group(1).trim();
            if (words.length() > 1 && (words.charAt(0) == '\'' || words.charAt(0) == '"') && words.charAt(words.length() - 1) == words.charAt(0)) {
                words = words.substring(1, words.length() - 1);
            }
            String w = words.replaceAll("\\s+", " ").trim();
            int at = t.toLowerCase(Locale.ROOT).indexOf(w.toLowerCase(Locale.ROOT));
            if (at < 0) {
                throw new IllegalStateException(where + " shows \"" + t + "\", which does not have the words \"" + w + "\". Change the rule in the test data.");
            }
            Matcher m = WORD_CHARS.matcher(t);
            if (m.find(at + w.length())) {
                return m.group();
            }
            throw new IllegalStateException(where + " shows \"" + t + "\": nothing comes after \"" + w + "\".");
        }
        if (!r.isEmpty()) {
            throw new IllegalStateException("The journey rule \"" + r + "\" is not known. Use: the whole text / the word after 'Reference No:' / the first word.");
        }
        // worked out from the text alone
        if (t.matches("[A-Za-z0-9][A-Za-z0-9/_.\\-]*")) {
            return t;
        }
        Matcher k = REFERENCE_WORD.matcher(t);
        while (k.find()) {
            Matcher m = WORD_CHARS.matcher(t);
            int from = k.end();
            while (m.find(from)) {
                if (m.group().matches(".*\\d.*")) {
                    return m.group();
                }
                if (REFERENCE_WORD.matcher(m.group()).matches()) {
                    from = m.end(); // "Reference No: 123": skip "No"
                    continue;
                }
                break;
            }
        }
        String best = null;
        Matcher m = WORD_CHARS.matcher(t);
        while (m.find()) {
            String w = m.group();
            if (w.length() >= 4 && w.matches(".*\\d.*") && (best == null || w.length() > best.length())) {
                best = w;
            }
        }
        if (best != null) {
            return best;
        }
        throw new IllegalStateException(where + " shows \"" + t + "\": no reference number found. Put a rule in the test data, for example: the word after 'Reference No:'.");
    }

    // ------------------------------------------------------------------ kept for reruns

    private static File file(String journey) {
        return java.nio.file.Paths.get(FrameworkConstants.TEST_DATA_PATH, ".runtime", "journeys",
                journey.replaceAll("[^A-Za-z0-9_-]", "_") + ".json").toFile();
    }

    private static void save(String journey, State st) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("journey", journey);
        m.put("savedAt", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        m.put("kept", new LinkedHashMap<>(st.kept));
        File f = file(journey);
        synchronized (Journey.class) {
            try {
                File dir = f.getParentFile();
                if (!dir.isDirectory() && !dir.mkdirs()) {
                    throw new IOException("cannot create " + dir);
                }
                JSON.writerWithDefaultPrettyPrinter().writeValue(f, m);
            } catch (IOException e) {
                LogUtils.warn("Journey " + journey + ": could not save the kept values to " + f + " (only a rerun of a single part needs them): " + e.getMessage());
            }
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> load(String journey) {
        File f = file(journey);
        if (!f.isFile()) {
            return new LinkedHashMap<>();
        }
        synchronized (Journey.class) {
            try {
                return JSON.readValue(f, Map.class);
            } catch (IOException e) {
                LogUtils.warn("Journey " + journey + ": " + f + " cannot be read: " + e.getMessage());
                return new LinkedHashMap<>();
            }
        }
    }

    private static String describeFile(String journey) {
        Map<String, Object> m = load(journey);
        return m.isEmpty() ? "none kept yet" : "kept " + m.get("savedAt");
    }
}
