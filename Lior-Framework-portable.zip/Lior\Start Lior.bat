@echo off
rem Double-click this file to open Lior. Uses lior.jar (or lior-small.jar) next to this file, else the one in the dist folder.
where javaw >nul 2>nul
if errorlevel 1 (
  echo Java is not installed or not on PATH. Please install Java 11 or newer.
  pause
  exit /b 1
)
set "LIOR_JAR="
for %%J in ("%~dp0lior.jar" "%~dp0lior-small.jar" "%~dp0dist\lior.jar" "%~dp0dist\lior-small.jar") do (
  if not defined LIOR_JAR if exist "%%~J" set "LIOR_JAR=%%~J"
)
if not defined LIOR_JAR (
  echo No lior.jar found next to this file or in its dist folder.
  pause
  exit /b 1
)
start "" javaw -jar "%LIOR_JAR%"
