package com.mashreq.automation.tcoe.utils;

import com.mashreq.automation.tcoe.constants.FrameworkConstants;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

/**
 * A utility class for managing report directories, including backup and cleanup.
 */
public final class ReportUtils {

    private ReportUtils() {}


    /**
     * Cleans the main report directory by backing it up and then deleting contents.
     * Also removes older backups beyond a configured threshold.
     */


    // === ONE PUBLIC ENTRYPOINT: backs up BOTH reports and logs ===
    public static void backupReportsAndLogsDirectories() throws IOException {
        // Reports
        backupOneArtifactFlat(
                Paths.get("./" + FrameworkConstants.REPORT_BASE_FOLDER_NAME),
                Paths.get("./" + FrameworkConstants.REPORT_BACKUP_BASE_FOLDER_NAME),
                "reports",
                FrameworkConstants.REPORT_BACKUP_COUNT
        );

        // Logs (use "logs/latest" if that's the live folder)
        backupOneArtifactFlat(
                Paths.get("./" + FrameworkConstants.LOGS_BASE_FOLDER_NAME),
                Paths.get("./" + FrameworkConstants.LOGS_BACKUP_BASE_FOLDER_NAME),
                "logs",
                FrameworkConstants.LOGS_BACKUP_COUNT
        );
    }

    /* ================== impl ================== */

    // UTC, pattern: yyyyMMdd_HHmmss'Z' -> e.g. 20250907_143012Z. Sorts by name = by time, and does not depend on the
    // language of the PC (the old yyyyMMMdd gave 2025Sep07: "Sep" sorts after "Oct", and a non-English month broke retention).
    private static final DateTimeFormatter TS = DateTimeFormatter
            .ofPattern("yyyyMMdd_HHmmss'Z'", Locale.ROOT)
            .withZone(ZoneOffset.UTC);

    // old (2025Sep07_143012Z) and new (20250907_143012Z) backup names
    private static final DateTimeFormatter OLD_TS = DateTimeFormatter
            .ofPattern("yyyyMMMdd_HHmmss'Z'", Locale.ENGLISH)
            .withZone(ZoneOffset.UTC);

    /**
     * When the run of a history / backup folder (reports__<timestamp>) took place: from the name (old and new format),
     * else the folder's last-modified time. For sorting runs oldest -> newest.
     */
    public static long runTimeMillis(File runFolder) {
        String name = runFolder.getName();
        int sep = name.indexOf("__");
        if (sep >= 0) {
            String stamp = name.substring(sep + 2);
            for (DateTimeFormatter f : new DateTimeFormatter[]{TS, OLD_TS}) {
                try {
                    return Instant.from(f.parse(stamp)).toEpochMilli();
                } catch (java.time.DateTimeException notThisFormat) {
                    // try the next format
                }
            }
        }
        return runFolder.lastModified();
    }

    private static void backupOneArtifactFlat(Path sourceDir,
                                              Path backupRoot,
                                              String artifact,  // "reports" or "logs"
                                              int keepCount) throws IOException {
        Files.createDirectories(sourceDir);
        Files.createDirectories(backupRoot);

        String name = artifact + "__" + TS.format(Instant.now()); // e.g. reports__20250907_143012Z
        Path backupDir = backupRoot.resolve(name);

        if (directoryHasContent(sourceDir)) {
            // the backup folder only when there is something to back up: empty folders counted toward the
            // retention limit and pushed real backups out
            Files.createDirectories(backupDir);
            copyDirectoryContents(sourceDir, backupDir);  // copy contents only
            deleteDirectoryContents(sourceDir);           // keep source folder
            LogUtils.info("Backup: " + backupDir.toAbsolutePath());
        } else {
            LogUtils.info("No content to back up in: " + sourceDir.toAbsolutePath());
        }

        enforceFlatRetention(backupRoot, artifact, keepCount);
    }

    private static boolean directoryHasContent(Path dir) throws IOException {
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir)) {
            return ds.iterator().hasNext();
        }
    }

    private static void copyDirectoryContents(Path src, Path dst) throws IOException {
        Files.walkFileTree(src, new SimpleFileVisitor<>() {
            @Override public FileVisitResult preVisitDirectory(Path d, BasicFileAttributes a) throws IOException {
                Path rel = src.relativize(d);
                Files.createDirectories(dst.resolve(rel));
                return FileVisitResult.CONTINUE;
            }
            @Override public FileVisitResult visitFile(Path f, BasicFileAttributes a) throws IOException {
                Path rel = src.relativize(f);
                Files.copy(f, dst.resolve(rel),
                        StandardCopyOption.COPY_ATTRIBUTES,
                        StandardCopyOption.REPLACE_EXISTING);
                return FileVisitResult.CONTINUE;
            }
        });
    }

    /**
     * Recursively deletes the contents of a folder; the folder itself stays. Files that cannot be deleted (e.g. a log
     * file log4j still has open on Windows) are listed in one warning instead of being skipped silently.
     */
    private static void deleteDirectoryContents(Path dir) throws IOException {
        List<String> notDeleted = new ArrayList<>();
        try (var children = Files.list(dir)) {
            for (Path child : children.toList()) {
                try (var walk = Files.walk(child)) {
                    for (Path p : walk.sorted(Comparator.reverseOrder()).toList()) {
                        try {
                            Files.deleteIfExists(p);
                        } catch (IOException e) {
                            notDeleted.add(p + " (" + e.getClass().getSimpleName() + ")");
                        }
                    }
                }
            }
        }
        if (!notDeleted.isEmpty()) {
            LogUtils.warn("Could not delete " + notDeleted.size() + " item(s) after the backup of " + dir.toAbsolutePath()
                    + ": " + String.join(", ", notDeleted.subList(0, Math.min(5, notDeleted.size())))
                    + (notDeleted.size() > 5 ? " ..." : ""));
        }
    }

    /** keep newest keepCount folders for a given artifact; delete older ones */
    private static void enforceFlatRetention(Path backupRoot, String artifact, int keepCount) throws IOException {
        if (!Files.exists(backupRoot)) return;

        // matches: reports__20250907_143012Z (and the old reports__2025Sep07_143012Z), logs__...
        Pattern pat = Pattern.compile(
                Pattern.quote(artifact) + "__\\d{4}([A-Za-z]{3}|\\d{2})\\d{2}_\\d{6}Z"
        );

        List<Path> folders;
        try (var s = Files.list(backupRoot)) {
            folders = s.filter(Files::isDirectory)
                    .filter(d -> pat.matcher(d.getFileName().toString()).matches())
                    .sorted(Comparator.comparingLong((Path d) -> runTimeMillis(d.toFile())).reversed()) // newest first
                    .toList();
        }

        for (int i = keepCount; i < folders.size(); i++) {
            deleteRecursively(folders.get(i));
            LogUtils.info("Deleted old backup: " + folders.get(i).toAbsolutePath());
        }
    }

    private static void deleteRecursively(Path root) throws IOException {
        if (!Files.exists(root)) return;
        try (var s = Files.walk(root)) {
            for (Path p : s.sorted(Comparator.reverseOrder()).toList()) {
                Files.deleteIfExists(p);
            }
        }
    }


    public static void generateCucumberReport() {
        try {
            File reportOutputDir = new File("target/cucumber-reports/advanced-reports");
            File reportsDir = new File("target/cucumber-reports");

            // Wait until all JSON files are ready
            if (waitForAllJsonReady(reportsDir)) { // 10 minutes
                List<String> jsonFiles = Arrays.stream(reportsDir.listFiles((dir, name) -> name.endsWith(".json")))
                        .map(File::getAbsolutePath)
                        .collect(Collectors.toList());

                if (!jsonFiles.isEmpty()) {
                    Configuration config = new Configuration(reportOutputDir, "TCoE Playwright BDD Framework");
                    config.setBuildNumber("1.0");
                    config.addClassifications("Platform", System.getProperty("os.name"));
                    config.addClassifications("Java", System.getProperty("java.version"));

                    ReportBuilder reportBuilder = new ReportBuilder(jsonFiles, config);
                    reportBuilder.generateReports();
                    LogUtils.info("Cucumber HTML report generated successfully with " + jsonFiles.size() + " JSON file(s).");
                } else {
                    LogUtils.warn("No Cucumber JSON files found after waiting.");
                }
            } else {
                LogUtils.warn("Cucumber JSON files were not ready in time. Skipping report generation.");
            }
        } catch (Exception e) {
            LogUtils.error("Failed to generate Cucumber report: " + e.getMessage(), e);
        }
    }

    /** How long to wait for the Cucumber JSON files to be complete: -DREPORT_JSON_WAIT_SECONDS / config, default 600. */
    private static long jsonWaitMillis() {
        String value = PropertiesHelpers.getValue("REPORT_JSON_WAIT_SECONDS");
        try {
            return value == null || value.isBlank() ? 600_000L : Long.parseLong(value.trim()) * 1000L;
        } catch (NumberFormatException e) {
            LogUtils.warn("REPORT_JSON_WAIT_SECONDS is not a number (" + value + "); using 600.");
            return 600_000L;
        }
    }

    private static boolean waitForAllJsonReady(File dir) {
        long start = System.currentTimeMillis();
        long maxWait = jsonWaitMillis();
        Map<String, Long> lastSizes = new HashMap<>();

        while (System.currentTimeMillis() - start < maxWait) {
            File[] jsonFiles = dir.listFiles((d, name) -> name.endsWith(".json"));
            if (jsonFiles != null && jsonFiles.length > 0) {
                boolean allStable = true;

                for (File json : jsonFiles) {
                    long size = json.length();
                    Long prevSize = lastSizes.get(json.getName());

                    // stable = not empty and the same size at two polls in a row (the first poll only records the size;
                    // it used to count as stable at once, so a half-written file was read)
                    if (size == 0 || prevSize == null || prevSize != size) {
                        allStable = false;
                    }
                    lastSizes.put(json.getName(), size);
                }

                if (allStable) {
                    return true; // all JSON files are stable
                }
            }
            try {
                Thread.sleep(500); // poll interval while the report files are still being written
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
        return false; // timed out
    }
}