package com.mashreq.automation.tcoe.reporting;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.automation.tcoe.driver.DriverManager;
import com.mashreq.automation.tcoe.utils.LogUtils;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;

import java.io.Writer;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class FeatureDetailsGenerator {

    private final Configuration freemarkerConfig;
    private final ObjectMapper objectMapper;

    /**
     * Initializes the ReportGenerator with the path to the template directory.
     *
     * @param templateDir The directory where .ftl templates are located.
     * @throws Exception if the template directory does not exist or is not a directory.
     */
    public FeatureDetailsGenerator(Path templateDir) throws Exception {
        // ... (constructor is unchanged)
        if (!Files.isDirectory(templateDir)) {
            throw new IllegalArgumentException("Template directory not found: " + templateDir);
        }
        this.objectMapper = new ObjectMapper();
        this.freemarkerConfig = configureFreeMarker(templateDir);
    }

    /**
     * Configures the FreeMarker engine.
     *
     * @param templateDir The directory for loading templates.
     * @return A configured FreeMarker instance.
     */
    private Configuration configureFreeMarker(Path templateDir) throws Exception {
        // ... (this method is unchanged)
        Configuration cfg = new Configuration(Configuration.VERSION_2_3_32);
        cfg.setDirectoryForTemplateLoading(templateDir.toFile());
        cfg.setDefaultEncoding("UTF-8");
        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
        cfg.setLogTemplateExceptions(false);
        cfg.setWrapUncheckedExceptions(true);
        return cfg;
    }

    /**
     * Scans a directory for feature JSON files (matching "feature_*.json")
     * and generates an HTML report for each one.
     *
     * @param jsonSourceDir The directory containing the feature JSON files.
     * @param outputDir     The root directory where the final HTML reports will be saved.
     */
    // MODIFIED: Method signature no longer accepts runInfo map
    public void generateAllFeatureReports(Path jsonSourceDir, Path outputDir) {
        LogUtils.info("Starting feature report generation process...");
        LogUtils.info("Scanning for feature files in: " + jsonSourceDir);

        // --- NEW: Create the runInfo map here, once for all feature reports ---
        Map<String, String> runInfo = new HashMap<>();
        runInfo.put("Environment", com.mashreq.automation.tcoe.constants.FrameworkConstants.REGION + " " + com.mashreq.automation.tcoe.constants.FrameworkConstants.ENV);
        String browserInfo = DriverManager.getBrowserVersion();
        runInfo.put("Browser", browserInfo != null ? browserInfo : "N/A");
        runInfo.put("Platform", System.getProperty("os.name"));

        try (DirectoryStream<Path> stream = Files.newDirectoryStream(jsonSourceDir, "feature_*.json")) {
            int featureCount = 0;
            for (Path featureJsonFile : stream) {
                try {
                    // Pass the newly created runInfo map to the single report generator
                    generateSingleReport(featureJsonFile, outputDir, runInfo);
                    featureCount++;
                } catch (Exception e) {
                    LogUtils.error("Failed to generate report for: " + featureJsonFile.getFileName(), e);
                }
            }
            if (featureCount == 0) {
                LogUtils.error("No feature JSON files (feature_*.json) found in the directory.");
            } else {
                LogUtils.info("Successfully generated " + featureCount + " feature report(s).");
            }

        } catch (Exception e) {
            LogUtils.error("Error scanning for feature JSON files in directory: " + jsonSourceDir, e);
        }
    }

    /**
     * Generates a single HTML report for a given feature JSON file.
     * This method remains unchanged as it already accepted the runInfo map.
     *
     * @param featureJsonFile The path to the input feature summary JSON file.
     * @param outputDir       The root directory where the report will be saved.
     * @param runInfo         The map of execution metadata.
     */
    private void generateSingleReport(Path featureJsonFile, Path outputDir, Map<String, String> runInfo) throws Exception {
        LogUtils.info("--- Processing: " + featureJsonFile.getFileName() + " ---");

        // 1. Prepare the Data Model
        Map<String, Object> dataModel = new HashMap<>();
        Map<String, Object> featureData = objectMapper.readValue(
                featureJsonFile.toFile(),
                new TypeReference<>() {}
        );
        dataModel.put("feature", featureData);
        dataModel.put("runInfo", runInfo);

        // 2. Get the template
        Template template = freemarkerConfig.getTemplate("feature-template.ftl");

        // 3. Define the output file path
        String outputHtmlFileName = featureJsonFile.getFileName().toString().replace(".json", ".html");
        Path outputHtmlPath = outputDir.resolve(outputHtmlFileName);
        Files.createDirectories(outputHtmlPath.getParent());

        // 4. Merge data model and write output file
        try (Writer out = java.nio.file.Files.newBufferedWriter(outputHtmlPath, java.nio.charset.StandardCharsets.UTF_8)) { // UTF-8 like the templates
            template.process(dataModel, out);
        }

        LogUtils.info(">>> Generated report: " + outputHtmlPath);
    }
}