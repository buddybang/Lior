<#
.SYNOPSIS
  Runs the same mobile scenarios one device at a time and then in parallel (optionally several times) and compares the
  results, to find failures that only happen when sessions run at the same time (shared users, BrowserStack limits,
  timeouts).

.EXAMPLE
  .\scripts\compare-sequential-parallel.ps1 -Group mobile-smoke -Threads 3
  .\scripts\compare-sequential-parallel.ps1 -Group termdeposit -Threads 2 -Iterations 3 -Offsite

.NOTES
  -Group is a group from run-groups.properties ("all" = every @Mobile scenario).
  Output under target\compare-<timestamp>\<iteration>-sequential|parallel: console log, Cucumber JSON, logs and reports
  (copied only when the run wrote a new report), plus summary.csv (exit code, threads, seconds per run) and
  comparison.csv (result per scenario per run).
  Exit code: 0 when every scenario has the same result in all runs, 1 otherwise.
  Iterations / fresh-report check / summary.csv merged in from Framework_Fixed's Compare-BrowserStackExecution.ps1.
#>
param(
    [string]$Group = "all",
    [ValidateRange(2, 20)][int]$Threads = 3,
    [ValidateRange(1, 20)][int]$Iterations = 1,
    [switch]$Offsite
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
$outDir = Join-Path $root ("target\compare-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
New-Item -ItemType Directory -Force $outDir | Out-Null
$profiles = if ($Offsite) { "mobile,offsite" } else { "mobile" }

$secrets = Join-Path $root "src\main\resources\config\secrets.local.properties"
if (-not $env:BROWSERSTACK_ACCESS_KEY -and -not (Test-Path $secrets)) {
    Write-Warning "No BrowserStack credentials found (BROWSERSTACK_ACCESS_KEY or secrets.local.properties): the runs will fail."
}

# scenario name -> PASSED / FAILED (a scenario passes when every step and hook passed)
function Get-Results([string]$jsonPath) {
    $results = @{}
    if (-not (Test-Path $jsonPath)) { return $results }
    foreach ($feature in (Get-Content $jsonPath -Raw -Encoding UTF8 | ConvertFrom-Json)) {
        foreach ($el in $feature.elements) {
            if ($el.type -ne "scenario") { continue }
            $all = @($el.before) + @($el.steps) + @($el.after) | Where-Object { $_ }
            $failed = $all | Where-Object { $_.result.status -ne "passed" }
            $results[$el.name] = if ($failed) { "FAILED" } else { "PASSED" }
        }
    }
    return $results
}

$summary = [System.Collections.Generic.List[object]]::new()
$runResults = [ordered]@{}
foreach ($iteration in 1..$Iterations) {
    foreach ($mode in @("sequential", "parallel")) {
        $name = "$iteration-$mode"
        $dest = Join-Path $outDir $name
        New-Item -ItemType Directory -Force $dest | Out-Null
        $runThreads = if ($mode -eq "sequential") { 1 } else { $Threads }
        $mvnArgs = @("test", "-P$profiles", "-DRUN_GROUP=$Group", "-DMOBILE_EXECUTION_MODE=browserstack",
                     "-Dparallel=$($mode -eq 'parallel')".ToLower(), "-Dthreads=$runThreads")
        Write-Host "=== $name run ($runThreads thread(s)) ===" -ForegroundColor Cyan
        $started = Get-Date
        & mvn @mvnArgs *> (Join-Path $dest "console.log")
        $exitCode = $LASTEXITCODE
        $json = Join-Path $root "target\cucumber-reports\cucumber.json"
        $fresh = (Test-Path $json) -and ((Get-Item $json).LastWriteTime -ge $started)
        if ($fresh) {
            # only this run's files: an old report must not be mistaken for this run's result
            Copy-Item $json (Join-Path $dest "cucumber.json")
            foreach ($folder in @("logs\latest", "reports\latest")) {
                if (Test-Path $folder) { Copy-Item $folder (Join-Path $dest ($folder -replace '\\', '-')) -Recurse }
            }
            if (Test-Path "target\rerun.txt") { Copy-Item "target\rerun.txt" $dest }
        }
        $runResults[$name] = Get-Results (Join-Path $dest "cucumber.json")
        $summary.Add([pscustomobject]@{
            Run            = $name
            Threads        = $runThreads
            ExitCode       = $exitCode
            FreshReport    = $fresh
            ElapsedSeconds = [math]::Round(((Get-Date) - $started).TotalSeconds, 1)
        })
    }
}

$summary | Format-Table -AutoSize
$summary | Export-Csv (Join-Path $outDir "summary.csv") -NoTypeInformation -Encoding UTF8

$names = $runResults.Values | ForEach-Object { $_.Keys } | Sort-Object -Unique
$rows = foreach ($n in $names) {
    $row = [ordered]@{ Scenario = $n }
    foreach ($run in $runResults.Keys) { $row[$run] = if ($runResults[$run].ContainsKey($n)) { $runResults[$run][$n] } else { "-" } }
    $row["Differs"] = (@($runResults.Keys | ForEach-Object { $row[$_] }) | Sort-Object -Unique).Count -gt 1
    [pscustomobject]$row
}
$rows | Format-Table -AutoSize
$rows | Export-Csv (Join-Path $outDir "comparison.csv") -NoTypeInformation -Encoding UTF8
Write-Host "Results and logs: $outDir"

$diff = @($rows | Where-Object { $_.Differs })
if ($diff.Count -gt 0 -or @($summary | Where-Object { -not $_.FreshReport }).Count -gt 0) {
    Write-Host "$($diff.Count) scenario(s) differ between runs; runs without a new report: $(@($summary | Where-Object { -not $_.FreshReport }).Count)." -ForegroundColor Yellow
    exit 1
}
Write-Host "Same result in every run." -ForegroundColor Green
exit 0
