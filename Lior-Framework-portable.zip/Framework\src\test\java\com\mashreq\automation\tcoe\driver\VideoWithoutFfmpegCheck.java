package com.mashreq.automation.tcoe.driver;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;

import java.io.File;
import java.nio.file.Paths;

/**
 * A machine without Playwright's ffmpeg (seen 2026-10-08 on a remote machine: "Executable doesn't exist at ...ffmpeg-1010\ffmpeg-win64.exe")
 * still runs web tests, without a video. Real Chrome; run it with an EMPTY Playwright folder so ffmpeg is missing:
 * <pre>
 *   set PLAYWRIGHT_BROWSERS_PATH=%CD%\target\no-playwright-browsers   (an empty folder)
 *   mvn -o test -Dsuite.xml.file=src/test/resources/suites/browser-portability.xml -DHEADLESS=true
 * </pre>
 */
public class VideoWithoutFfmpegCheck {

    @Test
    public void webTestRunsWithoutVideoWhenFfmpegIsMissing() {
        String dir = System.getenv("PLAYWRIGHT_BROWSERS_PATH");
        File[] inside = dir == null ? null : new File(dir).listFiles((d, n) -> n.startsWith("ffmpeg"));
        if (dir == null || inside == null || inside.length > 0) {
            throw new SkipException("Set PLAYWRIGHT_BROWSERS_PATH to an empty folder (no ffmpeg) to run this check.");
        }

        // 1. this machine now looks like the remote one: a video cannot start
        RuntimeException asBefore = null;
        try (Playwright pw = Playwright.create(DriverManager.createOptions("chrome"))) {
            Browser b = pw.chromium().launch(new BrowserType.LaunchOptions().setChannel("chrome").setHeadless(true));
            BrowserContext c = b.newContext(new Browser.NewContextOptions().setRecordVideoDir(Paths.get("target/video-check")));
            c.newPage();
        } catch (RuntimeException e) {
            asBefore = e;
        }
        Assert.assertNotNull(asBefore, "the check needs a machine without ffmpeg, but a video started");
        Assert.assertTrue(DriverManager.videoToolMissing(asBefore), "expected the ffmpeg error, got: " + asBefore.getMessage());

        // 2. the framework sees ffmpeg is missing and still runs the test, without a video (VIDEO_RECORD=true in the config)
        Assert.assertFalse(DriverManager.videoToolInstalled());
        DriverManager.initDriver("chrome");
        try {
            Page page = DriverManager.getPage();
            page.setContent("<h1 id='t'>works without video</h1>");
            Assert.assertEquals(page.textContent("#t"), "works without video");
        } finally {
            DriverManager.closeDriver("video-check");
        }
    }
}
