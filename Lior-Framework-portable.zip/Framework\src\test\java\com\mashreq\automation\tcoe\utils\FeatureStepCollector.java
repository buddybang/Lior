package com.mashreq.automation.tcoe.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.context.ScreenshotContextHolder;
import com.mashreq.automation.tcoe.keywords.IActionLogger;
import lombok.*;

import java.io.*;
import java.nio.charset.StandardCharsets; // <-- IMPORT ADDED
import java.nio.file.Files; // <-- IMPORT ADDED
import java.nio.file.StandardOpenOption; // <-- IMPORT ADDED
import java.time.Instant;
import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class FeatureStepCollector implements IActionLogger {

    private static final ThreadLocal<List<StepInfo>> steps = ThreadLocal.withInitial(ArrayList::new);
    private static final ThreadLocal<List<ActionInfo>> pendingActions = ThreadLocal.withInitial(ArrayList::new);
    private static final ThreadLocal<Long> stepStartTime = ThreadLocal.withInitial(() -> 0L);
    private static final ThreadLocal<Integer> stepCounter = ThreadLocal.withInitial(() -> 0);
    private static final ThreadLocal<Integer> actionCounter = ThreadLocal.withInitial(() -> 0);
    private static final ThreadLocal<Map<String, String>> featureUUIDMap = ThreadLocal.withInitial(HashMap::new);
    private static final ThreadLocal<ScenarioResult> currentScenarioResult = new ThreadLocal<>();
    /** Per thread: parallel scenarios each have their own start time. */
    private static final ThreadLocal<Instant> scenarioStartTime = new ThreadLocal<>();
    /** Cucumber's own result of the scenario (includes failures in hooks). */
    private static final ThreadLocal<String> cucumberStatus = new ThreadLocal<>();

    // ======================= New helpers =======================
    private static final List<String> STATUS_PRECEDENCE =
            List.of("FAILED", "AMBIGUOUS", "UNDEFINED", "PENDING", "SKIPPED", "PASSED");

    private static String nullToEmpty(String s) {
        return s == null ? "" : s;
    }

    private static String worstStatusForScenario(List<StepInfo> steps) {
        if (steps == null || steps.isEmpty()) return "PASSED";
        for (String candidate : STATUS_PRECEDENCE) {
            for (StepInfo s : steps) {
                String st = s.getStatus();
                if (st != null && candidate.equalsIgnoreCase(st.trim())) {
                    return candidate;
                }
            }
        }
        return "PASSED";
    }

    // ======================= IActionLogger implementation =======================
    @Override
    public <T> T logAction(String description, Supplier<T> action) {
        long start = System.currentTimeMillis();
        String status = "PASSED";
        String error = null;
        String screenshotPath;
        T result = null;
        Throwable caughtThrowable = null;

        ScreenshotContextHolder.planScreenshot(stepCounter.get(), actionCounter.get() + 1);

        try {
            result = action.get();
            if (result instanceof String resultStr && resultStr.trim().toUpperCase().startsWith("FAILED")) {
                status = "FAILED";
                error = resultStr;
            }
        } catch (Throwable t) {
            status = "FAILED";
            error = getStackTraceAsString(t);
            caughtThrowable = t;
        } finally {
            long duration = System.currentTimeMillis() - start;
            screenshotPath = ScreenshotContextHolder.consumeLastScreenshotPath();

            if (!steps.get().isEmpty()) {
                StepInfo currentStep = steps.get().get(steps.get().size() - 1);
                DataTableInfo dti = currentStep.getDataTable();

                String resultString = (result == null) ? null : String.valueOf(result);

                int mappedRowIndex = -1;

                if (dti != null && dti.isSingleColumnIteration()) {
                    int actionIndex = currentStep.getActions().size();
                    if (actionIndex < dti.getRows().size()) {
                        mappedRowIndex = actionIndex;
                    }
                }

                if (dti != null && !dti.isSingleColumnIteration()) {
                    boolean mapped = false;
                    String actionTextSource = (description == null ? "" : description) + " " + (resultString == null ? "" : resultString);
                    String actionTextLower = actionTextSource.toLowerCase(Locale.ROOT);

                    for (int i = 0; i < dti.getRows().size(); i++) {
                        List<String> rowData = dti.getRows().get(i).getData();
                        if (rowData != null && !rowData.isEmpty()) {
                            String fieldName = rowData.get(0);
                            if (fieldName != null && !fieldName.isBlank()) {
                                String fieldLower = fieldName.toLowerCase(Locale.ROOT);
                                if (actionTextLower.contains(fieldLower) || fieldLower.contains(actionTextLower)) {
                                    mappedRowIndex = i;
                                    mapped = true;
                                    break;
                                }
                            }
                        }
                    }

                    if (!mapped) {
                        int actionIndex = currentStep.getActions().size();
                        if (actionIndex < dti.getRows().size()) {
                            mappedRowIndex = actionIndex;
                        }
                    }
                }

                if (dti != null && mappedRowIndex >= 0 && mappedRowIndex < dti.getRows().size()) {
                    int firstFailed = -1;
                    for (int i = 0; i < dti.getRows().size(); i++) {
                        String s = dti.getRows().get(i).getStatus();
                        if (s != null && "FAILED".equalsIgnoreCase(s)) {
                            firstFailed = i;
                            break;
                        }
                    }

                    if (firstFailed != -1 && mappedRowIndex > firstFailed) {
                        status = "SKIPPED";
                        error = null;
                        resultString = "SKIPPED";
                        dti.getRows().get(mappedRowIndex).setStatus("SKIPPED");
                    } else {
                        dti.getRows().get(mappedRowIndex).setStatus(status);

                        if ("FAILED".equalsIgnoreCase(status)) {
                            for (int j = mappedRowIndex + 1; j < dti.getRows().size(); j++) {
                                dti.getRows().get(j).setStatus("SKIPPED");
                            }
                        }
                    }
                }
                addAction(description, status, error, duration, screenshotPath, resultString);

                if ("FAILED".equalsIgnoreCase(status)) {
                    String best = pickMostInformative(currentStep.getError(), error);
                    currentStep.setError(best);
                    currentStep.setStatus("FAILED");
                }

                currentStep.setDurationMillis(System.currentTimeMillis() - stepStartTime.get());
            }

            ScreenshotContextHolder.clear();
        }

        if (caughtThrowable != null && LogUtils.containsSecret(caughtThrowable)) {
            // Cucumber, Allure and Extent print the exception as it is: a masked copy instead (frames and causes kept)
            throw new AssertionError(LogUtils.mask(caughtThrowable.getMessage()), LogUtils.sanitized(caughtThrowable));
        }
        if (caughtThrowable instanceof RuntimeException re) {
            throw re; // keep the type (e.g. PendingException) and the cause chain
        }
        if (caughtThrowable instanceof Error err) {
            throw err;
        }
        if (caughtThrowable != null) {
            throw new AssertionError(caughtThrowable.getMessage(), caughtThrowable); // checked exception
        }
        return result;
    }

    private static String getStackTraceAsString(Throwable throwable) {
        if (throwable == null) return "";
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        throwable.printStackTrace(pw);
        return LogUtils.mask(sw.toString()); // the report must not show the BrowserStack key / URL credentials
    }

    public static void attachScreenshotToLastAction(
            String screenshotPath) {

        if (steps.get().isEmpty()) {
            return;
        }

        StepInfo currentStep =
                steps.get().get(steps.get().size() - 1);

        if (currentStep.getActions().isEmpty()) {
            return;
        }

        ActionInfo lastAction =
                currentStep.getActions()
                        .get(currentStep.getActions().size() - 1);

        lastAction.setScreenshotPath(screenshotPath);
    }

    // ======================= Feature/Scenario methods =======================
    public static void setFeature(String moduleName, String name, String description, String keyword, String uri, List<String> tags) {
        ScenarioResult scenarioResult = currentScenarioResult.get();
        if (scenarioResult == null) {
            scenarioResult = new ScenarioResult();
            currentScenarioResult.set(scenarioResult);
        }

        // Generate UUID based on moduleName + featureName
        String uuidSource = (moduleName != null ? moduleName : "") + "::" + (name != null ? name : "");
        String featureUUID = UUID.nameUUIDFromBytes(uuidSource.getBytes(StandardCharsets.UTF_8)).toString();

        scenarioResult.setFeatureUUID(featureUUID);
        scenarioResult.setFeatureName(name);
        scenarioResult.setFeatureDescription(description);
        scenarioResult.setFeatureKeyword(keyword);
        scenarioResult.setFeatureUri(uri);
        scenarioResult.setFeatureTags(tags);
    }

    public static void startScenario(String id, String name, List<String> scenarioTags) {
        scenarioStartTime.set(Instant.now());
        cucumberStatus.remove();
        ScenarioResult scenarioResult = currentScenarioResult.get();
        if (scenarioResult == null) {
            scenarioResult = new ScenarioResult();
            currentScenarioResult.set(scenarioResult);
        }
        scenarioResult.setScenarioUUID(id);
        scenarioResult.setScenarioName(name);
        scenarioResult.setTags(scenarioTags);
        steps.get().clear();
        pendingActions.get().clear();
        stepCounter.set(0);
    }

    public static void endScenario() {
        saveScenarioJson();
        clear();
    }

    /** Saves the scenario with Cucumber's own result, so a scenario whose hook failed is never shown as passed. */
    public static void endScenario(String status) {
        cucumberStatus.set(status == null ? null : status.trim().toUpperCase(Locale.ROOT));
        endScenario();
    }

    /**
     * A failed hook (@Before / @After ...) as its own FAILED line in the report. Without it a scenario whose @Before
     * failed (no device, browser did not start, no free user) had only SKIPPED steps and was counted as passed.
     */
    public static void addHookFailure(String hookName, String error) {
        StepInfo hook = new StepInfo("Hook", hookName);
        hook.setStatus("FAILED");
        hook.setError(LogUtils.mask(error));
        if (!pendingActions.get().isEmpty()) {
            hook.getActions().addAll(pendingActions.get());
            pendingActions.get().clear();
        }
        steps.get().add(hook);
    }

    public static void setScenarioMetadata(String moduleName, String scenarioId) {
        ScenarioResult sr = currentScenarioResult.get();
        if (sr == null) {
            sr = new ScenarioResult();
            currentScenarioResult.set(sr);
        }
        if (moduleName != null && !moduleName.isBlank()) {
            sr.setModuleName(moduleName);
        }
        if (scenarioId != null && !scenarioId.isBlank()) {
            sr.setScenarioId(scenarioId);
        }
    }

    // ======================= Step methods =======================
    public static void startStep(String keyword, String text) {
        stepCounter.set(stepCounter.get() + 1);
        actionCounter.set(0);
        stepStartTime.set(System.currentTimeMillis());
        StepInfo step = new StepInfo(keyword, text);
        steps.get().add(step);
        if (!pendingActions.get().isEmpty()) {
            step.getActions().addAll(pendingActions.get());
            pendingActions.get().clear();
        }
    }

    public static void startStep(String keyword, String text, List<List<String>> tableAsLists) {
        startStep(keyword, text);

        if (tableAsLists == null || tableAsLists.isEmpty() || steps.get().isEmpty()) return;

        StepInfo currentStep = steps.get().get(steps.get().size() - 1);
        DataTableInfo dataTableInfo = new DataTableInfo();

        List<String> firstRow = tableAsLists.get(0);
        int colCount = firstRow.size();
        boolean singleCol = (colCount == 1);

        List<String> header;
        int bodyStartIdx;
        if (singleCol) {
            header = List.of("Fields");
            bodyStartIdx = 0;
            dataTableInfo.setSingleColumnIteration(true);
        } else {
            header = firstRow;
            bodyStartIdx = 1;
            dataTableInfo.setSingleColumnIteration(false);
        }
        dataTableInfo.setHeader(header);

        for (int i = bodyStartIdx; i < tableAsLists.size(); i++) {
            dataTableInfo.getRows().add(new DataTableRow(tableAsLists.get(i), null));
        }

        currentStep.setDataTable(dataTableInfo);
    }

    public static void endStep(String status, String error) {
        if (steps.get().isEmpty()) return;
        StepInfo currentStep = steps.get().get(steps.get().size() - 1);

        String st = (status == null || status.trim().isEmpty()) ? "UNDEFINED" : status.trim().toUpperCase(Locale.ROOT);
        currentStep.setStatus(st);

        String fromActions = getLatestFailedActionError(currentStep);
        String best = pickMostInformative(currentStep.getError(), LogUtils.mask(error), fromActions);
        currentStep.setError(best);

        currentStep.setDurationMillis(System.currentTimeMillis() - stepStartTime.get());

        DataTableInfo dti = currentStep.getDataTable();
        if (dti != null && !dti.isSingleColumnIteration()) {
            boolean anyRowMapped = dti.getRows().stream()
                    .anyMatch(r -> r.getStatus() != null && !"SKIPPED".equalsIgnoreCase(r.getStatus()));

            if (!anyRowMapped) {
                for (DataTableRow row : dti.getRows()) {
                    if (row.getStatus() == null) {
                        row.setStatus(st);
                    }
                }
            } else {
                for (DataTableRow row : dti.getRows()) {
                    if (row.getStatus() == null) {
                        row.setStatus(st);
                    }
                }
            }
        }
        if (dti != null && dti.isSingleColumnIteration()) {
            for (DataTableRow row : dti.getRows()) {
                if (row.getStatus() == null) {
                    row.setStatus(st);
                }
            }
        }
    }

    // ======================= Action methods =======================
    public static void addAction(String description, String status, String error,
                                 long durationMillis, String screenshotPath, String result) {
        actionCounter.set(actionCounter.get() + 1);
        ActionInfo action = new ActionInfo(description, status, error, durationMillis, screenshotPath, result);
        if (steps.get().isEmpty()) {
            pendingActions.get().add(action);
        } else {
            steps.get().get(steps.get().size() - 1).getActions().add(action);
        }
    }

    // ======================= JSON Output & Cleanup =======================
    public static void saveScenarioJson() {
        String fileName = "";
        try {
            ScenarioResult scenarioResult = currentScenarioResult.get();
            if (scenarioResult == null) return;

            Instant start = scenarioStartTime.get() != null ? scenarioStartTime.get() : Instant.now();
            Instant endTime = Instant.now(); // real end, hooks included
            scenarioResult.setStartTime(start.toString());

            List<StepInfo> stepList = steps.get();
            scenarioResult.setSteps(stepList);
            scenarioResult.setTotalSteps(stepList.size());

            scenarioResult.setDurationMillis(java.time.Duration.between(start, endTime).toMillis());
            scenarioResult.setEndTime(endTime.toString());

            String scenarioStatus = worstStatusForScenario(stepList);
            scenarioResult.setStatus(scenarioStatus);
            scenarioResult.setCucumberStatus(cucumberStatus.get());

            long failed = stepList.stream()
                    .filter(s -> {
                        String ss = nullToEmpty(s.getStatus()).toUpperCase(Locale.ROOT);
                        return "FAILED".equals(ss) || "AMBIGUOUS".equals(ss) || "UNDEFINED".equals(ss) || "PENDING".equals(ss);
                    }).count();

            long passed = stepList.stream().filter(s -> "PASSED".equalsIgnoreCase(nullToEmpty(s.getStatus()))).count();
            long skipped = stepList.stream().filter(s -> "SKIPPED".equalsIgnoreCase(nullToEmpty(s.getStatus()))).count();

            scenarioResult.setPassedSteps((int) passed);
            scenarioResult.setFailedSteps((int) failed);
            scenarioResult.setSkippedSteps((int) skipped);

            try {
                ScenarioContext ctx = ScenarioContext.get();
                if (ctx != null) {
                    if (ctx.getCurrentModule() != null && !ctx.getCurrentModule().isEmpty()) {
                        scenarioResult.setModuleName(ctx.getCurrentModule());
                    }
                    if (ctx.getScenarioId() != null && !ctx.getScenarioId().isEmpty()) {
                        scenarioResult.setScenarioId(ctx.getScenarioId());
                    }
                }
            } catch (Exception e) {
                // defensive: ignore if context unavailable
            }

            String modulePart = nullToEmpty(scenarioResult.getModuleName()).replaceAll("[^a-zA-Z0-9-_]", "_");
            String scenarioIdPart = nullToEmpty(scenarioResult.getScenarioId()).replaceAll("[^a-zA-Z0-9-_]", "_");
            String uuidPart = nullToEmpty(scenarioResult.getScenarioUUID());

            if (modulePart.isEmpty()) modulePart = "unknownModule";
            if (scenarioIdPart.isEmpty()) scenarioIdPart = "unknownScenario";
            if (uuidPart.isEmpty()) uuidPart = UUID.randomUUID().toString();

            fileName = String.format("%s_%s_%s.js", modulePart, scenarioIdPart, uuidPart);
            String dirPath = System.getProperty("user.dir") + "/reports/latest/custom-report/json/scenarios/";
            File dir = new File(dirPath);
            if (!dir.exists()) dir.mkdirs();

            File file = new File(dir, fileName);

            ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
            String jsonContent = mapper.writeValueAsString(scenarioResult);
            String jsContent = "loadScenarioData(" + jsonContent + ");";

            // ==================== START OF THE FIX ====================
            // Replaced the old FileWriter with the more robust Files.writeString().
            // This is a more atomic operation and less prone to being interrupted
            // during the fast shutdown of the Maven Surefire forked process.
            Files.writeString(file.toPath(), jsContent, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            // ===================== END OF THE FIX =====================

            LogUtils.info("Scenario JS file saved: " + file.getAbsolutePath());

        } catch (Exception e) {
            LogUtils.error("Error in saving JS file for scenario " + fileName + ": " + e.getMessage(), e);
        }
    }

    public static void setVideoPath(String path) {
        ScenarioResult sr = currentScenarioResult.get();
        if (sr != null) sr.setVideoPath(path);
    }

    public static void clear() {
        steps.remove();
        pendingActions.remove();
        stepStartTime.remove();
        stepCounter.remove();
        actionCounter.remove();
        currentScenarioResult.remove();
        scenarioStartTime.remove();
        cucumberStatus.remove();
    }

    // ======================= Helpers (NEW) =======================
    private static String getLatestFailedActionError(StepInfo step) {
        List<ActionInfo> acts = step.getActions();
        if (acts == null || acts.isEmpty()) return null;
        for (int i = acts.size() - 1; i >= 0; i--) {
            ActionInfo a = acts.get(i);
            if ("FAILED".equalsIgnoreCase(a.getStatus())
                    && a.getError() != null && !a.getError().isBlank()) {
                return a.getError();
            }
        }
        return null;
    }

    private static String pickMostInformative(String... candidates) {
        String best = null;
        int bestLen = -1;
        if (candidates == null) return null;
        for (String c : candidates) {
            if (c == null) continue;
            String t = c.trim();
            if (t.isEmpty()) continue;
            int len = t.length();
            if (len > bestLen) {
                best = t;
                bestLen = len;
            }
        }
        return best;
    }

    // ======================= Nested Classes =======================
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class DataTableInfo {
        private List<String> header;
        private List<DataTableRow> rows = new ArrayList<>();
        private boolean isSingleColumnIteration;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class DataTableRow {
        private List<String> data;
        private String status;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class StepInfo {
        private String keyword;
        private String text;
        private String status;
        private String error;
        private long durationMillis;
        private List<ActionInfo> actions = new ArrayList<>();
        private DataTableInfo dataTable;
        public StepInfo(String keyword, String text) {
            this.keyword = keyword;
            this.text = text;
        }
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class ActionInfo {
        private String action;
        private String status;
        private String error;
        private long durationMillis;
        private String screenshotPath;
        private String result;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class ScenarioResult {
        private String moduleName, featureUUID, featureName, featureDescription, featureKeyword, featureUri;
        private List<String> featureTags;
        private String scenarioUUID, scenarioId, scenarioName, description;
        private List<String> tags;
        private String startTime, endTime;
        private long durationMillis;
        private int totalSteps, passedSteps, failedSteps, skippedSteps;
        private String videoPath;
        private List<StepInfo> steps;
        private String status;
        /** Cucumber's result of the whole scenario (PASSED, FAILED, SKIPPED ...); null in files of older runs. */
        private String cucumberStatus;
    }
}