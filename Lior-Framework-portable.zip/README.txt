﻿LIOR + TCoE FRAMEWORK - PORTABLE PACKAGE
=========================================

What is inside
  Framework\        the complete TCoE automation framework (Maven project: pom.xml, src, flexcube-features, testdata ...)

  Lior\lior-small.jar   Lior for Windows - Java 11 or newer
  Lior\Start Lior.bat   double-click to start Lior on Windows

What the computer needs
  - Java 17 or newer (JDK) and Maven 3.9 or newer
  - the Maven libraries: internet / the company Maven mirror, or a copy of %USERPROFILE%\.m2\repository from a computer
    that has run the framework
  - Edge or Chrome (the framework uses the other one, or Playwright's own Chromium, when one is missing)

Set up (replace the old copy completely)
  1. Delete the old framework folder. Unzip this package anywhere (a path with spaces is fine).
  2. Put the BrowserStack key in Framework\src\main\resources\config\secrets.local.properties
     (or as an environment variable). It is not in this package on purpose.
  3. Check Framework\src\main\resources\config\config.properties for this computer: ENV, REGION, MOBILE_EXECUTION_MODE,
     the application addresses in urls-<ENV>.properties.
  4. Open the Framework folder in IntelliJ (the folder with pom.xml) and let Maven load. Or run once:  mvn test-compile
  5. Start Lior (Lior\Start Lior.bat). Automation pack tab: set "Framework folder" to the new Framework folder, then press
     "Make pack and copy into framework" for each recording (the old framework folder had them; they are reinstalled now).
  6. Performance tests: make the JMeter test again in the Performance test tab (step names are corrected).

Run
  Web tests:      mvn test -Pweb
  Mobile tests:   mvn test -Pmobile
  Journeys:       mvn test -Pjourney -Dcucumber.tags="@Journey_<Name>"
  One scenario:   mvn test -Pweb -Dcucumber.tags="@Web and @SC_001"

Good to know
  - No ffmpeg on the computer: web tests run without a video and say so in the log (copy ms-playwright\ffmpeg-<n> from a
    computer that has it into %LOCALAPPDATA%\ms-playwright to get videos, or set VIDEO_RECORD=false).
  - Outside the client network the BrowserStack proxy is skipped automatically (warning in the log).
  - Framework\testdata\Users holds test users' passwords: share this package only inside the team.
  - Mobile screens that load slowly: raise MOBILE_TIMEOUT_SECONDS in config.properties (default 20 seconds per step),
    or for one run: mvn test -Pmobile -DMOBILE_TIMEOUT_SECONDS=40
  - What changed and why: Framework\CHANGELOG-FIXES.md (entries #83 - #95 are from 2026-10-08, #96 - #98 from 2026-10-10).
