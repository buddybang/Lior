package com.mashreq.automation.tcoe.utils;

import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Values in the test data that change on every run, so tests that CREATE something (a project, a customer, a payment)
 * can run again without "already exists" errors.
 *
 * <pre>
 * ${unique}               a stamp that is new for every run, e.g. 261002141530 (the same everywhere within one run)
 * ${today}                today's date, MM/dd/yyyy
 * ${today:+5}             5 days from today (also -3 for 3 days ago)
 * ${today:+5:dd-MM-yyyy}  with your own date format
 * ${random:6}             6 random digits
 *
 * One-time passwords (details in {@link OneTimeCodes}):
 * ${fromScreen:Transfers.OtpMessage}     the code the application shows in that element
 * ${fromScreen:Transfers.OtpMessage:3}   its 3rd character (OTP boxes that take one digit each)
 * ${ask:Type the OTP sent to the phone}  a person types it while the test runs
 * ${totp:SECRETKEY}                      the code of an authenticator app set up with that key
 *
 * Journeys (several scenarios that are one business case, see {@link Journey}):
 * ${journey:TxnRef}                      a value an earlier part of the journey kept (a reference number) or typed (by field name)
 * </pre>
 * Example: "ProjectName": "Test project ${unique}". Anything else is left exactly as written.
 */
public final class TestDataTokens {

    /** One stamp per run: a value used in two steps (create, then search) is the same in both. */
    private static final String RUN_STAMP = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMddHHmmss"));
    private static final Pattern TOKEN = Pattern.compile("\\$\\{(\\w+)(?::([^}]*))?}");
    private static final SecureRandom RANDOM = new SecureRandom();

    private TestDataTokens() {
    }

    public static String resolve(String value) {
        if (value == null || !value.contains("${")) {
            return value;
        }
        Matcher m = TOKEN.matcher(value);
        StringBuilder out = new StringBuilder();
        int last = 0;
        while (m.find()) {
            out.append(value, last, m.start());
            String replacement = replacement(m.group(1), m.group(2));
            out.append(replacement != null ? replacement : m.group());
            last = m.end();
        }
        out.append(value.substring(last));
        return out.toString();
    }

    private static String replacement(String name, String arg) {
        switch (name.toLowerCase()) {
            case "unique":
                return RUN_STAMP;
            case "random": {
                int digits = parseInt(arg, 6);
                StringBuilder b = new StringBuilder();
                for (int i = 0; i < Math.max(1, Math.min(digits, 18)); i++) {
                    b.append(RANDOM.nextInt(10));
                }
                return b.toString();
            }
            case "today": {
                String[] parts = arg == null ? new String[0] : arg.split(":", 2);
                int days = parts.length > 0 && !parts[0].isBlank() ? parseInt(parts[0].replace("+", ""), 0) : 0;
                String format = parts.length > 1 && !parts[1].isBlank() ? parts[1] : "MM/dd/yyyy";
                return LocalDate.now().plusDays(days).format(DateTimeFormatter.ofPattern(format));
            }
            case "fromscreen":
                return OneTimeCodes.fromScreen(arg);
            case "ask":
                return OneTimeCodes.ask(arg);
            case "totp":
                return OneTimeCodes.totp(arg);
            case "journey":
                return Journey.value(arg);
            default:
                return null; // not ours: keep it as written
        }
    }

    private static int parseInt(String s, int fallback) {
        try {
            return s == null || s.isBlank() ? fallback : Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }
}
