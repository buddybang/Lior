package com.mashreq.automation.tcoe.driver;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.automation.tcoe.context.Platform;
import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.context.ScreenshotContextHolder;
import com.mashreq.automation.tcoe.hooks.ApplicationHooks;
import com.mashreq.automation.tcoe.keywords.MobileUI;
import com.mashreq.automation.tcoe.utils.FailureKind;
import com.mashreq.automation.tcoe.utils.LogUtils;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.remote.http.ClientConfig;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.IOException;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Offline regression tests of the mobile session handling (fake Appium server on 127.0.0.1; never BrowserStack).
 * Run: mvn test -Pmobile-regression. Adapted from Framework_Fixed's MobileSessionRegressionTest to this framework's API.
 */
public class MobileSessionRegressionTest {

    @org.testng.annotations.BeforeClass
    public void ownStatusFolder() {
        // never next to real results: Sync-BrowserStackResults.ps1 would send the fake session to BrowserStack
        System.setProperty("BS_STATUS_DIR", "target/offline-regression/browserstack-status");
    }

    @AfterMethod(alwaysRun = true)
    public void cleanUp() {
        MobileDriverManager.quitDriver();
        ScenarioContext.clear();
        ScreenshotContextHolder.clear();
        System.clearProperty("MOBILE_EXECUTION_MODE");
        System.clearProperty("BS_READ_TIMEOUT_SECONDS");
    }

    @Test
    public void distinguishesLookupTransportAndSessionFailures() {
        Assert.assertEquals(FailureKind.of(new TimeoutException("element not visible")), FailureKind.LOCATOR);
        Assert.assertEquals(FailureKind.of(new TimeoutException("HTTP timed out", new java.util.concurrent.TimeoutException())),
                FailureKind.TRANSPORT);
        Assert.assertEquals(FailureKind.of(new IOException("closed")), FailureKind.TRANSPORT);
        Assert.assertEquals(FailureKind.of(new NoSuchSessionException("deleted")), FailureKind.SESSION);
        Assert.assertEquals(FailureKind.of(new IllegalStateException("no driver")), FailureKind.SETUP);
    }

    @Test
    public void setupFailureLeavesNoDriverAndTakesNoWebScreenshot() {
        mobileContext();
        System.setProperty("MOBILE_EXECUTION_MODE", "invalid-offline-test-mode");
        RuntimeException failure = Assert.expectThrows(RuntimeException.class, MobileDriverManager::initDriver);
        Assert.assertTrue(failure.getCause() instanceof IllegalArgumentException, String.valueOf(failure.getCause()));
        Assert.assertNull(MobileDriverManager.getDriver());
        Assert.assertEquals(ApplicationHooks.takeScreenshot("offline_setup_failure", Platform.MOBILE), "");
        Assert.assertEquals(MobileDriverManager.quitDriver(false, "setup failed"), MobileDriverManager.QuitOutcome.NO_DRIVER);
    }

    @Test
    public void leftoverSessionIsRefused() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            mobileContext();
            bindManager(server.driver());
            Assert.expectThrows(RuntimeException.class, MobileDriverManager::initDriver);
        }
    }

    @Test
    public void maskedCopyHidesSecretsAndKeepsFrames() {
        IOException root = new IOException("accessKey: test-secret, https://user:password@host/wd/hub");
        RuntimeException outer = new RuntimeException("Authorization: Basic dXNlcjpwYXNz", root);
        outer.addSuppressed(new IOException("password=another-secret"));
        Throwable safe = LogUtils.sanitized(outer);
        String trace = LogUtils.getFullStackTrace(safe);
        Assert.assertFalse(trace.contains("test-secret"), trace);
        Assert.assertFalse(trace.contains("another-secret"), trace);
        Assert.assertFalse(trace.contains("dXNlcjpwYXNz"), trace);
        Assert.assertFalse(trace.contains("user:password@"), trace);
        Assert.assertTrue(trace.contains("java.io.IOException"), trace);
        Assert.assertEquals(safe.getCause().getStackTrace(), root.getStackTrace());
        Assert.assertEquals(safe.getSuppressed().length, 1);
        Assert.assertTrue(LogUtils.containsSecret(outer));
        Assert.assertFalse(LogUtils.containsSecret(new IllegalStateException("element not found")));
    }

    @Test
    public void browserStackConfigHasNoCredentialsInUrlOrCapabilities() throws Exception {
        System.setProperty("BS_READ_TIMEOUT_SECONDS", "7");
        ClientConfig config = MobileDriverManager.createBrowserStackClientConfig();
        Assert.assertNull(config.baseUri().getUserInfo());
        Assert.assertNull(config.credentials(), "authentication is a preemptive header, not a JDK Authenticator");
        Assert.assertEquals(config.readTimeout(), Duration.ofSeconds(7));
        String caps = MobileDriverManager.getBrowserStackAndroidOptions().asMap().toString();
        Assert.assertFalse(caps.contains("accessKey"), caps);
        Assert.assertFalse(caps.contains("userName"), caps);
        System.setProperty("BS_READ_TIMEOUT_SECONDS", "0");
        Assert.expectThrows(IllegalStateException.class, MobileDriverManager::createBrowserStackClientConfig);
    }

    @Test
    public void credentialsTravelInAHeaderNotTheUrl() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            AppiumDriver driver = server.driver();
            try {
                Assert.assertTrue(String.valueOf(server.authorization.get()).startsWith("Basic "));
                Assert.assertEquals(server.sessionPath.get(), "/session");
            } finally {
                driver.quit();
            }
        }
    }

    @Test
    public void missingElementFailsAsLocatorWithOneFailureScreenshot() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            ScenarioContext ctx = mobileContext();
            AppiumDriver driver = bindManager(server.driver());
            ctx.setMobileDriver(driver);
            MobileUI ui = new MobileUI(ctx, null, Duration.ofMillis(10));
            AssertionError failure = Assert.expectThrows(AssertionError.class, () -> ui.verifyText("Missing|id|missing", "x"));
            Assert.assertTrue(failure.getMessage().startsWith("[LOCATOR]"), failure.getMessage());
            Assert.assertTrue(LogUtils.getFullStackTrace(failure).contains("org.openqa.selenium.TimeoutException"));
            Assert.assertTrue(ctx.isFailureScreenshotTaken());
            ui.captureFailureScreenshot(); // a second request in the same scenario takes nothing
            Assert.assertEquals(server.screenshots.get(), 1);
            Assert.assertTrue(MobileDriverManager.isSessionUsable(), "a missing element does not end the session");
        }
    }

    @Test
    public void brokenScreenshotStopsScreenshotsButSessionContinues() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            ScenarioContext ctx = mobileContext();
            AppiumDriver driver = bindManager(server.driver());
            ctx.setMobileDriver(driver);
            MobileUI ui = new MobileUI(ctx, null);
            server.truncateScreenshot = true;
            ui.captureScreenshot();
            Assert.assertTrue(ctx.isScreenshotsSuppressed());
            Assert.assertTrue(MobileDriverManager.isSessionUsable(), "a failed screenshot alone does not end the session");
            Assert.assertEquals(driver.getPageSource(), "<hierarchy/>");
            ui.captureScreenshot();
            Assert.assertEquals(server.screenshots.get(), 1);
        }
    }

    @Test
    public void lostConnectionMarksSessionAndKeywordsFailFast() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            ScenarioContext ctx = mobileContext();
            AppiumDriver driver = bindManager(server.driver());
            ctx.setMobileDriver(driver);
            MobileUI ui = new MobileUI(ctx, null, Duration.ofSeconds(1));
            server.dropElements = true;
            Assert.expectThrows(Exception.class, () -> ui.isElementEnabled("Field|id|anything"));
            Assert.assertFalse(MobileDriverManager.isSessionUsable(), MobileDriverManager.sessionLostReason());
            AssertionError next = Assert.expectThrows(AssertionError.class, () -> ui.getText("Field|id|anything"));
            Assert.assertTrue(next.getMessage().startsWith("[SESSION]"), next.getMessage());
            Assert.assertEquals(server.screenshots.get(), 0, "no screenshot is requested from a lost session");
        }
    }

    @Test
    public void unusableSessionIsMarkedThroughRestAndQuitOnce() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            mobileContext();
            bindManager(server.driver());
            MobileDriverManager.markSessionUnusable("test: connection lost");
            Assert.assertEquals(MobileDriverManager.quitDriver(false, "lookup failed", server.apiConfig()),
                    MobileDriverManager.QuitOutcome.QUIT);
            Assert.assertEquals(MobileDriverManager.quitDriver(false, "duplicate teardown"),
                    MobileDriverManager.QuitOutcome.NO_DRIVER);
            Assert.assertEquals(server.statusCalls.get(), 0);
            Assert.assertEquals(server.restStatusCalls.get(), 1);
            Assert.assertEquals(server.deletes.get(), 1);
            JsonNode record = statusRecord();
            Assert.assertTrue(record.get("confirmed").asBoolean());
            Assert.assertEquals(record.get("channel").asText(), "rest-api");
        }
    }

    @Test
    public void usableSessionIsMarkedThroughTheSessionThenQuit() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            mobileContext();
            bindManager(server.driver());
            MobileDriverManager.quitDriver(false, "Reason with quotes \" and newline\n", server.apiConfig());
            Assert.assertEquals(server.statusCalls.get(), 1);
            Assert.assertEquals(server.restStatusCalls.get(), 0);
            Assert.assertEquals(server.deletes.get(), 1);
            Assert.assertTrue(server.resultBody.get().contains("failed"), server.resultBody.get());
        }
    }

    @Test
    public void deadSessionDuringStatusFallsBackToRest() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            mobileContext();
            bindManager(server.driver());
            server.failStatus = true;
            MobileDriverManager.quitDriver(false, "action failed", server.apiConfig());
            Assert.assertEquals(server.statusCalls.get(), 1);
            Assert.assertEquals(server.restStatusCalls.get(), 1);
            Assert.assertEquals(server.deletes.get(), 1);
            Assert.assertTrue(server.resultBody.get().contains("failed"));
        }
    }

    @Test
    public void failedRestCallLeavesPendingRecordAndStillQuits() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            mobileContext();
            bindManager(server.driver());
            MobileDriverManager.markSessionUnusable("test: session gone");
            server.failRest = true;
            MobileDriverManager.quitDriver(false, "failed", server.apiConfig());
            JsonNode record = statusRecord();
            Assert.assertFalse(record.get("confirmed").asBoolean());
            Assert.assertEquals(record.get("status").asText(), "failed");
            Assert.assertEquals(server.deletes.get(), 1);
            Assert.assertNull(MobileDriverManager.getDriver());
        }
    }

    @Test
    public void parallelScenariosDoNotShareSessionState() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            ExecutorService workers = Executors.newFixedThreadPool(2);
            try {
                Future<Boolean> lost = workers.submit(() -> {
                    try {
                        bindManager(server.driver());
                        MobileDriverManager.markSessionUnusable("test: lost on this thread");
                        return MobileDriverManager.isSessionUsable();
                    } finally {
                        MobileDriverManager.quitDriver();
                    }
                });
                Future<Boolean> healthy = workers.submit(() -> {
                    try {
                        bindManager(server.driver());
                        Thread.sleep(200); // poll gap: the other thread marks its session meanwhile
                        return MobileDriverManager.isSessionUsable();
                    } finally {
                        MobileDriverManager.quitDriver();
                    }
                });
                Assert.assertFalse(lost.get());
                Assert.assertTrue(healthy.get());
            } finally {
                workers.shutdownNow();
            }
        }
    }

    // ---------------------------------------------------------------

    static ScenarioContext mobileContext() {
        ScenarioContext ctx = new ScenarioContext();
        ctx.setPlatform(Platform.MOBILE);
        ctx.setCurrentModule("Offline");
        ctx.setScenarioId("offline_mobile_regression");
        ScenarioContext.set(ctx);
        return ctx;
    }

    /** Makes the driver the current thread's framework session (as initDriver would), on "BrowserStack". */
    @SuppressWarnings("unchecked")
    static AppiumDriver bindManager(AppiumDriver driver) throws Exception {
        var field = MobileDriverManager.class.getDeclaredField("DRIVER");
        field.setAccessible(true);
        ((ThreadLocal<AppiumDriver>) field.get(null)).set(driver);
        var mode = MobileDriverManager.class.getDeclaredField("EXECUTION_MODE");
        mode.setAccessible(true);
        ((ThreadLocal<String>) mode.get(null)).set("browserstack");
        return driver;
    }

    private static JsonNode statusRecord() throws Exception {
        return new ObjectMapper().readTree(BrowserStackRestStatus.recordDirectory().resolve("offline-session.json").toFile());
    }
}
