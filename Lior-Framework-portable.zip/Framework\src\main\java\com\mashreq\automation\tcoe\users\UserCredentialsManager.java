package com.mashreq.automation.tcoe.users;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.automation.tcoe.constants.FrameworkConstants;
import com.mashreq.automation.tcoe.utils.LogUtils;
import lombok.Data;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

public final class UserCredentialsManager {

    /**
     * Created on first use (holder idiom). A missing / broken users file now fails every web scenario with the same
     * clear error; the eager static instance gave ExceptionInInitializerError once, then NoClassDefFoundError.
     */
    private static final class Holder {
        private static final UserCredentialsManager INSTANCE = new UserCredentialsManager();
    }

    private static volatile RuntimeException initFailure;
    private BlockingQueue<UserPair> availableUsers;
    private int totalPairs;

    @Data
    private static class UserConfig {
        @JsonProperty("user_pairs")
        private List<UserPair> userPairs;
    }

    private UserCredentialsManager() {
        try {
            LogUtils.info("Initializing UserCredentialsManager...");

            // ======================= START OF THE FIX =======================
            // Read the file directly from the project's root directory.
            // System.getProperty("user.dir") gets the main project folder path.
            String filePath = System.getProperty("user.dir") + File.separator + "testdata" + File.separator + "Users" + File.separator + FrameworkConstants.REGION + "_users.json";
            File userFile = new File(filePath);

            if (!userFile.exists()) {
                throw new FileNotFoundException("Could not find users.json at path: " + userFile.getAbsolutePath());
            }

            UserConfig config;
            try (InputStream is = new FileInputStream(userFile)) { // closed (was left open)
                config = new ObjectMapper().readValue(is, UserConfig.class);
            }
            List<UserPair> loadedPairs = config.getUserPairs();

            if (loadedPairs == null || loadedPairs.isEmpty()) {
                throw new RuntimeException("No user pairs found in users.json. The 'user_pairs' array is missing or empty.");
            }

            totalPairs = loadedPairs.size();
            availableUsers = new ArrayBlockingQueue<>(loadedPairs.size());
            availableUsers.addAll(loadedPairs);

            LogUtils.info("User pool initialized with " + availableUsers.size() + " user pairs.");

        } catch (Exception e) {
            LogUtils.error("FATAL: Could not initialize UserCredentials-Manager.", e);
            throw new RuntimeException("Failed to load user credentials from users.json", e);
        }
    }

    public static UserCredentialsManager getInstance() {
        if (initFailure != null) {
            throw initFailure;
        }
        try {
            return Holder.INSTANCE;
        } catch (ExceptionInInitializerError | NoClassDefFoundError e) {
            Throwable cause = e instanceof ExceptionInInitializerError && e.getCause() != null ? e.getCause() : e;
            initFailure = cause instanceof RuntimeException re ? re
                    : new IllegalStateException("Failed to load user credentials from the users file", cause);
            throw initFailure;
        }
    }

    /** Max time a scenario waits for a free user pair. Override with -DUSER_POOL_TIMEOUT_SECONDS=<n>. */
    private static long timeoutSeconds() {
        try {
            return Long.parseLong(System.getProperty("USER_POOL_TIMEOUT_SECONDS", String.valueOf(DEFAULT_TIMEOUT_SECONDS)).trim());
        } catch (NumberFormatException e) {
            return DEFAULT_TIMEOUT_SECONDS;
        }
    }

    private static final long DEFAULT_TIMEOUT_SECONDS = 300;

    public UserPair checkoutUserPair() {
        long timeout = timeoutSeconds();
        try {
            LogUtils.info("Thread '" + Thread.currentThread().getName() + "' is waiting to check out a user pair...");
            UserPair userPair = availableUsers.poll(timeout, TimeUnit.SECONDS);
            if (userPair == null) {
                throw new IllegalStateException("No user pair became available within " + timeout + "s. "
                        + "Pool size is " + totalPairs + ". Either add more pairs to the users JSON, reduce the thread count, "
                        + "or check that an earlier scenario did not fail to return its pair.");
            }
            LogUtils.info("Thread '" + Thread.currentThread().getName() + "' has checked out user pair: " + userPair.getPairId());
            return userPair;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Thread was interrupted while waiting for a user pair.", e);
        }
    }

    public void checkinUserPair(UserPair userPair) {
        if (userPair == null) return;
        LogUtils.info("Thread '" + Thread.currentThread().getName() + "' is checking in user pair: " + userPair.getPairId());
        // offer() never blocks; contains() stops the same pair being returned twice and overfilling the pool.
        if (availableUsers.contains(userPair) || !availableUsers.offer(userPair)) {
            LogUtils.warn("User pair '" + userPair.getPairId() + "' was already in the pool; ignoring duplicate check-in.");
        }
    }
}