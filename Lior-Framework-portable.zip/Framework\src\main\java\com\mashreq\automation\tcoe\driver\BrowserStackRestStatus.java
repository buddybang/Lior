package com.mashreq.automation.tcoe.driver;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.automation.tcoe.constants.FrameworkConstants;
import org.openqa.selenium.remote.http.ClientConfig;
import org.openqa.selenium.remote.http.Contents;
import org.openqa.selenium.remote.http.HttpClient;
import org.openqa.selenium.remote.http.HttpMethod;
import org.openqa.selenium.remote.http.HttpRequest;
import org.openqa.selenium.remote.http.HttpResponse;

import java.net.Proxy;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;

/**
 * Marks a BrowserStack App Automate session through the REST API
 * (PUT https://api-cloud.browserstack.com/app-automate/sessions/<id>.json), which works also when the Appium connection
 * of the session is gone, and keeps a local record of every result in target/browserstack-status/.
 * Ported from Framework_Fixed (BrowserStackResultReporter), 2026-10-06.
 */
final class BrowserStackRestStatus {

    private BrowserStackRestStatus() {
    }

    static void update(ClientConfig config, String session, boolean passed, String reason) throws Exception {
        if (session == null || !session.matches("[A-Za-z0-9-]+")) {
            throw new IllegalArgumentException("Invalid BrowserStack session id: " + session);
        }
        String json = new ObjectMapper().writeValueAsString(
                Map.of("status", passed ? "passed" : "failed", "reason", reason == null ? "" : reason));
        try (HttpClient client = HttpClient.Factory.createDefault().createClient(config)) {
            HttpRequest request = new HttpRequest(HttpMethod.PUT, "/app-automate/sessions/" + session + ".json");
            request.setHeader("Content-Type", "application/json");
            request.setContent(Contents.utf8String(json));
            HttpResponse response = client.execute(request);
            if (response.getStatus() < 200 || response.getStatus() >= 300) {
                throw new IllegalStateException("BrowserStack REST API answered HTTP " + response.getStatus());
            }
        }
    }

    /** api-cloud.browserstack.com with the account credentials (header) and the same proxy as the sessions. */
    static ClientConfig config() throws Exception {
        ClientConfig config = MobileDriverManager.withCredentials(
                ClientConfig.defaultConfig()
                        .baseUrl(new URL("https://api-cloud.browserstack.com"))
                        .connectionTimeout(Duration.ofSeconds(10))
                        .readTimeout(Duration.ofSeconds(15)),
                FrameworkConstants.BROWSERSTACK_USERNAME,
                FrameworkConstants.BROWSERSTACK_ACCESS_KEY);
        Proxy proxy = MobileDriverManager.getBrowserStackProxy();
        return proxy == null ? config : config.proxy(proxy);
    }

    /** Folder of the result records; -DBS_STATUS_DIR=... (the offline tests use their own, so no fake session is synced). */
    static Path recordDirectory() {
        return Paths.get(System.getProperty("BS_STATUS_DIR", "target/browserstack-status"));
    }

    /** target/browserstack-status/<session>.json, written atomically. */
    static void record(String session, boolean passed, String reason, boolean confirmed, String channel) throws Exception {
        Path directory = recordDirectory();
        Files.createDirectories(directory);
        Path temporary = Files.createTempFile(directory, "result-", ".tmp");
        try {
            new ObjectMapper().writerWithDefaultPrettyPrinter().writeValue(temporary.toFile(), Map.of(
                    "sessionId", session,
                    "status", passed ? "passed" : "failed",
                    "reason", reason == null ? "" : reason,
                    "confirmed", confirmed,
                    "channel", channel,
                    "recordedAt", Instant.now().toString()));
            Files.move(temporary, directory.resolve(session + ".json"), StandardCopyOption.REPLACE_EXISTING);
        } finally {
            Files.deleteIfExists(temporary);
        }
    }
}
