package com.mashreq.automation.tcoe.utils;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Offline tests of run-groups.properties (no device, no browser). Run: mvn test -Pmobile-regression.
 * The project folder is pointed at target/scenario-groups-test for each test, with its own run-groups.properties.
 */
public class ScenarioGroupsRegressionTest {

    private static final String[] KEYS = {"user.dir", "cucumber.filter.name", "cucumber.filter.tags", "RUN_GROUP"};
    private final String[] saved = new String[KEYS.length];
    private Path dir;

    @BeforeMethod
    public void remember() throws Exception {
        for (int i = 0; i < KEYS.length; i++) {
            saved[i] = System.getProperty(KEYS[i]);
        }
        dir = Paths.get(System.getProperty("user.dir"), "target", "scenario-groups-test");
        Files.createDirectories(dir);
        System.clearProperty("cucumber.filter.name");
        System.clearProperty("RUN_GROUP");
    }

    @AfterMethod(alwaysRun = true)
    public void restore() {
        for (int i = 0; i < KEYS.length; i++) {
            if (saved[i] == null) {
                System.clearProperty(KEYS[i]);
            } else {
                System.setProperty(KEYS[i], saved[i]);
            }
        }
    }

    private void groups(String content, String tags) throws Exception {
        Files.write(dir.resolve(ScenarioGroups.FILE_NAME), content.getBytes(StandardCharsets.UTF_8));
        System.setProperty("user.dir", dir.toString());
        System.setProperty("cucumber.filter.tags", tags);
    }

    @Test
    public void journeyRunIsOnlyTheJourneyProfile() {
        Assert.assertTrue(ScenarioGroups.isJourneyRun("@Journey and not @WIP"));
        Assert.assertTrue(ScenarioGroups.isJourneyRun("@Journey_TxnApproval"));
        Assert.assertFalse(ScenarioGroups.isJourneyRun("@Mobile and not @WIP and not @Journey"));
        Assert.assertFalse(ScenarioGroups.isJourneyRun("@Web and not @WIP and not @Journey"));
        Assert.assertFalse(ScenarioGroups.isJourneyRun(""));
    }

    /** The bug: on -Pmobile the group was never used ("Journey run (@Mobile and not @WIP and not @Journey)"). */
    @Test
    public void mobileRunUsesTheGroup() throws Exception {
        groups("RUN_GROUP=oat\noat=OAT|SC_001\n", "@Mobile and not @WIP and not @Journey");
        ScenarioGroups.apply();
        String name = System.getProperty("cucumber.filter.name");
        Assert.assertNotNull(name, "the group must be used on a mobile run");
        Assert.assertTrue("OAT|SC_001|OAT".matches(name + ".*"), name);
        Assert.assertFalse("OAT|SC_0010|Other".matches(name + ".*"), name);
    }

    @Test
    public void journeyGroupPicksWholeJourneysByTag() throws Exception {
        groups("RUN_GROUP=approvals\napprovals=@Journey_TxnApproval, Journey_Payroll\n", "@Journey and not @WIP");
        ScenarioGroups.apply();
        Assert.assertEquals(System.getProperty("cucumber.filter.tags"),
                "(@Journey and not @WIP) and (@Journey_TxnApproval or @Journey_Payroll)");
        Assert.assertNull(System.getProperty("cucumber.filter.name"), "never a name filter on parts of a journey");
    }

    @Test
    public void journeyRunIgnoresAGroupOfSingleScenarios() throws Exception {
        groups("RUN_GROUP=oat\noat=OAT|SC_001\n", "@Journey and not @WIP");
        ScenarioGroups.apply();
        Assert.assertEquals(System.getProperty("cucumber.filter.tags"), "@Journey and not @WIP");
        Assert.assertNull(System.getProperty("cucumber.filter.name"));
    }

    @Test
    public void journeyRunWithAllRunsEveryJourney() throws Exception {
        groups("RUN_GROUP=all\napprovals=@Journey_TxnApproval\n", "@Journey and not @WIP");
        ScenarioGroups.apply();
        Assert.assertEquals(System.getProperty("cucumber.filter.tags"), "@Journey and not @WIP");
    }

    @Test
    public void mixedGroupOnMobileKeepsTheScenariosAndLeavesJourneysOut() throws Exception {
        groups("RUN_GROUP=smoke\nsmoke=OAT|SC_001, @Journey_TxnApproval\n", "@Mobile and not @WIP and not @Journey");
        ScenarioGroups.apply();
        String name = System.getProperty("cucumber.filter.name");
        Assert.assertTrue("OAT|SC_001|OAT".matches(name + ".*"), name);
        Assert.assertEquals(System.getProperty("cucumber.filter.tags"), "@Mobile and not @WIP and not @Journey");
    }

    @Test
    public void onlyJourneysOnAMobileRunSaysUseTheJourneyProfile() throws Exception {
        groups("RUN_GROUP=approvals\napprovals=@Journey_TxnApproval\n", "@Mobile and not @WIP and not @Journey");
        IllegalStateException e = Assert.expectThrows(IllegalStateException.class, ScenarioGroups::apply);
        Assert.assertTrue(e.getMessage().contains("-Pjourney"), e.getMessage());
    }
}
