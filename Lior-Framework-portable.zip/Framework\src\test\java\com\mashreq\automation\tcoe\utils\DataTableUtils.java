package com.mashreq.automation.tcoe.utils;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import io.cucumber.datatable.DataTable;

import java.util.*;

/**
 * Utility class to standardize parsing of Cucumber DataTables across step definitions.
 *
 * <p>This class enforces consistency in how DataTables are interpreted, ensuring that
 * all teams use the same reliable parsing logic. It supports the three most common formats:
 *
 * <ul>
 *     <li><b>Single-column</b>: Field names only (values fetched from external test data).</li>
 *     <li><b>Two-column</b>: Key-value pairs (values provided inline in the feature file).</li>
 *     <li><b>Multi-column</b>: Structured rows with headers (mapped into maps or POJOs).</li>
 * </ul>
 *
 * <p><b>Why centralize?</b>
 * Teams of 20+ contributors avoid duplication, reduce parsing errors, and keep
 * their Step Definitions business-focused instead of re-implementing table parsing logic.
 */
public final class DataTableUtils {

    private DataTableUtils() {
        // Prevent instantiation
    }

    // ----------------------------------------------------------------------
    //  1 & 2 COLUMN SUPPORT (toMap)
    // ----------------------------------------------------------------------

    /**
     * Converts a 1 or 2-column DataTable into a {@code Map<String, String>}.
     *
     * <p>Supported formats:
     *
     * <p><b>1-Column Table (Fields only):</b>
     * Each row contains a field name. The value for each field will be fetched
     * from the test data JSON via {@link DataHandler}.
     * <pre>
     * | FieldName    |
     * |--------------|
     * | CustomerName |
     * | AccountType  |
     * </pre>
     *
     * <p><b>2-Column Table (Key-Value):</b>
     * Each row is a field name and its value, directly provided in the feature file.
     * <pre>
     * | FieldName    | Value              |
     * |--------------|--------------------|
     * | CustomerName | John Doe           |
     * | AccountType  | SAVINGS_PREMIUM    |
     * </pre>
     *
     * <p><b>Notes:</b>
     * <ul>
     *     <li>Values are {@code trimmed()} to avoid whitespace issues.</li>
     *     <li>Duplicate keys in 2-column format will throw an exception.</li>
     *     <li>Scenario ID is resolved automatically via {@link DataHandler#getScenarioId()}.</li>
     * </ul>
     *
     * @param table       The DataTable provided in the step.
     * @param dataHandler Instance of DataHandler to look up external test data (for 1-column).
     * @param module      Module name required for test data lookup.
     * @return An immutable {@code Map<String,String>} with resolved field-value pairs.
     * @throws IllegalArgumentException if required test data is missing or keys are empty.
     * @throws UnsupportedOperationException if the table has more than 2 columns.
     */
    public static Map<String, String> toMap(DataTable table, DataHandler dataHandler, String module) {
        return toMap(table, dataHandler, module, ScenarioContext.get().getScenarioId());
    }

    /**
     * Variant of {@link #toMap(DataTable, DataHandler, String)} allowing an explicit scenarioId.
     *
     * @param table       The DataTable.
     * @param dataHandler Data handler.
     * @param module      Module name.
     * @param scenarioId  Explicit scenario identifier (instead of auto-detected).
     * @return Immutable map of field → value.
     */
    public static Map<String, String> toMap(DataTable table, DataHandler dataHandler, String module, String scenarioId) {
        requireNonEmpty(table);
        int width = table.width();

        if (width == 1) {
            // Single-column: lookup values
            List<String> fields = table.asList(String.class).stream()
                    .map(String::trim).filter(s -> !s.isEmpty()).toList();

            LogUtils.debug("Resolving " + fields.size() +
                    " fields from test data (module='" + module +
                    "', scenario='" + scenarioId + "')");

            Map<String, String> out = new LinkedHashMap<>();
            for (String field : fields) {
                String value = dataHandler.getTestDataOrThrow(module, scenarioId, field);
                out.put(field, value);
            }
            return Collections.unmodifiableMap(out);
        }

        if (width == 2) {
            // Two-column: direct KV usage
            List<List<String>> rows = table.asLists(String.class);
            Map<String, String> out = new LinkedHashMap<>();
            Set<String> seen = new HashSet<>();

            for (List<String> row : rows) {
                String k = trimOrEmpty(row.get(0));
                String v = trimOrEmpty(row.get(1));
                if (k.isEmpty()) {
                    throw new IllegalArgumentException("Empty key in 2-column DataTable row: " + row);
                }
                if (!seen.add(k)) {
                    throw new IllegalArgumentException("Duplicate key '" + k + "' in DataTable.");
                }
                out.put(k, v);
            }
            LogUtils.debug("Parsed " + out.size() + " key/value pairs directly from DataTable.");
            return Collections.unmodifiableMap(out);
        }

        throw new UnsupportedOperationException(
                "Unsupported DataTable shape: expected 1 or 2 columns, got " + width +
                        ". For multi-column, use toListOfMaps() or toList().");
    }

    // ----------------------------------------------------------------------
    //  MULTI-ROW / MULTI-COLUMN SUPPORT
    // ----------------------------------------------------------------------

    /**
     * Converts a multi-column DataTable into a list of maps,
     * where each row becomes a {@code Map<header,value>}.
     *
     * <p><b>Example:</b>
     * <pre>
     * | FirstName | LastName | Type   |
     * |-----------|----------|--------|
     * | John      | Doe      | RETAIL |
     * | Jane      | Smith    | SME    |
     * </pre>
     *
     * → Produces:
     * <pre>
     * [
     *   {FirstName=John, LastName=Doe, Type=RETAIL},
     *   {FirstName=Jane, LastName=Smith, Type=SME}
     * ]
     * </pre>
     *
     * @param table DataTable with headers + rows.
     * @return Immutable list of row-maps.
     */
    public static List<Map<String, String>> toListOfMaps(DataTable table) {
        requireNonEmpty(table);
        List<Map<String, String>> rows = table.asMaps(String.class, String.class).stream()
                .map(DataTableUtils::trimMap).toList();
        LogUtils.debug("Parsed " + rows.size() + "row(s) into list-of-maps from DataTable.");
        return Collections.unmodifiableList(rows);
    }

    /**
     * Converts a multi-column DataTable into a list of strongly typed POJOs.
     * Field names in the DataTable header must match POJO property names.
     *
     * <p><b>Example:</b>
     * <pre>
     * | firstName | lastName | type   |
     * |-----------|----------|--------|
     * | John      | Doe      | RETAIL |
     * </pre>
     *
     * With:
     * <pre>
     * class Customer {
     *   private String firstName;
     *   private String lastName;
     *   private String type;
     *   // getters & setters
     * }
     * </pre>
     *
     * Usage:
     * <pre>
     * List<Customer> customers = DataTableUtils.toList(table, Customer.class);
     * </pre>
     *
     * @param table      DataTable with headers + rows.
     * @param targetType Target POJO class type.
     * @param <T>        Generic type for mapping.
     * @return Immutable list of typed objects.
     */
    public static <T> List<T> toList(DataTable table, Class<T> targetType) {
        requireNonEmpty(table);
        List<T> out = table.asList(targetType);
        LogUtils.debug("Mapped " + out.size() + " row(s) to " + targetType.getSimpleName());
        return Collections.unmodifiableList(out);
    }

    // ----------------------------------------------------------------------
    //  INTERNAL HELPERS
    // ----------------------------------------------------------------------

    private static void requireNonEmpty(DataTable table) {
        if (table == null || table.isEmpty()) {
            throw new IllegalArgumentException("DataTable is null or empty.");
        }
    }

    private static String trimOrEmpty(String s) {
        return s == null ? "" : s.trim();
    }

    private static Map<String, String> trimMap(Map<String, String> in) {
        Map<String, String> out = new LinkedHashMap<>();
        in.forEach((k, v) -> out.put(trimOrEmpty(k), trimOrEmpty(v)));
        return out;
    }
}
