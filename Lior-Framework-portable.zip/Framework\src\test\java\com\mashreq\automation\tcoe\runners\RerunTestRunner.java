package com.mashreq.automation.tcoe.runners;

import com.mashreq.automation.tcoe.utils.LogUtils;
import com.mashreq.automation.tcoe.reporting.DashboardGenerator;
import com.mashreq.automation.tcoe.reporting.FeatureDetailsGenerator;
import com.mashreq.automation.tcoe.utils.ReportUtils;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.DataProvider;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@CucumberOptions(
        // Path to your feature files
         features = {"@target/rerun.txt"},

        // Package containing your step definitions, hooks, and context
        glue = "com.mashreq.automation.tcoe",

        // Generates different report formats
        plugin = {
                "pretty",
                // own file names: the rerun used to overwrite the first run's results
                "html:reports/latest/cucumber-reports/cucumber-report-rerun.html",
                "json:reports/latest/cucumber-reports/cucumber-report-rerun.json",
                "io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
                "json:target/cucumber-reports/cucumber-rerun.json", // the HTML report reads every JSON here: first run + rerun
                "com.mashreq.automation.tcoe.listeners.StepEventListener",
                "rerun:target/rerun_1.txt" //To write failed scenarios
        },

        monochrome = true

        //You can specify tags to run specific scenarios
//        tags = "@Regression"
//        tags = "@CustomerMaintenance"
//        tags = "@AccountMaintenance"
//        tags =  ""
      // tags ="@CASA and @Day1 and ( @SC_002 or @SC_019 or @SC_013)"
                //tags = " or @SC_016 or @SC_007 or @SC_020 or @SC_016 or SC_015)"
        //tags ="@CASA and @Day0 and (@SC_020)"
        // tags = "@SC_004 and @Day1"//"@CIF" //"@SC_008_Day1"// "@SC_007_Day1"//"@SC_008_Day1 or  //"@SC_011_D1"//"@SC_004 or @SC_006 and @CIF"//"@SC_012_D1 or SC_012_D2"//"@SC_006_D1 and @SI" //or @AccountMaintenance"
)

public class RerunTestRunner extends AbstractTestNGCucumberTests {

    static {
        // read by ApplicationHooks.beforeAll: a rerun adds to the first run's reports/latest instead of moving it to the backup
        System.setProperty("RERUN", "true");
    }

    /**
     * This method enables parallel execution of scenarios.
     * The @DataProvider(parallel = true) annotation tells TestNG that the scenarios
     * returned by the superclass method can be distributed among worker threads.
     */
    @Override
    @DataProvider(parallel = true) // This will be overridden dynamically
    public Object[][] scenarios() {
        boolean isParallel = Boolean.parseBoolean(System.getProperty("parallel", "false"));
        System.setProperty("dataprovider.parallel", String.valueOf(isParallel));
        return super.scenarios();
    }

    /**
     * This method generates the Maven Cucumber report.
     * IMPORTANT: The 'ReportUtils.generateCucumberReport()' method must also be
     * configured internally to read from "target/cucumber-reports/cucumber.json".
     */
    @AfterSuite(alwaysRun = true)
    public void generateReportsAfterSuite() {
        ReportUtils.generateCucumberReport();
    }


    /**
     * This method generates our custom FreeMarker dashboard report.
     */
    @AfterSuite(alwaysRun = true) // Added alwaysRun = true for consistency
    public void generateCustomReport() {
        try {
            System.out.println("Starting custom report generation...");

            // Path to point to the JSON file generated required for Custom Report
            String userDir = System.getProperty("user.dir");
            String masterJsonPathStr = userDir + "/reports/latest/custom-report/json/master.json";
            String templateDirStr = userDir + "/src/main/resources/templates";
            String dashboardOutputPathStr = userDir + "/reports/latest/custom-report/Dashboard.html";

            // No scenario ran (ApplicationHooks.afterAll skipped aggregation), so there is nothing to report
            if (!Files.exists(Paths.get(masterJsonPathStr))) {
                LogUtils.warn("Custom report skipped: " + masterJsonPathStr + " was not created (no scenario ran).");
                return;
            }

            // Dashboard Report Generator
            DashboardGenerator.generateReport(masterJsonPathStr, templateDirStr, dashboardOutputPathStr);

            // Feature file HTML report generator

            // 1. Define paths
            Path reportsDir = Paths.get(userDir, "reports", "latest", "custom-report");
            Path jsonSourceDir = reportsDir.resolve("json");
            Path templateDir = Paths.get(templateDirStr);

            // 2. Initialize the generator
            FeatureDetailsGenerator reportGenerator = new FeatureDetailsGenerator(templateDir);

            // 3. Call the method to generate all feature reports
            reportGenerator.generateAllFeatureReports(jsonSourceDir, reportsDir);

        } catch (Exception e) {
            LogUtils.error("Could not generate the feature reports: " + e.getMessage(), e);
        }
    }
}