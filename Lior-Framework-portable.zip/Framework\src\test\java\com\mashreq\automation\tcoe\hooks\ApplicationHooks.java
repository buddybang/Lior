
package com.mashreq.automation.tcoe.hooks;

import com.mashreq.automation.tcoe.context.Platform;
import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.context.ScreenshotContextHolder;
import com.mashreq.automation.tcoe.driver.DriverManager;
import com.mashreq.automation.tcoe.driver.MobileDriverManager;
import com.mashreq.automation.tcoe.users.UserCredentialsManager;
import com.mashreq.automation.tcoe.users.UserPair;
import com.mashreq.automation.tcoe.utils.FeatureAggregator;
import com.mashreq.automation.tcoe.utils.Journey;
import com.mashreq.automation.tcoe.utils.LogUtils;
import com.mashreq.automation.tcoe.utils.ReportUtils;
import com.microsoft.playwright.Page;
import io.appium.java_client.AppiumDriver;
import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.Scenario;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.SkipException;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicInteger;

public class ApplicationHooks {

    private final ScenarioContext ctx;

    private Instant scenarioStartTime;

    private static Instant suiteStartTime;

    // Thread-safe scenario counter
    private static final AtomicInteger scenarioCounter =
            new AtomicInteger(0);

    public ApplicationHooks(ScenarioContext ctx) {
        this.ctx = ctx;
    }

    // ================================================================
    // BEFORE ALL
    // ================================================================

    @BeforeAll
    public static void beforeAll() throws IOException {

        if (Boolean.getBoolean("RERUN")) {
            LogUtils.info("Rerun of failed scenarios: the first run's reports/latest is kept (no backup).");
        } else {
            ReportUtils.backupReportsAndLogsDirectories();
        }

        suiteStartTime = Instant.now();
    }

    // ================================================================
    // BEFORE SCENARIO
    // ================================================================

    @Before
    public void setup(Scenario scenario) {

        // ============================================================
        // START TIME
        // ============================================================

        scenarioStartTime = Instant.now();

        // ============================================================
        // CHECKOUT USER FIRST
        // ============================================================

        // Maker/checker pairs are only used by web (Flexcube) scenarios. Mobile and API
        // scenarios skip the pool, so they never queue behind web tests and can run in
        // parallel on BrowserStack.
        Collection<String> scenarioTags =
                scenario.getSourceTagNames();

        boolean needsUserPair =
                !scenarioTags.contains("@Mobile")
                        && !scenarioTags.contains("@API");

        UserPair userPair = null;

        if (needsUserPair) {

            userPair =
                    UserCredentialsManager
                            .getInstance()
                            .checkoutUserPair();
        }

        final String userPairId =
                userPair != null
                        ? userPair.getPairId()
                        : "n/a (not required)";

        ctx.setUserPair(userPair);
        // WEB / MOBILE / API from the tags: decides which object repository folder this scenario reads
        ctx.setPlatform(Platform.fromTags(scenarioTags));

        ScenarioContext.set(ctx);

        // ============================================================
        // TEST CASE ID
        // ============================================================

        String caseId =
                ScenarioContext.consumePendingCaseId();

        ctx.setTestCaseId(caseId);

        // ============================================================
        // SCENARIO NAME
        // ============================================================

        String rawName =
                scenario.getName();

        String[] parts =
                rawName.split("\\|");

        if (parts.length >= 3) {

            String module =
                    parts[0].trim();

            String scnId =
                    parts[1].trim();

            String description =
                    parts[2].trim();

            ctx.setCurrentModule(module);
            ctx.setScenarioId(scnId);

            StringBuilder fileNameBuilder =
                    new StringBuilder();

            fileNameBuilder
                    .append(module)
                    .append("_")
                    .append(scnId);

            String currentTestCaseId =
                    ctx.getTestCaseId();

            if (currentTestCaseId != null
                    && !currentTestCaseId.trim().isEmpty()) {

                fileNameBuilder
                        .append("_")
                        .append(currentTestCaseId);
            }

            String sanitizedFileName =
                    fileNameBuilder
                            .toString()
                            .replaceAll(
                                    "[^a-zA-Z0-9-_]",
                                    "_"
                            );

            String threadContextName =
                    module + "_" + scnId;

            LogUtils.startScenario(
                    threadContextName,
                    "Log_" + sanitizedFileName
            );

            StringBuilder scenarioStartLog =
                    new StringBuilder();

            scenarioStartLog.append(
                    "\n-----------------------------------------------------------------\n"
            );

            scenarioStartLog.append(
                    "SCENARIO STARTED\n"
            );

            scenarioStartLog.append(
                    String.format(
                            "  - Module:         %s\n",
                            module
                    )
            );

            scenarioStartLog.append(
                    String.format(
                            "  - Scenario ID:    %s\n",
                            scnId
                    )
            );

            scenarioStartLog.append(
                    String.format(
                            "  - Description:    %s\n",
                            description
                    )
            );

            scenarioStartLog.append(
                    String.format(
                            "  - User Pair ID:   %s\n",
                            userPairId
                    )
            );

            scenarioStartLog.append(
                    String.format(
                            "  - Tags:           %s\n",
                            String.join(
                                    ", ",
                                    scenario.getSourceTagNames()
                            )
                    )
            );

            scenarioStartLog.append(
                    "-----------------------------------------------------------------"
            );

            LogUtils.info(
                    scenarioStartLog.toString()
            );

        } else {

            String logFileName =
                    rawName.replaceAll(
                            "[^a-zA-Z0-9-_]",
                            "_"
                    );

            LogUtils.startScenario(
                    logFileName,
                    "Log_" + logFileName
            );

            StringBuilder scenarioStartLog =
                    new StringBuilder();

            scenarioStartLog.append(
                    "\n-----------------------------------------------------------------\n"
            );

            scenarioStartLog.append(
                    "SCENARIO STARTED: "
            );

            scenarioStartLog
                    .append(logFileName)
                    .append("\n");

            scenarioStartLog.append(
                    String.format(
                            "  - User Pair ID:   %s\n",
                            userPairId
                    )
            );

            scenarioStartLog.append(
                    "  - Tags: "
            );

            scenarioStartLog
                    .append(
                            String.join(
                                    ", ",
                                    scenario.getSourceTagNames()
                            )
                    )
                    .append("\n");

            scenarioStartLog.append(
                    "-----------------------------------------------------------------"
            );

            LogUtils.info(
                    scenarioStartLog.toString()
            );
        }

        // ============================================================
        // JOURNEY (several scenarios that are one business case)
        // ============================================================

        Collection<String> tags =
                scenario.getSourceTagNames();

        // waits for the part before it; skipped (not failed) when that part did not pass
        String skipReason =
                Journey.beforePart(tags, scenario.getName());

        if (skipReason != null) {

            LogUtils.warn(skipReason);

            throw new SkipException(skipReason);
        }

        // ============================================================
        // DRIVER INITIALIZATION
        // ============================================================

        if (tags.contains("@Mobile")) {

            MobileDriverManager.initDriver();

            ctx.setMobileDriver(
                    MobileDriverManager.getDriver()
            );

            LogUtils.info(
                    "Mobile Driver started: "
                            + MobileDriverManager.getDeviceDetails()
            );

        } else if (tags.contains("@API")) {

            LogUtils.info(
                    "API scenario — no UI driver initialised."
            );

        } else {

            DriverManager.initDriver(browserTag(tags));

            Page page =
                    DriverManager.getPage();

            ctx.setPage(page);

            LogUtils.info(
                    "Web Driver started: "
                            + DriverManager.getBrowserVersion()
            );
        }
    }

    // ================================================================
    // AFTER SCENARIO
    // ================================================================

    @After
    public void afterScenario(Scenario scenario) {

        UserPair userPairToCheckin = null;

        try {

            // ========================================================
            // SCENARIO DURATION
            // ========================================================

            Instant scenarioEndTime =
                    Instant.now();

            Duration scenarioDuration =
                    Duration.between(
                            scenarioStartTime,
                            scenarioEndTime
                    );

            // ========================================================
            // FAILURE SCREENSHOT
            // ========================================================

            if (scenario.isFailed()) {

                if (ctx.isFailureScreenshotTaken()) {
                    LogUtils.info("Failure screenshot already taken by the failing step.");
                } else {
                    ctx.setFailureScreenshotTaken(true);
                    takeScreenshot(
                            ctx.getScenarioId(),
                            ctx.getPlatform()
                    );
                }
            }

            // ========================================================
            // SCENARIO END LOG
            // ========================================================

            StringBuilder scenarioEndLog =
                    new StringBuilder();

            scenarioEndLog.append(
                    "\n-----------------------------------------------------------------\n"
            );

            scenarioEndLog.append(
                    "SCENARIO FINISHED\n"
            );

            // ========================================================
            // USER PAIR
            // ========================================================

            userPairToCheckin =
                    ctx.getUserPair();

            if (userPairToCheckin != null) {

                scenarioEndLog.append(
                        String.format(
                                "  - User Pair ID:   %s (returned to pool)\n",
                                userPairToCheckin.getPairId()
                        )
                );
            }

            // ========================================================
            // SCENARIO INFORMATION
            // ========================================================

            scenarioEndLog.append(
                    "  - Name:           "
            );

            scenarioEndLog
                    .append(scenario.getName())
                    .append("\n");

            scenarioEndLog.append(
                    "  - Status:         "
            );

            scenarioEndLog
                    .append(scenario.getStatus())
                    .append("\n");

            scenarioEndLog.append(
                    String.format(
                            "  - Duration:       %d seconds (%d ms)\n",
                            scenarioDuration.toSeconds(),
                            scenarioDuration.toMillis()
                    )
            );

            scenarioEndLog.append(
                    "-----------------------------------------------------------------\n"
            );

            LogUtils.info(
                    scenarioEndLog.toString()
            );

        } catch (Exception e) {

            /*
             * Do not allow logging/screenshot problems to prevent
             * driver teardown and user check-in.
             */
            LogUtils.warn(
                    "Error while processing scenario completion: "
                            + e.getMessage()
            );

        } finally {

            // the next part of a journey waits for this result
            try {
                Journey.afterPart(scenario.getSourceTagNames(), String.valueOf(scenario.getStatus()));
            } catch (RuntimeException journeyEx) {
                LogUtils.warn("Journey bookkeeping failed: " + journeyEx.getMessage());
            }

            // ========================================================
            // DRIVER TEARDOWN
            // ========================================================

            try {

                Collection<String> tags =
                        scenario.getSourceTagNames();

                if (tags.contains("@Mobile")) {

                    /*
                     * MobileDriverManager.quitDriver()
                     * only quits the Appium driver.
                     *
                     * No video processing is performed.
                     */
                    MobileDriverManager.QuitOutcome outcome =
                            MobileDriverManager.quitDriver(
                                    // SKIPPED / UNDEFINED / PENDING are not "passed" (isFailed() is false for them)
                                    scenario.getStatus() == io.cucumber.java.Status.PASSED,
                                    scenario.getStatus() + ": " + scenario.getName()
                            );

                    switch (outcome) {
                        case QUIT:
                            LogUtils.info("Mobile driver closed.");
                            break;
                        case QUIT_FAILED:
                            LogUtils.warn("Mobile driver could not be closed cleanly (see the warning above); local state cleared.");
                            break;
                        default:
                            LogUtils.info("Mobile driver teardown skipped: no mobile session was started.");
                    }

                } else if (!tags.contains("@API")) {

                    /*
                     * Web driver cleanup.
                     */
                    // video named per test case (the scenario id alone, e.g. SC_001, is not unique across modules)
                    String videoName = (ctx.getCurrentModule() + "_" + ctx.getScenarioId() + "_" + ctx.getTestCaseId())
                            .replaceAll("[^a-zA-Z0-9-_]", "_");
                    Path video = DriverManager.closeDriver(videoName);
                    if (video != null) {
                        // the custom report shows the video of the scenario
                        com.mashreq.automation.tcoe.utils.FeatureStepCollector.setVideoPath(
                                "./" + Paths.get(System.getProperty("user.dir")).toAbsolutePath()
                                        .relativize(video.toAbsolutePath()).toString().replace("\\", "/"));
                    }

                    LogUtils.info(
                            "Web driver closed."
                    );

                } else {

                    LogUtils.info(
                            "API scenario — no UI driver to close."
                    );
                }

            } catch (Exception driverEx) {

                LogUtils.warn(
                        "Driver teardown failed (non-fatal): "
                                + driverEx.getMessage()
                );
            }

            // ========================================================
            // CHECK USER BACK INTO POOL
            // ========================================================

            if (userPairToCheckin != null) {

                UserCredentialsManager
                        .getInstance()
                        .checkinUserPair(
                                userPairToCheckin
                        );

            } else {

                /*
                 * Fallback in case the user pair was not assigned
                 * to userPairToCheckin before an exception occurred.
                 */
                UserPair finalUserPair =
                        ctx.getUserPair();

                if (finalUserPair != null) {

                    UserCredentialsManager
                            .getInstance()
                            .checkinUserPair(
                                    finalUserPair
                            );
                }
            }

            // ========================================================
            // CLEAR SCENARIO CONTEXT
            // ========================================================

            ScenarioContext.clear();

            // ========================================================
            // END SCENARIO LOG
            // ========================================================

            LogUtils.endScenario();

            // ========================================================
            // INCREMENT SCENARIO COUNTER
            // ========================================================

            scenarioCounter.incrementAndGet();
        }
    }

    // ================================================================
    // AFTER ALL
    // ================================================================

    @AfterAll
    public static void afterAll() {

        // ============================================================
        // SUITE DURATION
        // ============================================================

        Instant suiteEndTime =
                Instant.now();

        long suiteDurationMillis = 0;

        if (suiteStartTime != null) {

            suiteDurationMillis =
                    Duration.between(
                            suiteStartTime,
                            suiteEndTime
                    ).toMillis();
        }

        final long finalSuiteDuration =
                suiteDurationMillis;

        LogUtils.info(
                String.format(
                        "Total Suite Wall-Clock Duration: %d seconds.",
                        Duration
                                .ofMillis(finalSuiteDuration)
                                .toSeconds()
                )
        );

        // ============================================================
        // NO SCENARIOS RAN: nothing to wait for or aggregate
        // ============================================================

        if (scenarioCounter.get() == 0) {

            LogUtils.warn(
                    "No scenario was executed. Check that feature files exist for this profile and that "
                            + "cucumber.tags='" + System.getProperty("cucumber.filter.tags", "") + "' / "
                            + "cucumber.filter.name='" + System.getProperty("cucumber.filter.name", "") + "' "
                            + "(RUN_GROUP in run-groups.properties) match at least one scenario. Reports skipped."
            );

            return;
        }

        // ============================================================
        // WAIT FOR SCENARIO FILES
        // ============================================================

        LogUtils.info(
                "Waiting for all scenario JSON files to be saved..."
        );

        String aggregatorDirPath =
                FeatureAggregator.getScenarioDir();

        File aggregatorDir =
                new File(
                        aggregatorDirPath
                );

        int expectedCount =
                scenarioCounter.get();

        // ============================================================
        // WAIT FOR FILES
        // ============================================================

        int attempts = 0;

        final int MAX_ATTEMPTS = 30;

        while (attempts < MAX_ATTEMPTS) {

            if (!aggregatorDir.exists()) {

                LogUtils.warn(
                        "Scenario directory does not exist yet. Waiting..."
                );

                sleepForOneSecond();

                attempts++;

                continue;
            }

            File[] files =
                    aggregatorDir.listFiles(
                            f -> f.getName().endsWith(".js")
                    );

            if (files != null
                    && files.length >= expectedCount) {

                boolean allFilesHaveContent =
                        true;

                for (File file : files) {

                    if (file.length() == 0) {

                        allFilesHaveContent =
                                false;

                        break;
                    }
                }

                if (allFilesHaveContent) {

                    LogUtils.info(
                            "All "
                                    + files.length
                                    + " scenario files appear to be ready."
                    );

                    break;
                }
            }

            LogUtils.info(
                    "Waiting for scenario files... Found "
                            + (files != null
                            ? files.length
                            : 0)
                            + "/"
                            + expectedCount
            );

            sleepForOneSecond();

            attempts++;
        }

        // ============================================================
        // TIMEOUT
        // ============================================================

        if (attempts >= MAX_ATTEMPTS) {

            LogUtils.warn(
                    "Timeout waiting for all scenario JSON files "
                            + "to be completely written. "
                            + "Aggregator may miss some data."
            );
        }

        // ============================================================
        // GENERATE REPORTS
        // ============================================================

        LogUtils.info(
                "Generating aggregated reports..."
        );

        // Azure DevOps exposes the variable Build.BuildId to scripts as BUILD_BUILDID ("Build.BuildId" is never set);
        // -DBUILD_NUMBER=... wins, e.g. for another CI server
        String buildNumber =
                System.getProperty("BUILD_NUMBER",
                        System.getenv("BUILD_BUILDID"));

        if (buildNumber == null
                || buildNumber.isEmpty()) {

            buildNumber =
                    "local_"
                            + java.time.format.DateTimeFormatter
                            .ofPattern(
                                    "yyyyMMdd_HHmmss"
                            )
                            .format(
                                    java.time.LocalDateTime.now()
                            );
        }

        LogUtils.info(
                "BuildNumber:" + buildNumber
        );

        FeatureAggregator.generateReports(
                buildNumber,
                finalSuiteDuration
        );

        LogUtils.info(
                "Aggregated reports generation completed."
        );
    }

    // ================================================================
    // SLEEP HELPER
    // ================================================================

    private static void sleepForOneSecond() {

        try {

            Thread.sleep(1000);

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();
        }
    }

    // ================================================================
    // SCREENSHOT
    // ================================================================

    /**
     * Takes a screenshot for the current scenario.
     *
     * Supports:
     * - Mobile Appium
     * - Web Playwright
     *
     * No video capture is performed.
     */
    public static String takeScreenshot(
            String scenarioId
    ) {
        ScenarioContext current = ScenarioContext.get();
        return takeScreenshot(scenarioId, current == null ? null : current.getPlatform());
    }

    /**
     * Screenshot of the scenario's own platform: a mobile scenario never falls back to a web screenshot, and nothing is
     * requested from a mobile session that is gone (setup failed or the connection was lost).
     */
    public static String takeScreenshot(
            String scenarioId,
            Platform platform
    ) {

        if (platform == Platform.API) {
            return "";
        }

        if (platform == Platform.MOBILE && MobileDriverManager.getDriver() == null) {
            LogUtils.info("Screenshot skipped: no mobile driver (the mobile session was not started).");
            return "";
        }

        if (platform == Platform.MOBILE && !MobileDriverManager.isSessionUsable()) {
            LogUtils.info("Screenshot skipped: the mobile session is not usable.");
            return "";
        }

        try {

            // ========================================================
            // SAFE STEP / ACTION NUMBER
            // ========================================================

            Integer step =
                    ScreenshotContextHolder.getStepNo();

            Integer action =
                    ScreenshotContextHolder.getActionNo();

            step =
                    (step == null)
                            ? 1
                            : step;

            action =
                    (action == null)
                            ? 1
                            : action;

            // ========================================================
            // PROJECT ROOT
            // ========================================================

            Path projectRoot =
                    Paths.get(
                            System.getProperty(
                                    "user.dir"
                            )
                    ).toAbsolutePath();

            // ========================================================
            // REPORTS ROOT
            // ========================================================

            Path reportsRoot =
                    projectRoot
                            .resolve("reports")
                            .resolve("latest")
                            .resolve("custom-report");

            // ========================================================
            // SCREENSHOT DIRECTORY
            // ========================================================

            String safeScenarioId =
                    (
                            scenarioId == null
                                    || scenarioId.isBlank()
                    )
                            ? "scenario"
                            : scenarioId.replaceAll(
                            "[^a-zA-Z0-9._-]",
                            "_"
                    );

            Path screenshotsDir =
                    reportsRoot
                            .resolve("screenshots")
                            .resolve(safeScenarioId);

            Files.createDirectories(
                    screenshotsDir
            );

            // ========================================================
            // FILE NAME
            // ========================================================

            long currentTimeMillis =
                    System.currentTimeMillis();

            String fileName =
                    String.format(
                            "%s_%d_%d_%d.png",
                            safeScenarioId,
                            step,
                            action,
                            currentTimeMillis
                    );

            Path destinationPath =
                    screenshotsDir.resolve(
                            fileName
                    );

            // ========================================================
            // MOBILE SCREENSHOT
            // ========================================================

            AppiumDriver mobileDriver =
                    MobileDriverManager.getDriver();

            if (mobileDriver != null) {

                File srcFile =
                        ((TakesScreenshot) mobileDriver)
                                .getScreenshotAs(
                                        OutputType.FILE
                                );

                FileUtils.copyFile(
                        srcFile,
                        destinationPath.toFile()
                );

                Path relativePath =
                        projectRoot.relativize(
                                destinationPath.toAbsolutePath()
                        );

                String finalPath =
                        "./"
                                + relativePath
                                .toString()
                                .replace(
                                        "\\",
                                        "/"
                                );

                LogUtils.info(
                        "Mobile screenshot captured: "
                                + finalPath
                );

                return finalPath;
            }

            // ========================================================
            // WEB SCREENSHOT
            // ========================================================

            Page page =
                    platform == Platform.MOBILE ? null : DriverManager.getPage();

            if (page != null
                    && !page.isClosed()) {

                page.screenshot(
                        new Page.ScreenshotOptions()
                                .setPath(destinationPath)
                                .setFullPage(true)
                );

                Path relativePath =
                        projectRoot.relativize(
                                destinationPath.toAbsolutePath()
                        );

                String finalPath =
                        "./"
                                + relativePath
                                .toString()
                                .replace(
                                        "\\",
                                        "/"
                                );

                ScreenshotContextHolder
                        .publishLastScreenshotPath(
                                finalPath
                        );

                LogUtils.info(
                        "Web screenshot captured: "
                                + finalPath
                );

                return finalPath;
            }

            // ========================================================
            // NO DRIVER
            // ========================================================

            LogUtils.warn(
                    "No active Web or Mobile driver found."
            );

            return "";

        } catch (Exception e) {

            LogUtils.error(
                    "Exception while taking screenshot: "
                            + e.getMessage(),
                    e
            );

            return "";
        }
    }

    /**
     * The browser a scenario asks for with a tag (@Chrome, @Edge, @Firefox, @Webkit / @Safari), or null for BROWSER from the
     * config. Lior tags each recorded web test with the browser it was recorded in. -DBROWSER=... on the command line wins over
     * the tag, so a whole run can still be sent to one browser.
     */
    static String browserTag(Collection<String> tags) {
        if (System.getProperty("BROWSER") != null && !System.getProperty("BROWSER").isBlank()) {
            return null;
        }
        for (String tag : tags) {
            switch (tag.toLowerCase()) {
                case "@chrome":
                    return "chrome";
                case "@edge":
                    return "edge";
                case "@firefox":
                    return "firefox";
                case "@webkit":
                case "@safari":
                    return "webkit";
                default:
                    break;
            }
        }
        return null;
    }
}
