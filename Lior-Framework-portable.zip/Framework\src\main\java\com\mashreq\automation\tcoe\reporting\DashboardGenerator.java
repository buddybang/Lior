package com.mashreq.automation.tcoe.reporting;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.automation.tcoe.constants.FrameworkConstants;
import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.driver.DriverManager;
import com.mashreq.automation.tcoe.reporting.model.Feature;
import com.mashreq.automation.tcoe.reporting.model.ReportData;
import com.mashreq.automation.tcoe.utils.LogUtils;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;

import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class DashboardGenerator {
    private static final String HISTORY_ROOT_DIR = System.getProperty("user.dir") + "/reports/history/";

    public static void generateReport(String jsonInputPath, String templateDirectory, String htmlOutputPath) {
        try {
            // --- 1. Read and Parse JSON into the Correct ReportData object ---
            ObjectMapper objectMapper = new ObjectMapper();
            ReportData reportData = objectMapper.readValue(new File(jsonInputPath), ReportData.class);

            // --- START: NEW HISTORY LOGIC ---
            // 2. Load historical data from the last 4 runs
            List<ReportData> historicalRuns = loadHistoricalData(); // typically oldest->newest
            // Build list with current run + previous runs, then ensure Latest is first
            List<ReportData> allRunsData = new ArrayList<>();
            allRunsData.add(reportData);               // current run
            allRunsData.addAll(historicalRuns);       // older runs

            // Ensure the final serialized array is Latest -> older.
            // If loadHistoricalData returned oldest->newest, then allRunsData currently = [current, oldest,..., newest]
            // so we want to reorder to [current, newest, ..., oldest] -> we reverse the sublist of historical runs.
            if (historicalRuns.size() > 1) {
                // reverse the sublist that contains historicalRuns
                Collections.reverse(allRunsData.subList(1, allRunsData.size()));
            }

            // Convert the history to a JSON string to easily pass to the template
            String historyJsonString = "[]";
            try {
                historyJsonString = objectMapper.writeValueAsString(allRunsData);
            } catch (Exception e) {
                LogUtils.error("Could not serialize history data: " + e.getMessage());
            }
            // --- END: NEW HISTORY LOGIC ---


            // --- 2. Aggregate Summaries for Dashboard Cards ---
            // Your JSON already has summaries per feature. This loop just adds them up for the grand totals.
            int featuresPassed = 0, featuresFailed = 0, featuresSkipped = 0;
            int scenariosTotal = 0, scenariosPassed = 0, scenariosFailed = 0;
            int stepsTotal = 0, stepsPassed = 0, stepsFailed = 0, stepsSkipped = 0;

            // --- Parallel Time Fix: Get total duration directly from the master report data ---
            // This is the true wall-clock duration calculated by the aggregator.
            long totalDurationMillis = reportData.getExecutionTime() == null ? 0L : Long.parseLong(reportData.getExecutionTime().trim());


            for (Feature feature : reportData.getFeatures()) {
                // Tally feature statuses
                switch (String.valueOf(feature.getStatus())) { // null status = skipped (was a NullPointerException)
                    case "PASSED": featuresPassed++; break;
                    case "FAILED": featuresFailed++; break;
                    default: featuresSkipped++; break;
                }
                // Sum up the pre-calculated numbers from the JSON
                scenariosTotal += feature.getTotalScenarios();
                scenariosPassed += feature.getPassedScenarios();
                scenariosFailed += feature.getFailedScenarios();
                stepsTotal += feature.getTotalSteps();
                stepsPassed += feature.getPassedSteps();
                stepsFailed += feature.getFailedSteps();
                stepsSkipped += feature.getSkippedSteps();
//                totalDurationMillis += feature.getDurationMillis();       // Parallel Time Fix

                // Format the duration for each feature row while we're looping
                feature.setDurationFormatted(formatDuration(feature.getDurationMillis()));
            }
            // Calculate total skipped scenarios
            int scenariosSkipped = scenariosTotal - scenariosPassed - scenariosFailed;

            // --- 3. Prepare Data Model for FreeMarker ---
            Map<String, Object> dataModel = new HashMap<>();

            dataModel.put("featureSummary", Map.of(
                    "total", reportData.getFeatures().size(),
                    "passed", featuresPassed, "failed", featuresFailed, "skipped", featuresSkipped,
                    "passedPct", calculatePercentage(featuresPassed, reportData.getFeatures().size()),
                    "failedPct", calculatePercentage(featuresFailed, reportData.getFeatures().size()),
                    "skippedPct", calculatePercentage(featuresSkipped, reportData.getFeatures().size())
            ));
            dataModel.put("scenarioSummary", Map.of(
                    "total", scenariosTotal,
                    "passed", scenariosPassed, "failed", scenariosFailed, "skipped", scenariosSkipped,
                    "passedPct", calculatePercentage(scenariosPassed, scenariosTotal),
                    "failedPct", calculatePercentage(scenariosFailed, scenariosTotal),
                    "skippedPct", calculatePercentage(scenariosSkipped, scenariosTotal)
            ));
            dataModel.put("stepSummary", Map.of(
                    "total", stepsTotal,
                    "passed", stepsPassed, "failed", stepsFailed, "skipped", stepsSkipped,
                    "passedPct", calculatePercentage(stepsPassed, stepsTotal),
                    "failedPct", calculatePercentage(stepsFailed, stepsTotal),
                    "skippedPct", calculatePercentage(stepsSkipped, stepsTotal)
            ));

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm:ss")
                    .withZone(ZoneId.systemDefault());

            dataModel.put("projectName", FrameworkConstants.PROJECT_NAME); // PROJECT_NAME in config.properties
            dataModel.put("executionDate", formatter.format(Instant.now()));
            dataModel.put("totalDurationFormatted", formatDuration(totalDurationMillis));
            String environment = FrameworkConstants.REGION  +" " + FrameworkConstants.ENV;
            dataModel.put("environment", environment);
            dataModel.put("platform", System.getProperty("os.name"));
            String browserInfo = DriverManager.getBrowserVersion();
            dataModel.put("browser", browserInfo != null ? browserInfo : "N/A");


            dataModel.put("features", reportData.getFeatures());
            dataModel.put("historyJson", historyJsonString);


            // --- 4. Configure FreeMarker and Generate Report ---
            Configuration cfg = new Configuration(Configuration.VERSION_2_3_32);
            cfg.setDirectoryForTemplateLoading(new File(templateDirectory));
            cfg.setDefaultEncoding("UTF-8");
            cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);

            Template template = cfg.getTemplate("dashboard-template.ftl");
            try (Writer fileWriter = java.nio.file.Files.newBufferedWriter(java.nio.file.Paths.get(htmlOutputPath), java.nio.charset.StandardCharsets.UTF_8)) { // UTF-8 like the templates (FileWriter used the PC code page)
                template.process(dataModel, fileWriter);
            }

            LogUtils.info("Custom report generated successfully: " + htmlOutputPath);

        } catch (Exception e) {
            LogUtils.error("Error generating custom report: " + e.getMessage(), e);
        }
    }

    // --- START: ADD THESE NEW HELPER METHODS ---
    private static List<ReportData> loadHistoricalData() {
        List<ReportData> history = new ArrayList<>();
        File historyDir = new File(HISTORY_ROOT_DIR);
        if (!historyDir.exists() || !historyDir.isDirectory()) return history;

        File[] runFolders = historyDir.listFiles(File::isDirectory);
        if (runFolders == null) return history;

        Arrays.sort(runFolders, Comparator.comparingLong(com.mashreq.automation.tcoe.utils.ReportUtils::runTimeMillis)); // oldest to newest (by run time, not by name)
        int runsToRead = Math.min(runFolders.length, 4); // Get up to 4 past runs

        for (int i = runFolders.length - runsToRead; i < runFolders.length; i++) {
            File masterFile = new File(runFolders[i], "custom-report/json/master.json");
            if (masterFile.exists()) {
                try {
                    history.add(new ObjectMapper().readValue(masterFile, ReportData.class));
                } catch (IOException e) {
                    LogUtils.error("Could not parse historical master.json: " + masterFile.getPath());
                }
            }
        }
        return history;
    }
    // --- END: ADD THESE NEW HELPER METHODS ---
    // --- Helper Methods (Unchanged) ---
    private static String formatDuration(long millis) {
        long minutes = TimeUnit.MILLISECONDS.toMinutes(millis);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60;
        return String.format("%dm %ds", minutes, seconds);
    }
    private static String calculatePercentage(int part, int total) {
        if (total == 0) return "0.00";
        return new BigDecimal(part * 100.0 / total).setScale(2, RoundingMode.HALF_UP).toString();
    }
}