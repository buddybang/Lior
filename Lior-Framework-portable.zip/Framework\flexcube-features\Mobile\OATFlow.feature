# Made by Lior on 2026-10-10 11:11.
# The values typed or checked by these steps are in the test data file
# testdata/<NN>.OAT/US_TestData_OAT.json (look for the scenario id).
# A test recorded in several versions (other data) is one Scenario Outline: steps ending in "if ... in the test data"
# run only for the versions whose test data has that field.
# Run only this module:  mvn test -Pmobile -Dcucumber.tags="@OAT"
@OAT
Feature: OAT - recorded mobile flow

  @Mobile @SC_001
  Scenario: OAT|SC_001|OAT
    Given the mobile app is launched
    Then the user verifies the following elements should be "visible" under "WelcomeScreenSlide3" screen
      |AndroidWidgetTextView|
    Then the user verifies the following elements should be "visible" under "WelcomeScreenSlide4" screen
      |AndroidWidgetTextView|
    And user clicks the "AppWelcomeAccessibilityLoginButton" button under "WelcomeScreenSlide4" screen
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp" screen
      |AndroidWidgetTextView|
    And user clicks the "LoginWithPassword" button under "LoginToMashreqNeoCorp" screen
    Then the user verifies the following elements should be "visible" under "UserId" screen
      |AndroidWidgetTextView|
    And user enters the following input field details under "UserId" screen
      |VerifyUsernameInputTextInput|
    Then the user verifies the following elements should be "visible" under "Password" screen
      |AndroidWidgetTextView|
    And user clicks the "PasswordInputTextInput" button under "Password" screen
    And user enters the following Mobile field details under "LoginToMashreqNeoCorp3" screen
      |PasswordInputTextInput|
    Then the user verifies the following elements should be "visible" under "Password" screen
      |AndroidWidgetTextView|
    And user clicks the "Login" button under "Password" screen
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp4" screen
      |AndroidWidgetTextView|
    And user enters the following input field details under "SetUpYourLoginPin" screen
      |SetUpA6DigitPin|
    And user clicks the "Continue" button under "SetUpYourLoginPin" screen
    Then the user verifies the following elements should be "visible" under "ConfirmYourLoginPin" screen
      |ConfirmYourLoginPin|
    And user enters the following Mobile field details under "ConfirmYourLoginPin" screen
      |ConfirmYour6DigitPin|
    Then the user verifies the following elements should be "visible" under "ConfirmYourLoginPin2" screen
      |ConfirmYourLoginPin|
    And user clicks the "Continue" button under "ConfirmYourLoginPin2" screen
    Then the user verifies the following elements should be "visible" under "SetUpBiometrics" screen
      |SetUpBiometrics|
    And user clicks the "SetUpBiometricsLater" button under "SetUpBiometrics" screen
    Then the user verifies the following elements should be "visible" under "YourDeviceIsSetUp" screen
      |YourDeviceIsSetUp|
    And user clicks the "Login" button under "YourDeviceIsSetUp" screen
    Then the user verifies the following elements should be "visible" under "LoginWithPinBiometrics" screen
      |AndroidWidgetTextView|
    And user clicks the "LoginWithPinBiometrics" button under "LoginWithPinBiometrics" screen
    Then the user verifies the following elements should be "visible" under "EnterYour6DigitPin" screen
      |LoginToMashreqNeoCorp|
    And user enters the following Mobile field details under "EnterYour6DigitPin" screen
      |EnterYour6DigitPin|
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp5" screen
      |LoginToMashreqNeoCorp|
    And user clicks the "Continue" button under "LoginToMashreqNeoCorp5" screen
    Then the user verifies the following elements should be "visible" under "LoginToMashreqNeoCorp6" screen
      |LoginToMashreqNeoCorp|
    Then the user verifies the following elements should be "visible" under "EndUserLicenseAgreement" screen
      |EndUserLicenseAgreement|
    And user swipes up 7 times and clicks the "IAgreeToTheTermsConditions" button under "EndUserLicenseAgreement" screen
    And user clicks the "AgreeContinue" button under "EndUserLicenseAgreement" screen
    Then the user verifies the following elements should be "visible" under "Home" screen
      |HomeLabel|
    And user swipes up 1 time and clicks the "QuickActionMakePayment" button under "MashreqAccounts" screen
    Then the user verifies the following elements should be "visible" under "Payment" screen
      |Payment|
    And user clicks the "BeneficiaryAccount" button under "Payment" screen
    Then the user verifies the following elements should be "visible" under "Self" screen
      |Accounts|
    And user clicks the "OtherSelfAccounts24" button under "Self" screen
    Then the user verifies the following elements should be "visible" under "IhzbwGolfxjLylConventional" screen
      |Accounts|
    And user clicks the "N019000007537AedFjwhdbtDlwiapiRutxiotBub" button under "IhzbwGolfxjLylConventional" screen
    Then the user verifies the following elements should be "visible" under "InternalSelfTransfer" screen
      |InternalSelfTransfer|
    And user clicks the "Continue" button under "InternalSelfTransfer" screen
    Then the user verifies the following elements should be "visible" under "SelectDebitAccount" screen
      |InternalSelfTransfer|
    And user clicks the "DebitAccount" button under "SelectDebitAccount" screen
    Then the user verifies the following elements should be "visible" under "ConventionalAccounts3" screen
      |Accounts|
    And user clicks the "ConventionalAccounts3" button under "ConventionalAccounts3" screen
    Then the user verifies the following elements should be "visible" under "YpwbbUrayhisAyyurggBkwConventional" screen
      |Accounts|
    And user clicks the "N019000077019AedYpwbbUrayhisAyyurggBkw" button under "YpwbbUrayhisAyyurggBkwConventional" screen
    Then the user verifies the following elements should be "visible" under "PaymentDetails" screen
      |InternalSelfTransfer|
    Then the user verifies the following elements should be "visible" under "InternalSelfTransfer2" screen
      |InternalSelfTransfer|
    And user enters the following Mobile field details under "InternalSelfTransfer2" screen
      |AmountTextbox|
    Then the user verifies the following elements should be "visible" under "PaymentDetails" screen
      |InternalSelfTransfer|
    And user clicks the "RightIcon" button under "PaymentDetails" screen
    Then the user verifies the following elements should be "visible" under "InternalSelfTransfer3" screen
      |Oct2026|
    And user clicks the "N12" button under "InternalSelfTransfer3" screen
    Then the user verifies the following elements should be "visible" under "PaymentDetails" screen
      |InternalSelfTransfer|
    And user clicks the "Continue" button under "PaymentDetails" screen
    Then the user verifies the following elements should be "visible" under "EnterAdditionalDetails" screen
      |InternalSelfTransfer|
    Then the user verifies the following elements should be "visible" under "InternalSelfTransfer4" screen
      |InternalSelfTransfer|
    And user enters the following Mobile field details under "InternalSelfTransfer4" screen
      |CustomerReferenceNumberTextbox|
    Then the user verifies the following elements should be "visible" under "InternalSelfTransfer5" screen
      |InternalSelfTransfer|
    And user clicks the "Continue" button under "InternalSelfTransfer5" screen
    Then the user verifies the following elements should be "visible" under "ReviewDetailsToConfirm" screen
      |InternalSelfTransfer|
    Then the user verifies the following elements should be "visible" under "SlideToConfirm" screen
      |InternalSelfTransfer|
    And user slides the "SlideToConfirm" element right under "SlideToConfirm" screen
    Then the user verifies the following elements should be "visible" under "ReviewDetailsToConfirm" screen
      |InternalSelfTransfer|
    Then the user verifies the following elements should be "visible" under "Summary" screen
      |Summary|
    And user clicks the "Done" button under "Summary" screen
    Then the user verifies the following elements should be "visible" under "HelloSitmaker" screen
      |AndroidWidgetTextView|
