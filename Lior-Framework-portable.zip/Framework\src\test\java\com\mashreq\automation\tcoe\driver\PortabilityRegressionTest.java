package com.mashreq.automation.tcoe.driver;

import com.mashreq.automation.tcoe.constants.FrameworkConstants;
import com.mashreq.automation.tcoe.utils.DataHandler;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.net.Proxy;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Comparator;
import java.util.stream.Stream;

/**
 * The framework on another machine (offline, no browser start, no BrowserStack): a missing browser, no screen, no internet for
 * Playwright's browser download, the client's proxy unknown on this network, file names in another case (Linux agents).
 */
public class PortabilityRegressionTest {

    @Test
    public void edgeOrChromeMissingFallsBackToTheOtherThenPlaywrightsChromium() {
        Assert.assertEquals(DriverManager.chromiumChannels("edge"), Arrays.asList("msedge", "chrome", null));
        Assert.assertEquals(DriverManager.chromiumChannels("chrome"), Arrays.asList("chrome", "msedge", null));
        Assert.assertEquals(DriverManager.chromiumChannels("chromium"), Arrays.asList(null, "chrome", "msedge"));
    }

    @Test
    public void onlyAMissingBrowserIsFallenBackFrom() {
        Assert.assertTrue(DriverManager.browserMissing(new RuntimeException(
                "Chromium distribution 'msedge' is not found at /opt/microsoft/msedge/msedge\nRun \"npx playwright install msedge\"")));
        Assert.assertTrue(DriverManager.browserMissing(new RuntimeException(
                "Executable doesn't exist at /root/.cache/ms-playwright/chromium-1148/chrome-linux/chrome")));
        Assert.assertFalse(DriverManager.browserMissing(new RuntimeException("Target page, context or browser has been closed")),
                "a browser that crashed must fail the test, not start another one");
    }

    /** The message a machine without Playwright's ffmpeg gave (2026-10-08, remote machine): the test runs without a video. */
    @Test
    public void missingVideoToolIsNotAMissingBrowser() {
        RuntimeException ffmpeg = new RuntimeException("Error: Executable doesn't exist at C:\\Users\\X\\AppData\\Local\\ms-playwright\\ffmpeg-1010\\ffmpeg-win64.exe\n"
                + "Looks like Playwright was just installed or updated.\nPlease run the following command to download new browsers:");
        Assert.assertTrue(DriverManager.videoToolMissing(ffmpeg));
        Assert.assertFalse(DriverManager.browserMissing(ffmpeg), "the browser started; only the video tool is missing");
        Assert.assertFalse(DriverManager.videoToolMissing(new RuntimeException("Target page, context or browser has been closed")));
    }

    /** Asking for a video without ffmpeg kills Playwright's connection, so the framework looks for ffmpeg before it asks. */
    @Test
    public void ffmpegIsLookedForBeforeAVideoIsAsked() throws Exception {
        Path dir = Paths.get("target", "portability-ffmpeg-check");
        try (Stream<Path> s = Files.exists(dir) ? Files.walk(dir) : Stream.empty()) {
            s.sorted(Comparator.reverseOrder()).forEach(p -> p.toFile().delete());
        }
        Files.createDirectories(dir.resolve("chromium-1148"));
        System.setProperty("PLAYWRIGHT_BROWSERS_PATH", dir.toAbsolutePath().toString());
        try {
            Assert.assertFalse(DriverManager.videoToolInstalled(), "no ffmpeg folder");
            Files.createDirectories(dir.resolve("ffmpeg-1010"));
            Assert.assertFalse(DriverManager.videoToolInstalled(), "an empty ffmpeg folder is no ffmpeg");
            Files.write(dir.resolve("ffmpeg-1010").resolve("ffmpeg-win64.exe"), new byte[]{0});
            Assert.assertTrue(DriverManager.videoToolInstalled());
        } finally {
            System.clearProperty("PLAYWRIGHT_BROWSERS_PATH");
        }
    }

    @Test
    public void installedBrowsersDoNotDownloadPlaywrightsBrowsers() {
        Assert.assertEquals(DriverManager.createOptions("edge").env.get("PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD"), "1");
        Assert.assertEquals(DriverManager.createOptions("Chrome").env.get("PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD"), "1");
        Assert.assertNull(DriverManager.createOptions("firefox").env.get("PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD"),
                "firefox / webkit / chromium are Playwright's own: they may be downloaded");
        System.setProperty("PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD", "1");
        try {
            Assert.assertEquals(DriverManager.createOptions("firefox").env.get("PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD"), "1", "the person's own choice wins");
        } finally {
            System.clearProperty("PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD");
        }
    }

    @Test
    public void noScreenMeansHeadless() {
        String before = System.getProperty("java.awt.headless");
        System.setProperty("java.awt.headless", "true");
        try {
            Assert.assertFalse(DriverManager.hasDisplay());
        } finally {
            if (before == null) {
                System.clearProperty("java.awt.headless");
            } else {
                System.setProperty("java.awt.headless", before);
            }
        }
    }

    @Test
    public void clientProxyUnknownOnThisNetworkConnectsWithoutIt() {
        System.setProperty("BS_USE_PROXY", "true");
        System.setProperty("BS_PROXY_HOST", "cloudproxy.example.invalid");
        System.setProperty("BS_PROXY_PORT", "443");
        try {
            Assert.assertNull(MobileDriverManager.getBrowserStackProxy(), "an unknown proxy name must not break every session");
            System.setProperty("BS_PROXY_HOST", "127.0.0.1");
            Proxy p = MobileDriverManager.getBrowserStackProxy();
            Assert.assertNotNull(p, "a known proxy is still used");
            Assert.assertEquals(p.type(), Proxy.Type.HTTP);
        } finally {
            System.clearProperty("BS_USE_PROXY");
            System.clearProperty("BS_PROXY_HOST");
            System.clearProperty("BS_PROXY_PORT");
        }
    }

    @Test
    public void testDataFileFoundInAnyCase() throws Exception {
        Path folder = Paths.get(FrameworkConstants.TEST_DATA_PATH, "98.PortCaseCheck");
        Files.createDirectories(folder);
        Path file = folder.resolve(FrameworkConstants.REGION + "_TestData_PortCaseCheck.json");
        Files.write(file, "{\"test_data\":{\"SC_001\":{\"Name\":\"Zoë\"}}}".getBytes(StandardCharsets.UTF_8));
        try {
            File found = new DataHandler().getTestDatapath("PortCaseCheck");
            Assert.assertTrue(found.isFile(), "found: " + found);
            Assert.assertEquals(found.getName(), file.getFileName().toString(), "the real file, not an upper-case name that only Windows would open");
            Assert.assertEquals(new DataHandler().getTestDataOrThrow("PortCaseCheck", "SC_001", "Name"), "Zoë", "read as UTF-8");
        } finally {
            try (Stream<Path> s = Files.walk(folder)) {
                s.sorted(Comparator.reverseOrder()).forEach(p -> p.toFile().delete());
            }
        }
    }
}
