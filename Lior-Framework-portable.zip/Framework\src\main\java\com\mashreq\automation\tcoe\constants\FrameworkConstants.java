package com.mashreq.automation.tcoe.constants;

/**
 * FrameworkConstants holds all the constant values used across the automation framework.
 * This helps in avoiding hard-coded "magic strings" and provides a single point of
 * maintenance for these values.
 */

import com.mashreq.automation.tcoe.utils.PropertiesHelpers;
import com.mashreq.automation.tcoe.utils.SystemHelpers;
import lombok.Getter;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * FrameworkConstants holds all the constant, unchanging values used across the framework.
 * This provides a single point of maintenance for these values.
 * Dynamic configuration values should be handled by the ConfigFactory.
 */
@Getter // Lombok annotation to automatically generate public static getters for all private static fields.
public final class FrameworkConstants {

    /**
     * Private constructor to prevent instantiation of this utility class.
     */
    private FrameworkConstants() {}

    static {
        PropertiesHelpers.loadAllFiles();
    }

    // Let -DENV / -DREGION override file values
    public static final String ENV = System.getProperty("ENV", PropertiesHelpers.getValue("ENV"));
    public static final String REGION = System.getProperty("REGION", PropertiesHelpers.getValue("REGION"));

    /** Get base URL based on merged properties: urls-<ENV>.properties supplies url.<REGION> */
    public static String getBaseUrl(String application) {
        String key = "url." + REGION + "."+ application;                  // e.g. url.US
        String url = PropertiesHelpers.getValue(key);  // comes from urls-<ENV>.properties
        if (url == null || url.isBlank()) {
            // optional: fallback to legacy single URL if present
            url = PropertiesHelpers.getValue("URL");
        }
        if (url == null || url.isBlank()) {
            throw new IllegalStateException("No URL resolved for key '" + key +
                    "' (ENV=" + ENV + ", REGION=" + REGION + "). Check urls-" + ENV + ".properties.");
        }
        return url.trim();
    }

    /** An optional setting (-D, environment, config files) or "" when absent; for settings without a constant. */
    public static String optionalSetting(String key) {
        return optionalValue(key);
    }

    /** An optional whole-number setting, or the default when absent; a clear error when it is not a number. */
    private static int intSetting(String key, int defaultValue) {
        String value = optionalValue(key);
        if (value.isEmpty()) {
            return defaultValue;
        }
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            throw new IllegalStateException(key + " must be a whole number, but is '" + value + "'", e);
        }
    }

    private static String textSetting(String key, String defaultValue) {
        String value = optionalValue(key);
        return value.isEmpty() ? defaultValue : value;
    }

    /** Returns the trimmed value of an optional key, or "" when it is absent (never null). */
    private static String optionalValue(String key) {
        String value = PropertiesHelpers.getValue(key);
        return value == null ? "" : value.trim();
    }

    /**
     * An app file setting (config.properties, -D or environment) as an absolute path; "" when not set.
     * It used to be PROJECT_PATH + "/" + -D value only, which is never empty, so a local iOS session always got the
     * project folder as its app; the config.properties values were never read.
     */
    private static String appPath(String key) {
        String value = optionalValue(key);
        if (value.isEmpty()) {
            return "";
        }
        java.nio.file.Path path = java.nio.file.Paths.get(value);
        return (path.isAbsolute() ? path : java.nio.file.Paths.get(PROJECT_PATH).resolve(path)).normalize().toString();
    }

    private static String buildNameForThisRun() {
        String base = optionalValue("BS_BUILD");
        if ("false".equalsIgnoreCase(optionalValue("BS_BUILD_TIMESTAMP"))) {
            return base;
        }
        String runTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        return base.isEmpty() ? runTime : base + " - " + runTime;
    }

    /**
     * Fails fast, with one clear message, when BrowserStack settings are missing.
     * Called before a BrowserStack session is requested so that web/local runs are not affected.
     */
    public static void validateBrowserStackConfig() {
        java.util.List<String> missing = new java.util.ArrayList<>();
        if (BROWSERSTACK_USERNAME.isEmpty()) missing.add("BROWSERSTACK_USERNAME");
        if (BROWSERSTACK_ACCESS_KEY.isEmpty()) missing.add("BROWSERSTACK_ACCESS_KEY");
        if (BROWSERSTACK_APP_URL.isEmpty()) missing.add("BROWSERSTACK_APP_URL");
        if (BS_DEVICE_NAME.isEmpty()) missing.add("BS_DEVICE_NAME");
        if (BS_OS_VERSION.isEmpty()) missing.add("BS_OS_VERSION");
        if (!missing.isEmpty()) {
            throw new IllegalStateException("BrowserStack run requested but these settings are missing or empty: "
                    + String.join(", ", missing) + ". Set them in config.properties or pass -D<KEY>=<value>.");
        }
    }

    // ---------------- Timeout Constants (in milliseconds) ----------------
    // Settings that no code reads today are optional (with a default), so a missing one does not stop the run.
    public static final int WAIT_SHORT_MS = intSetting("WAIT_SHORT_SECONDS", 5) * 1000;
    public static final int WAIT_MEDIUM_MS = intSetting("WAIT_MEDIUM_SECONDS", 10) * 1000;
    public static final int WAIT_LONG_MS = intSetting("WAIT_LONG_SECONDS", 30) * 1000;

    public static final int DEFAULT_TIMEOUT_MS = Integer.parseInt(PropertiesHelpers.getRequiredValue("DEFAULT_TIMEOUT_SECONDS")) * 1000;
    public static final int DEFAULT_DOWNLOAD_TIMEOUT_MS = intSetting("DEFAULT_DOWNLOAD_TIMEOUT_SECONDS", 60) * 1000;
    /** Mobile steps: how long a check / tap / typing step waits for its element (a slow screen) before it fails. */
    public static final int MOBILE_TIMEOUT_SECONDS = intSetting("MOBILE_TIMEOUT_SECONDS", 20);


    // ---------------- Environment & Project Info ----------------
    private static final String PROJECT_PATH = System.getProperty("user.dir");
    /** Object repositories live in one folder per platform; web and mobile never read each other's files. */
    public static final String OBJECT_REPO_ROOT = PROJECT_PATH + "/src/main/resources/objectrepo";
    public static final String OBJECT_REPO_WEB_PATH = OBJECT_REPO_ROOT + "/Web";
    public static final String OBJECT_REPO_MOBILE_PATH = OBJECT_REPO_ROOT + "/Mobile";
    /** @deprecated kept for older code; it is the MOBILE folder. Use {@link #objectRepoPath(com.mashreq.automation.tcoe.context.Platform)}. */
    @Deprecated
    public static final String OBJECT_REPO_PATH = OBJECT_REPO_MOBILE_PATH;

    /** The object repository folder of a platform (API scenarios have none and get the web folder). */
    public static String objectRepoPath(com.mashreq.automation.tcoe.context.Platform platform) {
        return platform == com.mashreq.automation.tcoe.context.Platform.MOBILE ? OBJECT_REPO_MOBILE_PATH : OBJECT_REPO_WEB_PATH;
    }
    public static final String TEST_DATA_PATH = PROJECT_PATH + "/testdata/";
    /** Shown as the dashboard title; optional. */
    public static final String PROJECT_NAME = textSetting("PROJECT_NAME", "TCoE Automation");
    public static final String OS_NAME = System.getProperty("os.name");

    // ---------------- Browser Configuration ----------------
    public static final String BROWSER = PropertiesHelpers.getRequiredValue("BROWSER");
    public static final boolean HEADLESS = Boolean.parseBoolean(PropertiesHelpers.getRequiredValue("HEADLESS"));
    public static final boolean INCOGNITO = Boolean.parseBoolean(textSetting("INCOGNITO", "false"));
    // ===========================================================
    // MOBILE CONFIGURATIONS (Appium) — all driven from config.properties
    // Override any value at runtime with a -D system property, e.g.:
    //   -DMOBILE_EXECUTION_MODE=browserstack  -DMOBILE_PLATFORM=ios
    // ===========================================================

    // Execution target: local | browserstack
    public static final String MOBILE_EXECUTION_MODE = PropertiesHelpers.getRequiredValue("MOBILE_EXECUTION_MODE");

    // Platform: android | ios
    public static final String MOBILE_PLATFORM = PropertiesHelpers.getRequiredValue("MOBILE_PLATFORM");

    // ---- Local device ----
    public static final String APPIUM_SERVER_URL = PropertiesHelpers.getValue("APPIUM_SERVER_URL");
    public static final String DEVICE_NAME = PropertiesHelpers.getValue("DEVICE_NAME");
    public static final String DEVICE_UDID = PropertiesHelpers.getValue("DEVICE_UDID");
    /** Local device OS version; optional (BrowserStack uses BS_OS_VERSION). */
    public static final String PLATFORM_VERSION = optionalValue("PLATFORM_VERSION");

    // ---- Android ----
    /** Local Android app to start; optional (web and BrowserStack runs do not need it; checked when a local session starts). */
    public static final String APP_PACKAGE = optionalValue("APP_PACKAGE");
    public static final String APP_ACTIVITY = optionalValue("APP_ACTIVITY");
    /** Local .apk to install (absolute, or relative to the project); "" = use the installed APP_PACKAGE / APP_ACTIVITY. */
    public static final String ANDROID_APP_PATH = appPath("ANDROID_APP_PATH");

    // ---- iOS ----
    /** Local .app / .ipa to install (absolute, or relative to the project); "" = the app already on the device. */
    public static final String IOS_APP_PATH = appPath("IOS_APP_PATH");

    // ---- BrowserStack ----
    public static final String BROWSERSTACK_USERNAME = optionalValue("BROWSERSTACK_USERNAME");
    public static final String BROWSERSTACK_ACCESS_KEY = optionalValue("BROWSERSTACK_ACCESS_KEY");
    public static final String BROWSERSTACK_APP_URL = optionalValue("BROWSERSTACK_APP_URL");
    public static final String BS_DEVICE_NAME = optionalValue("BS_DEVICE_NAME");
    public static final String BS_OS_VERSION = optionalValue("BS_OS_VERSION");
    public static final String BS_PROJECT = optionalValue("BS_PROJECT");
    public static final String BS_BUILD = optionalValue("BS_BUILD");
    /**
     * BrowserStack build name for this run. Made once per JVM, so all sessions of a run (also parallel ones) share it,
     * and a new run never joins the build of an earlier one (BS_BUILD_TIMESTAMP=false keeps BS_BUILD as it is).
     */
    public static final String BS_BUILD_NAME = buildNameForThisRun();
    public static final String BS_TEST_NAME = optionalValue("BS_TEST_NAME");
    public static final String BS_PROXY_HOST = optionalValue("BS_PROXY_HOST");
    public static final String BS_PROXY_PORT = optionalValue("BS_PROXY_PORT");
    /** Interactive debugging + visual logs + 300 s idle timeout on BrowserStack sessions (see config.properties). */
    public static final boolean BS_INTERACTIVE_DEBUGGING = Boolean.parseBoolean(optionalValue("BS_INTERACTIVE_DEBUGGING"));

    // ---------------- Report Configuration ----------------
    public static final int REPORT_BACKUP_COUNT = Integer.parseInt(PropertiesHelpers.getRequiredValue("REPORT_BACKUP_COUNT"));
    public static final String REPORT_BASE_FOLDER_NAME = "reports/latest";
    public static final String REPORT_BACKUP_BASE_FOLDER_NAME = "reports/history";
    public static final String LOGS_BASE_FOLDER_NAME = "logs/latest";
    public static final String LOGS_BACKUP_BASE_FOLDER_NAME = "logs/backup";
    public static final int LOGS_BACKUP_COUNT = Integer.parseInt(PropertiesHelpers.getRequiredValue("LOGS_BACKUP_COUNT"));

    // ---------------- UI/Visual Settings ----------------
    public static final boolean HIGHLIGHT = Boolean.parseBoolean(PropertiesHelpers.getRequiredValue("HIGHLIGHT"));
    public static final String LOCALE = textSetting("LOCALE", "en_US");
    public static final String DATE_FORMAT = textSetting("DATE_FORMAT", "dd/MM/yyyy");

    // ---------------- Test Options ----------------
    public static final boolean VIDEO_RECORD = Boolean.parseBoolean(PropertiesHelpers.getRequiredValue("VIDEO_RECORD"));

}