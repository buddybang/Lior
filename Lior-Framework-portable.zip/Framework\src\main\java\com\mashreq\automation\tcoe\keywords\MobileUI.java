package com.mashreq.automation.tcoe.keywords;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.context.ScreenshotContextHolder;
import com.mashreq.automation.tcoe.utils.LocatorUtils;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.*;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.remote.RemoteWebElement;
import com.mashreq.automation.tcoe.utils.CaptureHelpers;
import com.mashreq.automation.tcoe.utils.LogUtils;
import com.mashreq.automation.tcoe.constants.FrameworkConstants;
import com.microsoft.playwright.Page;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.HasOnScreenKeyboard;
import io.appium.java_client.HidesKeyboard;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import com.mashreq.automation.tcoe.driver.MobileDriverManager;
import com.mashreq.automation.tcoe.utils.FailureKind;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;
import java.util.*;
import java.util.List;
import java.util.function.Supplier;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;

/**
 * A keyword-driven engine for Mobile Automation using Appium.
 * Provides high-level keywords for Android and iOS interactions.
 *
 * Locator format: "strategy|value", optionally after the field name the object repository puts in front
 * ("Field|strategy|value" or "Field|//xpath"):
 *   xpath|//android.widget.EditText[@content-desc='username']
 *   id|com.example:id/btnLogin
 *   accessibility|login-button
 *   class|android.widget.TextView
 *   predicate|type == 'XCUIElementTypeButton' AND name == 'Login'      (iOS predicate string)
 *   classchain|**&#47;XCUIElementTypeCell[`name == "Pay"`]               (iOS class chain)
 *   uiautomator|new UiSelector().text("Login")                          (Android UiAutomator)
 *
 * A raw XPath (starting with / or ( ) needs no prefix. Anything else is rejected with a clear message
 * (it used to be tried as an XPath, which failed later with a confusing "element not found").
 */
public final class MobileUI {

    private final IActionLogger logger;
    private final ScenarioContext ctx;
    private final Duration timeout;


    // ---------------------------------------------------------------
    // CONSTRUCTION
    // ---------------------------------------------------------------

    /**
     * Creates a MobileUI engine with a custom explicit-wait timeout.
     *
     * @param ctx     Active scenario context (provides the AppiumDriver).
     * @param logger  Action logger; falls back to NoOp if null.
     * @param timeout Explicit wait duration applied to every element lookup.
     */
    public MobileUI(ScenarioContext ctx, IActionLogger logger, Duration timeout) {
        this.ctx = ctx;
        this.logger = (logger != null) ? logger : new NoOpActionLogger();
        this.timeout = (timeout != null) ? timeout : Duration.ofSeconds(FrameworkConstants.MOBILE_TIMEOUT_SECONDS);
    }

    /**
     * Convenience constructor — waits MOBILE_TIMEOUT_SECONDS from config.properties (20 when not set).
     */
    public MobileUI(ScenarioContext ctx, IActionLogger logger) {
        this(ctx, logger, Duration.ofSeconds(FrameworkConstants.MOBILE_TIMEOUT_SECONDS));
    }

    // ---------------------------------------------------------------
    // DRIVER ACCESS
    // ---------------------------------------------------------------

    private AppiumDriver driver() {
        AppiumDriver d = ctx.getMobileDriver();
        if (d == null) {
            throw new IllegalStateException(
                    "AppiumDriver is null. Ensure @Before hook initialises the mobile driver correctly.");
        }
        if (d == MobileDriverManager.getDriver() && !MobileDriverManager.isSessionUsable()) {
            // fail at once instead of waiting for the timeout on a connection / session that is gone
            throw new NoSuchSessionException("The mobile session is not usable: " + MobileDriverManager.sessionLostReason());
        }
        return d;
    }

    // ---------------------------------------------------------------
    // LOCATOR RESOLUTION
    // ---------------------------------------------------------------

    /** A field name in front of the locator ("NextButton|//..."), as the object repository writes it. */
    private static final java.util.regex.Pattern FIELD_NAME = java.util.regex.Pattern.compile("[A-Za-z0-9_. -]+");

    /**
     * Parses a locator (see the class comment) into a {@link By}.
     *
     * @param locator "strategy|value", "Field|strategy|value", "Field|//xpath" or a raw XPath.
     * @return Resolved {@link By} strategy.
     * @throws IllegalArgumentException for an empty or unknown locator, naming what was given.
     */
    private By resolveLocator(String locator) {
        return resolveLocator(locator, locator);
    }

    private By resolveLocator(String locator, String original) {
        if (locator == null || locator.isBlank()) {
            throw new IllegalArgumentException("Locator must not be null or blank.");
        }
        String value = locator.trim();
        int sep = value.indexOf('|');
        if (sep > 0) {
            String prefix = value.substring(0, sep).trim();
            String rest = value.substring(sep + 1).trim();
            By byStrategy = byStrategy(prefix.toLowerCase(Locale.ROOT), rest, original);
            if (byStrategy != null) {
                return byStrategy;
            }
            if (!looksLikeXPath(prefix) && FIELD_NAME.matcher(prefix).matches()) {
                // "Field|<locator>" from the object repository
                if (rest.isEmpty()) {
                    throw new IllegalArgumentException("No locator recorded for '" + prefix + "' on this platform "
                            + "(the object repository entry is empty).");
                }
                return resolveLocator(rest, original);
            }
        }
        if (looksLikeXPath(value)) {
            return AppiumBy.xpath(value);
        }
        throw new IllegalArgumentException("Unknown locator format: '" + original + "'. Use xpath|, id|, accessibility|, "
                + "class|, predicate|, classchain|, uiautomator| or a raw XPath starting with / or (");
    }

    /** The By for a known strategy prefix, or null when {@code prefix} is not a strategy. */
    private static By byStrategy(String prefix, String value, String original) {
        boolean known = java.util.List.of("xpath", "id", "accessibility", "accessibility id", "accessibilityid", "class",
                "classname", "class name", "predicate", "iospredicate", "-ios predicate string", "ios predicate", "classchain",
                "iosclasschain", "-ios class chain", "ios class chain", "uiautomator", "androiduiautomator",
                "-android uiautomator", "android uiautomator")
                .contains(prefix);
        if (known && value.isEmpty()) {
            throw new IllegalArgumentException("Locator '" + original + "' has the strategy '" + prefix + "' but no value.");
        }
        By by;
        switch (prefix) {
            case "xpath": by = AppiumBy.xpath(value); break;
            case "id": by = AppiumBy.id(value); break;
            case "accessibility": case "accessibility id": case "accessibilityid": by = AppiumBy.accessibilityId(value); break;
            case "class": case "classname": case "class name": by = AppiumBy.className(value); break;
            case "predicate": case "iospredicate": case "-ios predicate string": case "ios predicate": by = AppiumBy.iOSNsPredicateString(value); break;
            case "classchain": case "iosclasschain": case "-ios class chain": case "ios class chain": by = AppiumBy.iOSClassChain(value); break;
            case "uiautomator": case "androiduiautomator": case "-android uiautomator": case "android uiautomator": by = AppiumBy.androidUIAutomator(value); break;
            default: return null;
        }
        return by;
    }

    private static boolean looksLikeXPath(String text) {
        return text.startsWith("/") || text.startsWith("(") || text.startsWith("./");
    }

    // ---------------------------------------------------------------
    // FAILURES
    // ---------------------------------------------------------------

    /**
     * Fails the step: "[KIND] what: cause message" with the original exception kept as the cause. KIND tells a missing
     * element (LOCATOR) from a lost connection (TRANSPORT), a dead session (SESSION), configuration (SETUP) or a failed
     * action (ACTION). After TRANSPORT / SESSION the session is marked unusable, so no more screenshots or status
     * updates are sent to it. At most one failure screenshot per scenario.
     */
    private void fail(String what, Throwable cause) {
        FailureKind kind = FailureKind.of(cause);
        if (kind.sessionLikelyLost()) {
            MobileDriverManager.markSessionUnusable(kind + " - " + what);
        }
        captureFailureScreenshot();
        Assert.fail("[" + kind + "] " + what + ": " + cause.getMessage(), cause);
    }

    /** The one failure screenshot of the scenario; skipped when already taken or when the session is not usable. */
    public void captureFailureScreenshot() {
        if (ctx.isFailureScreenshotTaken()) {
            return;
        }
        ctx.setFailureScreenshotTaken(true);
        if (!MobileDriverManager.isSessionUsable()) {
            LogUtils.info("Failure screenshot skipped: the mobile session is not usable.");
            return;
        }
        captureScreenshot();
    }

    private boolean isIos() {
        Object platform = driver().getCapabilities().getPlatformName();
        return platform != null && "ios".equalsIgnoreCase(platform.toString());
    }

    /** Native iOS element types that accept typed text. */
    private static final Set<String> IOS_TEXT_INPUTS = Set.of(
            "XCUIElementTypeTextField", "XCUIElementTypeSecureTextField",
            "XCUIElementTypeTextView", "XCUIElementTypeSearchField");

    /** An attribute, or null when the platform does not know it (no exception). */
    private static String attributeOrNull(WebElement element, String name) {
        try {
            return element.getAttribute(name);
        } catch (UnsupportedCommandException | InvalidArgumentException notKnown) {
            return null;
        }
    }

    /**
     * The text of a native element by what it is: an iOS text input -> its value; otherwise getText(); when that is
     * empty -> the iOS label or the Android text attribute. Lookup / connection errors are thrown, never turned into "".
     */
    private String readText(WebElement element) {
        if (isIos()) {
            String type = attributeOrNull(element, "type");
            if (type != null && IOS_TEXT_INPUTS.contains(type)) {
                // a text input's content is its value, also when empty (its label / placeholder is not its text)
                String value = attributeOrNull(element, "value");
                return value == null ? "" : value;
            }
            String text = element.getText();
            if (text != null && !text.isEmpty()) {
                return text;
            }
            String label = attributeOrNull(element, "label");
            return label == null ? "" : label;
        }
        String text = element.getText();
        if (text != null && !text.isEmpty()) {
            return text;
        }
        String attr = attributeOrNull(element, "text");
        return attr == null ? "" : attr;
    }

    /** Typed values of password / PIN / OTP fields are not written to logs and reports. */
    private static final java.util.regex.Pattern SECRET_FIELD =
            java.util.regex.Pattern.compile("(?i).*(pass|pwd|pin|otp|secret|cvv|token).*");

    private static String shown(String locator, String text) {
        int sep = locator == null ? -1 : locator.indexOf('|');
        String field = sep > 0 ? locator.substring(0, sep) : "";
        if (text != null && SECRET_FIELD.matcher(field).matches()) {
            return "*".repeat(Math.min(text.length(), 8));
        }
        return text;
    }

    // ---------------------------------------------------------------
    // ELEMENT LOOKUP
    // ---------------------------------------------------------------

    /**
     * Waits for an element to be present in the DOM and returns it.
     * Captures a screenshot automatically on failure.
     *
     * @param locator Prefixed locator string (e.g. "xpath|//...")
     * @return The located {@link WebElement}.
     * @throws org.openqa.selenium.TimeoutException if the element is not found within the timeout.
     */
    public WebElement findElement(String locator) {
        // FIX: resolveLocator() was called twice — once stored in 'by' (unused) and once
        //      inline. Now resolved once and reused to avoid double-parsing overhead.
        By by = resolveLocator(locator);
        try {
            // visibilityOfElementLocated (not presence): the returned element is visible and interactable
            return untilOnDevice(ExpectedConditions.visibilityOfElementLocated(by));
        } catch (Exception e) {
            LogUtils.error("Element not found within " + timeout.getSeconds() + "s: " + locator);
            throw e; // the keyword that called this reports the failure (and takes the failure screenshot)
        }
    }


    /** How long one element lookup may wait on the device itself while the element is not there yet. */
    private static final Duration DEVICE_WAIT = Duration.ofSeconds(5);

    /**
     * Waits for {@code condition} within {@link #timeout}. Checked once at once (one call when the element is already there);
     * otherwise the device waits for the element itself (implicit wait, at most {@link #DEVICE_WAIT} per lookup) instead of
     * one round trip to the device every 500 ms. The implicit wait is switched off again afterwards, so other lookups
     * (for example "not visible" checks) still answer at once.
     */
    private <T> T untilOnDevice(java.util.function.Function<WebDriver, T> condition) {
        WebDriver d = driver();
        try {
            T now = condition.apply(d);
            if (now != null && !Boolean.FALSE.equals(now)) {
                return now;
            }
        } catch (NotFoundException | StaleElementReferenceException notYet) {
            // the wait below handles it
        }
        d.manage().timeouts().implicitlyWait(timeout.compareTo(DEVICE_WAIT) < 0 ? timeout : DEVICE_WAIT);
        try {
            return new WebDriverWait(d, timeout)
                    .pollingEvery(Duration.ofMillis(300))
                    .ignoring(StaleElementReferenceException.class)
                    .until(condition);
        } finally {
            try {
                d.manage().timeouts().implicitlyWait(Duration.ZERO);
            } catch (WebDriverException sessionGone) {
                // the session ended; nothing to switch off
            }
        }
    }

    /**
     * Highlights a mobile element before action execution.
     * Works for Native Android/iOS apps by drawing temporary overlay effect
     * using Appium supported operations.
     *
     * Screenshot is captured AFTER highlight and BEFORE action.
     */
    // ---------------------------------------------------------------
    // ACTION KEYWORDS
    // ---------------------------------------------------------------

    /**
     * Taps / clicks a mobile element.
     *
     * @param locator Prefixed locator string.
     */
    public void click(String locator) {
        logger.logAction("Click: " + locator, () -> {
            try {
                // clickable, and no longer moving (a screen transition can make an element clickable while it still slides in)
                WebElement ele = untilOnDevice(ExpectedConditions.elementToBeClickable(resolveLocator(locator)));
                Rectangle still = waitUntilStill(ele);
                captureScreenshot(ele, still);
                ele.click();

                LogUtils.info("Clicked: " + locator);
            } catch (Exception e) {
                fail("Failed to click element [" + locator + "]", e);
            }
        });
    }

    /**
     * Waits (at most 2 s) until the element is in the same place twice in a row, i.e. an animation has finished.
     * Returns where it is (the screenshot highlight uses it, so it is not asked for again).
     */
    private Rectangle waitUntilStill(WebElement ele) {
        Rectangle last = null;
        long end = System.currentTimeMillis() + 2000;
        while (System.currentTimeMillis() < end) {
            Rectangle now = ele.getRect();
            if (now.equals(last)) {
                return now;
            }
            last = now;
            try {
                Thread.sleep(150); // poll interval of the condition, not a fixed wait
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return last;
            }
        }
        return last;
    }

    /** Waits until the element exists and is enabled; false when that does not happen within {@code max}. */
    public boolean waitUntilEnabled(String locator, java.time.Duration max) {
        try {
            new WebDriverWait(driver(), max).until(d -> isElementEnabled(locator));
            return true;
        } catch (org.openqa.selenium.TimeoutException notYet) {
            return false;
        }
    }

    /** Non-asserting check: true if the element exists and is enabled. */
    public boolean isElementEnabled(String locator) {
        try {
            List<WebElement> elements = driver().findElements(resolveLocator(locator));
            return !elements.isEmpty() && elements.get(0).isEnabled();
        } catch (Exception e) {
            if (FailureKind.of(e).sessionLikelyLost()) {
                throw e; // a lost connection is not "not enabled": waitUntilEnabled would poll a dead session
            }
            return false;
        }
    }

    public void swipeHorizontalUntilVisibleClick(String locator) {

        List<WebElement> elements =
                driver().findElements(resolveLocator(locator));

        if (!elements.isEmpty() && elements.get(0).isDisplayed()) {
            elements.get(0).click();
            return;
        }

        for (int i = 0; i < 10; i++) {

            swipeLeft();

            elements = driver().findElements(resolveLocator(locator));

            if (!elements.isEmpty() && elements.get(0).isDisplayed()) {
                elements.get(0).click();
                return;
            }
        }

        Assert.fail("Element not found after swiping: " + locator);
    }

    /**
     * Presses the Android Back button.
     */
    public void pressBack() {

        logger.logAction("Press Android Back Button", () -> {

            try {

                if (isIos()) {
                    driver().navigate().back(); // iOS has no Back key; the navigation back gesture of the app
                } else {
                    ((AndroidDriver) driver())
                            .pressKey(new KeyEvent(AndroidKey.BACK));
                }

                captureScreenshot();

                LogUtils.info("Pressed Back");

            } catch (Exception e) {

                fail("Failed to press Back", e);
            }
        });
    }

    /**
     * Presses the Android Home button.
     */
    public void pressHome() {

        logger.logAction("Press Android Home Button", () -> {

            try {

                if (isIos()) {
                    driver().executeScript("mobile: pressButton", Map.of("name", "home"));
                } else {
                    ((AndroidDriver) driver())
                            .pressKey(new KeyEvent(AndroidKey.HOME));
                }

                captureScreenshot();

                LogUtils.info("Pressed Home");

            } catch (Exception e) {

                fail("Failed to press Home", e);
            }
        });
    }

    /**
     * Opens Android Recent Apps screen.
     */
    public void openRecentApps() {

        logger.logAction("Open Android Recent Apps", () -> {

            try {

                if (isIos()) {
                    throw new IllegalStateException("Opening Recent Apps is supported on Android only.");
                }
                ((AndroidDriver) driver())
                        .pressKey(new KeyEvent(AndroidKey.APP_SWITCH));

                captureScreenshot();

                LogUtils.info("Opened Android Recent Apps");

            } catch (Exception e) {

                fail("Failed to open Android Recent Apps", e);
            }
        });
    }


    /**
     * Focuses the field, clears it and types the text, then closes the on-screen keyboard.
     *
     * @param locator Prefixed locator string.
     * @param text    Text to enter.
     */
    public void sendKeys(String locator, String text) {
        logger.logAction("Type '" + shown(locator, text) + "' into: " + locator, () -> {
            typeInto(locator, text, false);
            // The on-screen keyboard can cover buttons below the field (e.g. Continue on the PIN screen),
            // which Appium then cannot find.
            hideKeyboardIfShown();
        });
    }

    /**
     * The one typing sequence of both typing keywords, on Android and iOS: find the field (on iOS it must be a native
     * text input, not a label or container), focus (tap), clear, type, and with {@code submit} press Done / Enter.
     * A failure names the phase it happened in, so a report shows whether any characters were sent.
     */
    private void typeInto(String locator, String text, boolean submit) {
        String phase = "inspecting the field";
        try {
            WebElement element = new WebDriverWait(driver(), timeout)
                    .until(ExpectedConditions.elementToBeClickable(resolveLocator(locator)));
            boolean ios = isIos();
            if (ios) {
                String type = attributeOrNull(element, "type");
                if (type == null || !IOS_TEXT_INPUTS.contains(type)) {
                    throw new InvalidElementStateException("The element is a " + type + ", not a text field "
                            + "(expected one of " + IOS_TEXT_INPUTS + "); nothing was typed.");
                }
            }
            phase = "focusing the field";
            element.click();
            phase = "clearing the field";
            element.clear();
            phase = "typing (characters may be partly entered)";
            element.sendKeys(text);
            if (submit) {
                phase = "pressing Done / Enter";
                if (ios) {
                    element.sendKeys(Keys.ENTER);
                } else {
                    driver().executeScript("mobile: performEditorAction", Map.of("action", "done"));
                }
            }
            captureScreenshot(element);
            LogUtils.info("Typed [" + shown(locator, text) + "] into [" + locator + "]" + (submit ? " and submitted" : ""));
        } catch (Exception e) {
            fail("Typing into [" + locator + "] failed while " + phase, e);
        }
    }

    /**
     * The value of one native attribute of the element, e.g. text, value, label, name, content-desc, enabled, checked.
     * Fails the step when the element is not found or the attribute cannot be read; null when the element has no such value.
     */
    public String getAttribute(String locator, String attribute) {
        return logger.logAction("Get attribute '" + attribute + "' of: " + locator, () -> {
            try {
                WebElement ele = findElement(locator);
                String value = ele.getAttribute(attribute);
                LogUtils.info("Attribute '" + attribute + "' of [" + locator + "]: " + value);
                return value;
            } catch (Exception e) {
                fail("Failed to read attribute '" + attribute + "' of [" + locator + "]", e);
                return null;
            }
        });
    }

    /**
     * Closes the on-screen keyboard if it is open. Never fails the step.
     */
    public void hideKeyboardIfShown() {
        try {
            AppiumDriver d = driver();
            if (d instanceof HasOnScreenKeyboard kb && kb.isKeyboardShown()
                    && d instanceof HidesKeyboard hk) {
                hk.hideKeyboard();
                LogUtils.info("On-screen keyboard hidden");
            }
        } catch (Exception e) {
            LogUtils.warn("Could not hide the on-screen keyboard: " + e.getMessage());
        }
    }

    /**
     * Retrieves the text of an element (see {@link #readText}): "" means the element really has no text.
     *
     * @param locator Prefixed locator string.
     * @return The element's text; the step fails when the element cannot be found or read (it used to return "").
     */
    public String getText(String locator) {
        return logger.logAction("Get text from: " + locator, () -> {
            try {
                WebElement ele = findElement(locator);
                String text = readText(ele);
                captureScreenshot(ele);
                LogUtils.info("Text retrieved from [" + locator + "]: " + text);
                return text;
            } catch (Exception e) {
                fail("Failed to get text from [" + locator + "]", e);
                return null;
            }
        });
    }

    public boolean verifyElementState(
            String locator,
            String expectedState) {

        return logger.logAction(
                "Verify element state: "
                        + locator
                        + " | Expected: "
                        + expectedState,
                () -> {

                    try {

                        if (locator == null || locator.trim().isEmpty()) {
                            throw new IllegalArgumentException(
                                    "Locator cannot be null or empty");
                        }

                        if (expectedState == null
                                || expectedState.trim().isEmpty()) {

                            throw new IllegalArgumentException(
                                    "Expected state cannot be null or empty");
                        }

                        String state =
                                expectedState.trim().toLowerCase();

                        /*
                         * Special handling for negative visibility.
                         *
                         * Element absent:
                         *      not visible/not displayed = PASS
                         *
                         * Element present but hidden:
                         *      not visible/not displayed = PASS
                         *
                         * Element present and visible:
                         *      FAIL
                         */
                        if ("not visible".equals(state)
                                || "not displayed".equals(state)) {

                            List<WebElement> elements =
                                    driver().findElements(
                                            resolveLocator(locator));

                            if (elements.isEmpty()) {

                                LogUtils.info(
                                        "Verified: Element '"
                                                + locator
                                                + "' is "
                                                + state + ".");

                                return true;
                            }

                            WebElement element = elements.get(0);

                            boolean actualDisplayed =
                                    element.isDisplayed();

                            captureScreenshot(element);

                            Assert.assertFalse(
                                    actualDisplayed,
                                    "Element was expected to be "
                                            + state
                                            + " but is displayed: "
                                            + locator);

                            LogUtils.info(
                                    "Successfully verified element '"
                                            + locator
                                            + "' is "
                                            + state + ".");

                            return true;
                        }

                        WebElement element =
                                findElement(locator);

                        boolean actualState;
                        boolean expectedResult;

                        switch (state) {

                            case "enabled":

                                actualState = element.isEnabled();
                                expectedResult = true;
                                break;

                            case "disabled":

                                actualState = element.isEnabled();
                                expectedResult = false;
                                break;

                            case "checked":
                            case "selected":

                                actualState = element.isSelected();
                                expectedResult = true;
                                break;

                            case "unchecked":
                            case "not selected":

                                actualState = element.isSelected();
                                expectedResult = false;
                                break;

                            case "visible":
                            case "displayed":

                                // findElement only returns an element it has just seen displayed: no second device call
                                actualState = true;
                                expectedResult = true;
                                break;

                            default:

                                throw new IllegalArgumentException(
                                        "Unsupported element state: "
                                                + expectedState);
                        }

                        captureScreenshot(element);

                        LogUtils.info(
                                "Element: " + locator
                                        + " | Expected State: " + state
                                        + " | Actual Result: " + actualState);

                        Assert.assertEquals(
                                actualState,
                                expectedResult,
                                "Element state verification failed for: "
                                        + locator
                                        + " | Expected State: "
                                        + state);

                        LogUtils.info(
                                "Successfully verified element '"
                                        + locator
                                        + "' is "
                                        + state + ".");

                        return true;

                    } catch (AssertionError e) {

                        throw e;

                    } catch (Exception e) {

                        captureScreenshot();

                        String errorMessage =
                                "Failed to verify element state: "
                                        + locator
                                        + " | Expected State: "
                                        + expectedState
                                        + " | Reason: "
                                        + e.getMessage();

                        LogUtils.error(
                                errorMessage,
                                e);

                        fail(errorMessage.replace(" | Reason: " + e.getMessage(), ""), e);

                        return false;
                    }
                });
    }

    /**
     * Scrolls through a list and taps the item matching {@code targetText} (case-insensitive).
     * FIX: now uses resolveLocator() so prefixed locators (e.g. "xpath|//...") work correctly
     *      instead of passing the raw string to AppiumBy.xpath().
     *
     * @param listLocator Prefixed locator for the repeating list items.
     * @param targetText  Visible text of the item to select.
     */
    public void selectByText(String listLocator, String targetText) {
        logger.logAction("Select '" + targetText + "' from list: " + listLocator, () -> {
            try {
                By by = resolveLocator(listLocator);
                List<WebElement> elements = driver().findElements(by);

                if (elements.isEmpty()) {
                    Assert.fail("List is empty — no items found at: " + listLocator);
                }

                for (WebElement el : elements) {
                    if (el.getText().equalsIgnoreCase(targetText)) {
                        el.click();
                        captureScreenshot(el);
                        LogUtils.info("Selected '" + targetText + "' from list: " + listLocator);
                        return;
                    }
                }
                Assert.fail("Item '" + targetText + "' not found in list: " + listLocator);
            } catch (AssertionError ae) {
                throw ae; // Let TestNG assertion propagate cleanly.
            } catch (Exception e) {
                fail("Error selecting from list [" + listLocator + "]", e);
            }
        });
    }

    /**
     * Sets a checkbox to the desired state without unnecessary clicks.
     *
     * @param locator  Prefixed locator string.
     * @param testdata "check" or "true" to check; any other value unchecks.
     */
    public void selectCheckbox(String locator, String testdata) {
        logger.logAction("Checkbox [" + locator + "] set to: " + testdata, () -> {
            try {
                WebElement checkbox = findElement(locator);
                boolean shouldBeChecked = testdata != null &&
                        ("check".equalsIgnoreCase(testdata) || "true".equalsIgnoreCase(testdata));
                boolean isChecked = checkbox.isSelected();
                if (shouldBeChecked != isChecked) {
                    checkbox.click();
                    LogUtils.info((shouldBeChecked ? "Checked" : "Unchecked") + " checkbox: " + locator);
                } else {
                    LogUtils.info("Checkbox already in desired state (" + testdata + "): " + locator);
                }
            } catch (Exception e) {
                fail("Failed to set checkbox state [" + locator + "]", e);
            }
        });
    }

    /**
     * Waits for the given number of seconds (supports fractional values).
     *
     * @param secondsStr Duration in seconds as a string (e.g. "2" or "0.5").
     */
    public void waitForDuration(String secondsStr) {
        logger.logAction("Wait for: " + secondsStr + " seconds", () -> {
            try {
                double seconds = Double.parseDouble(secondsStr.trim());
                long millis = (long) (seconds * 1000);
                captureScreenshot();
                LogUtils.info("Waiting for " + seconds + " seconds...");
                Thread.sleep(millis);
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
            } catch (Exception e) {
                fail("Invalid wait duration [" + secondsStr + "]", e);
            }
        });
    }

    // ---------------------------------------------------------------
    // VALIDATION KEYWORDS
    // ---------------------------------------------------------------

    /**
     * Asserts that an element's text matches the expected value.
     *
     * @param locator       Prefixed locator string.
     * @param expectedText  Text the element is expected to display.
     */

    public void verifyText(String locator, String expectedText) {
        logger.logAction("Verify text '" + expectedText + "' on: " + locator, () -> {
            String actualText;
            WebElement ele;
            try {
                ele = findElement(locator);
                actualText = readText(ele);
            } catch (Exception e) {
                fail("Failed to read the text of [" + locator + "]", e);
                return;
            }
            captureScreenshot(ele);
            LogUtils.info("Text — expected: '" + expectedText + "', actual: '" + actualText + "'");
            Assert.assertEquals(actualText, expectedText,
                    "Text mismatch on [" + locator + "]. Expected '" + expectedText
                            + "' but got '" + actualText + "'.");
        });
    }

    /**
     * Soft-assertion variant of {@link #verifyText(String, String)}.
     * If {@code soft} is true, logs the failure without stopping the test.
     *
     * @param locator       Prefixed locator string.
     * @param expectedText  Text the element is expected to show (exact match, like the hard variant).
     * @param soft          true = log-only on failure; false = hard fail.
     * @return PASSED/FAILED result string.
     */
    public String verifyText(String locator, String expectedText, boolean soft) {
        return logger.logAction("Verify text '" + expectedText + "' on: " + locator, () -> {
            try {
                WebElement ele = findElement(locator);
                String actualText = readText(ele);
                captureScreenshot(ele);
                LogUtils.info("Text — expected: '" + expectedText + "', actual: '" + actualText + "'");
                // exact match (was contains(): an empty expected value always passed, "10" matched "100")
                if (actualText.equals(expectedText)) {
                    String successMsg = "PASSED | Expected='" + expectedText + "' | Actual='" + actualText + "'";

                    LogUtils.info(successMsg);
                    return successMsg;
                } else {
                    String failMsg = "FAILED | Expected='" + expectedText + "' | Actual='" + actualText + "'";
                    LogUtils.error(failMsg);
                    if (!soft) Assert.fail(failMsg);
                    return failMsg;
                }
            } catch (AssertionError ae) {
                throw ae;
            } catch (Exception e) {
                captureFailureScreenshot();
                String errorMsg = "[" + FailureKind.of(e) + "] ERROR verifying text for [" + locator + "]: " + e.getMessage();
                LogUtils.error(errorMsg);
                if (!soft) Assert.fail(errorMsg, e);
                return errorMsg;
            }
        });
    }

    // ---------------------------------------------------------------
    // RETRIEVAL KEYWORDS
    // ---------------------------------------------------------------

    /**
     * Retrieves the visible text of an element and logs the variable name it is stored under.
     *
     * @param locator Prefixed locator string.
     * @param varName Logical name of the variable for logging purposes.
     * @return Retrieved text, or null on failure.
     */
    public String retrieveText(String locator, String varName) {
        return logger.logAction("Retrieve text from: " + locator, () -> {
            try {
                WebElement ele = findElement(locator);
                String retrievedData = readText(ele);
                if (retrievedData == null || retrievedData.isEmpty()) {
                    String msg = "Could not retrieve any text from element: " + locator;
                    LogUtils.error(msg);
                    Assert.fail(msg);
                    return null;
                }
                captureScreenshot(ele);
                LogUtils.info("Retrieved '" + retrievedData + "' from [" + locator + "] stored as: '" + varName + "'");
                return retrievedData;
            } catch (Exception e) {
                fail("Failed to retrieve text from element [" + locator + "]", e);
                return null;
            }
        });
    }

    public String retrieveText(String locator) {

        return logger.logAction(
                "Retrieve text from element: " + locator,
                () -> {

                    try {

                        WebElement element = findElement(locator);

                        String text = readText(element);

                        captureScreenshot(element);

                        LogUtils.info(
                                "Retrieved text from element '" +
                                        locator +
                                        "': " +
                                        text);

                        return text;

                    } catch (Exception e) {

                        fail("Failed to retrieve text from [" + locator + "]", e);
                        return null;
                    }
                });
    }


    // ---------------------------------------------------------------
    // GESTURE KEYWORDS
    // ---------------------------------------------------------------

    /**
     * Swipes vertically like a finger: "up" moves the finger up (the content scrolls down), "down" the other way.
     * {@code times} > 0: exactly that many swipes. {@code times} <= 0: quick long swipes (a fling) until nothing on the screen
     * moves any more (the end of the content), at most 25. Returns the number of swipes made.
     */
    public int swipeVertically(boolean up, int times) {
        if (times > 0) {
            // the same quick swipe a person makes (the content flings on); the slow scrollDown/scrollUp drag moves only
            // 40% of the screen, so N of them fall short of N recorded swipes (NeoCorp EULA: page 4 of 6 after 5)
            for (int i = 0; i < times; i++) {
                flick(up);
            }
            LogUtils.info("Swiped " + (up ? "up" : "down") + " " + times + " time(s)");
            return times;
        }
        // compared by picture: a PDF / image viewer scrolls without changing the page source
        byte[] before = driver().getScreenshotAs(OutputType.BYTES);
        int done = 0;
        while (done < 25) {
            flick(up);
            done++;
            byte[] after = driver().getScreenshotAs(OutputType.BYTES);
            if (Arrays.equals(after, before)) {
                break; // nothing moved: the end is reached
            }
            before = after;
        }
        LogUtils.info("Swiped " + (up ? "up" : "down") + " " + done + " time(s) (until the screen stopped moving)");
        return done;
    }

    /**
     * One quick, long swipe (the content keeps moving after the finger lifts). Stays between 15% and 72% of the screen height,
     * so it starts inside the content and not on a footer (tick box, buttons) at the bottom.
     */
    private void flick(boolean up) {
        logger.logAction(up ? "Swipe up" : "Swipe down", () -> {
            try {
                Dimension size = driver().manage().window().getSize();
                int x = size.getWidth() / 2;
                int low = (int) (size.getHeight() * 0.72);
                int high = (int) (size.getHeight() * 0.15);
                performSwipe(x, up ? low : high, x, up ? high : low, 300);
                captureScreenshot();
            } catch (Exception e) {
                fail("Failed to swipe " + (up ? "up" : "down"), e);
            }
        });
    }

    /**
     * Scrolls the screen downward (finger moves up — content moves down).
     * Swipes from 70% to 30% of screen height at the horizontal centre.
     */

    public void scrollDown() {
        logger.logAction("Scroll down", () -> {
            try {
                Dimension size = driver().manage().window().getSize();
                int x = size.getWidth() / 2;
                performSwipe(x, (int) (size.getHeight() * 0.70),
                        x, (int) (size.getHeight() * 0.30), 600);
                captureScreenshot();
                LogUtils.info("Scrolled down.");
            } catch (Exception e) {
                fail("Failed to scroll down", e);
            }
        });
    }

    /**
     * Scrolls the screen upward (finger moves down — content moves up).
     * Swipes from 30% to 70% of screen height at the horizontal centre.
     */
    public void scrollUp() {
        logger.logAction("Scroll up", () -> {
            try {
                Dimension size = driver().manage().window().getSize();
                int x = size.getWidth() / 2;
                performSwipe(x, (int) (size.getHeight() * 0.30),
                        x, (int) (size.getHeight() * 0.70), 600);
                captureScreenshot();
                LogUtils.info("Scrolled up.");
            } catch (Exception e) {
                fail("Failed to scroll up", e);
            }
        });
    }

    /**
     * Scrolls down repeatedly until the element identified by {@code locator} is visible,
     * up to 10 attempts.
     *
     * @param locator Prefixed locator string of the target element.
     */
    public void scrollToElement(String locator) {
        logger.logAction("Scroll to element: " + locator, () -> {
            try {
                By by = resolveLocator(locator);
                int maxAttempts = 10;
                for (int i = 0; i < maxAttempts; i++) {
                    List<WebElement> found = driver().findElements(by);
                    if (!found.isEmpty() && found.get(0).isDisplayed()) {
                        captureScreenshot(found.get(0));
                        LogUtils.info("Element visible after " + i + " scroll(s): " + locator);
                        return;
                    }
                    scrollDown();
                }
                Assert.fail("Element not visible after " + maxAttempts + " scroll attempts: " + locator);
            } catch (AssertionError ae) {
                throw ae;
            } catch (Exception e) {
                fail("Error scrolling to element [" + locator + "]", e);
            }
        });
    }

    /**
     * Swipes left (finger moves left — content/page moves right, e.g. next tab).
     * Swipes from 80% to 20% of screen width at the vertical centre.
     */
    public void swipeLeft() {
        logger.logAction("Swipe left", () -> {
            try {
                Dimension size = driver().manage().window().getSize();
                int y = size.getHeight() / 2;
                performSwipe((int) (size.getWidth() * 0.80), y,
                        (int) (size.getWidth() * 0.20), y, 400);
                captureScreenshot();
                LogUtils.info("Swiped left.");
            } catch (Exception e) {
                fail("Failed to swipe left", e);
            }
        });
    }

    /**
     * Swipes right (finger moves right — content/page moves left, e.g. previous tab).
     * Swipes from 20% to 80% of screen width at the vertical centre.
     */
    public void swipeRight() {
        logger.logAction("Swipe right", () -> {
            try {
                Dimension size = driver().manage().window().getSize();
                int y = size.getHeight() / 2;
                performSwipe((int) (size.getWidth() * 0.20), y,
                        (int) (size.getWidth() * 0.80), y, 400);
                captureScreenshot();
                LogUtils.info("Swiped right.");
            } catch (Exception e) {
                fail("Failed to swipe right", e);
            }
        });
    }

    /**
     * Fast upward swipe (finger moves up) — shorter duration than {@link #scrollDown()}.
     */
    public void swipeUp() {
        logger.logAction("Swipe up", () -> {
            try {
                Dimension size = driver().manage().window().getSize();
                int x = size.getWidth() / 2;
                performSwipe(x, (int) (size.getHeight() * 0.70),
                        x, (int) (size.getHeight() * 0.30), 300);
                captureScreenshot();
                LogUtils.info("Swiped up.");
            } catch (Exception e) {
                fail("Failed to swipe up", e);
            }
        });
    }

    /**
     * Fast downward swipe (finger moves down) — shorter duration than {@link #scrollUp()}.
     */
    public void swipeDown() {
        logger.logAction("Swipe down", () -> {
            try {
                Dimension size = driver().manage().window().getSize();
                int x = size.getWidth() / 2;
                performSwipe(x, (int) (size.getHeight() * 0.30),
                        x, (int) (size.getHeight() * 0.70), 300);
                captureScreenshot();
                LogUtils.info("Swiped down.");
            } catch (Exception e) {
                fail("Failed to swipe down", e);
            }
        });
    }

    /**
     * Performs a pull-to-refresh gesture — fast downward swipe from the top third
     * of the screen, mimicking a native pull-to-refresh.
     */
    public void pullToRefresh() {
        logger.logAction("Pull to refresh", () -> {
            try {
                Dimension size = driver().manage().window().getSize();
                int x = size.getWidth() / 2;
                performSwipe(x, (int) (size.getHeight() * 0.20),
                        x, (int) (size.getHeight() * 0.80), 800);
                captureScreenshot();
                LogUtils.info("Pull-to-refresh performed.");
            } catch (Exception e) {
                fail("Failed to pull-to-refresh", e);
            }
        });
    }

    /**
     * Long-presses an element for 2 seconds using the W3C PointerInput API.
     *
     * @param locator Prefixed locator string.
     */
    public void longPress(String locator) {
        logger.logAction("Long press: " + locator, () -> {
            try {
                WebElement element = findElement(locator);
                PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
                Sequence longPress = new Sequence(finger, 1);
                longPress.addAction(finger.createPointerMove(
                        Duration.ZERO, PointerInput.Origin.fromElement(element), 0, 0));
                longPress.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
                longPress.addAction(new Pause(finger, Duration.ofSeconds(2)));
                longPress.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
                driver().perform(Arrays.asList(longPress));
                captureScreenshot(element);
                LogUtils.info("Long pressed: " + locator);
            } catch (Exception e) {
                fail("Failed to long press [" + locator + "]", e);
            }
        });
    }

    /**
     * Taps at the given absolute screen coordinates.
     *
     * @param x Horizontal pixel coordinate.
     * @param y Vertical pixel coordinate.
     */
    public void tapByCoordinates(int x, int y) {
        logger.logAction("Tap at coordinates: (" + x + ", " + y + ")", () -> {
            try {
                PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
                Sequence tap = new Sequence(finger, 1);
                tap.addAction(finger.createPointerMove(
                        Duration.ZERO, PointerInput.Origin.viewport(), x, y));
                tap.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
                tap.addAction(new Pause(finger, Duration.ofMillis(100)));
                tap.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
                driver().perform(Arrays.asList(tap));
                captureScreenshot();
                LogUtils.info("Tapped at (" + x + ", " + y + ").");
            } catch (Exception e) {
                fail("Failed to tap at (" + x + ", " + y + ")", e);
            }
        });
    }

    // ---------------------------------------------------------------
    // APP LIFECYCLE KEYWORDS
    // ---------------------------------------------------------------

    /**
     * Brings the app to the foreground (activates it by package/bundle ID).
     *
     * @param appId Android package name or iOS bundle ID (e.g. "com.example.app").
     */
    /**
     * Brings the app to the foreground (activates it by package/bundle ID).
     *
     * @param appId Android package name or iOS bundle ID.
     */
    public void launchApp(String appId) {
        logger.logAction("Launch app: " + appId, () -> {
            try {
                Map<String, Object> params = new HashMap<>();
                params.put("appId", appId);

                driver().executeScript("mobile: activateApp", params);

                captureScreenshot();

                LogUtils.info("App launched: " + appId);
            } catch (Exception e) {
                fail("Failed to launch app [" + appId + "]", e);
            }
        });
    }

    /**
     * Terminates (force-closes) the app by package/bundle ID.
     *
     * @param appId Android package name or iOS bundle ID.
     */
    public void closeApp(String appId) {
        logger.logAction("Close app: " + appId, () -> {
            try {
                Map<String, Object> params = new HashMap<>();
                params.put("appId", appId);

                driver().executeScript("mobile: terminateApp", params);

                captureScreenshot();

                LogUtils.info("App closed: " + appId);
            } catch (Exception e) {
                fail("Failed to close app [" + appId + "]", e);
            }
        });
    }

    /**
     * Terminates the app then reactivates it — simulates a full cold restart.
     *
     * @param appId Android package name or iOS bundle ID.
     */
    public void restartApp(String appId) {
        logger.logAction("Restart app: " + appId, () -> {
            try {
                Map<String, Object> params = new HashMap<>();
                params.put("appId", appId);

                driver().executeScript("mobile: terminateApp", params);
                driver().executeScript("mobile: activateApp", params);

                captureScreenshot();

                LogUtils.info("App restarted: " + appId);
            } catch (Exception e) {
                fail("Failed to restart app [" + appId + "]", e);
            }
        });
    }

    /**
     * Sends the app to the background for the given number of seconds, then
     * automatically brings it back to the foreground.
     *
     * @param seconds Duration to keep the app backgrounded.
     */
    public void runAppInBackground(int seconds) {
        logger.logAction("Run app in background for " + seconds + "s", () -> {
            try {
                Map<String, Object> params = new HashMap<>();
                params.put("seconds", seconds);

                driver().executeScript("mobile: backgroundApp", params);

                captureScreenshot();

                LogUtils.info("App backgrounded for " + seconds + " second(s).");
            } catch (Exception e) {
                fail("Failed to background app", e);
            }
        });
    }


    // ---------------------------------------------------------------
// SCREENSHOT HELPER
// ---------------------------------------------------------------

    /**
     * Captures screenshot for both Web and Mobile
     * and publishes path to ScreenshotContextHolder.
     */

    public void captureScreenshot() {

        if (screenshotsOff()) {
            return;
        }

        try {

            String path = "";

            // MOBILE
            if (driver() instanceof AppiumDriver) {
                path = CaptureHelpers.takeMobileScreenshot(
                        (AppiumDriver) driver(),
                        ctx.getScenarioId()
                );
                if (path == null || path.isEmpty()) {
                    // CaptureHelpers logs and returns "" on failure: still a failed screenshot
                    throw new IllegalStateException("the screenshot could not be taken (see the error above)");
                }
            }

            ScreenshotContextHolder
                    .publishLastScreenshotPath(path);

        } catch (Exception e) {

            suppressScreenshots(e);
        }
    }

    /** Like {@link #sendKeys} (focus, clear, type), then Done on Android / Enter on iOS; the keyboard stays as the app leaves it. */
    public void sendKeyswithEnter(String locator, String text) {
        logger.logAction("Type '" + shown(locator, text) + "' into: " + locator, () -> typeInto(locator, text, true));
    }


    public void scrollandVerifyText(
            String messageKey,
            String expectedValue,
            String screenName,
            String moduleName) {

        logger.logAction(
                "Verify account detail field: " + messageKey
                        + " | Expected value: " + expectedValue,
                () -> {

                    try {

                        String locator = LocatorUtils.byPath(
                                moduleName + "/"
                                        + screenName + "/"
                                        + messageKey);

                        boolean isFieldFound = false;
                        String previousPageSource = "";

                        while (true) {

                            List<WebElement> elements =
                                    driver().findElements(
                                            resolveLocator(locator));

                            if (!elements.isEmpty()) {

                                for (WebElement element : elements) {

                                    String actualValue =
                                            element.getText().trim();

                                    captureScreenshot(element);

                                    LogUtils.info(
                                            "Field: " + messageKey
                                                    + " | Expected: "
                                                    + expectedValue
                                                    + " | Actual: "
                                                    + actualValue);

                                    Assert.assertEquals(
                                            actualValue,
                                            expectedValue,
                                            "Value mismatch for field: "
                                                    + messageKey);

                                    LogUtils.info(
                                            "Successfully verified field: "
                                                    + messageKey);

                                    isFieldFound = true;
                                    break;
                                }

                                if (isFieldFound) {
                                    break;
                                }
                            }

                            String currentPageSource =
                                    driver().getPageSource();

                            if (currentPageSource.equals(previousPageSource)) {
                                break;
                            }

                            previousPageSource = currentPageSource;

                            scrollDown();
                        }

                        Assert.assertTrue(
                                isFieldFound,
                                "Unable to find account detail field: "
                                        + messageKey);

                    } catch (Exception e) {

                        fail("Failed to verify account detail field [" + messageKey + "]", e);
                    }

                    return null;
                });
    }

    public void doubleClick(String locator) {
        logger.logAction("Double-tap: " + locator, () -> {
            try {
                WebElement element = findElement(locator);

                captureScreenshot(element);

                Rectangle rect = element.getRect();

                int centerX = rect.getX() + rect.getWidth() / 2;
                int centerY = rect.getY() + rect.getHeight() / 2;

                PointerInput finger =
                        new PointerInput(PointerInput.Kind.TOUCH, "finger");

                Sequence doubleTap = new Sequence(finger, 0);

                // First tap
                doubleTap.addAction(
                        finger.createPointerMove(
                                Duration.ZERO,
                                PointerInput.Origin.viewport(),
                                centerX,
                                centerY
                        )
                );

                doubleTap.addAction(
                        finger.createPointerDown(
                                PointerInput.MouseButton.LEFT.asArg()
                        )
                );

                doubleTap.addAction(
                        finger.createPointerUp(
                                PointerInput.MouseButton.LEFT.asArg()
                        )
                );

                // Delay between taps
                doubleTap.addAction(
                        new Pause(finger, Duration.ofMillis(100))
                );

                // Second tap
                doubleTap.addAction(
                        finger.createPointerDown(
                                PointerInput.MouseButton.LEFT.asArg()
                        )
                );

                doubleTap.addAction(
                        finger.createPointerUp(
                                PointerInput.MouseButton.LEFT.asArg()
                        )
                );

                driver().perform(
                        Collections.singletonList(doubleTap)
                );

                LogUtils.info("Double-tapped: " + locator);

            } catch (Exception e) {
                fail("Failed to double-tap element [" + locator + "]", e);
            }
        });
    }

    /** The device window size per session: it does not change during a session, so it is asked for once. */
    private static final Map<String, Dimension> WINDOW_SIZES = new java.util.concurrent.ConcurrentHashMap<>();

    private Dimension windowSize() {
        WebDriver d = driver();
        String session = d instanceof org.openqa.selenium.remote.RemoteWebDriver
                ? String.valueOf(((org.openqa.selenium.remote.RemoteWebDriver) d).getSessionId()) : null;
        if (session == null) {
            return d.manage().window().getSize();
        }
        return WINDOW_SIZES.computeIfAbsent(session, s -> d.manage().window().getSize());
    }

    // Screenshot with highlighter
    public void captureScreenshot(WebElement element) {
        captureScreenshot(element, null);
    }

    /** Like {@link #captureScreenshot(WebElement)}; {@code knownRect} is where the element is (null: ask the device). */
    private void captureScreenshot(WebElement element, Rectangle knownRect) {

        if (screenshotsOff()) {
            return;
        }

        try {

            String path = "";

            // MOBILE
            if (driver() instanceof AppiumDriver) {
                Rectangle logicalRect = knownRect;
                if (logicalRect == null) {
                    try {
                        logicalRect = element.getRect();
                    } catch (org.openqa.selenium.StaleElementReferenceException | org.openqa.selenium.NoSuchElementException gone) {
                        // the element re-rendered between finding and highlighting it: a plain screenshot, not none
                        captureScreenshot();
                        return;
                    }
                }

                Dimension logicalScreenSize = windowSize();

                path = CaptureHelpers.takeMobileScreenshot(
                        (AppiumDriver) driver(),
                        ctx.getScenarioId()
                );

                BufferedImage fullImg = ImageIO.read(new File(path));

                // This handles high-density displays (Retina, 2x, 3x, 4x screens)
                double scaleFactor = (double) fullImg.getWidth() / logicalScreenSize.getWidth();

                int physicalX = (int) (logicalRect.getX() * scaleFactor);
                int physicalY = (int) (logicalRect.getY() * scaleFactor);
                int physicalWidth = (int) (logicalRect.getWidth() * scaleFactor);
                int physicalHeight = (int) (logicalRect.getHeight() * scaleFactor);

                Graphics2D g2d = fullImg.createGraphics();
                // Setup styling: Red box, 8px thick
                g2d.setColor(Color.GREEN);
                g2d.setStroke(new BasicStroke(8.0f));
                // Draw the rectangle
                g2d.drawRect(physicalX, physicalY, physicalWidth, physicalHeight);
                // Optional: Add a semi-transparent fill to make the element pop

                g2d.dispose(); // Release graphics resources

                File finalImage = new File(path);
                ImageIO.write(fullImg, "png", finalImage);
            }


            ScreenshotContextHolder
                    .publishLastScreenshotPath(path);

        } catch (Exception e) {

            suppressScreenshots(e);
        }
    }


    /**
     * True when screenshots are off for the rest of the scenario: an earlier one failed, or the session is not usable.
     * A screenshot that fails because the connection is gone would otherwise be retried after every action, each one
     * waiting for the full timeout.
     */
    private boolean screenshotsOff() {
        return ctx.isScreenshotsSuppressed() || !MobileDriverManager.isSessionUsable();
    }

    private void suppressScreenshots(Exception e) {
        if (MobileDriverManager.isSessionUsable() && (e instanceof org.openqa.selenium.StaleElementReferenceException
                || e instanceof org.openqa.selenium.NoSuchElementException)) {
            // one element changed under the screenshot: only this screenshot is lost, the next ones still work
            LogUtils.warn("Screenshot skipped (the element changed while it was captured): " + e.getMessage());
            return;
        }
        ctx.setScreenshotsSuppressed(true);
        LogUtils.warn("Screenshot failed; no more screenshots in this scenario. Reason: " + e.getMessage());
    }

    /** @deprecated Use {@link #captureScreenshot()} instead. */
    @Deprecated
    public void capturescreenshot() {
        captureScreenshot();
    }


    // ---------------------------------------------------------------
    // PRIVATE: GESTURE HELPER
    // ---------------------------------------------------------------

    /**
     * Executes a single-finger swipe using the W3C PointerInput API.
     * All public gesture methods delegate to this helper to avoid duplication.
     *
     * @param startX     Starting X pixel coordinate (viewport-relative).
     * @param startY     Starting Y pixel coordinate (viewport-relative).
     * @param endX       Ending X pixel coordinate.
     * @param endY       Ending Y pixel coordinate.
     * @param durationMs Duration of the swipe motion in milliseconds.
     */
    private void performSwipe(int startX, int startY, int endX, int endY, long durationMs) {
        PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
        Sequence swipe = new Sequence(finger, 1);
        swipe.addAction(finger.createPointerMove(
                Duration.ZERO, PointerInput.Origin.viewport(), startX, startY));
        swipe.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
        swipe.addAction(finger.createPointerMove(
                Duration.ofMillis(durationMs), PointerInput.Origin.viewport(), endX, endY));
        swipe.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
        driver().perform(Arrays.asList(swipe));
    }

    // ---------------------------------------------------------------
    // PRIVATE: NO-OP LOGGER
    // ---------------------------------------------------------------

    private static class NoOpActionLogger implements IActionLogger {
        @Override
        public <T> T logAction(String description, Supplier<T> action) {
            return action.get();
        }
    }
}