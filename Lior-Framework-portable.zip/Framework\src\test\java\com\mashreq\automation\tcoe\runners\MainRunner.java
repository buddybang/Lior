package com.mashreq.automation.tcoe.runners;



import org.testng.TestNG;


public class MainRunner {
    public static void main(String[] args) {
        // Allow system properties to be passed via -D on the java command line
        // e.g., -Dparallel=true -Dcucumber.filter.tags="@CIF and @Day1 and @SC_006"

        TestNG testng = new TestNG();
        // Run the Cucumber TestNG runner class
        testng.setTestClasses(new Class[]{
                com.mashreq.automation.tcoe.runners.TestRunner.class
        });

        // You may enable parallel from system property (your runner already reads "parallel")
        // testng.setParallel(XmlSuite.ParallelMode.METHODS); // optional if you want control here

        // thread count from -Dparallel / -Dthreads, as in testng.xml (was missing here)
        testng.addListener(new com.mashreq.automation.tcoe.listeners.ParallelExecutionListener());

        testng.setDefaultSuiteName("BDD Suite");
        testng.setDefaultTestName("Cucumber TestNG");

        // Execute
        testng.run();
    }
}
