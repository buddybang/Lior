package com.mashreq.automation.tcoe.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.LinkedHashMap;
import java.util.Map;

public class ORGenerator {

    public static void convertToJson(String sourceFile, String outputJsonFile) {

        Map<String, Object> finalJson = new LinkedHashMap<>();

        // UTF-8 on every machine (FileReader without a charset used Windows-1252 on Windows and UTF-8 on Linux)
        try (BufferedReader reader = new BufferedReader(new FileReader(sourceFile, java.nio.charset.StandardCharsets.UTF_8))) {

            // Read and skip header
            String header = reader.readLine();

            if (header == null || header.trim().isEmpty()) {
                throw new IllegalArgumentException("Source file is empty");
            }

            String line;

            while ((line = reader.readLine()) != null) {

                if (line.trim().isEmpty()) {
                    continue;
                }

                // Keep empty columns also
                String[] data = line.split(";", -1);

                if (data.length < 5) {
                    throw new IllegalArgumentException(
                            "Invalid row. Expected 5 columns but found "
                                    + data.length + ": " + line
                    );
                }

                String screenName = data[0].trim();
                String page = data[1].trim();
                String type = data[2].trim();
                String androidLocator = data[3].trim();
                String iosLocator = data[4].trim();

                if (screenName.isEmpty()) {
                    throw new IllegalArgumentException(
                            "ScreenName cannot be empty: " + line
                    );
                }

                Map<String, Object> screenData = new LinkedHashMap<>();

                // Android
                Map<String, String> android = new LinkedHashMap<>();
                android.put("locator", androidLocator);
                android.put("type", type);

                // iOS
                Map<String, String> ios = new LinkedHashMap<>();
                ios.put("locator", iosLocator);
                ios.put("type", type);

                screenData.put("android", android);
                screenData.put("ios", ios);

                finalJson.put(screenName, screenData);
            }

            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.enable(SerializationFeature.INDENT_OUTPUT);

            objectMapper.writeValue(
                    new File(outputJsonFile),
                    finalJson
            );

            System.out.println(
                    "JSON file generated successfully: " + outputJsonFile
            );

        } catch (Exception e) {
            throw new RuntimeException(
                    "Failed to convert source data to JSON", e
            );
        }
    }

    public static void main(String[] args) {

        String sourceFile =
                "src/main/resources/objectrepo/Object.txt";

        String outputFile =
                "src/main/resources/objectrepo/Mobile/locators.json";

        convertToJson(sourceFile, outputFile);
    }
}